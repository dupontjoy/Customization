// ==UserScript==
// @name         YouTube Homepage Video Filter
// @namespace    http://tampermonkey.net/
// @version      1.3.1
// @description  Filter YouTube homepage videos by upload time, watched status, view count, Shorts/Games, Members Only, and keywords
// @license      MIT
// @author       Henry Suen
// @match        https://www.youtube.com
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_registerMenuCommand
// @icon         https://www.google.com/s2/favicons?sz=64&domain=YouTube.com
// @run-at       document-idle
// @downloadURL https://update.greasyfork.org/scripts/577132/YouTube%20Homepage%20Video%20Filter.user.js
// @updateURL https://update.greasyfork.org/scripts/577132/YouTube%20Homepage%20Video%20Filter.meta.js
// ==/UserScript==

(function () {
    'use strict';

    // ===================== 多语言 =====================
    const LANG = {
        en: {
            title: '🎬 YouTube Homepage Video Filter',
            basicSection: 'BASIC',
            enableFilter: 'Enable Filter',
            filterHint: 'On first page load, the original layout will briefly appear before filtering is applied (elements must load before they can be filtered).',
            rearrangeEnabled: 'Auto rearrange grid layout',
            itemsPerRow: 'Videos per row',
            timeSection: 'UPLOAD TIME',
            maxAgeDays: 'Hide videos older than N days (0 = off)',
            viewSection: 'VIEW COUNT',
            minViews: 'Min views (hide below, 0 = off)',
            maxViews: 'Max views (hide above, 0 = off)',
            typeSection: 'CONTENT TYPE',
            hideWatched: 'Hide watched videos',
            hideShorts: 'Hide Shorts',
            hideGames: 'Hide Games content',
            hidePlaylists: 'Hide Playlists / Mixes',
            hideMembersOnly: 'Hide Members Only videos',
            hideLive: 'Hide Live streams',
            keywordSection: 'KEYWORD BLOCK',
            keywordPlaceholder: 'Keyword',
            keywordHint: 'Video titles/Channel names matching keywords will be hidden. One keyword per line',
            save: 'Save & Apply',
            cancel: 'Cancel',
            btnLabel: '🔧 Filter',
            langSwitch: '中文',
        },
        zh: {
            title: '🎬 YouTube 首页视频过滤器',
            basicSection: '基本设置',
            enableFilter: '启用过滤器',
            filterHint: '首次进入页面时，会先短暂显示原始界面，待元素加载完毕后才会应用过滤（这是无法避免的）。',
            rearrangeEnabled: '自动重新排列视频布局',
            itemsPerRow: '每行显示视频数',
            timeSection: '上传时间过滤',
            maxAgeDays: '隐藏超过 N 天前的视频（0=不过滤）',
            viewSection: '播放量过滤',
            minViews: '最低播放量（低于此值隐藏，0=不过滤）',
            maxViews: '最高播放量（高于此值隐藏，0=不过滤）',
            typeSection: '内容类型过滤',
            hideWatched: '隐藏已看过的视频',
            hideShorts: '隐藏 Shorts',
            hideGames: '隐藏 Games 游戏内容',
            hidePlaylists: '隐藏播放列表 / 合集',
            hideMembersOnly: '隐藏会员专属视频',
            hideLive: '隐藏直播',
            keywordSection: '关键字屏蔽',
            keywordPlaceholder: '关键字',
            keywordHint: '标题或频道名包含这些关键字的视频将被隐藏，每行一个',
            save: '保存并应用',
            cancel: '取消',
            btnLabel: '🔧 过滤设置',
            langSwitch: 'English',
        }
    };

    // ===================== 默认配置 =====================
    const DEFAULT_CONFIG = {
        enabled: true,
        rearrangeEnabled: true,
        itemsPerRow: 4,
        maxAgeDays: 0,
        hideWatched: false,
        minViews: 0,
        maxViews: 0,
        hideShorts: true,
        hideGames: true,
        hidePlaylists: false,
        hideMembersOnly: true,
        hideLive: false,
        keywords: [],
        lang: 'en',
    };

    let config = loadConfig();

    /**
     * 对配置值进行安全规范化
     * - 数值型：确保为非负整数且在合理范围内
     * - 关键字：过滤空白和非法字符，限制单条长度和总数
     * - 布尔型：确保为布尔值
     * - 每行视频数：限制在 1~8 之间
     */
    function sanitizeConfig(cfg) {
        // 布尔值规范化
        cfg.enabled = !!cfg.enabled;
        cfg.rearrangeEnabled = !!cfg.rearrangeEnabled;
        cfg.hideWatched = !!cfg.hideWatched;
        cfg.hideShorts = !!cfg.hideShorts;
        cfg.hideGames = !!cfg.hideGames;
        cfg.hidePlaylists = !!cfg.hidePlaylists;
        cfg.hideMembersOnly = !!cfg.hideMembersOnly;
        cfg.hideLive = !!cfg.hideLive;

        // itemsPerRow: 整数，范围 1~10
        cfg.itemsPerRow = Math.max(1, Math.min(10, Math.floor(Number(cfg.itemsPerRow) || 4)));

        // maxAgeDays: 非负整数，上限 36500（~100年）
        cfg.maxAgeDays = Math.max(0, Math.min(36500, Math.floor(Number(cfg.maxAgeDays) || 0)));

        // minViews / maxViews: 非负整数，上限 10亿
        cfg.minViews = Math.max(0, Math.min(1e9, Math.floor(Number(cfg.minViews) || 0)));
        cfg.maxViews = Math.max(0, Math.min(1e9, Math.floor(Number(cfg.maxViews) || 0)));

        // keywords: 数组，过滤空白/非法项，每条最多200字符，最多500条
        if (!Array.isArray(cfg.keywords)) cfg.keywords = [];
        cfg.keywords = cfg.keywords
            .map(k => (typeof k === 'string' ? k : String(k)).trim())
            .filter(k => k.length > 0 && k.length <= 200)
            .slice(0, 500);

        // lang: 只允许 'en' 或 'zh'
        if (cfg.lang !== 'en' && cfg.lang !== 'zh') cfg.lang = 'en';

        return cfg;
    }

    function loadConfig() {
        const saved = GM_getValue('ytFilterConfig', null);
        if (saved) {
            try {
                const parsed = JSON.parse(saved);
                return sanitizeConfig({ ...DEFAULT_CONFIG, ...parsed });
            } catch (e) {
                // JSON 解析失败，使用默认配置
                return { ...DEFAULT_CONFIG };
            }
        }
        return { ...DEFAULT_CONFIG };
    }

    function saveConfig() {
        config = sanitizeConfig(config);
        GM_setValue('ytFilterConfig', JSON.stringify(config));
    }

    function t(key) {
        return LANG[config.lang][key] || LANG.en[key] || key;
    }

    // ===================== 解析工具函数 =====================

    /**
     * 解析上传时间文本为天数
     * 支持: "3 years ago", "2 months ago", "5 days ago", "3年前", "2个月前"
     */
    function parseUploadTime(timeText) {
        if (!timeText) return null;
        const text = timeText.toLowerCase().trim();

        // English: "6 years ago", "3 months ago", "2 weeks ago", "5 days ago"
        let match = text.match(/(\d+)\s*(second|minute|hour|day|week|month|year)s?\s*(ago)?/);
        if (match) {
            const num = parseInt(match[1]);
            const unit = match[2];
            switch (unit) {
                case 'second': case 'minute': case 'hour': return 0;
                case 'day': return num;
                case 'week': return num * 7;
                case 'month': return num * 30;
                case 'year': return num * 365;
            }
        }

        // Chinese: "6年前", "3个月前", "2周前", "5天前"
        match = text.match(/(\d+)\s*(秒|分钟|小时|天|周|个月|月|年)/);
        if (match) {
            const num = parseInt(match[1]);
            const unit = match[2];
            switch (unit) {
                case '秒': case '分钟': case '小时': return 0;
                case '天': return num;
                case '周': return num * 7;
                case '个月': case '月': return num * 30;
                case '年': return num * 365;
            }
        }

        return null;
    }

    /**
     * 解析播放量文本为数字
     * 支持: "239K views", "1.2M views", "1,234 views", "120万次观看"
     */
    function parseViewCount(viewText) {
        if (!viewText) return null;
        const text = viewText.toLowerCase().trim();

        if (text.includes('no views') || text === '0 views') return 0;

        // English: "1.2M views", "345K views", "1,234 views"
        let match = text.match(/([\d,.]+)\s*([kmb])?\s*views?/);
        if (match) {
            let num = parseFloat(match[1].replace(/,/g, ''));
            const suffix = match[2];
            if (suffix === 'k') num *= 1000;
            else if (suffix === 'm') num *= 1000000;
            else if (suffix === 'b') num *= 1000000000;
            return Math.round(num);
        }

        // Chinese: "120万次观看", "3.4万次观看", "1234次观看"
        match = text.match(/([\d,.]+)\s*(亿|万)?\s*次/);
        if (match) {
            let num = parseFloat(match[1].replace(/,/g, ''));
            const suffix = match[2];
            if (suffix === '万') num *= 10000;
            else if (suffix === '亿') num *= 100000000;
            return Math.round(num);
        }

        // Fallback: just numbers
        match = text.match(/([\d,]+)/);
        if (match) {
            return parseInt(match[1].replace(/,/g, ''));
        }

        return null;
    }

    // ===================== 过滤逻辑 =====================

    function shouldHideVideo(videoElement) {
        if (!config.enabled) return false;

        // === 获取视频链接 ===
        // 新版: yt-lockup-view-model 内的 a 链接
        // 旧版: #video-title
        const lockupLink = videoElement.querySelector('a.ytLockupViewModelContentImage, a[href*="/watch"], a[href*="/shorts/"]');
        const titleLink = videoElement.querySelector('a.ytLockupMetadataViewModelTitle, #video-title, #video-title-link, a#video-title');
        const href = lockupLink?.href || titleLink?.href || '';

        // === 获取标题 ===
        let title = '';
        if (titleLink) {
            // 新版: 标题在子span中（排除隐藏的cbCustomTitle）
            const titleSpan = titleLink.querySelector('span[role="text"]:not(.cbCustomTitle)');
            title = titleSpan ? titleSpan.textContent.trim() : titleLink.textContent.trim();
        }

        // === Members Only 检测 ===
        if (config.hideMembersOnly) {
            // 新版: yt-lockup-view-model 有 ytb-members-only 属性
            const lockupModel = videoElement.querySelector('yt-lockup-view-model[ytb-members-only]');
            if (lockupModel) return true;
            // 检测 badge 中的 "Members only" 文字
            const badges = videoElement.querySelectorAll('badge-shape .ytBadgeShapeText');
            for (const badge of badges) {
                if (/members\s*only|会员专属|會員專屬/i.test(badge.textContent.trim())) {
                    return true;
                }
            }
        }

        // === 直播检测 ===
        if (config.hideLive) {
            // 缩略图上的 LIVE badge
            const liveBadge = videoElement.querySelector('badge-shape.ytBadgeShapeThumbnailLive, .ytBadgeShapeThumbnailLive');
            if (liveBadge) return true;
            // 头像上的 live ring
            const liveRing = videoElement.querySelector('.ytSpecAvatarShapeLiveRing, .ytSpecAvatarShapeLiveBadge');
            if (liveRing) return true;
            // 元数据中的 "watching" 文字（直播特有）
            const metaSpansLive = videoElement.querySelectorAll('span.ytContentMetadataViewModelMetadataText');
            for (const span of metaSpansLive) {
                if (/watching|在线观看|正在观看/i.test(span.textContent.trim())) {
                    return true;
                }
            }
        }

        // === Shorts 检测 ===
        if (config.hideShorts) {
            if (href.includes('/shorts/')) return true;
        }

        // === Games 检测 ===
        if (config.hideGames) {
            // 检测Gaming相关badge或标记
            const badges = videoElement.querySelectorAll('[aria-label*="Gaming"], [aria-label*="游戏"]');
            if (badges.length > 0) return true;
            // 检查shelf标题
            const shelf = videoElement.closest('ytd-rich-shelf-renderer');
            if (shelf) {
                const shelfTitle = shelf.querySelector('#title, #title-text, .title');
                if (shelfTitle && /(game|gaming|游戏)/i.test(shelfTitle.textContent)) return true;
            }
        }

        // === 关键字检测 ===
        if (config.keywords.length > 0) {
            // 新版: 频道名在 ytContentMetadataViewModelMetadataRow 的第一个row中
            let channelName = '';
            const metadataRows = videoElement.querySelectorAll('.ytContentMetadataViewModelMetadataRow');
            if (metadataRows.length > 0) {
                // 第一行通常是频道名
                const channelLink = metadataRows[0].querySelector('a');
                channelName = channelLink ? channelLink.textContent.trim() : metadataRows[0].textContent.trim();
            }
            // 旧版回退
            if (!channelName) {
                const channelEl = videoElement.querySelector('#channel-name a, ytd-channel-name a');
                channelName = channelEl ? channelEl.textContent.trim() : '';
            }

            const combinedText = (title + ' ' + channelName).toLowerCase();
            for (const keyword of config.keywords) {
                if (keyword && combinedText.includes(keyword.toLowerCase())) {
                    return true;
                }
            }
        }

        // === 获取播放量和时间 ===
        let viewText = '';
        let timeText = '';

        // 新版结构: div.ytContentMetadataViewModelMetadataRow 内的 span.ytContentMetadataViewModelMetadataText
        const metaSpans = videoElement.querySelectorAll('span.ytContentMetadataViewModelMetadataText');
        metaSpans.forEach(span => {
            const txt = span.textContent.trim();
            if (!viewText && /views?|次观看|次播放/i.test(txt)) {
                viewText = txt;
            } else if (!timeText && /ago|前|streamed|\d+\s*(second|minute|hour|day|week|month|year)s?|\d+\s*(秒|分钟|小时|天|周|个月|月|年)/i.test(txt)) {
                timeText = txt;
            }
        });

        // 旧版回退: #metadata-line > span.inline-metadata-item
        if (!viewText || !timeText) {
            const metadataLine = videoElement.querySelector('#metadata-line');
            if (metadataLine) {
                const metaItems = metadataLine.querySelectorAll('span.inline-metadata-item, span');
                metaItems.forEach(item => {
                    const txt = item.textContent.trim();
                    if (!viewText && /views?|次观看|次播放/i.test(txt)) {
                        viewText = txt;
                    } else if (!timeText && /ago|前|streamed/i.test(txt)) {
                        timeText = txt;
                    }
                });
            }
        }

        // 从aria-label提取（最后兜底）
        if (!viewText || !timeText) {
            const ariaLabel = titleLink?.getAttribute('aria-label') || '';
            if (ariaLabel) {
                if (!viewText) {
                    const viewMatch = ariaLabel.match(/([\d,.]+\s*[KkMmBb]?\s*views?|[\d,.]+\s*[万亿]?\s*次)/i);
                    if (viewMatch) viewText = viewMatch[0];
                }
                if (!timeText) {
                    const timeMatch = ariaLabel.match(/(\d+\s*(?:second|minute|hour|day|week|month|year)s?\s*ago|\d+\s*(?:秒|分钟|小时|天|周|个月|月|年)前?)/i);
                    if (timeMatch) timeText = timeMatch[0];
                }
            }
        }

        // === 上传时间过滤 ===
        if (config.maxAgeDays > 0) {
            const days = parseUploadTime(timeText);
            if (days !== null && days > config.maxAgeDays) {
                return true;
            }
        }

        // === 播放量过滤 ===
        const views = parseViewCount(viewText);
        if (config.minViews > 0 && views !== null && views < config.minViews) {
            return true;
        }
        if (config.maxViews > 0 && views !== null && views > config.maxViews) {
            return true;
        }

        // === 已看过过滤 ===
        if (config.hideWatched) {
            // 新版: 红色进度条在缩略图底部
            const progressBar = videoElement.querySelector(
                '#progress, ' +
                'ytd-thumbnail-overlay-resume-playback-renderer, ' +
                '.ytThumbnailOverlayProgressBarHost, ' +
                '[class*="ProgressBar"], ' +
                'yt-thumbnail-overlay-progress-bar-view-model'
            );
            if (progressBar) return true;
            // 旧版
            const overlays = videoElement.querySelectorAll('ytd-thumbnail-overlay-playback-status-renderer');
            if (overlays.length > 0) return true;
        }

        return false;
    }

    // ===================== DOM操作 =====================

    // 注入/更新CSS样式
    function injectStyles() {
        let cssText = '';

        if (config.rearrangeEnabled) {
            // 重排模式：flex-wrap 布局 + CSS隐藏，可见视频自动填满每行
            const cols = config.itemsPerRow || 4;
            const gap = 16; // YouTube默认列间距(px)
            cssText = `
                ytd-rich-grid-renderer #contents.ytd-rich-grid-renderer {
                    display: flex !important;
                    flex-wrap: wrap !important;
                    gap: ${gap}px !important;
                    --ytd-rich-grid-items-per-row: ${cols} !important;
                }
                ytd-rich-grid-renderer #contents.ytd-rich-grid-renderer > ytd-rich-item-renderer {
                    flex: 0 0 calc((100% - ${gap * (cols - 1)}px) / ${cols}) !important;
                    max-width: calc((100% - ${gap * (cols - 1)}px) / ${cols}) !important;
                    box-sizing: border-box !important;
                    margin: 0 !important;
                }
                ytd-rich-grid-renderer #contents.ytd-rich-grid-renderer > ytd-rich-section-renderer,
                ytd-rich-grid-renderer #contents.ytd-rich-grid-renderer > ytd-rich-shelf-renderer {
                    flex: 0 0 100% !important;
                    max-width: 100% !important;
                }
                [data-ytf-hidden="1"] {
                    display: none !important;
                }
            `;
        } else {
            // 非重排模式：仅隐藏，保留原始grid位置（可能有空位）
            cssText = `
                [data-ytf-hidden="1"] {
                    display: none !important;
                }
            `;
        }

        let style = document.getElementById('ytf-injected-styles');
        if (!style) {
            style = document.createElement('style');
            style.id = 'ytf-injected-styles';
            document.head.appendChild(style);
        }
        style.textContent = cssText;
    }

    function filterVideos(fullRefresh = false) {
        if (!config.enabled) {
            pauseObserver();
            restoreAllHidden();
            resumeObserver();
            return;
        }

        // 注入/更新样式
        injectStyles();

        // 暂停 observer 避免循环触发
        pauseObserver();

        // 配置变化时全量重新判定
        if (fullRefresh) {
            restoreAllHidden();
        }

        // 隐藏Shorts货架
        if (config.hideShorts) {
            document.querySelectorAll('ytd-rich-shelf-renderer[is-shorts]').forEach(shelf => {
                // 如果 shelf 在 section 内，隐藏外层 section；否则隐藏 shelf 本身
                const section = shelf.closest('ytd-rich-section-renderer');
                hideElement(section || shelf);
            });
            document.querySelectorAll('ytd-rich-shelf-renderer:not([is-shorts]), ytd-reel-shelf-renderer').forEach(shelf => {
                const titleEl = shelf.querySelector('#title, #title-text, .title');
                if (titleEl && /^shorts$/i.test(titleEl.textContent.trim())) {
                    const section = shelf.closest('ytd-rich-section-renderer');
                    hideElement(section || shelf);
                }
            });
        }

        // 隐藏Games货架
        if (config.hideGames) {
            document.querySelectorAll('ytd-rich-shelf-renderer').forEach(shelf => {
                const titleEl = shelf.querySelector('#title, #title-text, .title');
                if (titleEl && /(game|gaming|游戏)/i.test(titleEl.textContent)) {
                    const section = shelf.closest('ytd-rich-section-renderer');
                    hideElement(section || shelf);
                }
            });
        }

        // 移除空的 section 元素（被广告拦截等清空的占位容器）
        document.querySelectorAll('ytd-rich-grid-renderer #contents > ytd-rich-section-renderer').forEach(section => {
            const content = section.querySelector('#content');
            if (!content || content.children.length === 0) {
                hideElement(section);
            }
        });

        // 过滤普通视频卡片（高性能批量处理）
        rearrangeGridItems();

        // 恢复 observer
        resumeObserver();
    }

    /**
     * 隐藏非视频类元素（货架等）
     * 统一通过 data-ytf-hidden="1" + CSS display:none 实现隐藏
     */
    function hideElement(el) {
        if (el.dataset.ytfHidden === '1') return;
        el.dataset.ytfHidden = '1';
    }

    /**
     * 高性能批量过滤视频卡片
     *
     * 统一使用 data-ytf-hidden 属性 + CSS display:none 隐藏
     * 重排模式下 CSS flex-wrap 会让可见视频自动填满每行
     * 不操作 DOM 结构（不 removeChild），因此：
     *   - YouTube 重建 DOM 时不会冲突
     *   - 无闪烁
     */
    function rearrangeGridItems() {
        const contentsEl = document.querySelector('ytd-rich-grid-renderer #contents');
        if (!contentsEl) return;

        const allItems = contentsEl.querySelectorAll(':scope > ytd-rich-item-renderer');
        if (allItems.length === 0) return;

        // 批量判定：先收集所有结果再统一修改属性
        const results = new Array(allItems.length);
        for (let i = 0; i < allItems.length; i++) {
            const item = allItems[i];
            // 广告元素或被广告拦截清空的元素直接隐藏
            if (item.querySelector('ytd-ad-slot-renderer')) {
                results[i] = true;
            // 播放列表/合集
            } else if (config.hidePlaylists && item.querySelector('yt-lockup-view-model[ytb-content-type="playlist"]')) {
                results[i] = true;
            } else {
                results[i] = shouldHideVideo(item);
            }
        }

        // 批量设置/清除属性
        let visibleCount = 0;
        for (let i = 0; i < allItems.length; i++) {
            const item = allItems[i];
            if (results[i]) {
                if (item.dataset.ytfHidden !== '1') {
                    item.dataset.ytfHidden = '1';
                }
            } else {
                if (item.dataset.ytfHidden === '1') {
                    delete item.dataset.ytfHidden;
                }
                visibleCount++;
            }
        }

        // 预设模式下插入空白占位，防止 YouTube 因空白区域触发无限加载
        manageSpacer(contentsEl, visibleCount);

        // 如果有预设激活且过滤后没有可见视频，提示用户并重置回用户规则
        if (visibleCount === 0 && allItems.length > 0 && (activeTimePresetId || activeViewPresetId)) {
            const msg = config.lang === 'zh'
                ? '当前预设条件下没有匹配的视频，已恢复为您的自定义过滤规则。'
                : 'No videos match the current preset filters. Restored to your custom filter settings.';

            // 重置预设
            activeTimePresetId = null;
            activeViewPresetId = null;
            Object.assign(config, userSavedConfig);
            updatePresetButtonStyles();

            // 恢复显示
            for (let i = 0; i < allItems.length; i++) {
                delete allItems[i].dataset.ytfHidden;
            }

            // 显示提示（简短 toast）
            showToast(msg);

            // 用用户规则重新过滤一次
            setTimeout(() => filterVideos(true), 100);
        }
    }

    /**
     * 显示临时提示信息（Toast）
     */
    function showToast(message) {
        let toast = document.getElementById('ytf-toast');
        if (toast) toast.remove();

        toast = document.createElement('div');
        toast.id = 'ytf-toast';
        toast.textContent = message;
        Object.assign(toast.style, {
            position: 'fixed',
            top: '120px',
            left: '50%',
            transform: 'translateX(-50%)',
            background: 'rgba(139, 28, 28, 0.95)',
            color: '#fff',
            padding: '12px 24px',
            borderRadius: '8px',
            fontSize: '14px',
            zIndex: '999999',
            boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
            transition: 'opacity 0.3s',
            maxWidth: '80vw',
            textAlign: 'center',
        });
        document.body.appendChild(toast);
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    }

    /**
     * 管理空白占位元素（Spacer）
     * 预设模式下在视频列表末尾插入占位，填满视口高度，
     * 阻止 YouTube 的 IntersectionObserver 检测到底部从而无限加载。
     * 非预设模式或重置时移除 spacer。
     */
    function manageSpacer(contentsEl, visibleCount) {
        const spacerId = 'ytf-spacer';
        let spacer = document.getElementById(spacerId);
        const hasActivePreset = !!(activeTimePresetId || activeViewPresetId);

        if (hasActivePreset && visibleCount > 0) {
            // 需要 spacer
            if (!spacer) {
                spacer = document.createElement('div');
                spacer.id = spacerId;
                Object.assign(spacer.style, {
                    width: '100%',
                    minHeight: '200vh',
                    flexBasis: '100%',
                    pointerEvents: 'none',
                });
            }
            // 确保 spacer 在末尾
            if (contentsEl && spacer.parentElement !== contentsEl) {
                contentsEl.appendChild(spacer);
            } else if (contentsEl && spacer.nextSibling) {
                // 如果 spacer 不在最后（有新元素被追加），重新移到末尾
                contentsEl.appendChild(spacer);
            }
        } else {
            // 不需要 spacer，移除
            if (spacer) spacer.remove();
        }
    }

    function restoreAllHidden() {
        // 清除所有隐藏标记，CSS 会立即让元素重新可见
        document.querySelectorAll('[data-ytf-hidden="1"]').forEach(item => {
            delete item.dataset.ytfHidden;
        });
        // 移除 spacer
        const spacer = document.getElementById('ytf-spacer');
        if (spacer) spacer.remove();
    }

    // ===================== 设置面板 UI =====================

    function createSettingsPanel() {
        if (document.getElementById('yt-filter-overlay')) return;

        const overlay = document.createElement('div');
        overlay.id = 'yt-filter-overlay';
        Object.assign(overlay.style, {
            position: 'fixed',
            top: '0', left: '0', right: '0', bottom: '0',
            background: 'rgba(0,0,0,0.6)',
            zIndex: '99999',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontFamily: "'Segoe UI', Roboto, Arial, sans-serif",
        });

        const panel = document.createElement('div');
        panel.id = 'yt-filter-panel';
        Object.assign(panel.style, {
            background: '#1e1e1e',
            color: '#e0e0e0',
            borderRadius: '12px',
            padding: '28px 32px',
            width: '480px',
            maxHeight: '80vh',
            overflowY: 'auto',
            boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
        });

        // 标题栏
        const header = document.createElement('div');
        Object.assign(header.style, {
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '20px',
            borderBottom: '1px solid #333',
            paddingBottom: '12px',
        });

        const titleEl = document.createElement('h2');
        titleEl.textContent = t('title');
        Object.assign(titleEl.style, { margin: '0', fontSize: '20px', color: '#fff' });

        const langBtn = document.createElement('button');
        langBtn.textContent = t('langSwitch');
        Object.assign(langBtn.style, {
            padding: '4px 12px',
            background: '#333',
            color: '#e0e0e0',
            border: '1px solid #555',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '12px',
        });
        langBtn.addEventListener('click', () => {
            config.lang = config.lang === 'en' ? 'zh' : 'en';
            saveConfig();
            overlay.remove();
            createSettingsPanel();
        });

        header.appendChild(titleEl);
        header.appendChild(langBtn);
        panel.appendChild(header);

        // 辅助函数
        function createSection(titleText) {
            const section = document.createElement('div');
            Object.assign(section.style, {
                marginBottom: '18px', paddingBottom: '14px', borderBottom: '1px solid #2a2a2a',
            });
            const sTitle = document.createElement('div');
            sTitle.textContent = titleText;
            Object.assign(sTitle.style, {
                fontSize: '13px', color: '#aaa', marginBottom: '10px',
                textTransform: 'uppercase', letterSpacing: '0.5px',
            });
            section.appendChild(sTitle);
            return section;
        }

        function createCheckboxRow(labelText, checked) {
            const row = document.createElement('div');
            Object.assign(row.style, { display: 'flex', alignItems: 'center', marginBottom: '8px', gap: '10px' });
            const label = document.createElement('label');
            label.textContent = labelText;
            Object.assign(label.style, { flex: '1', fontSize: '13px' });
            const input = document.createElement('input');
            input.type = 'checkbox';
            input.checked = checked;
            Object.assign(input.style, { width: '16px', height: '16px', cursor: 'pointer' });
            row.appendChild(label);
            row.appendChild(input);
            return { row, input };
        }

        function createNumberRow(labelText, value) {
            const row = document.createElement('div');
            Object.assign(row.style, { display: 'flex', alignItems: 'center', marginBottom: '14px', gap: '12px' });
            const label = document.createElement('label');
            label.textContent = labelText;
            Object.assign(label.style, { flex: '1', fontSize: '14px' });
            const input = document.createElement('input');
            input.type = 'number';
            input.min = '0';
            input.value = value;
            Object.assign(input.style, {
                width: '100px', padding: '6px 10px', border: '1px solid #444',
                borderRadius: '6px', background: '#2a2a2a', color: '#fff', fontSize: '14px',
            });
            row.appendChild(label);
            row.appendChild(input);
            return { row, input };
        }

        // 构建表单
        const basicSection = createSection(t('basicSection'));
        const enabledRow = createCheckboxRow(t('enableFilter'), config.enabled);
        basicSection.appendChild(enabledRow.row);

        // 首次加载提示
        const filterHint = document.createElement('small');
        filterHint.textContent = t('filterHint');
        Object.assign(filterHint.style, {
            color: '#888', fontSize: '12px', display: 'block', marginBottom: '12px', lineHeight: '1.4',
        });
        basicSection.appendChild(filterHint);

        panel.appendChild(basicSection);

        // 布局重排区域
        const layoutSection = createSection(t('rearrangeEnabled'));
        const rearrangeRow = createCheckboxRow(t('rearrangeEnabled'), config.rearrangeEnabled);
        layoutSection.appendChild(rearrangeRow.row);

        const itemsPerRowRow = createNumberRow(t('itemsPerRow'), config.itemsPerRow);
        itemsPerRowRow.input.min = '1';
        itemsPerRowRow.input.max = '8';
        itemsPerRowRow.input.disabled = !config.rearrangeEnabled;
        if (!config.rearrangeEnabled) {
            itemsPerRowRow.input.style.opacity = '0.5';
        }
        layoutSection.appendChild(itemsPerRowRow.row);

        // 动态启用/禁用 itemsPerRow
        rearrangeRow.input.addEventListener('change', () => {
            itemsPerRowRow.input.disabled = !rearrangeRow.input.checked;
            itemsPerRowRow.input.style.opacity = rearrangeRow.input.checked ? '1' : '0.5';
        });

        panel.appendChild(layoutSection);

        const timeSection = createSection(t('timeSection'));
        const maxAgeRow = createNumberRow(t('maxAgeDays'), config.maxAgeDays);
        maxAgeRow.input.max = '36500';
        timeSection.appendChild(maxAgeRow.row);
        panel.appendChild(timeSection);

        const viewSection = createSection(t('viewSection'));
        const minViewsRow = createNumberRow(t('minViews'), config.minViews);
        const maxViewsRow = createNumberRow(t('maxViews'), config.maxViews);
        minViewsRow.input.max = '1000000000';
        maxViewsRow.input.max = '1000000000';
        viewSection.appendChild(minViewsRow.row);
        viewSection.appendChild(maxViewsRow.row);
        panel.appendChild(viewSection);

        const typeSection = createSection(t('typeSection'));
        const watchedRow = createCheckboxRow(t('hideWatched'), config.hideWatched);
        const shortsRow = createCheckboxRow(t('hideShorts'), config.hideShorts);
        const gamesRow = createCheckboxRow(t('hideGames'), config.hideGames);
        const playlistsRow = createCheckboxRow(t('hidePlaylists'), config.hidePlaylists);
        const membersOnlyRow = createCheckboxRow(t('hideMembersOnly'), config.hideMembersOnly);
        const liveRow = createCheckboxRow(t('hideLive'), config.hideLive);
        typeSection.appendChild(watchedRow.row);
        typeSection.appendChild(shortsRow.row);
        typeSection.appendChild(gamesRow.row);
        typeSection.appendChild(playlistsRow.row);
        typeSection.appendChild(membersOnlyRow.row);
        typeSection.appendChild(liveRow.row);
        panel.appendChild(typeSection);

        const keywordSection = createSection(t('keywordSection'));
        const textarea = document.createElement('textarea');
        textarea.placeholder = t('keywordPlaceholder');
        textarea.value = config.keywords.join('\n');
        textarea.maxLength = 10000; // 限制总输入字符数
        Object.assign(textarea.style, {
            width: '100%', minHeight: '80px', padding: '10px', border: '1px solid #444',
            borderRadius: '6px', background: '#2a2a2a', color: '#fff', fontSize: '13px',
            resize: 'vertical', boxSizing: 'border-box',
        });
        const hint = document.createElement('small');
        hint.textContent = t('keywordHint');
        Object.assign(hint.style, { color: '#888', fontSize: '12px' });
        keywordSection.appendChild(textarea);
        keywordSection.appendChild(hint);
        panel.appendChild(keywordSection);

        // 按钮
        const btnContainer = document.createElement('div');
        Object.assign(btnContainer.style, { display: 'flex', gap: '12px', marginTop: '20px', justifyContent: 'flex-end' });

        const cancelBtn = document.createElement('button');
        cancelBtn.textContent = t('cancel');
        Object.assign(cancelBtn.style, {
            padding: '8px 20px', background: '#333', color: '#e0e0e0',
            border: 'none', borderRadius: '6px', fontSize: '14px', cursor: 'pointer',
        });

        const saveBtn = document.createElement('button');
        saveBtn.textContent = t('save');
        Object.assign(saveBtn.style, {
            padding: '8px 20px', background: '#3ea6ff', color: '#000',
            border: 'none', borderRadius: '6px', fontSize: '14px', fontWeight: '600', cursor: 'pointer',
        });

        btnContainer.appendChild(cancelBtn);
        btnContainer.appendChild(saveBtn);
        panel.appendChild(btnContainer);

        overlay.appendChild(panel);
        document.body.appendChild(overlay);

        // 事件
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) overlay.remove();
        });
        cancelBtn.addEventListener('click', () => overlay.remove());
        saveBtn.addEventListener('click', () => {
            config.enabled = enabledRow.input.checked;
            config.rearrangeEnabled = rearrangeRow.input.checked;
            config.itemsPerRow = parseInt(itemsPerRowRow.input.value) || 4;
            config.maxAgeDays = parseInt(maxAgeRow.input.value) || 0;
            config.minViews = parseInt(minViewsRow.input.value) || 0;
            config.maxViews = parseInt(maxViewsRow.input.value) || 0;
            config.hideWatched = watchedRow.input.checked;
            config.hideShorts = shortsRow.input.checked;
            config.hideGames = gamesRow.input.checked;
            config.hidePlaylists = playlistsRow.input.checked;
            config.hideMembersOnly = membersOnlyRow.input.checked;
            config.hideLive = liveRow.input.checked;
            config.keywords = textarea.value.split('\n').map(k => k.trim()).filter(k => k.length > 0);
            saveConfig();
            // 更新用户配置快照，清除预设激活状态
            snapshotUserConfig();
            activeTimePresetId = null;
            activeViewPresetId = null;
            updatePresetButtonStyles();
            overlay.remove();
            filterVideos(true);
        });
    }

    // ===================== 过滤按钮（YouTube Logo 右侧） =====================

    function addFilterButton() {
        if (document.getElementById('ytf-toggle-btn')) return;

        const btn = document.createElement('button');
        btn.id = 'ytf-toggle-btn';
        btn.textContent = t('btnLabel');
        Object.assign(btn.style, {
            marginLeft: '12px',
            padding: '6px 14px',
            background: 'transparent',
            color: 'inherit',
            border: '1px solid var(--yt-spec-10-percent-layer, #ccc)',
            borderRadius: '18px',
            fontSize: '13px',
            fontWeight: '500',
            cursor: 'pointer',
            transition: 'background 0.2s',
            whiteSpace: 'nowrap',
            verticalAlign: 'middle',
        });
        btn.addEventListener('mouseenter', () => {
            btn.style.background = 'var(--yt-spec-10-percent-layer, rgba(255,255,255,0.1))';
        });
        btn.addEventListener('mouseleave', () => {
            btn.style.background = 'transparent';
        });
        btn.addEventListener('click', createSettingsPanel);

        // 插入到YouTube Logo右侧（#start 容器内）
        function insertBtn() {
            const startContainer = document.querySelector('ytd-masthead #start');
            if (startContainer) {
                startContainer.appendChild(btn);
                return true;
            }
            return false;
        }

        if (!insertBtn()) {
            const retryInterval = setInterval(() => {
                if (insertBtn()) clearInterval(retryInterval);
            }, 500);
            setTimeout(() => {
                clearInterval(retryInterval);
                if (!btn.parentElement) {
                    // 兜底: fixed定位在左上角
                    Object.assign(btn.style, {
                        position: 'fixed', top: '14px', left: '170px',
                        zIndex: '99998', marginLeft: '0',
                    });
                    document.body.appendChild(btn);
                }
            }, 10000);
        }
    }

    // ===================== 预设按钮 =====================

    // 预设分两组：时间组（互斥）和播放量组（互斥），两组之间可组合
    const TIME_PRESETS = {
        en: [
            { id: 'latest', label: '⚡ Latest', title: 'Videos from last 24 hours', maxAgeDays: 1 },
            { id: 'week', label: '📅 This Week', title: 'Videos from last 7 days', maxAgeDays: 7 },
            { id: 'month', label: '📆 This Month', title: 'Videos from last 30 days', maxAgeDays: 30 },
        ],
        zh: [
            { id: 'latest', label: '⚡ 最新', title: '仅显示24小时内的视频', maxAgeDays: 1 },
            { id: 'week', label: '📅 本周', title: '仅显示7天内的视频', maxAgeDays: 7 },
            { id: 'month', label: '📆 本月', title: '仅显示30天内的视频', maxAgeDays: 30 },
        ]
    };

    const VIEW_PRESETS = {
        en: [
            { id: 'goat1m', label: '🏆 1M+', title: '1M+ views', minViews: 1000000 },
            { id: 'goat5m', label: '💎 5M+', title: '5M+ views', minViews: 5000000 },
            { id: 'goat10m', label: '👑 10M+', title: '10M+ views', minViews: 10000000 },
        ],
        zh: [
            { id: 'goat1m', label: '🏆 百万+', title: '播放量100万以上', minViews: 1000000 },
            { id: 'goat5m', label: '💎 500万+', title: '播放量500万以上', minViews: 5000000 },
            { id: 'goat10m', label: '👑 千万+', title: '播放量1000万以上', minViews: 10000000 },
        ]
    };

    const RESET_PRESET = {
        en: { id: 'reset', label: '🔄 Reset', title: 'Restore to your saved filter settings' },
        zh: { id: 'reset', label: '🔄 重置', title: '恢复为你保存的过滤设置' },
    };

    // 当前激活的时间预设 id 和播放量预设 id（各自组内互斥）
    let activeTimePresetId = null;
    let activeViewPresetId = null;

    // 保存用户配置的副本，用于预设重置时恢复
    let userSavedConfig = null;

    function snapshotUserConfig() {
        userSavedConfig = {
            maxAgeDays: config.maxAgeDays,
            minViews: config.minViews,
            maxViews: config.maxViews,
        };
    }

    // 初始化时保存一份用户配置快照
    snapshotUserConfig();

    function getTimePresets() {
        return TIME_PRESETS[config.lang] || TIME_PRESETS.en;
    }
    function getViewPresets() {
        return VIEW_PRESETS[config.lang] || VIEW_PRESETS.en;
    }
    function getResetPreset() {
        return RESET_PRESET[config.lang] || RESET_PRESET.en;
    }

    function applyPresets() {
        // 根据当前激活的预设组合计算 config
        // 时间：如果有激活的时间预设，使用其 maxAgeDays；否则恢复用户配置
        if (activeTimePresetId) {
            const tp = getTimePresets().find(p => p.id === activeTimePresetId);
            config.maxAgeDays = tp ? tp.maxAgeDays : userSavedConfig.maxAgeDays;
        } else {
            config.maxAgeDays = userSavedConfig.maxAgeDays;
        }
        // 播放量：如果有激活的播放量预设，使用其 minViews；否则恢复用户配置
        if (activeViewPresetId) {
            const vp = getViewPresets().find(p => p.id === activeViewPresetId);
            config.minViews = vp ? vp.minViews : userSavedConfig.minViews;
            config.maxViews = 0; // 预设不限制最高播放量
        } else {
            config.minViews = userSavedConfig.minViews;
            config.maxViews = userSavedConfig.maxViews;
        }
        config.enabled = true;
        updatePresetButtonStyles();
        filterVideos(true);
    }

    function handlePresetClick(preset) {
        const timeIds = getTimePresets().map(p => p.id);
        const viewIds = getViewPresets().map(p => p.id);

        if (preset.id === 'reset') {
            // 重置：清除所有预设，恢复用户配置
            activeTimePresetId = null;
            activeViewPresetId = null;
        } else if (timeIds.includes(preset.id)) {
            // 时间组：切换（再次点击取消）
            activeTimePresetId = (activeTimePresetId === preset.id) ? null : preset.id;
        } else if (viewIds.includes(preset.id)) {
            // 播放量组：切换（再次点击取消）
            activeViewPresetId = (activeViewPresetId === preset.id) ? null : preset.id;
        }
        applyPresets();
    }

    function updatePresetButtonStyles() {
        const allPresets = [...getTimePresets(), ...getViewPresets(), getResetPreset()];
        allPresets.forEach(preset => {
            const btnEl = document.getElementById(`ytf-preset-${preset.id}`);
            if (btnEl) {
                const isActive = (preset.id === activeTimePresetId || preset.id === activeViewPresetId);
                btnEl.className = isActive ? 'ytf-chip ytf-chip-active' : 'ytf-chip ytf-chip-inactive';
            }
        });
    }

    function addPresetButtons() {
        // 注入预设按钮专用 CSS（无论按钮是否已存在）
        let presetStyle = document.getElementById('ytf-preset-styles');
        if (!presetStyle) {
            presetStyle = document.createElement('style');
            presetStyle.id = 'ytf-preset-styles';
            presetStyle.textContent = `
                #ytf-presets-bar {
                    display: inline-flex;
                    align-items: center;
                    gap: 8px;
                    margin-right: 12px;
                    padding-left: 12px;
                    border-right: 1px solid rgba(255,255,255,0.2);
                    padding-right: 12px;
                }
                html:not([dark]) #ytf-presets-bar {
                    border-right-color: rgba(0,0,0,0.1);
                }
                #ytf-presets-bar .ytf-separator {
                    width: 1px;
                    height: 20px;
                    margin: 0 4px;
                    background: rgba(255,255,255,0.2);
                }
                html:not([dark]) #ytf-presets-bar .ytf-separator {
                    background: rgba(0,0,0,0.1);
                }
                #ytf-presets-bar .ytf-chip {
                    padding: 6px 12px;
                    border-radius: 8px;
                    font-size: 14px;
                    font-weight: 500;
                    line-height: 20px;
                    cursor: pointer;
                    white-space: nowrap;
                    border: none;
                    font-family: "Roboto", "Arial", sans-serif;
                    transition: background 0.2s, color 0.2s;
                }
                /* 浅色模式 */
                html:not([dark]) #ytf-presets-bar .ytf-chip-inactive {
                    background: rgba(0, 0, 0, 0.05);
                    color: #0f0f0f;
                }
                html:not([dark]) #ytf-presets-bar .ytf-chip-inactive:hover {
                    background: rgba(0, 0, 0, 0.1);
                }
                html:not([dark]) #ytf-presets-bar .ytf-chip-active {
                    background: #0f0f0f;
                    color: #fff;
                }
                /* 深色模式 */
                html[dark] #ytf-presets-bar .ytf-chip-inactive {
                    background: rgba(255, 255, 255, 0.1);
                    color: #f1f1f1;
                }
                html[dark] #ytf-presets-bar .ytf-chip-inactive:hover {
                    background: rgba(255, 255, 255, 0.2);
                }
                html[dark] #ytf-presets-bar .ytf-chip-active {
                    background: #f1f1f1;
                    color: #0f0f0f;
                }
                /* Filter 按钮深浅色适配 */
                html:not([dark]) #ytf-toggle-btn {
                    color: #0f0f0f !important;
                    border-color: rgba(0, 0, 0, 0.1) !important;
                }
                html[dark] #ytf-toggle-btn {
                    color: #f1f1f1 !important;
                    border-color: rgba(255, 255, 255, 0.2) !important;
                }
            `;
            document.head.appendChild(presetStyle);
        }

        if (document.getElementById('ytf-presets-bar')) return;

        const bar = document.createElement('div');
        bar.id = 'ytf-presets-bar';

        function createChip(preset) {
            const chip = document.createElement('button');
            chip.id = `ytf-preset-${preset.id}`;
            chip.className = 'ytf-chip ytf-chip-inactive';
            chip.textContent = preset.label;
            chip.title = preset.title;
            chip.addEventListener('click', () => handlePresetClick(preset));
            return chip;
        }

        // 时间组
        getTimePresets().forEach(p => bar.appendChild(createChip(p)));

        // 分隔符
        const sep = document.createElement('span');
        sep.className = 'ytf-separator';
        bar.appendChild(sep);

        // 播放量组
        getViewPresets().forEach(p => bar.appendChild(createChip(p)));

        // 分隔符
        const sep2 = document.createElement('span');
        sep2.className = 'ytf-separator';
        bar.appendChild(sep2);

        // 重置按钮
        bar.appendChild(createChip(getResetPreset()));

        // 插入到 iron-selector#chips 的最前面（和原生 tab 在同一行）
        function insertBar() {
            const chipsContainer = document.querySelector('iron-selector#chips');
            if (chipsContainer) {
                chipsContainer.insertBefore(bar, chipsContainer.firstChild);
                return true;
            }
            return false;
        }

        if (!insertBar()) {
            const retryInterval = setInterval(() => {
                if (insertBar()) clearInterval(retryInterval);
            }, 500);
            setTimeout(() => clearInterval(retryInterval), 10000);
        }
    }

    // ===================== 观察器与初始化 =====================

    let mainObserver = null;
    let observerTarget = null;
    let observerTimer = null;
    let observerPaused = false;

    function pauseObserver() {
        observerPaused = true;
        if (mainObserver) mainObserver.disconnect();
    }

    function resumeObserver() {
        observerPaused = false;
        if (mainObserver && observerTarget) {
            mainObserver.observe(observerTarget, { childList: true, subtree: true });
        }
    }

    function setupObserver() {
        mainObserver = new MutationObserver((mutations) => {
            if (observerPaused) return;
            // 只在有新的 renderer 节点加入时触发过滤
            let hasNewItems = false;
            for (const mutation of mutations) {
                for (const node of mutation.addedNodes) {
                    if (node.nodeType === 1 && (
                        node.tagName === 'YTD-RICH-ITEM-RENDERER' ||
                        node.tagName === 'YTD-RICH-SHELF-RENDERER' ||
                        node.tagName === 'YTD-REEL-SHELF-RENDERER' ||
                        (node.querySelector && node.querySelector('ytd-rich-item-renderer'))
                    )) {
                        hasNewItems = true;
                        break;
                    }
                }
                if (hasNewItems) break;
            }
            if (hasNewItems) {
                if (observerTimer) clearTimeout(observerTimer);
                observerTimer = setTimeout(() => filterVideos(), 150);
            }
        });

        // 优先监听更精确的容器
        observerTarget = document.querySelector('ytd-rich-grid-renderer') ||
                         document.querySelector('ytd-app') ||
                         document.querySelector('#content') ||
                         document.body;
        if (observerTarget) {
            mainObserver.observe(observerTarget, { childList: true, subtree: true });
        }
    }

    // 注册油猴菜单
    GM_registerMenuCommand('⚙️ YouTube Filter Settings', createSettingsPanel);

    // 初始化
    function init() {
        addFilterButton();
        addPresetButtons();
        filterVideos();
        setupObserver();

        // chips 容器可能延迟加载，额外重试确保预设按钮能插入
        let presetRetry = 0;
        const presetRetryInterval = setInterval(() => {
            presetRetry++;
            if (document.getElementById('ytf-presets-bar') || presetRetry > 20) {
                clearInterval(presetRetryInterval);
                return;
            }
            addPresetButtons();
        }, 1000);
    }

    if (document.readyState === 'complete') {
        init();
    } else {
        window.addEventListener('load', () => setTimeout(init, 1000));
    }

    // YouTube SPA URL 变化监听
    let lastUrl = location.href;
    const urlObserver = new MutationObserver(() => {
        if (location.href !== lastUrl) {
            lastUrl = location.href;
            if (location.pathname === '/' || location.pathname === '') {
                setTimeout(() => {
                    filterVideos(true);
                    addFilterButton();
                    addPresetButtons();
                }, 1500);
            } else {
                const btn = document.getElementById('ytf-toggle-btn');
                if (btn) btn.style.display = 'none';
                const presetsBar = document.getElementById('ytf-presets-bar');
                if (presetsBar) presetsBar.style.display = 'none';
            }
        }
    });
    urlObserver.observe(document.body, { childList: true, subtree: true });

})();
