// ==UserScript==
// @name         更好的 X（BetterX）
// @name:zh-CN   更好的 X（BetterX）
// @name:zh-TW   更好的 X（BetterX）
// @name:ja      もっと便利な X（BetterX）
// @name:en      Better X (BetterX)
// @namespace    https://github.com/Iskongkongyo
// @version      4.1.0
// @description  BetterX 是一款 X（原 Twitter）增强脚本，支持本地帖子记录、搜索、收藏与备注，并集成广告和黄推过滤、媒体下载、帖子截图下载、帖子通知管理及界面优化等功能。
// @description:zh-CN BetterX 是一款 X（原 Twitter）增强脚本，支持本地帖子记录、搜索、收藏与备注，并集成广告和黄推过滤、媒体下载、帖子截图下载、帖子通知管理及界面优化等功能。
// @description:zh-TW BetterX 是一款 X（原 Twitter）增強腳本，支援本機貼文記錄、搜尋、收藏與備註，並整合廣告與成人引流內容過濾、媒體下載、貼文截圖下載、貼文通知管理及介面最佳化等功能。
// @description:ja BetterX は、X（旧 Twitter）向けの機能拡張ユーザースクリプトです。ポストのローカル記録・検索・お気に入り・メモに加え、広告や成人向けスパムの非表示、メディア保存、ポストのスクリーンショット保存、ポスト通知の管理、UI の改善などに対応します。
// @description:en BetterX is a userscript for X (formerly Twitter) with local post history, search, favorites, and notes, plus ad and adult spam filtering, media downloads, post screenshot downloads, post notification management, interface improvements, and more.
// @author        流萤可爱捏
// @match        https://x.com/*
// @match        https://m.x.com/*
// @match        https://twitter.com/*
// @grant        GM_addStyle
// @grant        GM_getValue
// @grant        GM_registerMenuCommand
// @grant        GM_xmlhttpRequest
// @grant        GM_info
// @grant        GM_setValue
// @grant        unsafeWindow
// @connect      twimg.com
// @connect      video.twimg.com
// @connect      pbs.twimg.com
// @connect      x.com
// @run-at       document-start
// @icon      data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAUEBAQEAwUEBAQGBQUGCA0ICAcHCBALDAkNExAUExIQEhIUFx0ZFBYcFhISGiMaHB4fISEhFBkkJyQgJh0gISD/2wBDAQUGBggHCA8ICA8gFRIVICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICD/wAARCABAAEADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD7LoorC17XpdLsoorO08/Vr2UwWdrI20OwyS7EZ2xqo3MfTjqQCAX9S1fStHgWfVdQt7KNjtUzSBdx9BnqfYVgD4ieGJYXmspL6+jXPz29hMyHHX59oXj61mG3t9BZtSvdQhudZmQm41e+IRYYx12gnEUYJwsYIyTyScmuF1j41/CzTrlllvbjxBeodrz2dkGDEHjLHarYPTrUOXYtRuenQ+PtDktheT2mrWVn/FdXemzRRJ/vMVwB/tH5feuohmgubeO4t5UmhlUOkkbBldTyCCOCK+etO/aJ8Fi+QTz61DbuwV2vbVWMWf4g8bHgdwR06Hse/m0268PsfEXgm8ijspF+0XGlM2bK6Ujd5kWAfJYg53J8pzkqeTQpdwcGj0qivO/EHiGDVvAyPoWoXenanqF7Fbp5ZxPayo4eVWHI+VEcnqrDHUMM9R4T1efXPCtnqF2ipd/PDcKn3fNjdo3I9iykj2IpxlfR7kdbGrdZFuX81YlT5mZm2gADnJ7Vw2m202veIZPFl67m0aFLbTLZgV/cg7mnYesjbSF7KiE8nA2fGMsMlpYaTczCK0v5yLticD7PHG0sgJ9GCBT7Map+GNWOtaPDrRJ23rCeND0jjIBQD/gJBPuTWbilJy7lI8Pux4h+I/xk8UW9tZXF54f0snT4pNwSCGSMEM29gRu37idoZsccA1s6P+zF4YhzP4k8SXt47fN5FoRCi+24hnb65FdVqcgfwDD4S01o7KbVY5IHmB2+UjfNcS9ufn27s8tIK6bw1rA1PQ7MSlY7xLdfNizyCv7tjj0Dqw/D3pJq5r7OUVzrr+hxx+Afwmkglgj0y886FtjMuoTbuRkHk46H0rq/B+ixeFNOfwnbXVxc2NgFksmumDyJC+f3ZIAyFYMBx0IHauV8TeObLwf43W51DWre30ya2aO4tpZFVjIkgO6PP3nCyAlP4l6cgZ67TNX0/WdRs9X0q/ttQsrmxcJcWzhkcB0I+h5PB5FHNccoSSTezOTks00L4x20ETNCup6e6Wbuu6GNhKisSOnmBdsa56rsHatrwrpEenfEVrXT7+9u47G0uDePcTmQI80quiYB2qxIkcjAIyM8EV57+0fYrd+BEvjIyHTpobpXB+4C/lP+B3oceqCvTfgto1/oXwd0Oy1XTn06/ZHmmgcgsC7swJH8OQQdpyV6HkVcaf8Ay8v8jCW5e+Imj32qaLbGwtJLtxKbaaKPG7yJ1MMrDJH3Q+76Ke9ct4T1qytrW30aS6jjKy/Y7cn5BK8a4ULns8aLIv8AeBOOldt4u1VILMaUk/kvdITNLnHkw5wx/wB5s7VHXJJHSvJZ9PtfFvju7i1GB9P0vSjBaqSdm5kHmnevbG9QAeVAP3SxwTLp2vZmB4q+EzeLPHt5fa9rM80NtcAWliGWOGKzcBwcn1k81Sf7yr6iuq8H/Ca70jSVl0XWpLG6tLyU27SsZYjFJ5ZYdc4wuCo+VioyMjdVbxBqNx4e1221GTXHutL0kG4VbqXbuQ5Ur54UyFTgfKdwbjPQVb0L9oDwxrqywx6NqtjcWitNLHNPbxgRqDucl3GVUDJGMjg4pRlePJb/ADOyVRtXT/y+4i8U/CS11PWdU1HX7s3rXkKn7T5bokeAoJVF3BSFjUEk85B4AxWP8NdL8JeF/Ez2Xhm68ybV7WELBDKJFjSJN09yeflWWQBVHfG4DBrauPjM17r1z4Ss9DFjfwIv73U7hbkPuXdgCElWbac7S447cGsvRtJ1CDXrrV5L0W9rfGO2nvLe3WKcJ3VXHyxqX2/dXIAGCDkknJuKj0QlUUVru/PfsZPxi8QR+INH8S+E9NjW4uIYo4mIcEMIy1xcAAdCixqPdmAr1X4D60dd+CehXEupS6hcW6vazSSjlWRiNoPdQNuD3GK5n+xLDQvFurfY9Lt7MX9nby294i8wNCQux8/8sw4jYn1kO7Ocj2LRbtL/AEW3vIkESSrkRBdvlHoUPuCCK0g/dscc2m9DhviWLzSbjTPEGnT26XUk8dnGbgZWJzvxLg8NtRpDj1C++eDj13R4IfsNpqNv5aFjJLLcKXlcklmJJ5JYks3ck177eWNjqNv9n1Czgu4chvLnjDrkdDg8VAuiaKqhV0iyVVGABbpgD06UNJ7ka9D5V8Y3UvjO7sPCfh64glm1F0haRmBjESnkv2wzkAA+nqQDXh8K6H4e8U/bPEl1Yz6qs8Xk6MGWNLaJG/fToHbc23aRlsAh2+UYBH0vq3w98K6zqAvrnTzFKYfs8gtpDCs0W7dscLjIzk+tXF8FeD1WJV8MaWBEwdf9FTO4DGSccnHrUSppxaQ1Od9dvI+fvEtl4R1jVTpehPb6TqccUmoQ3Ej+VmdOPMKDGSudhGNxD4A+bNaNp410m50WGKLUEtLaVY/Ps7q4jys2cSDr0BOPwr3G88G+FL8H7R4esN5xiWOFY5Fx0w64Yfga0rfS9NtLSG0trGCOCBBHGgQYVQMAflUUqMacVHe39dROUm9WfPN1qkuopeWcet2t1bxSv9jfzVEkS/ZvMaMuD+8iJUxuDyBKgyeK9w8EK58EaZdSAK17H9tKBshPNJkC574DAZ74rTutF0a9CC80myudgIXzYEfbnrjI4q8qqiBEUKqjAAGABWyVg1P/2Q==
// @noframes
// @license      MIT
// @downloadURL https://update.greasyfork.org/scripts/588748/%E6%9B%B4%E5%A5%BD%E7%9A%84%20X%EF%BC%88BetterX%EF%BC%89.user.js
// @updateURL https://update.greasyfork.org/scripts/588748/%E6%9B%B4%E5%A5%BD%E7%9A%84%20X%EF%BC%88BetterX%EF%BC%89.meta.js
// ==/UserScript==
(function () {
'use strict';
const APP_ICON_URL = (() => {
  try {
    const icon = typeof GM_info !== 'undefined' && GM_info.script
      ? (GM_info.script.icon64 || GM_info.script.icon || '')
      : '';
    return /^(?:data:image\/|https?:\/\/)/i.test(icon) ? icon : '';
  } catch (err) {
    return '';
  }
})();
const UI_LANGUAGE_OVERRIDE_KEY = 'betterx_ui_language_v1';
const SUPPORTED_UI_LANGUAGES = new Set(['zh-CN', 'zh-TW', 'ja', 'en']);
const UI_TEXT_ENTRIES = [ ['更好的 X', '更好的 X', 'もっと便利な X', 'Better X'], ['Alt+X 开关', 'Alt+X 開關', 'Alt+X で開閉', 'Toggle with Alt+X'], ['刷新', '重新整理', '更新', 'Refresh'], ['全部已读', '全部已讀', 'すべて既読', 'Mark all read'], ['重新扫描当前页面', '重新掃描目前頁面', '現在のページを再スキャン', 'Rescan the current page'], ['把当前列表全部标为已读', '將目前列表全部標為已讀', '現在の一覧をすべて既読にする', 'Mark the current list as read'], ['切换语言', '切換語言', '言語を切替', 'Switch language'], ['切换 BetterX 界面语言', '切換 BetterX 介面語言', 'BetterX の表示言語を切り替える', 'Switch BetterX interface language'], ['选择界面语言', '選擇介面語言', '表示言語を選択', 'Choose interface language'], ['选择后页面会刷新，帖子与设置数据不会受到影响。', '選擇後頁面會重新整理，貼文與設定資料不受影響。', '選択後にページを更新します。ポストや設定データには影響しません。', 'The page will reload after selection. Your posts and settings will not be affected.'], ['正在切换语言并刷新…', '正在切換語言並重新整理…', '言語を切り替えて更新中…', 'Switching language and reloading…'], ['无法保存语言设置', '無法儲存語言設定', '言語設定を保存できませんでした', 'Could not save the language setting'], ['更多', '更多', 'その他', 'More'], ['关闭', '關閉', '閉じる', 'Close'], ['帖子', '貼文', 'ポスト', 'Posts'], ['通知', '通知', '通知', 'Notifications'], ['设置', '設定', '設定', 'Settings'], ['导出筛选', '匯出篩選結果', '絞り込み結果をエクスポート', 'Export filtered'], ['备份全部', '備份全部', 'すべてバックアップ', 'Back up all'], ['导出备份', '匯出備份', 'バックアップをエクスポート', 'Export backup'], ['导入', '匯入', 'インポート', 'Import'], ['备份已分卷', '備份已分卷', 'バックアップを分割しました', 'Backup split into parts'], ['数据较大，请保存全部分卷；恢复时可同时选择这些 JSON 文件。', '資料較大，請儲存全部分卷；還原時可同時選取這些 JSON 檔案。', 'データ量が多いため、すべての分割ファイルを保存してください。復元時にこれらの JSON ファイルをまとめて選択できます。', 'Save every part. You can select these JSON files together when restoring.'], ['下载分卷', '下載分卷', '分割ファイルを保存', 'Download part'], ['完成', '完成', '完了', 'Done'], ['无法导出：单条记录或设置超过备份容量限制。', '無法匯出：單筆記錄或設定超過備份容量限制。', '1 件の記録または設定がバックアップ容量の上限を超えています。', 'Cannot export: a record or the settings exceed the backup size limit.'], ['此前已导入的分卷会保留，可重新选择文件继续恢复。', '先前已匯入的分卷會保留，可重新選取檔案繼續還原。', '読み込み済みの分割ファイルは保持されます。ファイルを選択し直して復元を続けられます。', 'Previously imported parts are kept. Select files again to continue restoring.'], ['清空', '清空', '消去', 'Clear'], ['快速筛选', '快速篩選', 'クイックフィルター', 'Quick filters'], ['搜索', '搜尋', '検索', 'Search'], ['搜索帖子', '搜尋貼文', 'ポストを検索', 'Search posts'], ['搜索作者、正文或备注…', '搜尋作者、內文或備註…', '投稿者・本文・メモを検索…', 'Search author, text, or notes…'], ['来源筛选', '來源篩選', 'ソースで絞り込む', 'Filter by source'], ['媒体筛选', '媒體篩選', 'メディアで絞り込む', 'Filter by media'], ['排序方式', '排序方式', '並べ替え', 'Sort order'], ['智能排序', '智慧排序', 'スマート順', 'Smart sort'], ['最近浏览', '最近瀏覽', '最近表示', 'Recently viewed'], ['最近抓取', '最近擷取', '最近取得', 'Recently captured'], ['首次抓取（新→旧）', '首次擷取（新→舊）', '初回取得（新→古）', 'First captured (new→old)'], ['首次抓取（旧→新）', '首次擷取（舊→新）', '初回取得（古→新）', 'First captured (old→new)'], ['出现次数', '出現次數', '表示回数', 'Appearances'], ['按作者', '依作者', '投稿者順', 'By author'], ['按来源', '依來源', 'ソース順', 'By source'], ['全部', '全部', 'すべて', 'All'], ['未打开', '未開啟', '未表示', 'Unopened'], ['已打开', '已開啟', '表示済み', 'Opened'], ['快速消失', '快速消失', 'すぐ消えた', 'Disappeared quickly'], ['已收藏', '已收藏', 'お気に入り済み', 'Favorited'], ['已置顶', '已置頂', '固定済み', 'Pinned'], ['命中关键词', '符合關鍵字', 'キーワード一致', 'Keyword matches'], ['全部媒体', '全部媒體', 'すべてのメディア', 'All media'], ['含图片', '含圖片', '画像あり', 'With images'], ['含视频', '含影片', '動画あり', 'With video'], ['纯文字', '純文字', 'テキストのみ', 'Text only'], ['全部来源', '全部來源', 'すべてのソース', 'All sources'], ['主页', '首頁', 'ホーム', 'Home'], ['正在关注', '正在關注', 'フォロー中', 'Following'], ['为你推荐', '為你推薦', 'おすすめ', 'For You'], ['列表', '列表', 'リスト', 'List'], ['书签', '書籤', 'ブックマーク', 'Bookmarks'], ['喜欢', '喜歡', 'いいね', 'Likes'], ['未知页面', '未知頁面', '不明なページ', 'Unknown page'], ['个人主页', '個人主頁', 'プロフィール', 'Profile'], ['帖子详情', '貼文詳情', 'ポスト詳細', 'Post details'], ['搜索页', '搜尋頁', '検索ページ', 'Search page'], ['书签页', '書籤頁', 'ブックマークページ', 'Bookmarks page'], ['喜欢页', '喜歡頁', 'いいねページ', 'Likes page'], ['列表页', '列表頁', 'リストページ', 'List page'], ['总数', '總數', '合計', 'Total'], ['未读', '未讀', '未読', 'Unread'], ['图片', '圖片', '画像', 'Image'], ['视频', '影片', '動画', 'Video'], ['来源:', '來源：', 'ソース：', 'Source:'], ['历史来源:', '歷史來源：', '過去のソース：', 'Source history:'], ['抓取:', '擷取：', '取得：', 'Captured:'], ['浏览:', '瀏覽：', '表示：', 'Viewed:'], ['出现:', '出現：', '表示：', 'Seen:'], ['当前来源:', '目前來源：', '現在のソース：', 'Current source:'], ['当前选择：', '目前選擇：', '現在の選択：', 'Current:'], ['打开', '開啟', '開く', 'Open'], ['复制链接', '複製連結', 'リンクをコピー', 'Copy link'], [' 的个人主页', ' 的個人主頁', ' のプロフィール', ' profile'], ['复制链接：', '複製連結：', 'リンクをコピー：', 'Copy link: '], ['已复制', '已複製', 'コピー済み', 'Copied'], ['取消置顶', '取消置頂', '固定解除', 'Unpin'], ['置顶', '置頂', '固定', 'Pin'], ['取消收藏', '取消收藏', 'お気に入り解除', 'Unfavorite'], ['收藏', '收藏', 'お気に入り', 'Favorite'], ['删', '刪除', '削除', 'Delete'], ['展开全文', '展開全文', '全文を表示', 'Show full text'], ['收起', '收合', '折りたたむ', 'Collapse'], ['备注', '備註', 'メモ', 'Note'], ['保存备注', '儲存備註', 'メモを保存', 'Save note'], ['取消', '取消', 'キャンセル', 'Cancel'], ['在这里写备注…', '在這裡寫備註…', 'ここにメモを入力…', 'Write a note here…'], ['无正文', '無內文', '本文なし', 'No text'], ['加载更多', '載入更多', 'さらに読み込む', 'Load more'], ['帖子通知管理', '貼文通知管理', 'ポスト通知の管理', 'Post notification management'], ['搜索用户名或 @用户名…', '搜尋使用者名稱或 @使用者名稱…', 'ユーザー名または @ユーザー名を検索…', 'Search name or @username…'], ['搜索帖子通知用户', '搜尋貼文通知使用者', '通知ユーザーを検索', 'Search notification users'], ['同步订阅用户', '同步訂閱使用者', '購読ユーザーを同期', 'Sync subscribed users'], ['正在同步…', '正在同步…', '同期中…', 'Syncing…'], ['尚未读取订阅用户', '尚未讀取訂閱使用者', '購読ユーザー未取得', 'Subscribed users not loaded'], ['正在读取关注列表…', '正在讀取關注列表…', 'フォロー一覧を取得中…', 'Reading following list…'], ['已订阅', '已訂閱', '購読中', 'Subscribed'], ['本地保留', '本機保留', 'ローカル保存', 'Stored locally'], ['筛选到', '篩選到', '絞り込み', 'Filtered'], ['上次同步：', '上次同步：', '最終同期：', 'Last sync: '], ['尚未完整同步', '尚未完整同步', '完全同期前', 'Not fully synced'], ['已同步', '已同步', '同期済み', 'Synced'], ['处理中…', '處理中…', '処理中…', 'Processing…'], ['关闭通知', '關閉通知', '通知をオフ', 'Disable notifications'], ['重新开启', '重新開啟', '再度オン', 'Re-enable'], ['移除记录', '移除記錄', '記録を削除', 'Remove record'], ['设置', '設定', '設定', 'Settings'], ['大多数设置会立即生效；带“保存”或“应用”按钮的设置需要手动确认。', '大多數設定會立即生效；帶「儲存」或「套用」按鈕的設定需要手動確認。', 'ほとんどの設定はすぐ反映されます。「保存」または「適用」ボタンがある設定は手動で確定してください。', 'Most settings apply immediately. Settings with a Save or Apply button require confirmation.'], ['关键词与排除词', '關鍵字與排除詞', 'キーワードと除外語', 'Keywords and exclusions'], ['任意匹配', '任意符合', 'いずれか一致', 'Match any'], ['全部匹配', '全部符合', 'すべて一致', 'Match all'], ['保存', '儲存', '保存', 'Save'], ['输入关键词，支持正则，按回车添加', '輸入關鍵字，支援正則，按 Enter 新增', 'キーワードを入力（正規表現対応）、Enter で追加', 'Enter keywords (regex supported), press Enter to add'], ['输入排除词，支持正则，按回车添加', '輸入排除詞，支援正則，按 Enter 新增', '除外語を入力（正規表現対応）、Enter で追加', 'Enter exclusions (regex supported), press Enter to add'], ['内容净化', '內容淨化', 'コンテンツフィルター', 'Content filtering'], ['隐藏黄推 / 成人引流机器人', '隱藏成人內容／引流機器人', '成人スパムを非表示', 'Hide adult spam accounts'], ['检测强度', '偵測強度', '検出強度', 'Detection strength'], ['均衡', '均衡', '標準', 'Balanced'], ['保守', '保守', '控えめ', 'Conservative'], ['不审查已关注账号（转发内容除外）', '不審查已關注帳號（轉發內容除外）', 'フォロー中のアカウントを除外（リポストは対象）', 'Skip followed accounts (except reposts)'], ['不审查已关注账号的转发内容', '不審查已關注帳號的轉發內容', 'フォロー中アカウントのリポストも除外', 'Also skip reposts by followed accounts'], ['启用自定义规则（屏蔽词与账号白名单）', '啟用自訂規則（封鎖詞與帳號白名單）', 'カスタムルールを有効化（ブロック語・許可リスト）', 'Enable custom rules (blocked words and allowlist)'], ['输入自定义屏蔽词，按回车添加', '輸入自訂封鎖詞，按 Enter 新增', 'ブロック語を入力し Enter で追加', 'Enter a blocked word and press Enter'], ['输入账号白名单（如 @example），按回车添加', '輸入帳號白名單（如 @example），按 Enter 新增', '許可するアカウント（例 @example）を入力し Enter', 'Enter an allowed account (e.g. @example) and press Enter'], ['当前隐藏', '目前隱藏', '現在非表示', 'Currently hidden'], ['本次累计', '本次累計', '今回の累計', 'This session'], ['已扫描', '已掃描', 'スキャン済み', 'Scanned'], ['已识别关注', '已識別關注', '認識済みフォロー', 'Known following'], ['界面简化与宽屏', '介面簡化與寬螢幕', 'UI 簡素化とワイド表示', 'Simplified and wide layout'], ['启用界面简化与宽屏', '啟用介面簡化與寬螢幕', 'UI 簡素化とワイド表示を有効化', 'Enable simplified and wide layout'], ['时间线宽度(px)', '時間軸寬度(px)', 'タイムライン幅 (px)', 'Timeline width (px)'], ['左侧栏宽度(px)', '左側欄寬度(px)', '左サイドバー幅 (px)', 'Left sidebar width (px)'], ['应用宽度', '套用寬度', '幅を適用', 'Apply widths'], ['隐藏左侧栏', '隱藏左側欄', '左サイドバーを非表示', 'Hide left sidebar'], ['隐藏右侧栏', '隱藏右側欄', '右サイドバーを非表示', 'Hide right sidebar'], ['中间栏填满（启用时同时隐藏左右栏）', '中間欄填滿（啟用時同時隱藏左右欄）', '中央列を全幅表示（左右列も非表示）', 'Fill center column (also hides sidebars)'], ['精简导航、Premium 推广与页脚', '精簡導覽、Premium 推廣與頁尾', 'ナビ・Premium 広告・フッターを簡素化', 'Clean navigation, Premium promos, and footer'], ['隐藏右下消息栏 / Grok', '隱藏右下訊息欄 / Grok', '右下のメッセージ欄 / Grok を非表示', 'Hide Messages bar / Grok'], ['下载功能', '下載功能', 'ダウンロード', 'Downloads'], ['一键下载图片 / 视频 / GIF', '一鍵下載圖片 / 影片 / GIF', '画像 / 動画 / GIF をワンクリック保存', 'One-click image / video / GIF downloads'], ['保存帖子截图', '儲存貼文截圖', 'ポストのスクリーンショットを保存', 'Save post screenshot'], ['正在生成帖子截图…', '正在產生貼文截圖…', 'ポストの画像を生成中…', 'Generating post screenshot…'], ['正在生成另一张截图，请稍候', '正在產生另一張截圖，請稍候', '別の画像を生成中です。お待ちください', 'Another screenshot is being generated. Please wait.'], ['帖子截图已保存', '貼文截圖已儲存', 'ポストの画像を保存しました', 'Post screenshot saved'], ['帖子截图失败，请重试', '貼文截圖失敗，請重試', 'ポストの画像を保存できませんでした。再試行してください', 'Post screenshot failed. Please try again.'], ['无法生成完整截图', '無法產生完整截圖', '完全な画像を生成できません', 'Unable to capture the complete post'], ['部分图片未能读取或渲染失败。请重试；仍有问题时可导出诊断信息。', '部分圖片無法讀取或渲染失敗。請重試；若仍有問題，可匯出診斷資訊。', '一部の画像を読み込めないか、描画に失敗しました。再試行し、解決しない場合は診断情報を保存してください。', 'Some images could not be read, or rendering failed. Try again; if the problem persists, export the diagnostic report.'], ['导出截图诊断', '匯出截圖診斷', 'スクリーンショットの診断情報を保存', 'Export screenshot diagnostics'], ['下载时保持静默', '下載時保持靜默', 'ダウンロード中は通知を控える', 'Keep downloads quiet'], ['点击下载全部，长按或 Shift+点击选择下载', '點擊下載全部，長按或 Shift+點擊選擇下載', 'クリックで全件保存、長押しまたは Shift+クリックで選択保存', 'Click to download all; hold or Shift+click to select media'], ['选择要下载的媒体', '選擇要下載的媒體', '保存するメディアを選択', 'Select media to download'], ['全选', '全選', 'すべて選択', 'Select all'], ['全不选', '全不選', 'すべて解除', 'Deselect all'], ['下载所选', '下載所選', '選択したメディアを保存', 'Download selected'], ['已选', '已選', '選択済み', 'Selected'], ['无预览', '無預覽', 'プレビューなし', 'No preview'], ['选择中', '選擇中', '選択中', 'Selecting'], ['正在选择下载内容', '正在選擇下載內容', '保存するメディアを選択中', 'Selecting media to download'], ['无法开始下载，请重试', '無法開始下載，請重試', 'ダウンロードを開始できません。再試行してください', 'Unable to start the download. Please try again.'], ['默认关闭；开启后隐藏应用徽标旁的下载任务提示和任务列表，帖子内的下载进度与取消按钮仍可使用。', '預設關閉；開啟後隱藏應用徽章旁的下載工作提示和工作清單，貼文內的下載進度與取消按鈕仍可使用。', '初期設定はオフです。有効にするとアプリバッジ横のダウンロード表示とタスク一覧を隠します。ポスト内の進捗表示とキャンセルボタンは引き続き使えます。', 'Off by default. Hides the download indicator and task list beside the app badge. Download progress and cancel buttons in posts remain available.'], ['GIF内容下载格式', 'GIF 內容下載格式', 'GIF コンテンツの保存形式', 'GIF content download format'], ['默认开启；关闭时 GIF 内容按原始 MP4 下载。选择 GIF 时会在浏览器内转换，耗时更长、文件更大。', '預設開啟；關閉時 GIF 內容會以原始 MP4 下載。選擇 GIF 時會在瀏覽器內轉換，耗時更長、檔案更大。', '既定で有効です。オフにすると GIF コンテンツは元の MP4 形式で保存されます。GIF を選ぶとブラウザー内で変換するため、時間がかかりファイルも大きくなります。', 'Enabled by default. When off, GIF content is saved as the original MP4. Selecting GIF converts it in the browser, which takes longer and produces larger files.'], ['自定义下载文件/压缩包名', '自訂下載檔案／壓縮檔名稱', 'ダウンロードファイル／ZIP 名をカスタマイズ', 'Customize downloaded file / ZIP names'], ['已自定义', '已自訂', 'カスタマイズ済み', 'Customized'], ['下载多个媒体自动压缩 ZIP 包', '下載多個媒體時自動壓縮 ZIP', '複数メディアを ZIP にまとめる', 'Package multiple media files as ZIP'], ['记录已经下载过的帖子', '記錄已下載過的貼文', 'ダウンロード済みポストを記録', 'Track downloaded posts'], ['媒体文件名（不含扩展名）', '媒體檔名（不含副檔名）', 'メディア名（拡張子なし）', 'Media filename (without extension)'], ['ZIP 压缩包名（不含 .zip）', 'ZIP 壓縮檔名（不含 .zip）', 'ZIP 名（.zip なし）', 'ZIP filename (without .zip)'], ['正则替换（可选）', '正則取代（選填）', '正規表現置換（任意）', 'Regex replacement (optional)'], ['替换为', '取代為', '置換後', 'Replace with'], ['例如：', '例如：', '例：', 'Example: '], ['；支持 $1', '；支援 $1', '（$1 に対応）', '; supports $1'], ['保存自定义命名设置', '儲存自訂命名設定', '命名設定を保存', 'Save naming settings'], ['常用功能', '常用功能', '一般機能', 'Common features'], ['关闭广告（含“订阅 Premium”）', '關閉廣告（含「訂閱 Premium」）', '広告を非表示（Premium を含む）', 'Hide ads (including Subscribe to Premium)'], ['关闭NFL', '關閉 NFL', 'NFL を非表示', 'Hide NFL'], ['帖子内媒体改为网格视图', '貼文內媒體改為網格檢視', 'ポスト内メディアをグリッド表示', 'Show post media in a grid'], ['取消年龄限制（用原图 / 视频进行替换）', '解除年齡限制（以原圖 / 影片取代）', '年齢制限を解除（元画像 / 動画に置換）', 'Bypass age gate (replace with original media)'], ['自动展开帖子里“显示更多”', '自動展開貼文中的「顯示更多」', 'ポストの「さらに表示」を自動展開', 'Automatically expand “Show more” in posts'], ['进入用户主页默认查看', '進入使用者主頁時預設檢視', 'プロフィールの既定タブ', 'Default profile tab'], ['亮点', '亮點', 'ハイライト', 'Highlights'], ['用户主页帖子排序方式', '使用者主頁貼文排序方式', 'プロフィールのポスト並び順', 'Profile post sorting'], ['最近', '最近', '最新', 'Recent'], ['热门', '熱門', '人気', 'Popular'], ['选择“热门”时，会使用 X 的热门排序；视频和图片页不受影响。', '選擇「熱門」時，會使用 X 的熱門排序；影片和圖片頁不受影響。', '「人気」を選ぶと X の人気順を使います。動画・画像ページには影響しません。', 'Selecting Popular uses X’s popular sorting; video and photo pages are unaffected.'], ['其他功能', '其他功能', 'その他の機能', 'Other features'], ['兼容 Firefox（仅 Firefox）', '相容 Firefox（僅 Firefox）', 'Firefox 互換モード（Firefox のみ）', 'Firefox compatibility (Firefox only)'], ['帖子上限提示', '貼文上限提示', 'ポスト件数の上限通知', 'Post limit warning'], ['帖子记录接近“最大条数”时提醒你。关闭提醒后，也可以随时在这里重新开启。', '貼文記錄接近「最大筆數」時提醒你。關閉提醒後，也可以隨時在這裡重新開啟。', 'ポスト記録が「最大件数」に近づくと通知します。通知を閉じても、ここからいつでも再開できます。', 'Warns you when saved posts approach the maximum. If dismissed, the warning can be re-enabled here anytime.'], ['已恢复上限提示', '已恢復上限提示', '上限通知を再開しました', 'Limit warning restored'], ['已关闭上限提示', '已關閉上限提示', '上限通知を無効にしました', 'Limit warning disabled'], ['隐藏应用徽标', '隱藏應用徽章', 'アプリバッジを非表示', 'Hide app badge'], ['切换为移动端徽标（仅 PC）', '切換為行動版徽章（僅 PC）', 'モバイル用バッジに切替（PC のみ）', 'Use mobile badge (PC only)'], ['切换为半透明蓝色条（仅移动端）', '切換為半透明藍色條（僅行動裝置）', '半透明の青いバーに切替（モバイルのみ）', 'Use translucent blue bar (mobile only)'], ['高级设置', '進階設定', '詳細設定', 'Advanced settings'], ['自动清理(天)', '自動清理（日）', '自動削除（日）', 'Auto-clean (days)'], ['最大条数', '最大筆數', '最大件数', 'Maximum posts'], ['闪现阈值(秒)', '閃現門檻（秒）', '消失判定（秒）', 'Disappear threshold (sec)'], ['主题', '主題', 'テーマ', 'Theme'], ['跟随系统', '跟隨系統', 'システムに合わせる', 'Follow system'], ['深色', '深色', 'ダーク', 'Dark'], ['浅色', '淺色', 'ライト', 'Light'], ['下载超时(秒)', '下載逾時（秒）', 'タイムアウト（秒）', 'Download timeout (sec)'], ['下载并发', '下載並行數', '同時ダウンロード数', 'Concurrent downloads'], ['应用', '套用', '適用', 'Apply'], ['帖子记录即将达到上限', '貼文記錄即將達到上限', 'ポスト記録が上限に近づいています', 'Post history is nearing its limit'], ['达到上限后，新帖子仍会继续记录；最旧的未收藏、未置顶帖子会被删除。收藏和置顶帖子不会被上限删除，因此总数有时可能超过设置值。', '達到上限後仍會繼續記錄新貼文；最舊且未收藏、未置頂的貼文會被刪除。收藏與置頂貼文不受上限刪除，因此總數有時可能超過設定值。', '上限に達しても新しいポストは記録され、古い未お気に入り・未固定のポストから削除されます。お気に入りと固定済みポストは削除されないため、合計が設定値を超える場合があります。', 'New posts will still be recorded at the limit; the oldest unfavorited and unpinned posts are removed. Favorited and pinned posts are protected, so the total may sometimes exceed the configured value.'], ['你可以打开“高级设置”调大“最大条数”，或先导出备份。', '你可以開啟「進階設定」調高「最大筆數」，或先匯出備份。', '「詳細設定」で上限を増やすか、先にバックアップをエクスポートできます。', 'You can increase the maximum under Advanced settings or export a backup first.'], ['打开高级设置', '開啟進階設定', '詳細設定を開く', 'Open advanced settings'], ['不再提示', '不再提示', '今後表示しない', "Don't remind me again"], ['点亮按钮即不保存对应页面的帖子', '點亮按鈕即不儲存對應頁面的貼文', 'ボタンをオンにすると、そのページのポストを保存しません', 'Turn on a button to stop saving posts from that page'], ['下载任务', '下載工作', 'ダウンロードタスク', 'Download tasks'], ['暂无下载任务', '暫無下載工作', 'ダウンロードはありません', 'No download tasks'], ['下载', '下載', 'ダウンロード', 'Download'], ['下载中', '下載中', 'ダウンロード中', 'Downloading'], ['转 GIF', '轉 GIF', 'GIF 変換', 'GIF'], ['正在转换 GIF', '正在轉換 GIF', 'GIF に変換中', 'Converting to GIF'], ['排队中', '排隊中', '待機中', 'Queued'], ['排队', '排隊', '待機', 'Queued'], ['正在打包', '正在打包', '圧縮中', 'Packing'], ['打包', '打包', '圧縮', 'Packing'], ['正在保存', '正在儲存', '保存中', 'Saving'], ['正在取消下载', '正在取消下載', 'キャンセル中', 'Cancelling download'], ['取消中', '取消中', 'キャンセル中', 'Cancelling'], ['下载完成', '下載完成', 'ダウンロード完了', 'Download complete'], ['已取消', '已取消', 'キャンセル済み', 'Cancelled'], ['失败：', '失敗：', '失敗：', 'Failed: '], ['重试', '重試', '再試行', 'Retry'], ['查看下载任务', '查看下載工作', 'ダウンロードを表示', 'View downloads'], ['取消下载', '取消下載', 'ダウンロードをキャンセル', 'Cancel download'], ['下载图片/视频/GIF', '下載圖片/影片/GIF', '画像/動画/GIFを保存', 'Download images/videos/GIFs'], ['正在获取视频地址…', '正在取得影片網址…', '動画 URL を取得中…', 'Getting video URL…'], ['获取中', '取得中', '取得中', 'Looking up'], ['已下载过媒体；点击可再次下载', '已下載過媒體；點擊可再次下載', 'ダウンロード済みです。クリックすると再保存できます', 'Downloaded before; click to download again'], ['个任务', '個工作', '件のタスク', ' tasks'], ['查看下载任务：', '查看下載工作：', 'ダウンロードを表示：', 'View downloads: '], ['命名效果预览：', '命名效果預覽：', 'ファイル名プレビュー：', 'Filename preview: '], ['示例用户', '範例使用者', 'サンプルユーザー', 'Sample user'], ['这是用于预览下载文件名的帖子正文', '這是用於預覽下載檔名的貼文內文', 'ダウンロード名を確認するためのサンプル本文', 'Sample post text for previewing download names'], ['下载超时', '下載逾時', 'ダウンロードがタイムアウトしました', 'Download timed out'], ['网络错误', '網路錯誤', 'ネットワークエラー', 'Network error'], ['下载失败', '下載失敗', 'ダウンロード失敗', 'Download failed'], ['读取失败', '讀取失敗', '読み込み失敗', 'Read failed'], ['媒体总量超出经典 ZIP 范围，请改为逐个下载', '媒體總量超出傳統 ZIP 範圍，請改為逐一下載', 'メディア総量が従来形式の ZIP 上限を超えました。個別に保存してください', 'Media exceeds classic ZIP limits; download files separately'], ['跨域下载失败：请使用支持 GM_xmlhttpRequest 的脚本管理器', '跨網域下載失敗：請使用支援 GM_xmlhttpRequest 的使用者腳本管理器', 'クロスオリジン保存に失敗しました。GM_xmlhttpRequest 対応のユーザースクリプト管理拡張を使用してください', 'Cross-origin download failed. Use a userscript manager that supports GM_xmlhttpRequest'], ['⚠️ 未能取得视频地址：检测到 Violentmonkey。安卓 Firefox 上可能无法正确携带 X 登录态，请改用 Tampermonkey 后重试', '⚠️ 無法取得影片網址：偵測到 Violentmonkey。Android Firefox 可能無法正確攜帶 X 登入狀態，請改用 Tampermonkey 後重試', '⚠️ 動画 URL を取得できませんでした。Violentmonkey を検出しました。Android Firefox では X のログイン状態が正しく送信されない場合があるため、Tampermonkey に変更して再試行してください', '⚠️ Could not get the video URL. Violentmonkey was detected; Android Firefox may not pass the X login session correctly. Switch to Tampermonkey and try again'], ['未能取得媒体地址，请确认已登录 X 后重试', '無法取得媒體網址，請確認已登入 X 後重試', 'メディア URL を取得できませんでした。X にログインして再試行してください', 'Could not get the media URL. Make sure you are signed in to X and try again'], ['未找到可下载的媒体，若为视频请先点开或播放一下再试', '找不到可下載的媒體；若為影片，請先開啟或播放後再試', '保存できるメディアが見つかりません。動画の場合は一度開くか再生してから再試行してください', 'No downloadable media was found. For video, open or play it once and try again'], ['图片预览', '圖片預覽', '画像プレビュー', 'Image preview'], ['关闭图片预览', '關閉圖片預覽', '画像プレビューを閉じる', 'Close image preview'], ['上一张图片', '上一張圖片', '前の画像', 'Previous image'], ['下一张图片', '下一張圖片', '次の画像', 'Next image'], ['提示：列表仅记录你浏览时出现过的帖子。收藏/置顶的帖子不会被上限删除或自动清理。', '提示：列表僅記錄你瀏覽時出現過的貼文。收藏／置頂貼文不會因數量上限或自動清理而刪除。', 'ヒント：閲覧中に表示されたポストだけを記録します。お気に入り／固定したポストは上限や自動削除の対象外です。', 'Tip: Only posts seen while browsing are saved. Favorited or pinned posts are never removed by limits or auto-cleaning.'], ['读取 X 的铃铛订阅状态；开关操作会同步修改 X 账号设置。本页不会抓取或显示订阅账号的帖子。', '讀取 X 的鈴鐺訂閱狀態；開關操作會同步修改 X 帳號設定。本頁不會擷取或顯示訂閱帳號的貼文。', 'X のベル購読状態を読み取り、切替は X アカウントにも反映されます。このページで購読アカウントのポストを取得・表示することはありません。', 'Reads X bell-subscription status; toggles also update your X account. This page does not fetch or display posts from subscribed accounts.'], ['只影响 BetterX 已记录的帖子：关键词用来高亮和筛选，排除词会隐藏匹配的帖子。', '只影響 BetterX 已記錄的貼文：關鍵字用來醒目提示和篩選，排除詞會隱藏符合的貼文。', 'BetterX に記録済みのポストだけが対象です。キーワードは強調と絞り込みに使い、除外語に一致したポストは非表示にします。', 'Only affects posts saved by BetterX: keywords highlight and filter, while exclusions hide matching posts.'], ['普通文字可直接输入；正则表达式请写成 <code>/表达式/</code>，例如 <code>/猫|狗/</code>。两种写法可以混用。', '一般文字可直接輸入；正則表達式請寫成 <code>/運算式/</code>，例如 <code>/貓|狗/</code>。兩種寫法可以混用。', '通常の文字はそのまま入力できます。正規表現は <code>/式/</code> の形で入力してください（例：<code>/猫|犬/</code>）。両方を組み合わせて使えます。', 'Enter plain text directly. Write regex as <code>/expression/</code>, for example <code>/cat|dog/</code>. Both forms can be mixed.'], ['根据正文、账号名和引流特征综合判断，只在当前页面隐藏可疑帖子，不会拉黑账号。关闭后会恢复显示。', '根據內文、帳號名稱和引流特徵綜合判斷，只在目前頁面隱藏可疑貼文，不會封鎖帳號。關閉後會恢復顯示。', '本文、アカウント名、誘導の特徴から総合的に判定し、現在のページで疑わしいポストだけを非表示にします。アカウントはブロックせず、オフにすると再表示します。', 'Checks post text, account names, and spam signals, then hides suspicious posts only on the current page. It never blocks accounts; turn it off to show them again.'], ['自动读取 X 当前的时间线与左侧栏宽度（默认开启）', '自動讀取 X 目前的時間軸與左側欄寬度（預設開啟）', 'X の現在のタイムライン幅と左サイドバー幅を自動取得（既定でオン）', 'Automatically detect X timeline and left-sidebar widths (enabled by default)'], ['在消息页和设置页不会调整布局；关闭此功能即可恢复 X 原来的界面。', '在訊息頁和設定頁不會調整版面；關閉此功能即可恢復 X 原來的介面。', 'メッセージと設定ページではレイアウトを変更しません。この機能をオフにすると X 本来の表示に戻ります。', 'The layout is not changed on Messages or Settings pages. Turn this feature off to restore X’s original layout.'], ['点击下载按钮保存全部媒体；长按或 Shift+点击可按缩略图选择图片、GIF 和视频。下载时帖子内会显示进度与取消按钮，徽标旁会显示任务提示。', '點擊下載按鈕儲存全部媒體；長按或 Shift+點擊可依縮圖選擇圖片、GIF 和影片。下載時貼文內會顯示進度與取消按鈕，徽章旁會顯示工作提示。', 'クリックで全メディアを保存します。長押しまたは Shift+クリックでサムネイルから画像・GIF・動画を選択できます。ダウンロード中はポスト内に進捗とキャンセルボタン、バッジ横にタスク表示が出ます。', 'Click to save all media, or hold or Shift+click to select images, GIFs and videos by thumbnail. Download progress and cancel buttons appear in posts, with a task indicator beside the app badge.'], ['默认开启；ZIP 内的文件会使用下方“媒体文件名”模板。关闭后会同时下载多个媒体。', '預設開啟；ZIP 內檔案使用下方「媒體檔名」範本。關閉後會同時下載多個媒體。', '既定でオンです。ZIP 内のファイル名には下のメディア名テンプレートを使います。オフの場合は複数ファイルを個別保存します。', 'Enabled by default. Files inside ZIP use the media filename template below. When disabled, media files download separately.'], ['默认关闭；至少成功下载帖子内一个媒体后会记录并修改该帖子的下载图标。再次点击已记录帖子的下载按钮时，会先询问是否继续下载。', '預設關閉；成功下載貼文內至少一個媒體後會記錄並變更下載圖示。再次點擊已記錄貼文時會先詢問是否繼續。', '既定ではオフです。メディアを1件以上保存すると記録し、アイコンを変更します。再ダウンロード時は確認します。', 'Disabled by default. After at least one media file is saved, the post is recorded and its icon changes. Re-downloading asks for confirmation.'], ['点击变量会插入到当前正在编辑的模板中；同时下载一个帖子内多个媒体文件时若未使用 <code>{序号}</code>，会自动追加序号避免重名。', '點擊變數會插入目前編輯中的範本；同時下載貼文內多個媒體時，若未使用 <code>{序號}</code>，會自動附加序號以避免重名。', '変数をクリックすると編集中のテンプレートへ挿入します。複数メディアで <code>{連番}</code> がない場合は重複防止の番号を自動追加します。', 'Click a variable to insert it into the active template. If <code>{index}</code> is omitted for multiple media files, a number is appended automatically.'], ['正则会在变量展开后，对两个名称进行全局替换；支持捕获组替换（如 <code>$1</code>）。无效或高风险的正则不会保存。', '正則會在變數展開後對兩個名稱進行全域取代；支援擷取群組（如 <code>$1</code>）。無效或高風險正則不會儲存。', '変数展開後に両方の名前へ一括置換します。キャプチャ置換（<code>$1</code> など）に対応し、無効または危険な式は保存しません。', 'After variables expand, the regex replaces globally in both names. Capture replacements such as <code>$1</code> are supported; invalid or risky regexes are not saved.'], ['隐藏时间线广告、广告卡片和“订阅 Premium”提示。广告帖子不会保存到 BetterX，关闭后会重新显示。', '隱藏時間軸廣告、廣告卡片和「訂閱 Premium」提示。廣告貼文不會儲存到 BetterX，關閉後會重新顯示。', 'タイムライン広告、広告カード、「Premium に登録」の案内を非表示にします。広告ポストは BetterX に保存されず、オフにすると再表示します。', 'Hides timeline ads, ad cards, and Subscribe to Premium prompts. Ad posts are not saved to BetterX and reappear when this is turned off.'], ['隐藏 X 右侧栏中的 NFL 球队、赛程和比赛入口；关闭此开关后会恢复显示。', '隱藏 X 右側欄中的 NFL 球隊、賽程和比賽入口；關閉此開關後會恢復顯示。', 'X の右サイドバーにある NFL のチーム、日程、試合への入口を非表示にします。オフにすると再表示します。', 'Hides NFL teams, schedules, and game links in X’s right sidebar. Turn it off to show them again.'], ['把帖子里的多张媒体改成网格：2 张并排，3 张左大右二，4 张按 2×2 排列。', '把貼文裡的多個媒體改成網格：2 個並排，3 個左大右二，4 個按 2×2 排列。', 'ポスト内の複数メディアをグリッド表示にします。2枚は横並び、3枚は左大＋右2枚、4枚は2×2です。', 'Shows multiple media items in a grid: two side by side, three with one large item on the left, and four in a 2×2 layout.'], ['移除敏感内容遮罩并显示原图或视频；在新打开的窗口里建议勾选上“显示可能含有敏感内容的媒体内容”', '移除敏感內容遮罩並顯示原圖或影片；建議在新開啟的視窗中勾選「顯示可能含有敏感內容的媒體內容」', 'センシティブな内容の覆いを外して元の画像や動画を表示します。新しく開いたウィンドウで「センシティブな内容を含む可能性のあるメディアを表示する」を有効にすることをおすすめします。', 'Removes sensitive-content covers and shows original images or videos. In the newly opened window, we recommend enabling “Display media that may contain sensitive content”.'], ['如果您没有勾选的话，麻烦您勾选上“显示可能含有敏感内容的媒体内容”，大部分成人内容会自动显示', '如果尚未勾選，請勾選「顯示可能含有敏感內容的媒體內容」，大部分成人內容便會自動顯示', 'まだ有効にしていない場合は、「センシティブな内容を含む可能性のあるメディアを表示する」を有効にしてください。ほとんどの成人向けコンテンツが自動的に表示されます。', 'If it is not already enabled, please enable “Display media that may contain sensitive content”. Most adult content will then appear automatically.'], ['自动点开帖子正文里的“显示更多 / Show more”；不会展开回复或侧栏内容。', '自動點開貼文內文裡的「顯示更多 / Show more」；不會展開回覆或側欄內容。', 'ポスト本文の「さらに表示 / Show more」を自動で開きます。返信やサイドバーの内容は展開しません。', 'Automatically opens “Show more” in post text. Replies and sidebar content are not expanded.'], ['进入用户主页时自动切换到所选页签；帖子详情、回复和关注者页面不受影响。', '進入使用者主頁時自動切換到所選分頁；貼文詳情、回覆和追蹤者頁面不受影響。', 'プロフィールを開くと選んだタブへ自動で切り替えます。ポスト詳細、返信、フォロワーページには影響しません。', 'Automatically switches to the selected tab when you open a profile. Post details, replies, and follower pages are unaffected.'], ['如果 X 一直停在启动图标，可尝试开启。开启后会停用部分网络数据读取；点击开关可先查看影响。', '如果 X 一直停在啟動圖示，可嘗試開啟。開啟後會停用部分網路資料讀取；點擊開關可先查看影響。', 'X が起動ロゴのまま止まる場合にお試しください。有効にすると一部のネットワークデータ読み取りを停止します。切り替える前に影響を確認できます。', 'Try this if X remains stuck on its startup logo. It disables some network-data reading; click the switch to review the impact first.'], ['在电脑上会隐藏徽标；在手机上会收成屏幕右侧的蓝色小条。点击小条、从屏幕右边缘向内滑动，或使用油猴菜单都能恢复。', '在電腦上會隱藏徽章；在手機上會收成螢幕右側的藍色小條。點擊小條、從螢幕右邊緣向內滑動，或使用腳本管理器選單都能恢復。', 'パソコンではバッジを隠し、スマートフォンでは画面右側の青いバーに収納します。バーをタップする、右端から内側へスワイプする、またはユーザースクリプトメニューから復元できます。', 'Hides the badge on desktop and collapses it into a blue bar on mobile. Tap the bar, swipe inward from the right edge, or use the userscript menu to restore it.'], ['在电脑上使用圆形图标和未读角标，仍可拖动位置。', '在電腦上使用圓形圖示和未讀角標，仍可拖曳位置。', 'パソコンで丸いアイコンと未読バッジを使います。位置は引き続きドラッグできます。', 'Uses a circular icon and unread badge on desktop; you can still drag it to a new position.'], ['把手机上的圆形徽标收成右侧蓝色小条；点击打开面板，长按后可上下移动。', '把手機上的圓形徽章收成右側藍色小條；點擊開啟面板，長按後可上下移動。', 'スマートフォンの丸いバッジを右側の青いバーに収納します。タップでパネルを開き、長押し後に上下へ動かせます。', 'Collapses the circular mobile badge into a blue bar on the right. Tap to open the panel; long-press to move it up or down.'], ['下载并发可设为 1～6，默认 2；调高会加快多媒体任务，但也会增加带宽与内存占用。自动清理(天)为0则不自动清理。', '下載並行數可設為 1～6，預設 2；提高可加速多媒體工作，但也會增加頻寬與記憶體使用。自動清理（日）設為0則不自動清理。', '同時数は1～6（既定2）。増やすと速くなりますが、帯域とメモリ使用量も増えます。自動削除（日）を0にすると自動削除しません。', 'Concurrency can be 1–6 (default 2). Higher values speed up multi-media jobs but use more bandwidth and memory. Set Auto-clean (days) to 0 to disable automatic cleaning.'], ['当前筛选条件下没有帖子。可以刷新页面、切换 X 标签页，或把筛选改回“全部”。', '目前篩選條件下沒有貼文。可重新整理頁面、切換 X 分頁，或將篩選改回「全部」。', '現在の条件に一致するポストはありません。ページや X のタブを更新するか、フィルターを「すべて」に戻してください。', 'No posts match the current filters. Refresh the page, switch X tabs, or reset the filter to All.'], ['还没有读取到帖子通知订阅。点击“同步订阅用户”，或浏览已开启铃铛的用户主页后再查看。', '尚未讀取貼文通知訂閱。請點擊「同步訂閱使用者」，或瀏覽已開啟鈴鐺的使用者主頁後再查看。', 'ポスト通知の購読情報がありません。「購読ユーザーを同期」を押すか、ベルを有効にしたプロフィールを開いてください。', 'No post-notification subscriptions have been read. Click “Sync subscribed users” or visit a profile with its bell enabled.'], ['智能排序：置顶、收藏和快消失的帖子先显示，其他的按抓到的顺序排。', '智慧排序：置頂、收藏和快速消失的貼文優先，其餘依擷取順序排列。', 'スマート順：固定・お気に入り・すぐ消えたポストを優先し、残りは取得順に表示します。', 'Smart sort: pinned, favorited, and quickly disappeared posts first; others follow capture order.'], ['最近浏览：按你在屏幕上看到的帖子顺序排。适合用来找刚刷过的帖子。', '最近瀏覽：依螢幕上看到貼文的順序排列，適合尋找剛瀏覽過的貼文。', '最近表示：画面で見た順に並べ、直前に見たポストを探すのに便利です。', 'Recently viewed: orders posts by when they appeared on screen, useful for finding what you just saw.'], ['最近抓取：按脚本发现帖子的时间排。X 会提前加载，顺序不一定等于你看到的顺序。', '最近擷取：依腳本發現貼文的時間排列。X 會預先載入，因此不一定等於實際看到的順序。', '最近取得：スクリプトが見つけた時刻順です。X の先読みのため、実際に見た順とは限りません。', 'Recently captured: orders by discovery time. X preloads posts, so this may differ from viewing order.'], ['出现次数：反复刷到的帖子排在前面。', '出現次數：反覆看到的貼文排在前面。', '表示回数：繰り返し表示されたポストを先にします。', 'Appearances: repeatedly seen posts come first.'], ['按作者：把同一个作者的帖子排在一起。', '依作者：將同一作者的貼文排在一起。', '投稿者順：同じ投稿者のポストをまとめます。', 'By author: groups posts from the same author.'], ['按来源：按为你推荐、正在关注、搜索、书签、喜欢等页面分类排。', '依來源：依為你推薦、正在關注、搜尋、書籤、喜歡等頁面分類。', 'ソース順：おすすめ、フォロー中、検索、ブックマーク、いいねなどで分類します。', 'By source: groups posts by For You, Following, Search, Bookmarks, Likes, and other pages.'], ['BetterX：显示 / 隐藏应用徽标', 'BetterX：顯示 / 隱藏應用徽章', 'BetterX：アプリバッジを表示 / 非表示', 'BetterX: Show / hide app badge'], ['BetterX：强制开启 Firefox 兼容模式并刷新', 'BetterX：強制開啟 Firefox 相容模式並重新整理', 'BetterX：Firefox 互換モードを強制して更新', 'BetterX: Force Firefox compatibility and reload'], ['BetterX：恢复 Firefox 完整模式并刷新', 'BetterX：恢復 Firefox 完整模式並重新整理', 'BetterX：Firefox フルモードに戻して更新', 'BetterX: Restore full Firefox mode and reload'], ['BetterX：导出 Firefox 兼容诊断', 'BetterX：匯出 Firefox 相容診斷', 'BetterX：Firefox 互換診断をエクスポート', 'BetterX: Export Firefox compatibility diagnostics'], ['无法读取当前 X 用户 ID，请确认已经登录', '無法讀取目前 X 使用者 ID，請確認已登入', '現在の X ユーザー ID を取得できません。ログインを確認してください', 'Could not read the current X user ID. Make sure you are signed in'], ['本次识别', '本次識別', '今回検出', 'Found this time'], ['个，当前保留', '個，目前保留', '件、現在保持', '; currently keeping'], ['个订阅', '個訂閱', '件の購読', ' subscriptions'], ['同步失败：', '同步失敗：', '同期失敗：', 'Sync failed: '], ['修改失败：', '修改失敗：', '変更失敗：', 'Update failed: '], ['已开启', '已開啟', '有効化しました', 'Enabled'], ['的帖子通知', '的貼文通知', 'のポスト通知', ' post notifications'], ['已关闭', '已關閉', '無効化しました', 'Disabled'], ['下载完成：已逐个保存', '下載完成：已逐一儲存', 'ダウンロード完了：個別に保存', 'Download complete: saved separately'], ['个文件', '個檔案', 'ファイル', ' files'], ['，跳过', '，略過', '、スキップ', '; skipped'], ['个失败项', '個失敗項目', '件の失敗', ' failed items'], ['正在开启 Firefox 兼容模式并刷新…', '正在開啟 Firefox 相容模式並重新整理…', 'Firefox 互換モードを有効にして更新中…', 'Enabling Firefox compatibility and reloading…'], ['正在关闭 Firefox 兼容模式并刷新…', '正在關閉 Firefox 相容模式並重新整理…', 'Firefox 互換モードを無効にして更新中…', 'Disabling Firefox compatibility and reloading…'], ['此选项仅用于 Firefox', '此選項僅適用於 Firefox', 'この設定は Firefox 専用です', 'This option is only for Firefox'], ['已开启 Firefox 兼容模式', '已開啟 Firefox 相容模式', 'Firefox 互換モードを有効にしました', 'Firefox compatibility enabled'], ['已使用 Firefox 完整功能模式', '已使用 Firefox 完整功能模式', 'Firefox フル機能モードを使用します', 'Using full Firefox mode'], ['已导出 Firefox 兼容诊断', '已匯出 Firefox 相容診斷', 'Firefox 互換診断をエクスポートしました', 'Firefox compatibility diagnostics exported'], ['已恢复应用徽标', '已恢復應用徽章', 'アプリバッジを復元しました', 'App badge restored'], ['已显示应用徽标', '已顯示應用徽章', 'アプリバッジを表示しました', 'App badge shown'], ['已隐藏应用徽标 · Alt+X 可打开面板', '已隱藏應用徽章 · Alt+X 可開啟面板', 'アプリバッジを非表示にしました · Alt+X でパネルを開けます', 'App badge hidden · Press Alt+X to open the panel'], ['点击屏幕右侧小蓝条可显示徽标', '點擊螢幕右側小藍條可顯示徽章', '画面右の青いバーをタップしてバッジを表示', 'Tap the blue bar on the right to show the badge'], ['已切换为屏幕右侧小蓝条', '已切換為螢幕右側小藍條', '画面右の青いバーに切り替えました', 'Switched to the blue right-edge bar'], ['显示 BetterX 应用徽标', '顯示 BetterX 應用徽章', 'BetterX アプリバッジを表示', 'Show BetterX app badge'], ['打开 BetterX 面板', '開啟 BetterX 面板', 'BetterX パネルを開く', 'Open BetterX panel'], ['关闭 BetterX 面板', '關閉 BetterX 面板', 'BetterX パネルを閉じる', 'Close BetterX panel'], ['点按显示 BetterX 徽标', '點按以顯示 BetterX 徽章', 'タップして BetterX バッジを表示', 'Tap to show the BetterX badge'], ['正则无效或风险过高，未保存', '正則無效或風險過高，未儲存', '正規表現が無効または危険なため保存しませんでした', 'Regex was invalid or too risky and was not saved'], ['已保存下载命名', '已儲存下載命名', 'ダウンロード命名設定を保存しました', 'Download naming saved'], ['已将当前列表全部标为已读', '已將目前列表全部標為已讀', '現在の一覧をすべて既読にしました', 'Marked the current list as read'], ['已保存关键词', '已儲存關鍵字', 'キーワードを保存しました', 'Keywords saved'], ['已保存排除词', '已儲存排除詞', '除外語を保存しました', 'Exclusions saved'], ['已保存自定义屏蔽词', '已儲存自訂封鎖詞', 'カスタムブロック語を保存しました', 'Custom blocked words saved'], ['已保存账号白名单', '已儲存帳號白名單', 'アカウント許可リストを保存しました', 'Account allowlist saved'], ['已切换为手动宽度并应用', '已切換為手動寬度並套用', '手動幅へ切り替えて適用しました', 'Switched to manual widths and applied'], ['已应用高级设置', '已套用進階設定', '詳細設定を適用しました', 'Advanced settings applied'], ['确定要清空', '確定要清空', '消去しますか：', 'Clear'], ['条未收藏/未置顶的帖子吗？此操作不可撤销。', '筆未收藏／未置頂的貼文嗎？此操作無法復原。', '件のお気に入り／固定されていないポスト。この操作は取り消せません。', ' unfavorited/unpinned posts? This cannot be undone.'], ['导入失败：单次最多允许', '匯入失敗：單次最多允許', 'インポート失敗：一度に許可される上限は', 'Import failed: at most'], ['条帖子。', '筆貼文。', '件です。', ' posts are allowed.'], ['导入完成：新增', '匯入完成：新增', 'インポート完了：追加', 'Import complete: added'], ['条，合并', '筆，合併', '件、統合', ', merged'], ['条，跳过', '筆，略過', '件、スキップ', ', skipped'], ['条无效记录', '筆無效記錄', '件の無効な記録', ' invalid records'], ['该帖子内媒体文件曾下载过，是否继续下载？', '此貼文的媒體曾下載過，是否繼續？', 'このポストのメディアはダウンロード済みです。続行しますか？', 'Media from this post was downloaded before. Continue?'], ['是否同时恢复备份中的设置？', '是否同時還原備份中的設定？', 'バックアップ内の設定も復元しますか？', 'Restore settings from the backup too?'], ['页面尚未就绪，诊断信息已输出到控制台。', '頁面尚未就緒，診斷資訊已輸出至主控台。', 'ページの準備ができていません。診断情報をコンソールへ出力しました。', 'The page is not ready; diagnostics were written to the console.'], ['当前筛选结果为空，没有可导出的内容。', '目前篩選結果為空，沒有可匯出的內容。', '現在の絞り込み結果は空です。エクスポートする内容がありません。', 'The current filtered result is empty; there is nothing to export.'], ['导入失败：备份文件不能超过 25 MB。', '匯入失敗：備份檔不得超過 25 MB。', 'インポート失敗：バックアップは 25 MB 以下にしてください。', 'Import failed: backup files cannot exceed 25 MB.'], ['无法识别的备份文件格式。', '無法識別的備份檔格式。', '認識できないバックアップ形式です。', 'Unrecognized backup format.'], ['导入失败：文件解析出错。', '匯入失敗：檔案解析錯誤。', 'インポート失敗：ファイルを解析できませんでした。', 'Import failed: file parsing error.'], ['当前列表没有未读的帖子喂～', '目前列表沒有未讀貼文喔～', '現在の一覧に未読ポストはありません。', 'There are no unread posts in the current list.'], ['确定要把当前列表的 ', '確定要將目前列表中的 ', '現在の一覧にある', 'Mark all '], [' 条未读帖子全部标为已读吗？', ' 筆未讀貼文全部標為已讀嗎？', '件の未読ポストをすべて既読にしますか？', ' unread posts in the current list as read?'], ['⚠️ 已忽略', '⚠️ 已忽略', '⚠️ 無視しました：', '⚠️ Ignored'], ['条高风险或无效正则', '筆高風險或無效正則', '件の危険または無効な正規表現', ' risky or invalid regex rules'], ['最多保存 50 个', '最多儲存 50 個', '保存できる上限は50件です：', 'At most 50 can be saved: '], ['自定义屏蔽词', '自訂封鎖詞', 'カスタムブロック語', 'custom blocked words'], ['关键词', '關鍵字', 'キーワード', 'keywords'], ['排除词', '排除詞', '除外語', 'exclusions'], ['没有找到与“', '找不到與「', '「', 'No username or @username matched “'], ['”匹配的用户名或 @用户名。', '」相符的使用者名稱或 @使用者名稱。', '」に一致するユーザー名または @ユーザー名はありません。', '”.'], ['开启“兼容 Firefox”？', '開啟「Firefox 相容模式」？', 'Firefox 互換モードを有効にしますか？', 'Enable Firefox compatibility?'], ['开启后 BetterX 不再改写页面的', '開啟後 BetterX 將不再改寫頁面的', '有効にすると BetterX はページの', 'When enabled, BetterX will stop wrapping the page’s'], ['可避免部分 Firefox 环境或多个 X 脚本冲突时一直卡在 X 图标。', '可避免部分 Firefox 環境或多個 X 腳本衝突時一直卡在 X 圖示。', 'を変更しなくなり、一部の Firefox 環境や複数の X スクリプトが競合した際に X ロゴで停止する問題を避けられます。', ', which can prevent X from getting stuck on its logo in some Firefox setups or when multiple X scripts conflict.'], ['以下能力可能降级：', '以下功能可能受限：', '次の機能が制限される場合があります：', 'The following features may be limited:'], ['部分视频 / GIF 无法取得真实下载地址；', '部分影片 / GIF 可能無法取得實際下載網址；', '一部の動画 / GIF の実際のダウンロード URL を取得できない場合があります。', 'Some videos / GIFs may not expose a direct download URL;'], ['部分年龄限制视频无法内联显示；', '部分年齡限制影片可能無法直接顯示；', '一部の年齢制限動画をページ内表示できない場合があります。', 'Some age-restricted videos may not display inline;'], ['无法从接口响应学习关注关系，主要依靠主页按钮和“正在关注”时间线。', '無法從介面回應學習關注關係，主要依靠個人主頁按鈕與「正在關注」時間軸。', 'API 応答からフォロー関係を学習できず、プロフィールのボタンと「フォロー中」タイムラインが主な情報源になります。', 'Following relationships cannot be learned from API responses and instead rely mainly on profile buttons and the Following timeline.'], ['帖子记录、搜索、面板、内容净化、广告过滤、布局和图片 DOM 兜底不受影响。确认后页面会刷新。', '貼文記錄、搜尋、面板、內容淨化、廣告過濾、版面配置與圖片 DOM 備援不受影響。確認後頁面會重新整理。', 'ポスト記録、検索、パネル、コンテンツフィルター、広告非表示、レイアウト、画像の DOM フォールバックには影響しません。確認後にページを更新します。', 'Post history, search, the panel, content filtering, ad hiding, layout, and the image DOM fallback are unaffected. The page will reload after confirmation.'], ['开启并刷新', '開啟並重新整理', '有効にして更新', 'Enable and reload'], ['关闭“兼容 Firefox”？', '關閉「Firefox 相容模式」？', 'Firefox 互換モードを無効にしますか？', 'Disable Firefox compatibility?'], ['关闭后将恢复 v1.7 的网络媒体与关注关系采集。如果当前环境曾卡在只显示 X 图标的页面，建议继续保持开启。确认后页面会刷新。', '關閉後將恢復 v1.7 的網路媒體與關注關係擷取。如果目前環境曾卡在只顯示 X 圖示的頁面，建議繼續保持開啟。確認後頁面會重新整理。', '無効にすると v1.7 のネットワークメディア・フォロー関係の取得を再開します。X ロゴだけの画面で停止したことがある環境では、有効のままにすることをおすすめします。確認後にページを更新します。', 'Disabling restores v1.7 network media and following-relationship capture. If this setup has ever stalled on the X logo, keeping compatibility enabled is recommended. The page will reload after confirmation.'], ['关闭并刷新', '關閉並重新整理', '無効にして更新', 'Disable and reload'], ['检测到 Firefox', '偵測到 Firefox', 'Firefox を検出しました', 'Firefox detected'], ['请问你在使用 BetterX 时，能否正常进入 X？', '使用 BetterX 時，是否能正常進入 X？', 'BetterX の使用中、X を正常に開けていますか？', 'Can you open X normally while using BetterX?'], ['目前已知部分 Firefox 用户会一直卡在', '目前已知部分 Firefox 使用者會一直卡在', '一部の Firefox ユーザーでは', 'Some Firefox users may remain stuck on the'], ['只显示 X 图标', '只顯示 X 圖示', 'X ロゴだけが表示される', 'X-logo-only'], ['的启动页面，常见于广告过滤、媒体下载等多个 X 脚本同时运行的环境。', '的啟動畫面，常見於廣告過濾、媒體下載等多個 X 腳本同時執行的環境。', '起動画面で停止することがあります。広告フィルターやメディア保存など、複数の X スクリプトを同時に使う環境で起きやすい問題です。', ' startup screen, especially when multiple X scripts such as ad filters and media downloaders run together.'], ['如果遇到异常，请点击', '如果遇到異常，請點擊', '問題がある場合は', 'If you encounter this issue, click'], ['有异常', '有異常', '問題あり', 'Having problems'], ['，BetterX 会开启', '，BetterX 會開啟', 'を選ぶと、BetterX は', '; BetterX will enable'], ['“设置 → 其他功能 → 兼容 Firefox”', '「設定 → 其他功能 → Firefox 相容模式」', '「設定 → その他の機能 → Firefox 互換モード」', '“Settings → Other features → Firefox compatibility”'], ['。该模式会停用页面网络 Hook；部分视频 / GIF 下载、年龄限制视频和接口关注关系识别可能降级，其他主体功能不受影响。', '。此模式會停用頁面網路 Hook；部分影片 / GIF 下載、年齡限制影片與介面關注關係識別可能受限，其他主要功能不受影響。', '。このモードはページのネットワーク Hook を無効化します。一部の動画 / GIF の保存、年齢制限動画、API によるフォロー関係の認識は制限される場合がありますが、その他の主要機能には影響しません。', '. This disables page network hooks. Some video / GIF downloads, age-restricted videos, and API-based following detection may be limited; other main features are unaffected.'], ['目前正常', '目前正常', '現在は正常', 'Working normally'], ['确定', '確定', '確認', 'OK'], ['未知错误', '未知錯誤', '不明なエラー', 'Unknown error'], ];
function readUiLanguageOverride() {
  try {
    if (typeof GM_getValue !== 'function') return '';
    const value = String(GM_getValue(UI_LANGUAGE_OVERRIDE_KEY, '') || '');
    return SUPPORTED_UI_LANGUAGES.has(value) ? value : '';
  } catch (err) { return ''; }
}
function detectUiLanguage() {
  const override = readUiLanguageOverride();
  if (override) return override;
  let raw = '';
  try { raw = (document.documentElement && document.documentElement.lang) || ''; } catch (err) {}
  if (!raw) raw = (navigator.languages && navigator.languages[0]) || navigator.language || '';
  const value = String(raw).toLowerCase();
  if (/^zh-(?:tw|hk|mo|hant)/.test(value)) return 'zh-TW';
  if (/^ja(?:-|$)/.test(value)) return 'ja';
  if (/^en(?:-|$)/.test(value)) return 'en';
  return 'zh-CN';
}
const UI_LANGUAGE = detectUiLanguage(); const UI_LANGUAGE_INDEX = { 'zh-TW': 1, ja: 2, en: 3 }; const UI_TRANSLATION_INDEX = UI_LANGUAGE_INDEX[UI_LANGUAGE] || 0; const UI_TRANSLATION_MAP = new Map( UI_TEXT_ENTRIES.map((entry) => [entry[0], UI_TRANSLATION_INDEX ? entry[UI_TRANSLATION_INDEX] : entry[0]]) ); const UI_TRANSLATION_PATTERN = UI_TRANSLATION_INDEX ? new RegExp(UI_TEXT_ENTRIES.map((entry) => entry[0]) .sort((a, b) => b.length - a.length) .map((text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|'), 'g') : null; const UI_LOCALIZATION_SKIP_SELECTOR = [ '.BetterX-text', '.BetterX-note-text', '.BetterX-note-input', '.BetterX-author-profile', '.BetterX-notification-user-main b', '.BetterX-notification-user-main small', '.BetterX-keyword-tags', '.BetterX-i18n-user-text', 'code', 'script', 'style', ].join(',');
function uiText(value) {
  const input = String(value == null ? '' : value);
  if (!UI_TRANSLATION_PATTERN || !input) return input;
  return input.replace(UI_TRANSLATION_PATTERN, (matched) => UI_TRANSLATION_MAP.get(matched) || matched);
}
function uiHtml(strings, ...values) {
  return strings.reduce((html, chunk, index) => (
    html + uiText(chunk) + (index < values.length ? values[index] : '')
  ), '');
}
function shouldSkipUiLocalization(node) {
  const element = node && (node.nodeType === 1 ? node : node.parentElement);
  return !!(element && element.closest && element.closest(UI_LOCALIZATION_SKIP_SELECTOR));
}
function localizeBetterXTree(root) {
  if (!UI_TRANSLATION_PATTERN || !root) return;
  if (root.nodeType === 3) {
    if (shouldSkipUiLocalization(root)) return;
    const before = root.nodeValue || '';
    const after = uiText(before);
    if (after !== before) root.nodeValue = after;
    return;
  }
  const localizeElement = (element) => {
    if (!element || element.nodeType !== 1 || element.matches('code, script, style')) return;
    ['title', 'placeholder', 'aria-label'].forEach((name) => {
      if (!element.hasAttribute(name)) return;
      const before = element.getAttribute(name) || '';
      const after = uiText(before);
      if (after !== before) element.setAttribute(name, after);
    });
  };
  if (root.nodeType === 1) localizeElement(root);
  if (root.querySelectorAll) root.querySelectorAll('*').forEach(localizeElement);
  const showText = typeof NodeFilter !== 'undefined' ? NodeFilter.SHOW_TEXT : 4;
  if (!document.createTreeWalker) return;
  const walker = document.createTreeWalker(root, showText);
  let node;
  while ((node = walker.nextNode())) {
    if (shouldSkipUiLocalization(node)) continue;
    const before = node.nodeValue || '';
    const after = uiText(before);
    if (after !== before) node.nodeValue = after;
  }
}
let downloadUiLocalizationObserver = null;
function installDownloadUiLocalizationFallback(root) {
  if (typeof MutationObserver !== 'function' || !root.querySelector) return;
  const downloadRoot = root.querySelector('#BetterX-download-popover');
  if (!downloadRoot) return;
  if (downloadUiLocalizationObserver) downloadUiLocalizationObserver.disconnect();
  downloadUiLocalizationObserver = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type === 'characterData') {
        localizeBetterXTree(mutation.target.parentElement);
      } else {
        mutation.addedNodes.forEach((node) => localizeBetterXTree(node));
      }
    }
  });
  downloadUiLocalizationObserver.observe(downloadRoot, {
    subtree: true,
    childList: true,
    characterData: true,
  });
}
function uiAlert(message) { window.alert(uiText(message)); }
function uiConfirm(message) { return window.confirm(uiText(message)); }
const DB_NAME = 'x_post_vault_db';
const DB_VERSION = 2;
const POSTS_STORE = 'posts';
const SETTINGS_STORE = 'settings';
const CLEANUP_INTERVAL_MS = 1500;
const NETWORK_HOOK_CHECK_INTERVAL_MS = 5000;
const MAX_NETWORK_RESPONSE_BYTES = 8000000;
const MAX_NETWORK_HARVEST_QUEUE_CHARS = 16000000;
const MAX_NETWORK_HARVEST_JOBS = 6;
const MAX_NETWORK_HARVEST_NODES_PER_JOB = 250000;
const NETWORK_HARVEST_SLICE_NODES = 1200;
const MAX_NETWORK_REHOOKS_PER_API = 4;
const MAX_MEDIA_REGISTRY_ENTRIES = 2000;
const MAX_SESSION_STAT_IDS = 20000;
const MAX_FOLLOWED_HANDLES = 5000;
const MAX_NOTIFICATION_SUBSCRIPTIONS = 2000;
const NOTIFICATION_MUTATION_GUARD_MS = 5000;
const MAX_DOWNLOADED_POST_IDS = 5000;
const DOWNLOAD_MIN_CONCURRENCY = 1;
const DOWNLOAD_MAX_CONCURRENCY = 6;
const DOWNLOAD_MAX_RETRIES = 1;
const DOWNLOAD_ZIP_MEMORY_LIMIT_DESKTOP = 384 * 1024 * 1024;
const DOWNLOAD_ZIP_MEMORY_LIMIT_MOBILE = 128 * 1024 * 1024;
const CLASSIC_ZIP_MAX_VALUE = 0xFFFFFFFF;
const CLASSIC_ZIP_MAX_FILES = 0xFFFF;
const MAX_IMPORT_FILE_BYTES = 25 * 1024 * 1024;
const MAX_IMPORT_POSTS = 20000;
const MAX_CAPTURED_POST_TEXT_LENGTH = 100000;
const DB_OPEN_BLOCKED_TIMEOUT_MS = 5000;
const CROSS_TAB_CHANNEL_NAME = 'betterx_state_sync_v1';
const MAX_REGEX_SOURCE_LENGTH = 180;
const MAX_REGEX_HAYSTACK_LENGTH = 20000;
const MAX_REGEX_BOUNDED_REPETITION = 1000;
const PAGE_SCROLL_SETTLE_MS = 180;
const IS_FIREFOX = /(?:^|\s)Firefox\//i.test(navigator.userAgent || '');
const USERSCRIPT_MANAGER = (() => {
  try {
    return typeof GM_info !== 'undefined' && GM_info
      ? String(GM_info.scriptHandler || '')
      : '';
  } catch (err) { return ''; }
})();
const IS_VIOLENTMONKEY = /violent\s*monkey/i.test(USERSCRIPT_MANAGER);
const FIREFOX_COMPAT_MODE_KEY = 'betterx_firefox_compatibility_mode';
const SETTINGS_MIRROR_KEY = 'betterx_settings_mirror_v1';
const DEBUG = false;
function readFirefoxCompatibilityMode() {
  if (!IS_FIREFOX) return 'normal';
  let value = '';
  try {
    if (typeof GM_getValue === 'function') value = GM_getValue(FIREFOX_COMPAT_MODE_KEY, '');
  } catch (err) {}
  return value === 'compat' || value === 'normal' ? value : 'unset';
}
let firefoxCompatibilityMode = readFirefoxCompatibilityMode();
function readSettingsMirror() {
  try {
    if (typeof GM_getValue !== 'function') return null;
    const raw = GM_getValue(SETTINGS_MIRROR_KEY, null);
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
    const settings = raw.settings && typeof raw.settings === 'object' && !Array.isArray(raw.settings)
      ? raw.settings
      : raw;
    return settings && typeof settings === 'object' && !Array.isArray(settings) ? settings : null;
  } catch (err) {
    debugLog('read settings mirror failed:', err);
    return null;
  }
}
function writeSettingsMirror(settings) {
  try {
    if (typeof GM_setValue !== 'function') return;
    GM_setValue(SETTINGS_MIRROR_KEY, {
      version: 1,
      savedAt: Date.now(),
      settings,
    });
  } catch (err) {
    debugLog('write settings mirror failed:', err);
  }
}
function writeFirefoxCompatibilityMode(mode) {
  const normalized = mode === 'compat' ? 'compat' : 'normal';
  firefoxCompatibilityMode = normalized;
  try {
    if (typeof GM_setValue === 'function') GM_setValue(FIREFOX_COMPAT_MODE_KEY, normalized);
  } catch (err) {}
}
const FILTERS = [ { key: 'all', label: '全部' }, { key: 'unread', label: '未打开' }, { key: 'flash', label: '快速消失' }, { key: 'favorite', label: '已收藏' }, { key: 'pinned', label: '已置顶' }, { key: 'opened', label: '已打开' }, { key: 'keyword', label: '命中关键词' }, ]; const MEDIA_FILTERS = [ { key: 'all', label: '全部媒体' }, { key: 'image', label: '含图片' }, { key: 'video', label: '含视频' }, { key: 'text', label: '纯文字' }, ]; const SORT_HINTS = { smart: '智能排序：置顶、收藏和快消失的帖子先显示，其他的按抓到的顺序排。', recent_viewed: '最近浏览：按你在屏幕上看到的帖子顺序排。适合用来找刚刷过的帖子。', recent_captured: '最近抓取：按脚本发现帖子的时间排。X 会提前加载，顺序不一定等于你看到的顺序。', first_captured: '首次抓取（新→旧）：新发现的帖子排在前；同一条帖子后来又出现，也不会换位置。', time_asc: '首次抓取（旧→新）：最早发现的帖子排在前，适合从头慢慢翻。', captures: '出现次数：反复刷到的帖子排在前面。', author: '按作者：把同一个作者的帖子排在一起。', source: '按来源：按为你推荐、正在关注、搜索、书签、喜欢等页面分类排。', }; const SORT_LABELS = { smart: '智能排序', recent_viewed: '最近浏览', recent_captured: '最近抓取', first_captured: '首次抓取（新→旧）', time_asc: '首次抓取（旧→新）', captures: '出现次数', author: '按作者', source: '按来源', }; const SOURCE_SORT_RANK = new Map([ ['Search', 0], ['Bookmarks', 1], ['Likes', 2], ['For You', 3], ['Following', 4], ]); const SOURCE_EXACT_LABELS = Object.freeze({ Following: '正在关注', 'For You': '为你推荐', Search: '搜索', List: '列表', Bookmarks: '书签', Likes: '喜欢', Notifications: '通知', Unknown: '未知页面', }); const SKIP_SOURCE_OPTIONS = [ { key: 'profile', label: '个人主页' }, { key: 'thread', label: '帖子详情' }, { key: 'search', label: '搜索页' }, { key: 'bookmarks', label: '书签页' }, { key: 'likes', label: '喜欢页' }, { key: 'list', label: '列表页' }, ];
const PROFILE_DEFAULT_VIEW_OPTIONS = ['posts', 'all', 'highlights', 'video', 'photo'];
const PROFILE_POST_SORT_OPTIONS = ['recent', 'popular'];
const POST_SHOW_MORE_LABELS = new Set([ '显示更多', '顯示更多', 'Show more', 'さらに表示', '더 보기', ]);
const PROFILE_DEFAULT_VIEW_REDIRECT_GUARD_KEY = 'betterx_profile_default_view_redirect_guard_v1';
const PROFILE_DEFAULT_VIEW_REDIRECT_GUARD_MS = 15000;
const PROFILE_NAVIGATION_BYPASS_GUARD_KEY = 'betterx_profile_navigation_bypass_guard_v1';
const PROFILE_NAVIGATION_BYPASS_GUARD_MS = 30000;
const PROFILE_LINK_REWRITE_EXCLUSION_SELECTOR = [
  '[role="menu"]',
  '[role="menuitem"]',
  '[data-testid="SideNav_AccountSwitcher_Button"]',
  '[data-testid*="AccountSwitcher"]',
].join(', ');
const PROFILE_ROOT_ROUTE_EXCLUSIONS = new Set([
  'about', 'account', 'compose', 'download', 'explore', 'home', 'i', 'intent', 'jobs',
  'legal', 'login', 'logout', 'messages', 'notifications', 'privacy', 'search', 'settings',
  'share', 'signup', 'tos', 'x',
]);
const bind = (stateKey, selector, property = 'checked') => [stateKey, selector, property];
const setting = (defaultValue, validate, control, effects) => Object.freeze({
  default: defaultValue, validate, ...(control ? { control } : {}), ...(effects ? { effects } : {}),
});
const bool = (defaultValue, control, effects) => setting(defaultValue, ['boolean'], control, effects);
const SETTINGS_SCHEMA = Object.freeze({ settingsRevision: setting(39, ['revision']), keywords: setting([], ['keywordRules', 50, 500], null, ['keywords']), excludeKeywords: setting([], ['keywordRules', 50, 500], null, ['keywords']), keywordMode: setting('plain', ['enum', ['plain', 'and']], bind('keywordModeEl', '#BetterX-keyword-mode', 'value'), ['keywords']), filter: setting('all', ['filter']), sourceFilter: setting('all', ['sourceFilter'], bind('sourceSelectEl', '#BetterX-source', 'value')), mediaFilter: setting('all', ['mediaFilter'], bind('mediaSelectEl', '#BetterX-media', 'value')), sortBy: setting('smart', ['enum', ['smart', 'recent_viewed', 'recent_captured', 'first_captured', 'time_asc', 'captures', 'author', 'source']], bind('sortEl', '#BetterX-sort', 'value')), quickFilterOpen: bool(false), autoCleanDays: setting(0, ['int', 0, 3650]), maxPosts: setting(1000, ['int', 50, 5000]), postLimitWarningDisabled: bool(false), flashMs: setting(3000, ['int', 1000, 60000]), skipSources: setting(['thread'], ['skipSources']), theme: setting('auto', ['enum', ['auto', 'dark', 'light']], bind('themeSelectEl', '#BetterX-theme', 'value'), ['theme']), pageSize: setting(60, ['int', 20, 200]), badgePos: setting(null, ['badgePos'], null, ['badge']), panelWidth: setting(520, ['int', 420, 1200], null, ['panelWidth']), hideAds: bool(true, bind('hideAdsEl', '#BetterX-hideads'), ['ads']), hideNfl: bool(true, bind('hideNflEl', '#BetterX-hide-nfl'), ['nfl']), hideAdultSpam: bool(false, bind('hideAdultSpamEl', '#BetterX-hide-adult-spam'), ['adultSpam']), adultSpamCustomRulesEnabled: bool(true, bind('adultSpamCustomRulesEl', '#BetterX-adultspam-custom-enabled'), ['adultSpam']), adultSpamLevel: setting('balanced', ['enum', ['conservative', 'balanced']], bind('adultSpamLevelEl', '#BetterX-adultspam-level', 'value'), ['adultSpam']), adultSpamSkipFollowing: bool(true, bind('adultSpamSkipFollowingEl', '#BetterX-adultspam-skip-following'), ['adultSpam']), adultSpamSkipFollowingReposts: bool(false, bind('adultSpamSkipFollowingRepostsEl', '#BetterX-adultspam-skip-following-reposts'), ['adultSpam']), knownFollowedHandles: setting([], ['handles', 5000]), notificationSubscriptions: setting([], ['notifications']), notificationSubscriptionsSyncedAt: setting(0, ['timestamp']), adultSpamKeywords: setting([], ['stringList', 50, 80], null, ['adultSpam']), adultSpamWhitelist: setting([], ['handles', 100], null, ['adultSpam']), layoutEnabled: bool(false, bind('layoutEnabledEl', '#BetterX-layout-enabled'), ['layout']), layoutAutoWidth: bool(true, bind('layoutAutoWidthEl', '#BetterX-layout-auto-width'), ['layout']), timelineWidth: setting(600, ['int', 100, 3000], null, ['layout']), leftbarWidth: setting(275, ['int', 50, 500], null, ['layout']), layoutHideLeftbar: bool(false, bind('layoutHideLeftbarEl', '#BetterX-layout-hide-leftbar'), ['layout']), layoutHideSidebar: bool(false, bind('layoutHideSidebarEl', '#BetterX-layout-hide-sidebar'), ['layout']), layoutFillCenter: bool(false, bind('layoutFillCenterEl', '#BetterX-layout-fill-center'), ['layout']), layoutCleanNavigation: bool(true, bind('layoutCleanNavigationEl', '#BetterX-layout-clean-nav'), ['layout']), layoutHideMessageGrok: bool(true, bind('layoutHideMessageGrokEl', '#BetterX-layout-hide-message'), ['layout']), layoutHideShowMore: bool(false, bind('layoutHideShowMoreEl', '#BetterX-layout-hide-showmore'), ['layout']), mediaDownload: bool(true, null, ['mediaDownload']), silentDownload: bool(false, bind('silentDownloadEl', '#BetterX-silent-download'), ['downloadUi']), gifDownloadFormatEnabled: bool(true, bind('gifDownloadFormatEnabledEl', '#BetterX-gif-download-format-enabled')), gifDownloadFormat: setting('mp4', ['enum', ['mp4', 'gif']], bind('gifDownloadFormatEl', '#BetterX-gif-download-format', 'value')), downloadZip: bool(true), downloadAdvancedOpen: bool(false), downloadFileNameTemplate: setting('{用户ID}_{帖子ID}', ['trimmedStringDefault', 180]), downloadZipNameTemplate: setting('{用户ID}_{帖子ID}', ['trimmedStringDefault', 180]), downloadNameRegex: setting('', ['safeRegex']), downloadNameReplacement: setting('', ['string', 180]), trackDownloadedPosts: bool(false), downloadedPostIds: setting([], ['downloadedIds']), bypassAgeRestriction: bool(false, bind('bypassAgeEl', '#BetterX-bypassage'), ['ageBypass']), restoreMediaGrid: bool(false, bind('restoreMediaGridEl', '#BetterX-restore-media-grid'), ['mediaGrid']), firefoxCompatibility: bool(false, null, ['firefoxCompatibility']), firefoxCompatibilityPrompted: bool(false), useMobileBadgeOnDesktop: bool(false, bind('useMobileBadgeOnDesktopEl', '#BetterX-desktop-mobile-badge'), ['badge']), hideAppBadge: setting(false, ['hideAppBadge'], null, ['badge']), useMobileBadgeHandle: setting(false, ['mobileBadgeHandle'], null, ['badge']), mobileBadgeHandleTop: setting(null, ['mobileBadgeTop']), profileDefaultViewEnabled: bool(true, bind('profileDefaultViewEnabledEl', '#BetterX-profile-default-view-enabled')), profileDefaultView: setting('posts', ['enum', PROFILE_DEFAULT_VIEW_OPTIONS], bind('profileDefaultViewEl', '#BetterX-profile-default-view', 'value')), profilePostSortEnabled: bool(true, bind('profilePostSortEnabledEl', '#BetterX-profile-post-sort-enabled')), profilePostSort: setting('recent', ['enum', PROFILE_POST_SORT_OPTIONS], bind('profilePostSortEl', '#BetterX-profile-post-sort', 'value')), autoExpandPostText: bool(false, bind('autoExpandPostTextEl', '#BetterX-auto-expand-post-text'), ['autoExpand']), downloadTimeout: setting(360000, ['int', 5000, 600000]), downloadConcurrency: setting(2, ['int', DOWNLOAD_MIN_CONCURRENCY, DOWNLOAD_MAX_CONCURRENCY]), });
const DEFAULT_SETTINGS = Object.freeze(Object.fromEntries(
  Object.entries(SETTINGS_SCHEMA).map(([key, definition]) => [key, definition.default])
));
const state = {
  dbPromise: null,
  dbWriteQueue: Promise.resolve(),
  posts: [],
  postIndexById: new Map(),
  settings: { ...DEFAULT_SETTINGS },
  searchQuery: '',
  expandedPosts: new Set(),
  editingNoteId: null,
  noteDrafts: new Map(),
  importInProgress: false,
  renderLimit: DEFAULT_SETTINGS.pageSize,
  lastFilteredCount: 0,
  visibleMap: new Map(),
  observer: null,
  viewObserver: null,
  viewedArticleIds: new WeakMap(),
  cleanupTimer: null,
  networkHookTimer: null,
  settingsLoaded: false,
  panelOpen: false,
  panelView: 'vault',
  notificationSearchQuery: '',
  detectedTimelineWidth: 0,
  detectedLeftbarWidth: 0,
  mobileBadgeRaf: 0,
  suppressNextBadgeClick: false,
  notificationSyncInProgress: false,
  notificationMutationUsers: new Set(),
  dbWriteFailureVersion: 0,
  lastDbWriteError: null,
};
let indexedPosts = state.posts;
let indexedPostLength = 0;
let crossTabChannel = null;
let crossTabReloadTimer = null;
let crossTabReloadAllPosts = false;
let crossTabReloadSettings = false;
const crossTabReloadPostIds = new Set();
const settingsWriteGenerations = new Map();
let matchCache = new Map();
let matchCacheVersion = 0;
const autoExpandedPostShowMoreControls = new WeakSet();
let adultSpamCache = new WeakMap();
let adultSpamRulesVersion = 0;
const followedHandles = new Set();
const notificationSubscriptions = new Map();
const notificationMutationGuards = new Map();
const adultSpamScannedIds = new Set();
const adultSpamSessionHiddenIds = new Set();
const adultSpamHiddenArticles = new Set();
let adultSpamScannedIdsCapped = false;
let adultSpamSessionHiddenIdsCapped = false;
let adultSpamScrollToken = 0;
let pageScrollBusyUntil = 0;
let pageScrollTrackingInstalled = false;
let autoExpandIdleTimer = null;
let adultSpamLayoutIdleTimer = null;
const pendingAdultSpamLayoutArticles = new Set();
const scheduleFollowingFilterRefresh = debounce(() => {
  adultSpamRulesVersion++;
  adultSpamCache = new WeakMap();
  if (document.body && state.settings.hideAdultSpam && state.settings.adultSpamSkipFollowing) {
    applyAdultSpamFiltering();
  } else {
    updateAdultSpamCount();
  }
}, 250);
const scheduleFollowedHandlesPersist = debounce(() => {
  if (!state.settingsLoaded) return;
  state.settings.knownFollowedHandles = [...followedHandles].sort().slice(0, MAX_FOLLOWED_HANDLES);
  queueSettingsPersist(['knownFollowedHandles']);
}, 750);
const scheduleNotificationSubscriptionsPersist = debounce(() => {
  if (!state.settingsLoaded) return;
  state.settings.notificationSubscriptions = [...notificationSubscriptions.values()]
    .sort((a, b) => Number(b.pinned === true) - Number(a.pinned === true)
      || Number(b.enabled) - Number(a.enabled) || (b.updatedAt || 0) - (a.updatedAt || 0))
    .slice(0, MAX_NOTIFICATION_SUBSCRIPTIONS);
  queueSettingsPersist(['notificationSubscriptions', 'notificationSubscriptionsSyncedAt']);
  renderNotificationSubscriptions();
}, 500);
function trimFollowedHandlesToMax() {
  while (followedHandles.size > MAX_FOLLOWED_HANDLES) {
    followedHandles.delete(followedHandles.values().next().value);
  }
}
function rememberFollowingRelation(handle, following) {
  const normalized = String(handle || '').replace(/^@+/, '').toLowerCase();
  if (!/^[a-z0-9_]{1,15}$/.test(normalized) || typeof following !== 'boolean') return false;
  const hadHandle = followedHandles.has(normalized);
  if (following) {
    if (!hadHandle && followedHandles.size >= MAX_FOLLOWED_HANDLES) {
      followedHandles.delete(followedHandles.values().next().value);
    }
    followedHandles.add(normalized);
  }
  else followedHandles.delete(normalized);
  if (hadHandle === following) return false;
  scheduleFollowingFilterRefresh();
  scheduleFollowedHandlesPersist();
  return true;
}
function addBoundedSessionStat(target, value, capFlag) {
  if (!value || target.has(value)) return capFlag;
  if (target.size >= MAX_SESSION_STAT_IDS) return true;
  target.add(value);
  return capFlag;
}
function now() { return Date.now(); }
function debugLog(...args) {
  if (DEBUG) console.debug('[BetterX]', ...args);
}
function clampInt(v, min, max, fallback) {
  const n = parseInt(v, 10);
  if (isNaN(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}
function escapeHtml(str) {
  return String(str == null ? '' : str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function escapeRegExp(str) {
  return String(str || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
function uniqueStrings(list) {
  return [...new Set((list || []).filter(Boolean))];
}
function safeString(value, maxLength) {
  if (typeof value !== 'string') return '';
  return value.slice(0, maxLength || 1000);
}
function safeHttpsUrl(value, allowedHosts) {
  if (typeof value !== 'string' || !value) return '';
  try {
    const u = new URL(value);
    if (u.protocol !== 'https:') return '';
    const host = u.hostname.toLowerCase();
    if (allowedHosts && !allowedHosts.some((allowed) => host === allowed || host.endsWith('.' + allowed))) return '';
    return u.toString();
  } catch { return ''; }
}
function safeImportedAssetUrl(value) {
  return safeHttpsUrl(value, ['twimg.com']);
}
function sanitizeNotificationSubscription(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const id = safeString(raw.id, 30).trim();
  const username = safeString(raw.username, 30).replace(/^@+/, '').trim();
  if (!/^\d{1,30}$/.test(id) || !/^[a-z0-9_]{1,15}$/i.test(username)) return null;
  const updatedAt = Number(raw.updatedAt);
  const item = {
    id,
    username,
    displayName: safeString(raw.displayName, 100).trim(),
    avatarUrl: safeImportedAssetUrl(raw.avatarUrl),
    enabled: raw.enabled !== false,
    updatedAt: Number.isFinite(updatedAt) ? Math.max(0, Math.min(Number.MAX_SAFE_INTEGER, Math.floor(updatedAt))) : now(),
  };
  if (typeof raw.pinned === 'boolean') item.pinned = raw.pinned;
  return item;
}
function getNotificationMutationGuard(key) {
  const guard = notificationMutationGuards.get(key);
  if (!guard) return null;
  if (!guard.pending && guard.expiresAt <= now()) {
    notificationMutationGuards.delete(key);
    return null;
  }
  return guard;
}
function beginNotificationMutationGuard(key, enabled) {
  const timestamp = now();
  for (const [username, guard] of notificationMutationGuards) {
    if (!guard.pending && guard.expiresAt <= timestamp) notificationMutationGuards.delete(username);
  }
  const guard = {
    enabled: enabled === true,
    pending: true,
    expiresAt: timestamp + NOTIFICATION_MUTATION_GUARD_MS,
  };
  if (notificationMutationGuards.has(key)) notificationMutationGuards.delete(key);
  notificationMutationGuards.set(key, guard);
  while (notificationMutationGuards.size > MAX_NOTIFICATION_SUBSCRIPTIONS) {
    notificationMutationGuards.delete(notificationMutationGuards.keys().next().value);
  }
  return guard;
}
function rememberNotificationSubscription(raw, enabled, options) {
  const input = sanitizeNotificationSubscription({ ...raw, enabled, updatedAt: now() });
  if (!input) return false;
  const key = input.username.toLowerCase();
  const opts = options || {};
  const guard = getNotificationMutationGuard(key);
  if (guard && opts.authoritative !== true
      && (guard.pending || guard.enabled !== (enabled === true))) return false;
  const existing = notificationSubscriptions.get(key);
  if (!enabled && !existing && !opts.trackDisabled) return false;
  const next = {
    ...(existing || {}),
    ...input,
    displayName: input.displayName || (existing && existing.displayName) || '',
    avatarUrl: input.avatarUrl || (existing && existing.avatarUrl) || '',
    enabled: enabled === true,
    updatedAt: now(),
  };
  const changed = !existing || existing.id !== next.id || existing.username !== next.username
    || existing.displayName !== next.displayName || existing.avatarUrl !== next.avatarUrl
    || existing.enabled !== next.enabled;
  if (!changed) return false;
  notificationSubscriptions.set(key, next);
  if (next.enabled) rememberFollowingRelation(next.username, true);
  scheduleNotificationSubscriptionsPersist();
  return true;
}
function removeRememberedNotificationSubscription(username) {
  const key = safeString(username, 30).replace(/^@+/, '').toLowerCase();
  if (!notificationSubscriptions.delete(key)) return false;
  scheduleNotificationSubscriptionsPersist();
  return true;
}
function toggleNotificationSubscriptionPinned(username) {
  const key = safeString(username, 30).replace(/^@+/, '').toLowerCase();
  const existing = notificationSubscriptions.get(key);
  if (!existing) return false;
  const pinned = existing.pinned !== true;
  notificationSubscriptions.set(key, { ...existing, pinned });
  scheduleNotificationSubscriptionsPersist();
  renderNotificationSubscriptions();
  showToast(pinned ? `📌 已置顶 @${existing.username}` : `已取消置顶 @${existing.username}`);
  return true;
}
function notificationMatchesSearch(item, query) {
  const terms = safeString(query, 120).trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  if (!terms.length) return true;
  const username = safeString(item && item.username, 30).toLocaleLowerCase();
  const displayName = safeString(item && item.displayName, 100).toLocaleLowerCase();
  const haystack = `${displayName}\n${username}\n@${username}`;
  return terms.every((term) => haystack.includes(term));
}
function applyNotificationSearch() {
  const value = state.notificationSearchEl ? state.notificationSearchEl.value : '';
  state.notificationSearchQuery = safeString(value, 120).trim();
  renderNotificationSubscriptions();
}
function safeImportedStatusUrl(value, expectedId) {
  const safe = safeHttpsUrl(value, ['x.com', 'twitter.com']);
  return safe && extractStatusIdFromUrl(safe) === String(expectedId) ? safe : '';
}
function parseKeywords(raw) {
  return uniqueStrings(
    String(raw || '')
      .split(/[,\n，]+/)
      .map((s) => s.trim().slice(0, 500))
      .filter(Boolean)
  ).slice(0, 50);
}
function parseKeywordRules(raw) {
  const values = [];
  let current = '';
  let inRegex = false;
  let escaped = false;
  const pushCurrent = () => {
    const value = current.trim().slice(0, 500);
    if (value) values.push(value);
    current = '';
    inRegex = false;
    escaped = false;
  };
  for (const ch of String(raw || '')) {
    if (inRegex) {
      current += ch;
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === '/') inRegex = false;
      continue;
    }
    if (ch === ',' || ch === '，' || ch === '\n') {
      if (current.trim()) pushCurrent();
      continue;
    }
    current += ch;
    if (ch === '/' && current.trim() === '/') inRegex = true;
  }
  pushCurrent();
  return uniqueStrings(values).slice(0, 50);
}
function debounce(fn, delay) {
  let timer = null;
  return function (...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), delay);
  };
}
function throttle(fn, interval) {
  let last = 0;
  return function (...args) {
    const t = Date.now();
    if (t - last >= interval) {
      last = t;
      fn.apply(this, args);
    }
  };
}
function monotonicNow() {
  return typeof performance !== 'undefined' && typeof performance.now === 'function'
    ? performance.now()
    : Date.now();
}
function markPageScrollBusy(duration) {
  pageScrollBusyUntil = Math.max(
    pageScrollBusyUntil,
    monotonicNow() + Math.max(PAGE_SCROLL_SETTLE_MS, Number(duration) || 0)
  );
  adultSpamScrollToken++;
}
function isPageScrollBusy() {
  return monotonicNow() < pageScrollBusyUntil;
}
function installPageScrollActivityTracking() {
  if (pageScrollTrackingInstalled) return;
  pageScrollTrackingInstalled = true;
  const markWheel = () => markPageScrollBusy(320);
  const markTouch = () => markPageScrollBusy(700);
  const markTouchEnd = () => markPageScrollBusy(900);
  const markScroll = () => markPageScrollBusy(PAGE_SCROLL_SETTLE_MS);
  window.addEventListener('wheel', markWheel, { passive: true, capture: true });
  window.addEventListener('touchstart', markTouch, { passive: true, capture: true });
  window.addEventListener('touchmove', markTouch, { passive: true, capture: true });
  window.addEventListener('touchend', markTouchEnd, { passive: true, capture: true });
  window.addEventListener('touchcancel', markTouchEnd, { passive: true, capture: true });
  window.addEventListener('scroll', markScroll, { passive: true, capture: true });
  document.addEventListener('scroll', markScroll, { passive: true, capture: true });
}
function schedulePostShowMoreExpansion() {
  if (autoExpandIdleTimer) clearTimeout(autoExpandIdleTimer);
  const run = () => {
    const remaining = pageScrollBusyUntil - monotonicNow();
    if (remaining > 0) {
      autoExpandIdleTimer = setTimeout(run, Math.ceil(remaining) + 60);
      return;
    }
    autoExpandIdleTimer = null;
    if (state.settings.autoExpandPostText) expandPostShowMore(document);
  };
  const remaining = Math.max(0, pageScrollBusyUntil - monotonicNow());
  autoExpandIdleTimer = setTimeout(run, Math.max(100, Math.ceil(remaining) + 60));
}
function scheduleAdultSpamLayoutFlush(article) {
  if (article) pendingAdultSpamLayoutArticles.add(article);
  if (adultSpamLayoutIdleTimer) return;
  const run = () => {
    const remaining = pageScrollBusyUntil - monotonicNow();
    if (remaining > 0) {
      adultSpamLayoutIdleTimer = setTimeout(run, Math.ceil(remaining) + 60);
      return;
    }
    adultSpamLayoutIdleTimer = null;
    const articles = [...pendingAdultSpamLayoutArticles].filter((item) => item && item.isConnected);
    pendingAdultSpamLayoutArticles.clear();
    if (!articles.length) return;
    const anchors = captureAdultSpamScrollAnchors();
    let layoutChanged = false;
    for (const item of articles) {
      if (adultSpamFilteringEnabled()) {
        const outcome = {};
        evaluateAndApplyAdultSpam(item, outcome, false);
        if (outcome.changed) layoutChanged = true;
      } else {
        const applied = setAdultSpamHidden(item, { hidden: false, score: 0, reasons: [] });
        if (applied.changed) layoutChanged = true;
      }
    }
    if (layoutChanged) stabilizeAdultSpamScroll(anchors);
    updateAdultSpamCount();
  };
  const remaining = Math.max(0, pageScrollBusyUntil - monotonicNow());
  adultSpamLayoutIdleTimer = setTimeout(run, Math.max(100, Math.ceil(remaining) + 60));
}
const debouncedRefreshUI = debounce(() => {
  if (!state.panelOpen) { refreshBadge(); return; }
  if (state.panelView === 'vault' && state.editingNoteId) { refreshBadge(); return; }
  refreshUI({ keepScroll: true });
}, 120);
const TIME_FORMATTER = new Intl.DateTimeFormat(UI_LANGUAGE, { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false, });
function formatTime(ts) {
  if (!ts) return '-';
  try {
    const date = new Date(ts);
    return Number.isFinite(date.getTime()) ? TIME_FORMATTER.format(date) : '-';
  } catch { return '-'; }
}
function normalizeUrl(url) {
  if (!url) return '';
  try {
    const u = new URL(url, location.origin);
    u.hash = '';
    return u.toString();
  } catch { return url; }
}
function extractStatusIdFromUrl(url) {
  const match = String(url || '').match(/\/status\/(\d+)/);
  return match ? match[1] : null;
}
const RESERVED_TOP_PATHS = new Set([ 'home', 'explore', 'search', 'notifications', 'messages', 'i', 'settings', 'compose', 'bookmarks', 'communities', 'jobs', 'premium', 'tos', 'privacy', 'login', 'signup', 'intent', ]);
function getActiveTabText() {
  const selectedTab = [...document.querySelectorAll(
    '[role="tab"][aria-selected="true"], [data-testid="ScrollSnap-List"] [aria-selected="true"]'
  )].find((tab) => !tab.closest('#BetterX-root'));
  return (selectedTab?.innerText || selectedTab?.textContent || '').trim();
}
function getHistorySourceInfo(path) {
  const route = String(path || '').split(/[?#]/)[0].replace(/\/+$/, '').toLowerCase();
  if (route === '/i/history/likes') return { type: 'likes', label: 'Likes' };
  if (route === '/i/history') return { type: 'bookmarks', label: 'Bookmarks' };
  return null;
}
function normalizeSourceLabel(value) {
  const label = safeString(value, 100).trim();
  if (/^(?:home|主页)$/i.test(label) || /^\/compose\/post(?:[/?#]|$)/i.test(label)) return '';
  const historySource = getHistorySourceInfo(label);
  if (historySource) return historySource.label;
  if (label !== 'Unknown' && Object.prototype.hasOwnProperty.call(SOURCE_EXACT_LABELS, label)) return label;
  if (/^(?:Profile|Thread)\s+@[A-Za-z0-9_]{1,15}$/i.test(label)) return label;
  return '';
}
function normalizePostSourceFields(raw) {
  const historySource = getHistorySourceInfo(raw.capturedPath) || getHistorySourceInfo(raw.sourceLabel);
  const sourceHistory = uniqueStrings(
    (Array.isArray(raw.sourceHistory) ? raw.sourceHistory : []).map(normalizeSourceLabel).filter(Boolean)
  ).slice(-8);
  const previousLabel = safeString(raw.sourceLabel, 100).trim();
  const restorePrevious = /^(?:home|主页)$/i.test(previousLabel) || /^\/compose\/post(?:[/?#]|$)/i.test(previousLabel);
  const sourceLabel = historySource?.label || normalizeSourceLabel(previousLabel)
    || (restorePrevious ? sourceHistory.at(-1) : '') || '';
  return {
    sourceType: historySource?.type || safeString(raw.sourceType, 50),
    sourceLabel,
    sourceHistory: uniqueStrings([...sourceHistory, sourceLabel].filter(Boolean)).slice(-8),
  };
}
function getCurrentSourceInfo() {
  const path = location.pathname || '/';
  const lower = path.toLowerCase().replace(/\/+$/, '') || '/';
  const search = location.search || '';
  if (lower === '/compose/post') return { type: 'compose', label: '' };
  const historySource = getHistorySourceInfo(path);
  if (historySource) return historySource;
  if (lower === '/' || lower === '/home') {
    const activeTabText = getActiveTabText().toLowerCase();
    if (/following|正在关注|正在關注|關注中|关注中|フォロー中/.test(activeTabText)) return { type: 'following', label: 'Following' };
    if (/for you|为你推荐|推薦|為你|おすすめ/.test(activeTabText)) return { type: 'for_you', label: 'For You' };
    return { type: 'home', label: '' };
  }
  if (lower.startsWith('/search') || lower.startsWith('/explore') || /[?&]q=/.test(search)) return { type: 'search', label: 'Search' };
  if (lower.includes('/i/lists/')) return { type: 'list', label: 'List' };
  if (lower.includes('/notifications')) return { type: 'notifications', label: 'Notifications' };
  if (/^\/[^/]+\/status\/\d+/i.test(path)) {
    const user = path.split('/').filter(Boolean)[0];
    return { type: 'thread', label: `Thread @${user}` };
  }
  const firstSeg = path.split('/').filter(Boolean)[0];
  if (firstSeg && !RESERVED_TOP_PATHS.has(firstSeg.toLowerCase())) return { type: 'profile', label: `Profile @${firstSeg}` };
  return { type: 'page', label: '' };
}
function getStatusLink(article) {
  const anchors = [...article.querySelectorAll('a[href*="/status/"]')];
  if (!anchors.length) return null;
  const best = anchors.find((a) => /\/status\/\d+($|\?)/.test(a.getAttribute('href') || '')) || anchors[0];
  const href = best.getAttribute('href');
  if (!href) return null;
  return normalizeUrl(new URL(href, location.origin).toString());
}
function sanitizeDisplayName(raw, username) {
  let text = String(raw || '').trim();
  if (!text) return '';
  if (text.includes('\n')) {
    text = text.split('\n')[0].trim();
  }
  if (username) {
    const handleClean = username.replace(/^@+/, '');
    const re = new RegExp('\\s*@?' + handleClean + '($|\\s.*)', 'i');
    text = text.replace(re, '').trim();
  }
  text = text.replace(/\s*[·•\u00B7\u2022]\s*.*$/, '').trim();
  return text;
}
function cleanAuthorInfo(rawDisplayName, rawUsername, rawTimeLabel) {
  let displayName = String(rawDisplayName || '').trim();
  let username = String(rawUsername || '').trim();
  let timeLabel = String(rawTimeLabel || '').trim();
  if (displayName.includes('\n')) {
    const lines = displayName.split('\n').map((s) => s.trim()).filter(Boolean);
    displayName = lines[0] || '';
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i];
      if (line.startsWith('@') && !username) {
        username = line;
      } else if (line === '·' || line === '•' || line === '\u00B7') {
        if (i + 1 < lines.length && !timeLabel) {
          timeLabel = lines[i + 1];
        }
      } else if (!timeLabel && (/\d+[年月日smhdw]/i.test(line) || /^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)/i.test(line))) {
        timeLabel = line;
      }
    }
  }
  displayName = sanitizeDisplayName(displayName, username);
  if (username && !username.startsWith('@')) {
    username = `@${username}`;
  }
  if (timeLabel) {
    timeLabel = timeLabel.replace(/^[·•\u00B7\u2022\s]+|[·•\u00B7\u2022\s]+$/g, '').trim();
  }
  return {
    displayName: displayName || username,
    username,
    timeLabel,
  };
}
function extractAuthor(article) {
  const text = (article.innerText || '').trim();
  const lines = text.split('\n').map((s) => s.trim()).filter(Boolean);
  let username = '';
  const statusLink = article.querySelector('a[href*="/status/"]');
  if (statusLink) {
    const parts = (statusLink.getAttribute('href') || '').split('/').filter(Boolean);
    if (parts.length >= 1 && parts[0] !== 'i') username = `@${parts[0]}`;
  }
  const userNameNode =
    article.querySelector('[data-testid="User-Name"]') ||
    article.querySelector('div[dir="ltr"] span');
  const nameLink = userNameNode?.querySelector('a[role="link"], a[href^="/"]');
  let rawDisplayName = '';
  if (nameLink) {
    const dirLtr = nameLink.querySelector('div[dir="ltr"]') || nameLink.querySelector('span');
    rawDisplayName = (dirLtr?.innerText || dirLtr?.textContent || nameLink.innerText || nameLink.textContent || '').trim();
  }
  if (!rawDisplayName && userNameNode) {
    const leafTexts = [...userNameNode.querySelectorAll('span')]
      .filter((node) => !node.querySelector('span'))
      .map((node) => (node.innerText || node.textContent || '').trim())
      .filter(Boolean);
    rawDisplayName = leafTexts.find((value) => (
      value !== username && value !== username.replace(/^@/, '') && value !== '·' && value !== '•'
    )) || (userNameNode.innerText || '').split('\n')[0].trim() || lines[0] || '';
  }
  if (!rawDisplayName) {
    rawDisplayName = lines[0] || '';
  }
  const timeNode = userNameNode?.querySelector('time') || article.querySelector('time');
  const rawTimeLabel = (timeNode?.innerText || timeNode?.textContent || '').trim();
  return cleanAuthorInfo(rawDisplayName, username, rawTimeLabel);
}
function extractText(article) {
  const nodes = [...article.querySelectorAll('[data-testid="tweetText"]')];
  let merged = nodes.map((el) => (el.innerText || '').trim()).filter(Boolean).join('\n');
  if (!merged) {
    const langNode = article.querySelector('div[lang]');
    merged = (langNode?.innerText || '').trim();
  }
  return (merged || '').slice(0, MAX_CAPTURED_POST_TEXT_LENGTH);
}
const VIDEO_CONTAINER_SELECTORS = [ '[data-testid="videoPlayer"]', '[data-testid="videoComponent"]', '[data-testid="playButton"]', '[data-testid="app-player-container"]', '[data-testid="preview-image"]', '[data-testid="card.layoutLarge.media"]', '[data-testid="card.layoutSmall.media"]', '[data-testid="placementTracking"]', 'div[aria-label*="播放"]', 'div[aria-label*="Play"]', 'div[aria-label*="视频"]', 'div[aria-label*="Video"]', 'div[aria-label*="GIF"]', 'div[aria-label*="动图"]', 'div[role="progressbar"]', 'button[aria-label*="播放"]', 'button[aria-label*="Play"]', ].join(', ');
const MEDIA_ASSET_RE = /pbs\.twimg\.com\/(?:media|ext_tw_video_thumb|amplify_tw_video_thumb|amplify_video_thumb|tweet_video_thumb)\//;
function isVideoPreviewImage(img, article) {
  if (!img) return false;
  const src = img.getAttribute('src') || '';
  if (/(?:ext_tw_video_thumb|amplify_tw_video_thumb|amplify_video_thumb|tweet_video_thumb)/i.test(src)) return true;
  if (img.closest && img.closest(VIDEO_CONTAINER_SELECTORS)) return true;
  let container = img.parentElement;
  for (let depth = 0; container && depth < 6 && container !== article && container.tagName !== 'ARTICLE'; depth++, container = container.parentElement) {
    if (container.querySelector && container.querySelector(`video, ${VIDEO_CONTAINER_SELECTORS}`)) return true;
  }
  return false;
}
function detectMedia(article, statusId) {
  const thumbs = [];
  const idKey = statusId ? String(statusId) : '';
  if (idKey) {
    for (const registry of [mediaRegistry, cardRegistry]) {
      const reg = getRegistryEntry(registry, idKey);
      if (!reg || !(reg.photos.length || reg.videos.length || reg.gifs.length)) continue;
      const hasImage = reg.photos.length > 0;
      const hasVideo = reg.videos.length > 0 || reg.gifs.length > 0;
      reg.photos.forEach((u) => { if (thumbs.length < 4) thumbs.push(u); });
      if (!hasImage && hasVideo) {
        if (registry === mediaRegistry) {
          for (const video of article.querySelectorAll('video')) {
            const poster = video.getAttribute('poster') || '';
            if (poster && thumbs.length < 4) thumbs.push(poster);
          }
        }
        for (const img of article.querySelectorAll('img[src]')) {
          const src = img.getAttribute('src') || '';
          if (MEDIA_ASSET_RE.test(src) && thumbs.length < 4) thumbs.push(src);
        }
      }
      return { hasImage, hasVideo, thumbs: uniqueStrings(thumbs).slice(0, 4) };
    }
  }
  const videos = [...article.querySelectorAll('video')];
  let hasVideo = videos.length > 0 || !!article.querySelector(VIDEO_CONTAINER_SELECTORS);
  let photoCount = 0;
  for (const video of videos) {
    const poster = video.getAttribute('poster') || '';
    if (poster && thumbs.length < 4) thumbs.push(poster);
  }
  for (const img of article.querySelectorAll('img[src]')) {
    const src = img.getAttribute('src') || '';
    if (/profile_images|emoji|hashflags/i.test(src)) continue;
    const isMediaAsset = MEDIA_ASSET_RE.test(src) || /\/media\//.test(src);
    if (!isMediaAsset) continue;
    if (isVideoPreviewImage(img, article)) {
      hasVideo = true;
    } else {
      photoCount++;
    }
    if (thumbs.length < 4) thumbs.push(src);
  }
  const hasImage = photoCount > 0;
  return { hasImage, hasVideo, thumbs: uniqueStrings(thumbs).slice(0, 4) };
}
function extractAvatar(article) {
  const img = article.querySelector('img[src*="profile_images"]');
  return img ? (img.getAttribute('src') || '') : '';
}
function bumpKeywordCache() {
  matchCacheVersion++;
  matchCache = new Map();
}
function buildHaystack(post) {
  return [
    post.displayName || '',
    post.username || '',
    post.text || '',
    post.sourceLabel || '',
    ...(post.sourceHistory || []),
  ].join('\n');
}
function readRegexQuantifier(source, index) {
  const ch = source[index];
  if (ch === '*') return { end: index, min: 0, max: Infinity, unbounded: true, unsafe: false };
  if (ch === '+') return { end: index, min: 1, max: Infinity, unbounded: true, unsafe: false };
  if (ch === '?') return { end: index, min: 0, max: 1, unbounded: false, unsafe: false };
  if (ch !== '{') return null;
  const match = source.slice(index).match(/^\{(\d+)(?:,(\d*))?\}/);
  if (!match) return null;
  const min = Number(match[1]);
  const hasComma = match[2] !== undefined;
  const max = !hasComma ? min : (match[2] === '' ? Infinity : Number(match[2]));
  return {
    end: index + match[0].length - 1,
    min,
    max,
    unbounded: max === Infinity,
    unsafe: min > MAX_REGEX_BOUNDED_REPETITION
      || (Number.isFinite(max) && max > MAX_REGEX_BOUNDED_REPETITION),
  };
}
function literalMatchesRegexCategory(value, category) {
  if (category === 'digit') return /^[0-9]$/.test(value);
  if (category === 'word') return /^[A-Za-z0-9_]$/.test(value);
  if (category === 'space') return /^\s$/.test(value);
  if (category === 'not-digit') return !/^[0-9]$/.test(value);
  if (category === 'not-word') return !/^[A-Za-z0-9_]$/.test(value);
  if (category === 'not-space') return !/^\s$/.test(value);
  return true;
}
function simplePositiveRegexClassMatcher(atom) {
  if (!atom || atom.kind !== 'class' || !/^\[(?!\^)/.test(atom.value)) return null;
  if ([...atom.value].some((ch) => ch.charCodeAt(0) > 0x7F) || /\\[pPxXuU]/.test(atom.value)) return null;
  try { return new RegExp(`^(?:${atom.value})$`, 'i'); } catch (err) { return null; }
}
function regexAtomsDefinitelyDisjoint(left, right) {
  if (!left || !right) return false;
  if (left.kind === 'literal' && right.kind === 'literal') return left.value.toLowerCase() !== right.value.toLowerCase();
  if (left.kind === 'literal' && right.kind === 'category') {
    return !literalMatchesRegexCategory(left.value, right.value);
  }
  if (left.kind === 'category' && right.kind === 'literal') {
    return !literalMatchesRegexCategory(right.value, left.value);
  }
  if (left.kind === 'class' && right.kind === 'class') {
    const leftMatcher = simplePositiveRegexClassMatcher(left);
    const rightMatcher = simplePositiveRegexClassMatcher(right);
    if (leftMatcher && rightMatcher) {
      for (let code = 0; code <= 0x7F; code++) {
        const value = String.fromCharCode(code);
        if (leftMatcher.test(value) && rightMatcher.test(value)) return false;
      }
      return true;
    }
  }
  if (left.kind !== 'category' || right.kind !== 'category') return false;
  const pair = `${left.value}|${right.value}`;
  return new Set([
    'digit|space', 'space|digit', 'digit|not-digit', 'not-digit|digit',
    'word|space', 'space|word', 'word|not-word', 'not-word|word',
    'space|not-space', 'not-space|space',
  ]).has(pair);
}
function hasRiskyAdjacentRegexQuantifiers(source) {
  const contexts = [{ variableAtoms: [], inheritedAtoms: [], branchAtoms: [], groupStart: -1 }];
  const currentContext = () => contexts[contexts.length - 1];
  let inClass = false;
  let classStart = -1;
  let escapedInClass = false;
  for (let i = 0; i < source.length; i++) {
    const ch = source[i];
    let atom = null;
    if (inClass) {
      if (escapedInClass) { escapedInClass = false; continue; }
      if (ch === '\\') { escapedInClass = true; continue; }
      if (ch !== ']') continue;
      inClass = false;
      atom = { kind: 'class', value: source.slice(classStart, i + 1) };
    } else if (ch === '[') {
      inClass = true;
      classStart = i;
      continue;
    } else if (ch === '\\') {
      if (i + 1 >= source.length) return true;
      const escaped = source[++i];
      if (escaped === 'b' || escaped === 'B') continue;
      if ('dDwWsS'.includes(escaped)) {
        const names = { d: 'digit', D: 'not-digit', w: 'word', W: 'not-word', s: 'space', S: 'not-space' };
        atom = { kind: 'category', value: names[escaped] };
      } else if ((escaped === 'p' || escaped === 'P') && source[i + 1] === '{') {
        const end = source.indexOf('}', i + 2);
        if (end < 0) return true;
        atom = { kind: 'class', value: source.slice(i - 1, end + 1) };
        i = end;
      } else if (escaped === 'x' && /^[0-9a-f]{2}/i.test(source.slice(i + 1, i + 3))) {
        atom = { kind: 'escape', value: source.slice(i - 1, i + 3) };
        i += 2;
      } else if (escaped === 'u' && /^[0-9a-f]{4}/i.test(source.slice(i + 1, i + 5))) {
        atom = { kind: 'escape', value: source.slice(i - 1, i + 5) };
        i += 4;
      } else if (escaped === 'c' && /^[a-z]$/i.test(source[i + 1] || '')) {
        atom = { kind: 'escape', value: source.slice(i - 1, i + 2) };
        i++;
      } else {
        atom = { kind: 'literal', value: escaped };
      }
    } else if (ch === '(') {
      const inheritedAtoms = [...currentContext().variableAtoms];
      const prefix = source.slice(i + 1).match(/^\?(?::|=|!|<=|<!|<[A-Za-z_$][\w$]*>)/)?.[0] || '';
      if (source[i + 1] === '?' && !prefix) return true;
      contexts.push({
        variableAtoms: [...inheritedAtoms], inheritedAtoms, branchAtoms: [], groupStart: i,
        zeroWidth: /^\?(?:[=!]|<[=!])/.test(prefix),
      });
      i += prefix.length;
      continue;
    } else if (ch === ')') {
      if (contexts.length <= 1) continue;
      const closed = contexts.pop();
      const quantified = readRegexQuantifier(source, i + 1);
      currentContext().variableAtoms = [...new Set([
        ...(quantified || closed.zeroWidth ? closed.inheritedAtoms : []),
        ...closed.branchAtoms, ...closed.variableAtoms,
      ])];
      atom = { kind: 'group', value: source.slice(closed.groupStart, i + 1) };
    } else if (ch === '|') {
      const context = currentContext();
      context.branchAtoms.push(...context.variableAtoms);
      context.variableAtoms = [...context.inheritedAtoms];
      continue;
    } else if (ch === '^' || ch === '$') {
      continue;
    } else if (ch === '.') {
      atom = { kind: 'any', value: '.' };
    } else if (ch === '*' || ch === '+' || ch === '?' || ch === '{') {
      continue;
    } else {
      atom = { kind: 'literal', value: ch };
    }
    if (!atom) continue;
    const quantifier = readRegexQuantifier(source, i + 1);
    if (!quantifier) {
      currentContext().variableAtoms = currentContext().variableAtoms
        .filter((previous) => !regexAtomsDefinitelyDisjoint(previous, atom));
      continue;
    }
    if (quantifier.unsafe) return true;
    const context = currentContext();
    const isVariable = quantifier.min !== quantifier.max;
    if (isVariable && context.variableAtoms.some((previous) => !regexAtomsDefinitelyDisjoint(previous, atom))) {
      return true;
    }
    if (quantifier.min > 0) {
      context.variableAtoms = context.variableAtoms
        .filter((previous) => !regexAtomsDefinitelyDisjoint(previous, atom));
    }
    if (isVariable) context.variableAtoms.push(atom);
    i = quantifier.end;
    if (source[i + 1] === '?') i++;
  }
  return false;
}
function isSafeRegexSource(src) {
  const text = String(src || '');
  if (!text || text.length > MAX_REGEX_SOURCE_LENGTH) return false;
  if (/\\(?:[1-9][0-9]*|0[0-9]|k<)/.test(text)) return false;
  if (hasRiskyAdjacentRegexQuantifiers(text)) return false;
  const stack = [{ hasRepeat: false, hasAlternation: false }];
  let escaped = false;
  let inClass = false;
  const quantifierAt = (index) => {
    const ch = text[index];
    if (ch === '*' || ch === '+' || ch === '?') return true;
    if (ch !== '{') return false;
    return /^\{\d+(?:,\d*)?\}/.test(text.slice(index));
  };
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (escaped) { escaped = false; continue; }
    if (ch === '\\') { escaped = true; continue; }
    if (inClass) { if (ch === ']') inClass = false; continue; }
    if (ch === '[') { inClass = true; continue; }
    if (ch === '(') { stack.push({ hasRepeat: false, hasAlternation: false }); continue; }
    if (ch === '|') { stack[stack.length - 1].hasAlternation = true; continue; }
    if (ch === ')' && stack.length > 1) {
      const group = stack.pop();
      const repeated = quantifierAt(i + 1);
      if (repeated && (group.hasRepeat || group.hasAlternation)) return false;
      const parent = stack[stack.length - 1];
      parent.hasRepeat ||= repeated || group.hasRepeat;
      parent.hasAlternation ||= group.hasAlternation;
      continue;
    }
    if (ch === '?' && text[i - 1] === '(') continue;
    if (quantifierAt(i)) stack[stack.length - 1].hasRepeat = true;
  }
  if (stack.length !== 1 || inClass || escaped) return false;
  try {
    new RegExp(text);
    return true;
  } catch {
    return false;
  }
}
function safeRegex(src, flags) {
  if (!isSafeRegexSource(src)) return null;
  try { return new RegExp(src, flags); } catch { return null; }
}
function getDelimitedRegexSource(value) {
  const text = String(value || '').trim();
  return text.length >= 3 && text.startsWith('/') && text.endsWith('/') ? text.slice(1, -1) : null;
}
function isSafeKeywordRule(value) {
  const source = getDelimitedRegexSource(value);
  return source === null || isSafeRegexSource(source);
}
const keywordRuleCache = new Map();
function getCompiledKeywordRule(rule) {
  const key = String(rule || '');
  const cached = keywordRuleCache.get(key);
  if (cached) return cached;
  const source = getDelimitedRegexSource(key);
  const compiled = source === null
    ? { literal: key.toLowerCase(), regex: null }
    : { literal: null, regex: safeRegex(source, 'i') };
  keywordRuleCache.set(key, compiled);
  if (keywordRuleCache.size > 200) keywordRuleCache.delete(keywordRuleCache.keys().next().value);
  return compiled;
}
function keywordRuleMatches(rule, haystack, lowerHaystack) {
  const compiled = getCompiledKeywordRule(rule);
  return compiled.literal !== null
    ? lowerHaystack.includes(compiled.literal)
    : !!(compiled.regex && compiled.regex.test(haystack));
}
function computeMatchedKeywords(post) {
  const cached = matchCache.get(post.id);
  if (cached && cached.v === matchCacheVersion) return cached.matched;
  const keywords = state.settings.keywords || [];
  const mode = state.settings.keywordMode === 'and' ? 'and' : 'plain';
  let matched = [];
  if (keywords.length) {
    const haystack = buildHaystack(post).slice(0, MAX_REGEX_HAYSTACK_LENGTH);
    const lower = haystack.toLowerCase();
    if (mode === 'and') {
      const all = keywords.every((kw) => keywordRuleMatches(kw, haystack, lower));
      matched = all ? [...keywords] : [];
    } else {
      matched = keywords.filter((kw) => keywordRuleMatches(kw, haystack, lower));
    }
  }
  matchCache.set(post.id, { v: matchCacheVersion, matched });
  return matched;
}
function matchesExclude(post) {
  const ex = state.settings.excludeKeywords || [];
  if (!ex.length) return false;
  const haystack = buildHaystack(post).slice(0, MAX_REGEX_HAYSTACK_LENGTH);
  const lower = haystack.toLowerCase();
  return ex.some((kw) => keywordRuleMatches(kw, haystack, lower));
}
function highlightText(rawText, matchedKeywords) {
  const text = rawText || '';
  const usable = uniqueStrings(matchedKeywords || []).filter(Boolean);
  if (!usable.length) return escapeHtml(text).replace(/\n/g, '<br>');
  const parts = [...usable]
    .sort((a, b) => b.length - a.length)
    .map((rule) => getDelimitedRegexSource(rule) ?? escapeRegExp(rule))
    .filter((source) => safeRegex(source, ''));
  const combined = parts.length ? safeRegex(`(${parts.join('|')})`, 'gi') : null;
  if (!combined) return escapeHtml(text).replace(/\n/g, '<br>');
  let out = '';
  let lastIndex = 0;
  let m;
  combined.lastIndex = 0;
  while ((m = combined.exec(text)) !== null) {
    if (m[0].length === 0) { combined.lastIndex++; continue; }
    out += escapeHtml(text.slice(lastIndex, m.index));
    out += `<mark class="BetterX-hl">${escapeHtml(m[0])}</mark>`;
    lastIndex = m.index + m[0].length;
  }
  out += escapeHtml(text.slice(lastIndex));
  return out.replace(/\n/g, '<br>');
}
function queueDbWrite(task) {
  state.dbWriteQueue = state.dbWriteQueue
    .then(() => task())
    .catch((err) => {
      state.dbWriteFailureVersion = (state.dbWriteFailureVersion || 0) + 1;
      state.lastDbWriteError = err || new Error('IndexedDB write failed');
      console.error('[BetterX] IndexedDB write failed:', err);
    });
  return state.dbWriteQueue;
}
function queueSettingsPersist(changedKeys) {
  const selection = changedKeys === undefined ? null : changedKeys;
  const snapshot = sanitizeSettings(state.settings);
  const keys = selection === null ? Object.keys(SETTINGS_SCHEMA) : (Array.isArray(selection) ? selection : []);
  const generations = new Map(keys.map((key) => {
    const generation = (settingsWriteGenerations.get(key) || 0) + 1;
    settingsWriteGenerations.set(key, generation);
    return [key, generation];
  }));
  return queueDbWrite(async () => {
    await persistSettings(selection, snapshot);
    const restore = {};
    for (const [key, generation] of generations) {
      if (settingsWriteGenerations.get(key) === generation
          && settingsValueChanged(state.settings[key], snapshot[key])) restore[key] = snapshot[key];
    }
    if (Object.keys(restore).length) {
      state.settings = { ...state.settings, ...restore };
      runSettingsEffects(restore);
      resetPaging();
      refreshUI({ keepScroll: true });
    }
  });
}
function queuePostPut(post, options) { return queueDbWrite(() => dbPutPost(post, options)); }
function queuePostPatch(id, changes) { return queueDbWrite(() => dbPatchPost(id, changes)); }
function openDb() {
  if (state.dbPromise) return state.dbPromise;
  const openPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    let settled = false;
    let blockedTimer = null;
    const rejectOpen = (error) => {
      if (settled) return;
      settled = true;
      if (blockedTimer) clearTimeout(blockedTimer);
      reject(error);
    };
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(POSTS_STORE)) {
        const postsStore = db.createObjectStore(POSTS_STORE, { keyPath: 'id' });
        postsStore.createIndex('lastCapturedAt', 'lastCapturedAt', { unique: false });
        postsStore.createIndex('favorite', 'favorite', { unique: false });
        postsStore.createIndex('clicked', 'clicked', { unique: false });
      }
      if (!db.objectStoreNames.contains(SETTINGS_STORE)) {
        db.createObjectStore(SETTINGS_STORE, { keyPath: 'key' });
      }
    };
    request.onblocked = () => {
      console.warn('[BetterX] IndexedDB upgrade is blocked by another X tab.');
      if (state.rootEl) showToast('⚠️ 数据库升级被其他 X 标签页阻塞；请关闭旧标签页后刷新', 7000);
      if (!blockedTimer) {
        blockedTimer = setTimeout(() => {
          const error = new Error('IndexedDB upgrade blocked by another tab');
          error.code = 'DB_OPEN_BLOCKED';
          rejectOpen(error);
        }, DB_OPEN_BLOCKED_TIMEOUT_MS);
      }
    };
    request.onsuccess = () => {
      const db = request.result;
      if (settled) {
        try { db.close(); } catch (err) {}
        return;
      }
      settled = true;
      if (blockedTimer) clearTimeout(blockedTimer);
      db.onversionchange = () => {
        try { db.close(); } catch (err) {}
        if (state.dbPromise === openPromise) state.dbPromise = null;
      };
      resolve(db);
    };
    request.onerror = () => rejectOpen(request.error || new Error('IndexedDB open failed'));
  });
  state.dbPromise = openPromise;
  openPromise.catch(() => {
    if (state.dbPromise === openPromise) state.dbPromise = null;
  });
  return openPromise;
}
async function dbRead(storeName, requestFactory) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const store = db.transaction(storeName, 'readonly').objectStore(storeName);
    const request = requestFactory(store);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
async function dbWrite(storeName, mutate) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    mutate(tx.objectStore(storeName));
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}
async function dbGetAllPosts() {
  return (await dbRead(POSTS_STORE, (store) => store.getAll())) || [];
}
async function dbGetPost(id) {
  return await dbRead(POSTS_STORE, (store) => store.get(id));
}
async function dbPutPost(post, options) {
  const opts = options || {};
  let storedPost = post;
  if (opts.preserveUserState === true) {
    const db = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(POSTS_STORE, 'readwrite');
      const store = tx.objectStore(POSTS_STORE);
      const request = store.get(post.id);
      request.onsuccess = () => {
        const current = request.result;
        if (!current) { store.put(post); return; }
        storedPost = {
          ...current,
          ...post,
          favorite: !!current.favorite,
          pinned: !!current.pinned,
          clicked: !!current.clicked,
          flashLost: !!(current.flashLost || post.flashLost),
          note: typeof current.note === 'string' ? current.note : (post.note || ''),
          firstViewedAt: current.firstViewedAt || post.firstViewedAt || 0,
          lastViewedAt: Math.max(current.lastViewedAt || 0, post.lastViewedAt || 0),
          lastClickedAt: Math.max(current.lastClickedAt || 0, post.lastClickedAt || 0),
        };
        store.put(storedPost);
      };
      request.onerror = () => reject(request.error);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  } else {
    await dbWrite(POSTS_STORE, (store) => store.put(post));
  }
  if (storedPost !== post) {
    const index = getPostIndexById(storedPost.id);
    if (index >= 0) {
      state.posts[index] = { ...state.posts[index], ...storedPost };
      debouncedRefreshUI();
    }
  }
  publishCrossTabChange('post-changed', { id: String(post && post.id || '') });
  return storedPost;
}
async function dbPatchPost(id, changes) {
  const db = await openDb();
  let storedPost = null;
  await new Promise((resolve, reject) => {
    const tx = db.transaction(POSTS_STORE, 'readwrite');
    const store = tx.objectStore(POSTS_STORE);
    const request = store.get(id);
    request.onsuccess = () => {
      const current = request.result || getPostById(id);
      if (current) {
        storedPost = { ...current, ...(changes || {}), id: current.id };
        if ('sourceLabel' in storedPost || 'sourceHistory' in storedPost || storedPost.capturedPath) {
          Object.assign(storedPost, normalizePostSourceFields(storedPost));
        }
        store.put(storedPost);
      }
    };
    request.onerror = () => reject(request.error);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
  if (storedPost) {
    const index = getPostIndexById(storedPost.id);
    if (index >= 0) state.posts[index] = storedPost;
    else {
      appendPost(storedPost);
    }
    debouncedRefreshUI();
  }
  publishCrossTabChange('post-changed', { id: String(id || '') });
}
async function dbPutPosts(posts, options) {
  if (!posts || !posts.length) return;
  const opts = options || {};
  if (opts.mergeUserState === true) {
    const db = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(POSTS_STORE, 'readwrite');
      const store = tx.objectStore(POSTS_STORE);
      for (const post of posts) {
        const request = store.get(post.id);
        request.onsuccess = () => {
          const current = request.result;
          if (!current) { store.put(post); return; }
          store.put({
            ...current,
            ...post,
            favorite: !!(current.favorite || post.favorite),
            pinned: !!(current.pinned || post.pinned),
            clicked: !!(current.clicked || post.clicked),
            flashLost: !!(current.flashLost || post.flashLost),
            note: current.note || post.note || '',
            firstViewedAt: current.firstViewedAt && post.firstViewedAt
              ? Math.min(current.firstViewedAt, post.firstViewedAt)
              : Math.max(current.firstViewedAt || 0, post.firstViewedAt || 0),
            lastViewedAt: Math.max(current.lastViewedAt || 0, post.lastViewedAt || 0),
            lastClickedAt: Math.max(current.lastClickedAt || 0, post.lastClickedAt || 0),
          });
        };
        request.onerror = () => reject(request.error);
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  } else {
    await dbWrite(POSTS_STORE, (store) => posts.forEach((post) => store.put(post)));
  }
  publishCrossTabChange('posts-reload');
}
async function dbDeletePost(id) {
  await dbWrite(POSTS_STORE, (store) => store.delete(id));
  publishCrossTabChange('post-changed', { id: String(id || '') });
}
async function dbDeleteMany(ids, options) {
  if (!ids || !ids.length) return;
  const opts = options || {};
  const preservedPosts = [];
  if (opts.preserveProtected === true) {
    const db = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(POSTS_STORE, 'readwrite');
      const store = tx.objectStore(POSTS_STORE);
      for (const id of ids) {
        const request = store.get(id);
        request.onsuccess = () => {
          const current = request.result;
          if (current && (current.favorite || current.pinned)) preservedPosts.push(current);
          else store.delete(id);
        };
        request.onerror = () => reject(request.error);
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  } else {
    await dbWrite(POSTS_STORE, (store) => ids.forEach((id) => store.delete(id)));
  }
  if (preservedPosts.length) {
    const byId = new Map(state.posts.map((post) => [String(post.id), post]));
    preservedPosts.map(sanitizeImportedPost).filter(Boolean)
      .forEach((post) => byId.set(String(post.id), post));
    state.posts = [...byId.values()];
    rebuildPostIndex();
    debouncedRefreshUI();
  }
  publishCrossTabChange('posts-reload');
}
async function dbGetSetting(key) {
  return (await dbRead(SETTINGS_STORE, (store) => store.get(key)))?.value;
}
async function dbPutSetting(key, value) {
  await dbWrite(SETTINGS_STORE, (store) => store.put({ key, value }));
  if (key === 'settings') publishCrossTabChange('settings-reload');
}
async function dbMergeSettings(partial, fallback) {
  const db = await openDb();
  let merged = fallback;
  await new Promise((resolve, reject) => {
    const tx = db.transaction(SETTINGS_STORE, 'readwrite');
    const store = tx.objectStore(SETTINGS_STORE);
    const request = store.get('settings');
    request.onsuccess = () => {
      const current = request.result && request.result.value;
      const base = current && typeof current === 'object' && !Array.isArray(current)
        ? sanitizeSettings(migrateSettingsDefaults(current))
        : fallback;
      merged = sanitizeSettings({ ...base, ...(partial || {}) });
      store.put({ key: 'settings', value: merged });
    };
    request.onerror = () => reject(request.error);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
  publishCrossTabChange('settings-reload');
  return merged;
}
function publishCrossTabChange(type, payload) {
  if (!crossTabChannel) return;
  try { crossTabChannel.postMessage({ type, ...(payload || {}) }); }
  catch (err) { debugLog('cross-tab publish failed:', err); }
}
function scheduleCrossTabReload(type, id) {
  if (type === 'posts-reload') {
    crossTabReloadAllPosts = true;
    crossTabReloadPostIds.clear();
  } else if (type === 'post-changed' && id && !crossTabReloadAllPosts) {
    crossTabReloadPostIds.add(String(id));
  } else if (type === 'settings-reload') {
    crossTabReloadSettings = true;
  }
  if (crossTabReloadTimer) return;
  crossTabReloadTimer = setTimeout(flushCrossTabReload, 60);
}
async function flushCrossTabReload() {
  crossTabReloadTimer = null;
  const reloadAllPosts = crossTabReloadAllPosts;
  const reloadSettings = crossTabReloadSettings;
  const postIds = [...crossTabReloadPostIds];
  crossTabReloadAllPosts = false;
  crossTabReloadSettings = false;
  crossTabReloadPostIds.clear();
  let postsChanged = false;
  try {
    if (reloadAllPosts) {
      state.posts = (await dbGetAllPosts()).map(sanitizeImportedPost).filter(Boolean)
        .sort((a, b) => (b.lastCapturedAt || 0) - (a.lastCapturedAt || 0));
      rebuildPostIndex();
      postsChanged = true;
    } else if (postIds.length) {
      const records = await Promise.all(postIds.map(async (id) => [id, await dbGetPost(id)]));
      const byId = new Map(state.posts.map((post) => [String(post.id), post]));
      for (const [id, rawPost] of records) {
        const post = sanitizeImportedPost(rawPost);
        if (post) byId.set(String(id), post);
        else byId.delete(String(id));
      }
      state.posts = [...byId.values()];
      rebuildPostIndex();
      postsChanged = true;
    }
    if (reloadSettings) {
      const savedSettings = await dbGetSetting('settings');
      if (savedSettings && typeof savedSettings === 'object') applySettingsSnapshot(savedSettings);
    }
    if (postsChanged) {
      bumpKeywordCache();
      resetPaging();
      refreshUI({ keepScroll: true });
    }
  } catch (err) {
    console.error('[BetterX] cross-tab reload failed:', err);
  }
}
function installCrossTabSync() {
  if (crossTabChannel || typeof BroadcastChannel !== 'function') return;
  try {
    crossTabChannel = new BroadcastChannel(CROSS_TAB_CHANNEL_NAME);
    crossTabChannel.addEventListener('message', (event) => {
      const message = event && event.data;
      if (!message || typeof message !== 'object') return;
      if (message.type === 'post-changed') scheduleCrossTabReload(message.type, message.id);
      else if (message.type === 'posts-reload' || message.type === 'settings-reload') {
        scheduleCrossTabReload(message.type);
      }
    });
  } catch (err) {
    crossTabChannel = null;
    debugLog('cross-tab sync unavailable:', err);
  }
}
function rebuildPostIndex() {
  state.postIndexById = new Map(state.posts.map((post, index) => [String(post.id), index]));
  indexedPosts = state.posts;
  indexedPostLength = state.posts.length;
}
function ensurePostIndex() {
  if (indexedPosts !== state.posts || indexedPostLength !== state.posts.length) rebuildPostIndex();
}
function appendPost(post) {
  ensurePostIndex();
  state.posts.push(post);
  state.postIndexById.set(String(post.id), state.posts.length - 1);
  indexedPostLength = state.posts.length;
}
function getPostIndexById(id) {
  ensurePostIndex();
  const key = String(id);
  const cached = state.postIndexById.get(key);
  if (cached == null) return -1;
  if (state.posts[cached] && String(state.posts[cached].id) === key) return cached;
  rebuildPostIndex();
  return state.postIndexById.get(key) ?? -1;
}
function getPostById(id) {
  const index = getPostIndexById(id);
  return index >= 0 ? state.posts[index] : undefined;
}
function protectedPost(p) { return !!(p.favorite || p.pinned); }
function prunePostRuntimeCaches(ids) {
  for (const rawId of ids || []) {
    const id = String(rawId);
    matchCache.delete(id);
    state.visibleMap.delete(id);
    state.expandedPosts.delete(id);
    state.noteDrafts.delete(id);
    mediaRegistry.delete(id);
    cardRegistry.delete(id);
  }
}
let postLimitWarningShownForMax = 0;
let postLimitWarningTimer = null;
let postLimitWarningReady = false;
function getPostLimitWarningThreshold(maxPosts) {
  const maximum = clampInt(maxPosts, 50, 5000, DEFAULT_SETTINGS.maxPosts);
  return Math.max(1, Math.ceil(maximum * 0.9));
}
function formatPostLimitWarningCount(count, maximum) {
  if (UI_LANGUAGE === 'zh-TW') return `目前已記錄 ${count} 筆貼文；設定的「最大筆數」為 ${maximum} 筆。`;
  if (UI_LANGUAGE === 'ja') return `現在 ${count} 件を記録しています。設定された上限は ${maximum} 件です。`;
  if (UI_LANGUAGE === 'en') return `Currently recorded: ${count} posts; the configured maximum is ${maximum}.`;
  return `当前已记录 ${count} 条帖子，设置的“最大条数”为 ${maximum} 条。`;
}
function openAdvancedSettingsFromPostLimitWarning() {
  togglePanel(true);
  setPanelView('settings');
  setTimeout(() => {
    const advanced = state.panelEl && state.panelEl.querySelector('#BetterX-advanced-settings');
    if (!advanced) return;
    advanced.open = true;
    try { advanced.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (err) {}
    if (state.maxPostsInputEl) {
      try { state.maxPostsInputEl.focus({ preventScroll: true }); } catch (err) { state.maxPostsInputEl.focus(); }
      state.maxPostsInputEl.select();
    }
  }, 0);
}
function maybeShowPostLimitWarning() {
  if (!postLimitWarningReady || !state.settingsLoaded || state.settings.postLimitWarningDisabled || !state.rootEl) return false;
  const maximum = clampInt(state.settings.maxPosts, 50, 5000, DEFAULT_SETTINGS.maxPosts);
  const threshold = getPostLimitWarningThreshold(maximum);
  const count = state.posts.length;
  if (count < threshold) {
    if (postLimitWarningShownForMax === maximum) postLimitWarningShownForMax = 0;
    return false;
  }
  if (postLimitWarningShownForMax === maximum) return false;
  if (document.getElementById('BetterX-choice-dialog')) {
    if (!postLimitWarningTimer) {
      postLimitWarningTimer = setTimeout(() => {
        postLimitWarningTimer = null;
        maybeShowPostLimitWarning();
      }, 1200);
    }
    return false;
  }
  postLimitWarningShownForMax = maximum;
  showBetterXDialog({
    title: '帖子记录即将达到上限',
    bodyHtml: `
        <p>${escapeHtml(formatPostLimitWarningCount(count, maximum))}</p>
        <p>${escapeHtml(uiText('达到上限后，新帖子仍会继续记录；最旧的未收藏、未置顶帖子会被删除。收藏和置顶帖子不会被上限删除，因此总数有时可能超过设置值。'))}</p>
        <p>${escapeHtml(uiText('你可以打开“高级设置”调大“最大条数”，或先导出备份。'))}</p>
      `,
    primaryText: '打开高级设置',
    secondaryText: '导出备份',
    tertiaryText: '不再提示',
    showCloseIcon: true,
    onPrimary: openAdvancedSettingsFromPostLimitWarning,
    onSecondary: backupAll,
    onTertiary: () => setSettingsPartial({ postLimitWarningDisabled: true }),
  });
  return true;
}
function trimPostsToMax() {
  const max = state.settings.maxPosts || 500;
  const kept = state.posts.filter(protectedPost);
  const others = state.posts
    .filter((p) => !protectedPost(p))
    .sort((a, b) => (b.lastCapturedAt || 0) - (a.lastCapturedAt || 0));
  const allowOthers = Math.max(0, max - kept.length);
  if (others.length <= allowOthers) return [];
  const toDelete = others.slice(allowOthers);
  const keepOthers = others.slice(0, allowOthers);
  state.posts = [...kept, ...keepOthers];
  rebuildPostIndex();
  const ids = toDelete.map((p) => p.id);
  prunePostRuntimeCaches(ids);
  return ids;
}
async function enforceMaxPosts() {
  const ids = trimPostsToMax();
  if (!ids.length) return;
  await dbDeleteMany(ids, { preserveProtected: true });
}
function refreshBadge() {
  if (!state.badgeEl) return;
  const totalCount = state.posts.length;
  let flashCount = 0, unreadCount = 0;
  for (const p of state.posts) {
    if (!p.clicked) unreadCount++;
    if (p.flashLost && !p.clicked) flashCount++;
  }
  if (state.badgeEl.classList.contains('mobile-mode')) {
    const iconHtml = APP_ICON_URL
      ? `<img class="BetterX-mobile-icon" src="${escapeHtml(APP_ICON_URL)}" alt="" draggable="false" />`
      : '<span class="BetterX-mobile-icon-fallback">🧰</span>';
    state.badgeEl.innerHTML = `${iconHtml}<span class="BetterX-mobile-dot" style="display:${unreadCount > 0 ? 'block' : 'none'}">${unreadCount}</span>`;
  } else {
    state.badgeEl.textContent = uiText(`总数 ${totalCount} · 未读${unreadCount}${flashCount ? ` · ⚡${flashCount}` : ''}`);
  }
}
function buildSummaryHtml() {
  const total = state.posts.length;
  let unread = 0, opened = 0, favorite = 0, flash = 0, keywordHits = 0, pinned = 0;
  for (const p of state.posts) {
    if (!p.clicked) unread++; else opened++;
    if (p.favorite) favorite++;
    if (p.pinned) pinned++;
    if (p.flashLost && !p.clicked) flash++;
    if (computeMatchedKeywords(p).length > 0) keywordHits++;
  }
  return uiHtml`
      <div class="BetterX-stat">总数 <b>${total}</b></div>
      <div class="BetterX-stat">未打开 <b>${unread}</b></div>
      <div class="BetterX-stat">已打开 <b>${opened}</b></div>
      <div class="BetterX-stat">已收藏 <b>${favorite}</b></div>
      <div class="BetterX-stat">已置顶 <b>${pinned}</b></div>
      <div class="BetterX-stat">快速消失 <b>${flash}</b></div>
      <div class="BetterX-stat">命中关键词 <b>${keywordHits}</b></div>
    `;
}
function buildFilterHtml() {
  return FILTERS.map((f) => {
    const active = state.settings.filter === f.key ? 'active' : '';
    return `<button class="BetterX-chip ${active}" data-action="set-filter" data-filter="${escapeHtml(f.key)}">${escapeHtml(uiText(f.label))}</button>`;
  }).join('');
}
function getAvailableSources() {
  return uniqueStrings(state.posts.map((p) => normalizeSourceLabel(p.sourceLabel)).filter(Boolean))
    .sort((a, b) => {
      const rank = (source) => SOURCE_SORT_RANK.get(source)
        ?? (/^Profile\s+@/i.test(source) ? 100 : 10);
      const rankDiff = rank(a) - rank(b);
      return rankDiff || localizeSourceLabel(a).localeCompare(localizeSourceLabel(b), UI_LANGUAGE);
    });
}
function localizeSourceLabel(source) {
  const raw = String(source || '').trim();
  if (SOURCE_EXACT_LABELS[raw]) return SOURCE_EXACT_LABELS[raw];
  if (/^Thread\s+@/i.test(raw)) return raw.replace(/^Thread\s+/i, '帖子详情 ');
  if (/^Profile\s+@/i.test(raw)) return raw.replace(/^Profile\s+/i, '个人主页 ');
  return raw;
}
function buildSourceOptionsHtml() {
  const selected = state.settings.sourceFilter || 'all';
  const options = ['all', ...getAvailableSources()];
  return options.map((source) => {
    const label = source === 'all' ? '全部来源' : localizeSourceLabel(source);
    const isSelected = selected === source ? 'selected' : '';
    return `<option value="${escapeHtml(source)}" ${isSelected}>${escapeHtml(uiText(label))}</option>`;
  }).join('');
}
function buildMediaOptionsHtml() {
  const selected = state.settings.mediaFilter || 'all';
  return MEDIA_FILTERS.map((f) => {
    const isSelected = selected === f.key ? 'selected' : '';
    return `<option value="${escapeHtml(f.key)}" ${isSelected}>${escapeHtml(uiText(f.label))}</option>`;
  }).join('');
}
function buildQuickFilterStateText() {
  const filterKey = state.settings.filter || DEFAULT_SETTINGS.filter;
  const filterLabel = FILTERS.find((item) => item.key === filterKey)?.label || '全部';
  const source = state.settings.sourceFilter || 'all';
  const sourceLabel = source === 'all' ? '全部来源' : (localizeSourceLabel(source) || '全部来源');
  const mediaKey = state.settings.mediaFilter || DEFAULT_SETTINGS.mediaFilter;
  const mediaLabel = MEDIA_FILTERS.find((item) => item.key === mediaKey)?.label || '全部媒体';
  const sortKey = state.settings.sortBy || DEFAULT_SETTINGS.sortBy;
  const sortLabel = SORT_LABELS[sortKey] || SORT_LABELS.smart;
  return `(当前选择：${filterLabel} · ${sourceLabel} · ${mediaLabel} · ${sortLabel})`;
}
function updateQuickFilterHeader() {
  if (state.quickFilterDetailsEl) {
    const shouldOpen = !!state.settings.quickFilterOpen;
    if (state.quickFilterDetailsEl.open !== shouldOpen) state.quickFilterDetailsEl.open = shouldOpen;
  }
  if (state.quickFilterStateEl) {
    const text = buildQuickFilterStateText();
    state.quickFilterStateEl.textContent = uiText(text);
    state.quickFilterStateEl.title = uiText(text);
  }
}
function updateDownloadAdvancedHeader() {
  if (state.downloadAdvancedDetailsEl) {
    const shouldOpen = !!state.settings.downloadAdvancedOpen;
    if (state.downloadAdvancedDetailsEl.open !== shouldOpen) state.downloadAdvancedDetailsEl.open = shouldOpen;
  }
  if (!state.downloadAdvancedStateEl) return;
  const customized = normalizeDownloadNameTemplate(state.settings.downloadFileNameTemplate || DEFAULT_SETTINGS.downloadFileNameTemplate) !== DEFAULT_SETTINGS.downloadFileNameTemplate
    || normalizeDownloadNameTemplate(state.settings.downloadZipNameTemplate || DEFAULT_SETTINGS.downloadZipNameTemplate) !== DEFAULT_SETTINGS.downloadZipNameTemplate
    || !!state.settings.downloadNameRegex
    || !!state.settings.downloadNameReplacement;
  state.downloadAdvancedStateEl.hidden = !customized;
  state.downloadAdvancedStateEl.textContent = customized ? uiText('已自定义') : '';
}
function buildSkipSourcesHtml() {
  const skip = state.settings.skipSources || [];
  return SKIP_SOURCE_OPTIONS.map((o) => {
    const active = skip.includes(o.key) ? 'active' : '';
    return `<button class="BetterX-chip ${active}" data-action="toggle-skip" data-skip="${escapeHtml(o.key)}">${escapeHtml(uiText(o.label))}</button>`;
  }).join('');
}
function updateSortHint() {
  if (!state.sortHintEl) return;
  const sortBy = state.settings.sortBy || DEFAULT_SETTINGS.sortBy;
  state.sortHintEl.textContent = uiText(SORT_HINTS[sortBy] || SORT_HINTS.smart);
}
function passesMediaFilter(p) {
  switch (state.settings.mediaFilter) {
    case 'image': return !!p.hasImage;
    case 'video': return !!p.hasVideo;
    case 'text':  return !p.hasImage && !p.hasVideo;
    default: return true;
  }
}
function filterPosts(posts) {
  let result = [...posts];
  switch (state.settings.filter) {
    case 'unread':   result = result.filter((p) => !p.clicked); break;
    case 'flash':    result = result.filter((p) => p.flashLost && !p.clicked); break;
    case 'favorite': result = result.filter((p) => p.favorite); break;
    case 'pinned':   result = result.filter((p) => p.pinned); break;
    case 'opened':   result = result.filter((p) => p.clicked); break;
    case 'keyword':  result = result.filter((p) => computeMatchedKeywords(p).length > 0); break;
    default: break;
  }
  if (state.settings.sourceFilter && state.settings.sourceFilter !== 'all') {
    result = result.filter((p) => p.sourceLabel === state.settings.sourceFilter);
  }
  result = result.filter(passesMediaFilter);
  if ((state.settings.excludeKeywords || []).length) {
    result = result.filter((p) => !matchesExclude(p));
  }
  const q = (state.searchQuery || '').trim().toLowerCase();
  if (q) {
    result = result.filter((p) =>
      (p.displayName || '').toLowerCase().includes(q) ||
      (p.username    || '').toLowerCase().includes(q) ||
      (p.text        || '').toLowerCase().includes(q) ||
      (p.note        || '').toLowerCase().includes(q)
    );
  }
  const sortBy = state.settings.sortBy || 'smart';
  result.sort((a, b) => {
    if (sortBy === 'recent_viewed') {
      return (b.lastViewedAt || b.lastCapturedAt || 0) - (a.lastViewedAt || a.lastCapturedAt || 0);
    }
    if (sortBy === 'recent_captured') return (b.lastCapturedAt || 0) - (a.lastCapturedAt || 0);
    if (sortBy === 'first_captured') return (b.firstCapturedAt || b.lastCapturedAt || 0) - (a.firstCapturedAt || a.lastCapturedAt || 0);
    if (sortBy === 'time_asc') return (a.firstCapturedAt || a.lastCapturedAt || 0) - (b.firstCapturedAt || b.lastCapturedAt || 0);
    const pinDiff = Number(!!b.pinned) - Number(!!a.pinned);
    if (pinDiff !== 0) return pinDiff;
    if (sortBy === 'captures')  return (b.capturedCount || 1) - (a.capturedCount || 1);
    if (sortBy === 'author')    return (a.displayName || '').localeCompare(b.displayName || '');
    if (sortBy === 'source')    return (a.sourceLabel || '').localeCompare(b.sourceLabel || '');
    const favDiff = Number(!!b.favorite) - Number(!!a.favorite);
    if (favDiff !== 0) return favDiff;
    const flashDiff = Number(!!b.flashLost) - Number(!!a.flashLost);
    if (flashDiff !== 0) return flashDiff;
    return (b.lastCapturedAt || 0) - (a.lastCapturedAt || 0);
  });
  return result;
}
function renderKeywordTags(matchedKeywords) {
  if (!matchedKeywords.length) return '';
  return matchedKeywords.map((kw) => `<span class="BetterX-tag keyword">${escapeHtml(kw)}</span>`).join('');
}
function renderMetaTags(post) {
  const tags = [];
  if (post.pinned) tags.push(uiHtml`<span class="BetterX-tag pin">📌 置顶</span>`);
  if (post.favorite) tags.push(uiHtml`<span class="BetterX-tag fav">★ 已收藏</span>`);
  if (post.flashLost && !post.clicked) tags.push(uiHtml`<span class="BetterX-tag flash">⚡ 快速消失</span>`);
  if (post.clicked) tags.push(uiHtml`<span class="BetterX-tag opened">👁 已打开</span>`);
  if (post.hasImage) tags.push(uiHtml`<span class="BetterX-tag">🖼 图片</span>`);
  if (post.hasVideo) tags.push(uiHtml`<span class="BetterX-tag">🎬 视频</span>`);
  if (post.sourceLabel) tags.push(uiHtml`<span class="BetterX-tag source">来源: ${escapeHtml(uiText(localizeSourceLabel(post.sourceLabel)))}</span>`);
  return tags.join('');
}
function renderThumbs(post) {
  const thumbs = uniqueStrings((post.mediaThumbs || []).map(safeImportedAssetUrl).filter(Boolean)).slice(0, 4);
  if (!thumbs.length) return '';
  return `<div class="BetterX-thumbs">${thumbs.map((src, index) =>
    uiHtml`<button type="button" class="BetterX-thumb-button" data-action="preview-image" data-post-id="${escapeHtml(post.id)}" data-image-index="${index}" data-image-url="${escapeHtml(src)}" aria-label="放大查看第 ${index + 1} 张图片">
        <img class="BetterX-thumb" src="${escapeHtml(src)}" loading="lazy" referrerpolicy="no-referrer" alt="" />
      </button>`
  ).join('')}</div>`;
}
function renderPostItem(post) {
  const matchedKeywords = computeMatchedKeywords(post);
  const authorInfo = cleanAuthorInfo(post.displayName, post.username, post.timeLabel);
  const displayName = authorInfo.displayName;
  const username = authorInfo.username;
  const timeLabel = authorInfo.timeLabel || post.timeLabel || '';
  const handle = username.replace(/^@/, '');
  const profileUrl = /^[A-Za-z0-9_]{1,15}$/.test(handle) ? `https://x.com/${handle}` : '';
  const displayNameHtml = highlightText(displayName, matchedKeywords);
  const showHandle = username &&
    username.toLowerCase() !== displayName.toLowerCase() &&
    handle.toLowerCase() !== displayName.toLowerCase();
  const handleHtml = showHandle
    ? `<span class="BetterX-author-handle">${highlightText(username, matchedKeywords)}</span>`
    : '';
  const authorLabelHtml = `${displayNameHtml}${handleHtml ? ' ' + handleHtml : ''}`;
  const authorHtml = profileUrl
    ? uiHtml`<a class="BetterX-author-profile" href="${escapeHtml(profileUrl)}" title="打开 @${escapeHtml(handle)} 的个人主页">${authorLabelHtml}</a>`
    : authorLabelHtml;
  const timeHtml = timeLabel ? `<span class="BetterX-author-time"> · ${escapeHtml(timeLabel)}</span>` : '';
  const textHtml = post.text
    ? highlightText(post.text, matchedKeywords) : escapeHtml(uiText('(无正文)'));
  const isExpanded = state.expandedPosts.has(post.id);
  const isEditingNote = state.editingNoteId === post.id;
  const textIsLong = (post.text || '').length > 120;
  const historyText = (post.sourceHistory || []).length > 1
    ? uiHtml` · 历史来源: ${(post.sourceHistory || []).map((source) => uiText(localizeSourceLabel(source))).join(' / ')}`
    : '';
  const avatarUrl = safeImportedAssetUrl(post.avatarUrl);
  const avatarHtml = avatarUrl
    ? `<img class="BetterX-avatar" src="${escapeHtml(avatarUrl)}" referrerpolicy="no-referrer" alt="" />`
    : '';
  const noteHtml = isEditingNote
    ? uiHtml`<div class="BetterX-note-edit">
           <textarea class="BetterX-note-input" data-id="${escapeHtml(post.id)}" placeholder="在这里写备注…">${escapeHtml(state.noteDrafts.get(post.id) ?? post.note ?? '')}</textarea>
           <div class="BetterX-note-actions">
             <button class="BetterX-btn primary" data-action="save-note" data-id="${escapeHtml(post.id)}">保存备注</button>
             <button class="BetterX-btn" data-action="cancel-note">取消</button>
           </div>
         </div>`
    : uiHtml`<button class="BetterX-btn BetterX-note-btn" data-action="edit-note" data-id="${escapeHtml(post.id)}">${uiText(post.note ? '✏️ 备注' : '+ 备注')}</button>
         ${post.note ? `<div class="BetterX-note-text">💬 ${escapeHtml(post.note)}</div>` : ''}`;
  return uiHtml`
      <div class="BetterX-item ${post.flashLost ? 'is-flash-lost' : ''} ${post.pinned ? 'is-pinned' : ''} ${!post.clicked ? 'is-unread' : ''}" data-id="${escapeHtml(post.id)}">
        <div class="BetterX-item-top">
          <div class="BetterX-author">
            <div class="BetterX-author-head">
              ${avatarHtml}
              <div class="BetterX-author-line">${authorHtml}${timeHtml}</div>
            </div>
          <div class="BetterX-submeta">
            <span>抓取: ${escapeHtml(formatTime(post.lastCapturedAt))}</span>
            ${post.lastViewedAt ? uiHtml`<span>浏览: ${escapeHtml(formatTime(post.lastViewedAt))}</span>` : ''}
            <span>出现: ${escapeHtml(String(post.capturedCount || 1))} 次</span>
            </div>
          </div>
          <div class="BetterX-actions">
            <button class="BetterX-btn primary" data-action="open" data-id="${escapeHtml(post.id)}">打开</button>
            <button class="BetterX-btn" data-action="copy" data-id="${escapeHtml(post.id)}">复制链接</button>
            <button class="BetterX-btn" data-action="pin" data-id="${escapeHtml(post.id)}">${uiText(post.pinned ? '取消置顶' : '置顶')}</button>
            <button class="BetterX-btn" data-action="fav" data-id="${escapeHtml(post.id)}">${uiText(post.favorite ? '取消收藏' : '收藏')}</button>
            <button class="BetterX-btn danger" data-action="delete" data-id="${escapeHtml(post.id)}">删</button>
          </div>
        </div>

        <div class="BetterX-text ${textIsLong && !isExpanded ? 'collapsed' : ''}">${textHtml}</div>
        ${textIsLong ? uiHtml`<button class="BetterX-expand-btn" data-action="toggle-expand" data-id="${escapeHtml(post.id)}">${uiText(isExpanded ? '▲ 收起' : '▼ 展开全文')}</button>` : ''}

        ${renderThumbs(post)}

        <div class="BetterX-tags">
          ${renderMetaTags(post)}
          ${renderKeywordTags(matchedKeywords)}
        </div>

        <div class="BetterX-note-area">${noteHtml}</div>

        <div class="BetterX-bottom-meta">
          <span>当前来源: ${escapeHtml(uiText(localizeSourceLabel(post.sourceLabel) || '全部来源'))}</span>
          <span>${escapeHtml(historyText)}</span>
        </div>
      </div>
    `;
}
function snapshotNoteEditor() {
  const input = state.listEl?.querySelector('.BetterX-note-input');
  const id = input?.getAttribute('data-id');
  if (!id || id !== state.editingNoteId) return null;
  state.noteDrafts.set(id, input.value);
  return {
    id, element: input.closest('.BetterX-note-edit'), focused: document.activeElement === input,
    scrollTop: input.scrollTop,
  };
}
function renderPostList(html, snapshot) {
  const editingCard = snapshot?.element.closest('.BetterX-item');
  if (!editingCard || snapshot.id !== state.editingNoteId) {
    state.listEl.innerHTML = html;
    return;
  }
  const template = document.createElement('template');
  template.innerHTML = html;
  const nextCard = template.content.querySelector('.BetterX-note-edit')?.closest('.BetterX-item');
  if (!nextCard) { state.listEl.innerHTML = html; return; }
  const noteArea = snapshot.element.closest('.BetterX-note-area');
  editingCard.className = nextCard.className;
  for (const child of [...editingCard.children]) {
    if (child !== noteArea) child.remove();
  }
  let afterNote = false;
  for (const child of [...nextCard.children]) {
    if (child.classList.contains('BetterX-note-area')) { afterNote = true; continue; }
    if (afterNote) editingCard.appendChild(child);
    else editingCard.insertBefore(child, noteArea);
  }
  for (const child of [...state.listEl.childNodes]) {
    if (child !== editingCard) child.remove();
  }
  let afterCard = false;
  for (const child of [...template.content.childNodes]) {
    if (child === nextCard) { afterCard = true; continue; }
    if (afterCard) state.listEl.appendChild(child);
    else state.listEl.insertBefore(child, editingCard);
  }
  const input = snapshot.element.querySelector('.BetterX-note-input');
  if (snapshot.focused && document.activeElement !== input) input.focus({ preventScroll: true });
  input.scrollTop = snapshot.scrollTop;
}
function refreshSettingsUI() {
  if (state.skipSourcesEl) state.skipSourcesEl.innerHTML = buildSkipSourcesHtml();
  renderSavedKeywordTags();
  renderSavedExcludeKeywordTags();
  syncSettingsControls('settings');
  updateDownloadAdvancedHeader();
  syncInactiveInput(state.autoCleanInputEl, state.settings.autoCleanDays || 0);
  syncInactiveInput(state.maxPostsInputEl, state.settings.maxPosts || DEFAULT_SETTINGS.maxPosts);
  syncInactiveInput(state.flashMsInputEl, Math.round((state.settings.flashMs || DEFAULT_SETTINGS.flashMs) / 1000));
  if (state.dlTimeoutInputEl && document.activeElement !== state.dlTimeoutInputEl) {
    state.dlTimeoutInputEl.value = String(Math.round((state.settings.downloadTimeout || DEFAULT_SETTINGS.downloadTimeout) / 1000));
  }
  if (state.dlConcurrencyInputEl && document.activeElement !== state.dlConcurrencyInputEl) {
    state.dlConcurrencyInputEl.value = String(state.settings.downloadConcurrency || DEFAULT_SETTINGS.downloadConcurrency);
  }
  renderAdultSpamKeywordTags();
  renderAdultSpamWhitelistTags();
  syncInactiveInput(state.timelineWidthEl,
    state.settings.layoutAutoWidth !== false && state.detectedTimelineWidth
      ? state.detectedTimelineWidth : (state.settings.timelineWidth || DEFAULT_SETTINGS.timelineWidth));
  syncInactiveInput(state.leftbarWidthEl,
    state.settings.layoutAutoWidth !== false && state.detectedLeftbarWidth
      ? state.detectedLeftbarWidth : (state.settings.leftbarWidth || DEFAULT_SETTINGS.leftbarWidth));
  updateAdultSpamCount();
  if (state.mediaDownloadEl) state.mediaDownloadEl.checked = !!state.settings.mediaDownload;
  if (state.downloadZipEl) state.downloadZipEl.checked = state.settings.downloadZip !== false;
  if (state.downloadFileNameTemplateEl && document.activeElement !== state.downloadFileNameTemplateEl) {
    state.downloadFileNameTemplateEl.value = localizeDownloadNameTemplate(state.settings.downloadFileNameTemplate || DEFAULT_SETTINGS.downloadFileNameTemplate);
  }
  if (state.downloadZipNameTemplateEl && document.activeElement !== state.downloadZipNameTemplateEl) {
    state.downloadZipNameTemplateEl.value = localizeDownloadNameTemplate(state.settings.downloadZipNameTemplate || DEFAULT_SETTINGS.downloadZipNameTemplate);
  }
  if (state.downloadNameRegexEl && document.activeElement !== state.downloadNameRegexEl) {
    state.downloadNameRegexEl.value = state.settings.downloadNameRegex || '';
  }
  if (state.downloadNameReplacementEl && document.activeElement !== state.downloadNameReplacementEl) {
    state.downloadNameReplacementEl.value = state.settings.downloadNameReplacement || '';
  }
  if (state.trackDownloadedPostsEl) state.trackDownloadedPostsEl.checked = !!state.settings.trackDownloadedPosts;
  updateDownloadNamingPreview();
  syncControlProperties([
    [state.firefoxCompatibilityEl, 'checked', !!state.settings.firefoxCompatibility],
    [state.hideAppBadgeEl, 'checked', !!state.settings.hideAppBadge],
    [state.postLimitWarningEl, 'checked', !state.settings.postLimitWarningDisabled],
    [state.useMobileBadgeHandleEl, 'checked', !!state.settings.useMobileBadgeHandle],
    [state.profileDefaultViewEl, 'disabled', state.settings.profileDefaultViewEnabled === false],
    [state.profilePostSortEl, 'disabled', state.settings.profilePostSortEnabled === false],
  ]);
  updateSettingsDependencyUI();
}
function refreshVaultUI(opts) {
  const noteEditor = snapshotNoteEditor();
  const keepListScroll = !!opts.keepScroll;
  if (state.summaryEl) state.summaryEl.innerHTML = buildSummaryHtml();
  if (state.filterBarEl) state.filterBarEl.innerHTML = buildFilterHtml();
  if (state.sourceSelectEl) state.sourceSelectEl.innerHTML = buildSourceOptionsHtml();
  syncSettingsControls('vault');
  updateSortHint();
  updateQuickFilterHeader();
  if (!state.listEl) return;
  const scrollTop = keepListScroll ? state.listEl.scrollTop : 0;
  const filtered = filterPosts(state.posts);
  state.lastFilteredCount = filtered.length;
  if (!filtered.length) {
    state.listEl.innerHTML = uiHtml`<div class="BetterX-empty">当前筛选条件下没有帖子。可以刷新页面、切换 X 标签页，或把筛选改回“全部”。</div>`;
    return;
  }
  const limit = state.renderLimit || state.settings.pageSize || 60;
  const shown = filtered.slice(0, limit);
  let html = shown.map(renderPostItem).join('');
  if (filtered.length > shown.length) {
    html += uiHtml`<button class="BetterX-loadmore" data-action="load-more">加载更多（还有 ${filtered.length - shown.length} 条）</button>`;
  }
  renderPostList(html, noteEditor);
  if (keepListScroll) state.listEl.scrollTop = scrollTop;
}
function refreshUI(opts) {
  opts = opts || {};
  if (!state.panelEl) return;
  refreshBadge();
  if (!state.panelOpen && opts.force !== true) return;
  if (state.panelView === 'settings') refreshSettingsUI();
  else if (state.panelView === 'notifications') renderNotificationSubscriptions(opts.force === true);
  else refreshVaultUI(opts);
}
function sanitizeSettings(raw) {
  const input = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const stringList = (value, maxItems, maxLength) => uniqueStrings(
    (Array.isArray(value) ? value : []).map((item) => safeString(item, maxLength).trim()).filter(Boolean)
  ).slice(0, maxItems);
  const notificationList = () => {
    const result = [];
    const handles = new Set();
    for (const rawItem of Array.isArray(input.notificationSubscriptions) ? input.notificationSubscriptions : []) {
      const item = sanitizeNotificationSubscription(rawItem);
      const key = item?.username.toLowerCase();
      if (!item || handles.has(key)) continue;
      handles.add(key);
      result.push(item);
      if (result.length >= MAX_NOTIFICATION_SUBSCRIPTIONS) break;
    }
    return result;
  };
  const sanitizeValue = (key, definition) => {
    const [type, first, second] = definition.validate || [];
    const value = input[key];
    const fallback = definition.default;
    switch (type) {
      case 'revision': return fallback;
      case 'boolean': return typeof value === 'boolean' ? value : fallback;
      case 'int': return clampInt(value, first, second, fallback);
      case 'enum': return first.includes(value) ? value : fallback;
      case 'filter': return FILTERS.some((item) => item.key === value) ? value : fallback;
      case 'mediaFilter': return MEDIA_FILTERS.some((item) => item.key === value) ? value : fallback;
      case 'string': return safeString(value, first);
      case 'stringDefault': return safeString(value, first) || fallback;
      case 'sourceFilter': return normalizeSourceLabel(value) || fallback;
      case 'trimmedStringDefault': return safeString(value, first).trim() || fallback;
      case 'stringList': return stringList(value, first, second);
      case 'keywordRules': return stringList(value, first, second).filter(isSafeKeywordRule);
      case 'skipSources': return stringList(Array.isArray(value) ? value : fallback, SKIP_SOURCE_OPTIONS.length, 30)
        .filter((candidate) => SKIP_SOURCE_OPTIONS.some((item) => item.key === candidate));
      case 'handles': return uniqueStrings(stringList(value, first, 30)
        .map((item) => item.replace(/^@+/, '').toLowerCase())
        .filter((item) => /^[a-z0-9_]{1,15}$/.test(item)));
      case 'notifications': return notificationList();
      case 'timestamp': {
        const timestamp = Number(value);
        return Number.isFinite(timestamp)
          ? Math.max(0, Math.min(Number.MAX_SAFE_INTEGER, Math.floor(timestamp))) : 0;
      }
      case 'badgePos': return value && Number.isFinite(value.left) && Number.isFinite(value.bottom)
        ? { left: value.left, bottom: value.bottom,
          ...(Number.isFinite(value.right) && value.right >= 0 ? { right: value.right } : {}) } : null;
      case 'safeRegex': {
        const source = safeString(value, MAX_REGEX_SOURCE_LENGTH);
        return isSafeRegexSource(source) ? source : fallback;
      }
      case 'downloadedIds': return uniqueStrings(stringList(value, MAX_DOWNLOADED_POST_IDS, 30)
        .filter((item) => /^\d{1,30}$/.test(item)));
      case 'hideAppBadge': return value === true || input.hideAppBadgeOnDesktop === true;
      case 'mobileBadgeHandle': return value === true
        && input.hideAppBadge !== true && input.hideAppBadgeOnDesktop !== true;
      case 'mobileBadgeTop': return Number.isFinite(value)
        ? Math.max(0, Math.min(100000, Math.round(value))) : fallback;
      default: throw new Error(`[BetterX] Missing settings validator: ${key}`);
    }
  };
  return Object.fromEntries(
    Object.entries(SETTINGS_SCHEMA).map(([key, definition]) => [key, sanitizeValue(key, definition)])
  );
}
function migrateSettingsDefaults(raw) {
  const input = raw && typeof raw === 'object' && !Array.isArray(raw) ? { ...raw } : {};
  const revision = clampInt(input.settingsRevision, 0, 999, 0);
  if (revision < DEFAULT_SETTINGS.settingsRevision) {
    if (revision < 39) {
      if (input.flashMs == null || Number(input.flashMs) === 8000) input.flashMs = DEFAULT_SETTINGS.flashMs;
      if (input.skipSources == null || (Array.isArray(input.skipSources) && input.skipSources.length === 0)) {
        input.skipSources = [...DEFAULT_SETTINGS.skipSources];
      }
    }
    if (input.maxPosts == null || Number(input.maxPosts) === 500) input.maxPosts = DEFAULT_SETTINGS.maxPosts;
    if (input.downloadTimeout == null || Number(input.downloadTimeout) === 60000) {
      input.downloadTimeout = DEFAULT_SETTINGS.downloadTimeout;
    }
    if (input.downloadConcurrency == null) input.downloadConcurrency = DEFAULT_SETTINGS.downloadConcurrency;
    if (revision < 4 && (input.adultSpamLevel == null || input.adultSpamLevel === 'conservative')) {
      input.adultSpamLevel = DEFAULT_SETTINGS.adultSpamLevel;
    }
    if (revision < 7) {
      if (input.hideAds == null || input.hideAds === false) input.hideAds = true;
      if (input.mediaDownload == null || input.mediaDownload === false) input.mediaDownload = true;
    }
    if (revision < 15 && (!input.sortBy || input.sortBy === 'default')) input.sortBy = 'smart';
    if (revision < 16 && input.downloadZip == null) input.downloadZip = DEFAULT_SETTINGS.downloadZip;
    if (revision < 17 && input.profileDefaultView == null) input.profileDefaultView = DEFAULT_SETTINGS.profileDefaultView;
    if (revision < 18 && input.autoExpandPostText == null) input.autoExpandPostText = DEFAULT_SETTINGS.autoExpandPostText;
    if (revision < 29 && input.profilePostSort == null) input.profilePostSort = DEFAULT_SETTINGS.profilePostSort;
    if (revision < 30 && input.profilePostSortEnabled == null) {
      input.profilePostSortEnabled = DEFAULT_SETTINGS.profilePostSortEnabled;
    }
    if (revision < 31 && input.postLimitWarningDisabled == null) {
      input.postLimitWarningDisabled = DEFAULT_SETTINGS.postLimitWarningDisabled;
    }
    if (revision < 32 && input.hideNfl == null) input.hideNfl = DEFAULT_SETTINGS.hideNfl;
    if (revision < 33 && input.gifDownloadFormat == null) {
      input.gifDownloadFormat = DEFAULT_SETTINGS.gifDownloadFormat;
    }
    if (revision < 34 && input.gifDownloadFormatEnabled == null) {
      input.gifDownloadFormatEnabled = DEFAULT_SETTINGS.gifDownloadFormatEnabled;
    }
    if (revision < 35 && input.panelWidth == null) input.panelWidth = DEFAULT_SETTINGS.panelWidth;
    if (revision < 19) {
      if (input.downloadFileNameTemplate == null) input.downloadFileNameTemplate = DEFAULT_SETTINGS.downloadFileNameTemplate;
      if (input.downloadZipNameTemplate == null) input.downloadZipNameTemplate = DEFAULT_SETTINGS.downloadZipNameTemplate;
      if (input.downloadNameRegex == null) input.downloadNameRegex = DEFAULT_SETTINGS.downloadNameRegex;
      if (input.downloadNameReplacement == null) input.downloadNameReplacement = DEFAULT_SETTINGS.downloadNameReplacement;
    }
    if (revision < 20) {
      if (input.downloadFileNameTemplate === '{user-id}_{status-id}') {
        input.downloadFileNameTemplate = DEFAULT_SETTINGS.downloadFileNameTemplate;
      }
      if (input.downloadZipNameTemplate === '{user-id}_{status-id}') {
        input.downloadZipNameTemplate = DEFAULT_SETTINGS.downloadZipNameTemplate;
      }
      if (input.trackDownloadedPosts == null) input.trackDownloadedPosts = DEFAULT_SETTINGS.trackDownloadedPosts;
      if (input.downloadedPostIds == null) input.downloadedPostIds = [];
    }
    if (revision < 21 && input.hideAppBadge == null && input.hideAppBadgeOnDesktop != null) {
      input.hideAppBadge = input.hideAppBadgeOnDesktop === true;
    }
    if (revision < 24 && input.keywordMode === 'regex') {
      ['keywords', 'excludeKeywords'].forEach((key) => {
        if (!Array.isArray(input[key])) return;
        input[key] = input[key].map((item) => {
          const rule = safeString(item, 500).trim();
          return isSafeRegexSource(rule) ? `/${rule}/` : rule;
        });
      });
      input.keywordMode = DEFAULT_SETTINGS.keywordMode;
    }
    if (input.layoutAutoWidth == null) {
      const customTimeline = input.timelineWidth != null && Number(input.timelineWidth) !== 600;
      const customLeftbar = input.leftbarWidth != null && Number(input.leftbarWidth) !== 275;
      input.layoutAutoWidth = !(customTimeline || customLeftbar);
    }
    input.settingsRevision = DEFAULT_SETTINGS.settingsRevision;
  }
  return input;
}
async function persistSettings(changedKeys, settingsSnapshot) {
  const sanitized = sanitizeSettings(settingsSnapshot || state.settings);
  writeSettingsMirror(sanitized);
  const replaceAll = changedKeys === null;
  const requestedKeys = changedKeys === undefined ? ['downloadedPostIds'] : changedKeys;
  const keys = Array.isArray(requestedKeys)
    ? uniqueStrings(requestedKeys.filter((key) => Object.prototype.hasOwnProperty.call(SETTINGS_SCHEMA, key)))
    : [];
  let persisted = sanitized;
  if (!replaceAll && keys.length) {
    const partial = Object.fromEntries(keys.map((key) => [key, sanitized[key]]));
    persisted = await dbMergeSettings(partial, sanitized);
  } else {
    await dbPutSetting('settings', sanitized);
  }
  if (persisted !== sanitized) writeSettingsMirror(persisted);
}
function resetPaging() { state.renderLimit = state.settings.pageSize || 60; }
const SETTINGS_EFFECT_ORDER = [ 'keywords', 'adultSpam', 'layout', 'theme', 'ads', 'nfl', 'mediaDownload', 'downloadUi', 'ageBypass', 'mediaGrid', 'autoExpand', 'firefoxCompatibility', 'badge', 'panelWidth', ]; const SETTINGS_EFFECT_HANDLERS = { keywords() { bumpKeywordCache(); }, adultSpam() { adultSpamRulesVersion++; adultSpamCache = new WeakMap(); applyAdultSpamFiltering(); }, layout() { applyLayoutEnhancements(); }, theme() { applyTheme(); }, ads() { applyAdHiding(); }, nfl() { applyNflHiding(); }, mediaDownload() { applyMediaDownload(); }, downloadUi() { scheduleDownloadUiRefresh(); }, ageBypass() { applyAgeBypass(); }, mediaGrid() { applyMediaGridLayout(); }, autoExpand(nextPartial) { if (nextPartial.autoExpandPostText) expandPostShowMore(document); }, firefoxCompatibility(nextPartial) { if (!IS_FIREFOX) return; state.settings.firefoxCompatibilityPrompted = true; writeFirefoxCompatibilityMode(nextPartial.firefoxCompatibility ? 'compat' : 'normal'); }, badge() { repositionBadge(); }, panelWidth() { updatePanelPlacement(); }, };
function runSettingsEffects(nextPartial) {
  const requestedEffects = new Set();
  for (const settingKey of Object.keys(nextPartial)) {
    for (const effect of SETTINGS_SCHEMA[settingKey]?.effects || []) requestedEffects.add(effect);
  }
  for (const effect of SETTINGS_EFFECT_ORDER) {
    if (requestedEffects.has(effect)) SETTINGS_EFFECT_HANDLERS[effect](nextPartial);
  }
}
function settingsValueChanged(left, right) {
  if (left === right) return false;
  if (!left || !right || typeof left !== 'object' || typeof right !== 'object') return true;
  try { return JSON.stringify(left) !== JSON.stringify(right); }
  catch (err) { return true; }
}
function applySettingsSnapshot(rawSettings, options) {
  const opts = options || {};
  const previous = state.settings || { ...DEFAULT_SETTINGS };
  const next = sanitizeSettings(migrateSettingsDefaults(rawSettings));
  if (opts.preserveFirefoxCompatibility) {
    next.firefoxCompatibility = !!previous.firefoxCompatibility;
    next.firefoxCompatibilityPrompted = !!previous.firefoxCompatibilityPrompted;
  }
  const changed = {};
  for (const key of Object.keys(SETTINGS_SCHEMA)) {
    if (settingsValueChanged(previous[key], next[key])) changed[key] = next[key];
  }
  state.settings = next;
  if (!Object.keys(changed).length && opts.force !== true) return next;
  const followedChanged = settingsValueChanged(previous.knownFollowedHandles, next.knownFollowedHandles);
  followedHandles.clear();
  for (const handle of next.knownFollowedHandles || []) followedHandles.add(handle);
  trimFollowedHandlesToMax();
  notificationSubscriptions.clear();
  for (const rawItem of next.notificationSubscriptions || []) {
    const item = sanitizeNotificationSubscription(rawItem);
    if (item) notificationSubscriptions.set(item.username.toLowerCase(), item);
  }
  runSettingsEffects(changed);
  if (followedChanged) {
    adultSpamRulesVersion++;
    adultSpamCache = new WeakMap();
    if (document.body && state.settings.hideAdultSpam && state.settings.adultSpamSkipFollowing) {
      applyAdultSpamFiltering();
    }
  }
  resetPaging();
  refreshUI({ keepScroll: true });
  scheduleDownloadUiRefresh();
  return next;
}
function setSettingsPartial(nextPartial) {
  state.settings = { ...state.settings, ...nextPartial };
  runSettingsEffects(nextPartial);
  resetPaging();
  queueSettingsPersist(Object.keys(nextPartial));
  refreshUI();
}
function upsertPost(post, opts) {
  post = { ...post, sourceLabel: normalizeSourceLabel(post.sourceLabel) };
  const countCapture = !opts || opts.countCapture !== false;
  const index = getPostIndexById(post.id);
  const timestamp = now();
  matchCache.delete(post.id);
  if (index >= 0) {
    const existing = state.posts[index];
    const merged = {
      ...existing,
      ...post,
      sourceLabel: post.sourceType === 'page' ? '' : (post.sourceLabel || normalizeSourceLabel(existing.sourceLabel)),
      sourceType: post.sourceLabel || post.sourceType === 'page' ? post.sourceType : (existing.sourceType || post.sourceType),
      id: existing.id,
      favorite: !!existing.favorite,
      pinned: !!existing.pinned,
      clicked: !!existing.clicked,
      flashLost: existing.flashLost || false,
      note: existing.note || post.note || '',
      firstCapturedAt: existing.firstCapturedAt || post.firstCapturedAt || timestamp,
      lastCapturedAt: timestamp,
      capturedCount: countCapture ? ((existing.capturedCount || 1) + 1) : (existing.capturedCount || 1),
      sourceHistory: uniqueStrings([...(existing.sourceHistory || []), post.sourceLabel]).slice(-8),
      mediaThumbs: (post.mediaThumbs && post.mediaThumbs.length) ? post.mediaThumbs : (existing.mediaThumbs || []),
      avatarUrl: existing.avatarUrl || post.avatarUrl || '',
    };
    state.posts[index] = merged;
    queuePostPut(merged, { preserveUserState: true });
  } else {
    const created = {
      favorite: false,
      pinned: false,
      clicked: false,
      flashLost: false,
      note: '',
      sourceHistory: uniqueStrings([post.sourceLabel]).slice(-8),
      capturedCount: 1,
      firstCapturedAt: timestamp,
      lastCapturedAt: timestamp,
      mediaThumbs: [],
      avatarUrl: '',
      ...post,
    };
    appendPost(created);
    maybeShowPostLimitWarning();
    queueDbWrite(async () => {
      await dbPutPost(created, { preserveUserState: true });
      await enforceMaxPosts();
    });
  }
  if (state.posts.length > (state.settings.maxPosts || 500) + 50) {
    queueDbWrite(enforceMaxPosts);
  }
  debouncedRefreshUI();
}
function deletePost(id) {
  state.posts = state.posts.filter((p) => p.id !== id);
  rebuildPostIndex();
  prunePostRuntimeCaches([id]);
  queueDbWrite(() => dbDeletePost(id));
  refreshUI({ keepScroll: true });
}
function clearNonFavoritePosts() {
  const targets = state.posts.filter((p) => !protectedPost(p));
  if (!targets.length) return;
  if (!uiConfirm(`确定要清空 ${targets.length} 条未收藏/未置顶的帖子吗？此操作不可撤销。`)) return;
  const ids = targets.map((p) => p.id);
  state.posts = state.posts.filter(protectedPost);
  rebuildPostIndex();
  prunePostRuntimeCaches(ids);
  queueDbWrite(() => dbDeleteMany(ids, { preserveProtected: true }));
  refreshUI();
}
function updateStoredPost(id, updater, refresh = () => refreshUI({ keepScroll: true })) {
  const index = getPostIndexById(id);
  if (index < 0) return null;
  const post = state.posts[index];
  const changes = updater(post);
  if (!changes) return null;
  const updated = { ...post, ...changes };
  state.posts[index] = updated;
  queuePostPatch(id, changes);
  if (refresh) refresh();
  return updated;
}
function markClicked(id) {
  updateStoredPost(id, (post) => post.clicked ? null : { clicked: true, lastClickedAt: now() });
}
function toggleFavorite(id) {
  updateStoredPost(id, (post) => ({ favorite: !post.favorite }));
}
function togglePin(id) {
  updateStoredPost(id, (post) => ({ pinned: !post.pinned }));
}
function markFlashLost(id) {
  updateStoredPost(id, (post) => post.clicked || post.flashLost
    ? null : { flashLost: true, flashLostAt: now() }, debouncedRefreshUI);
}
function updatePostNote(id, note) {
  if (!updateStoredPost(id, () => ({ note }), null)) return;
  state.editingNoteId = null;
  state.noteDrafts.delete(id);
  matchCache.delete(id);
  refreshUI({ keepScroll: true });
}
function getPageWindow() {
  if (IS_FIREFOX && firefoxCompatibilityMode !== 'normal') return window;
  return (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;
}
let networkHookWarningShown = false;
let networkRehookWarningShown = false;
const networkHookInstallCounts = { fetch: 0, xhrOpen: 0, xhrSend: 0 };
const mediaRegistry = new Map(); // statusId -> { photos:[], gifs:[], videos:[] }
const cardRegistry = new Map(); // statusId -> { photos:[], gifs:[], videos:[] }
const videoPosterRegistry = new Map(); // posterKey -> { type:'video'|'gif', url, thumbnailUrl }
const tweetDetailMediaLookupJobs = new Map(); // statusId -> Promise<boolean>
const TWEET_DETAIL_QUERY_ID = 'zAz9764BcLZOJ0JU2wrd1A';
const TWEET_DETAIL_FEATURES = { creator_subscriptions_tweet_preview_api_enabled: true, premium_content_api_read_enabled: false, communities_web_enable_tweet_community_results_fetch: true, c9s_tweet_anatomy_moderator_badge_enabled: true, responsive_web_grok_analyze_button_fetch_trends_enabled: false, responsive_web_grok_analyze_post_followups_enabled: false, responsive_web_jetfuel_frame: false, responsive_web_grok_share_attachment_enabled: true, articles_preview_enabled: true, responsive_web_edit_tweet_api_enabled: true, graphql_is_translatable_rweb_tweet_is_translatable_enabled: true, view_counts_everywhere_api_enabled: true, longform_notetweets_consumption_enabled: true, longform_notetweets_inline_media_enabled: true, responsive_web_twitter_article_tweet_consumption_enabled: true, tweet_awards_web_tipping_enabled: false, responsive_web_grok_show_grok_translated_post: false, responsive_web_grok_analysis_button_from_backend: false, creator_subscriptions_quote_tweet_preview_enabled: false, freedom_of_speech_not_reach_fetch_enabled: true, standardized_nudges_misinfo: true, tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled: true, longform_notetweets_rich_text_read_enabled: true, profile_label_improvements_pcf_label_in_post_enabled: true, rweb_tipjar_consumption_enabled: true, verified_phone_label_enabled: false, responsive_web_grok_image_annotation_enabled: true, responsive_web_graphql_skip_user_profile_image_extensions_enabled: false, responsive_web_graphql_timeline_navigation_enabled: true, responsive_web_enhance_cards_enabled: false, };
function setBoundedRegistryEntry(registry, key, value) {
  if (registry.has(key)) registry.delete(key);
  registry.set(key, value);
  while (registry.size > MAX_MEDIA_REGISTRY_ENTRIES) {
    registry.delete(registry.keys().next().value);
  }
}
function getRegistryEntry(registry, key) {
  if (!registry.has(key)) return null;
  const value = registry.get(key);
  registry.delete(key);
  registry.set(key, value);
  return value;
}
function getVideoPosterKey(rawUrl) {
  if (!rawUrl) return '';
  try {
    const url = new URL(String(rawUrl), 'https://pbs.twimg.com');
    if (!/(?:^|\.)twimg\.com$/i.test(url.hostname)) return '';
    const path = url.pathname;
    const directoryMatch = path.match(/\/(amplify_tw_video_thumb|amplify_video_thumb|ext_tw_video_thumb)\/([A-Za-z0-9_-]+)/i);
    if (directoryMatch) return `${directoryMatch[1].toLowerCase()}:${directoryMatch[2]}`;
    const gifMatch = path.match(/\/tweet_video_thumb\/([A-Za-z0-9_-]+)(?:\.[A-Za-z0-9]+)?$/i);
    return gifMatch ? `tweet_video_thumb:${gifMatch[1]}` : '';
  } catch (err) { return ''; }
}
function registerVideoPosterMedia(media, mp4Url) {
  if (!media || !mp4Url) return;
  const posterUrl = media.media_url_https || media.media_url || '';
  const posterKey = getVideoPosterKey(posterUrl);
  if (!posterKey) return;
  setBoundedRegistryEntry(videoPosterRegistry, posterKey, {
    type: media.type === 'animated_gif' ? 'gif' : 'video',
    url: mp4Url,
    thumbnailUrl: safeHttpsUrl(posterUrl, ['pbs.twimg.com']),
  });
}
function registerMedia(id, mediaArr) {
  if (!id || !Array.isArray(mediaArr) || !mediaArr.length) return;
  const key = String(id);
  const entry = getRegistryEntry(mediaRegistry, key) || { photos: [], gifs: [], videos: [] };
  for (const m of mediaArr) {
    if (!m || typeof m !== 'object') continue;
    if (m.type === 'photo' && m.media_url_https) {
      entry.photos.push(m.media_url_https);
    } else if ((m.type === 'video' || m.type === 'animated_gif') && m.video_info && Array.isArray(m.video_info.variants)) {
      const mp4s = m.video_info.variants.filter((v) => v && v.content_type === 'video/mp4' && v.url);
      mp4s.sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0));
      if (mp4s[0]) {
        if (m.type === 'animated_gif') entry.gifs.push(mp4s[0].url);
        else entry.videos.push(mp4s[0].url);
        registerVideoPosterMedia(m, mp4s[0].url);
      }
    }
  }
  entry.photos = uniqueStrings(entry.photos);
  entry.gifs = uniqueStrings(entry.gifs);
  entry.videos = uniqueStrings(entry.videos);
  setBoundedRegistryEntry(mediaRegistry, key, entry);
  syncMediaFlagsToPost(key);
}
function pushCardEntry(id, acc) {
  if (!id) return;
  if (!acc || (!acc.photos.length && !acc.gifs.length && !acc.videos.length)) return;
  const key = String(id);
  const entry = getRegistryEntry(cardRegistry, key) || { photos: [], gifs: [], videos: [] };
  acc.photos.forEach((u) => { if (u) entry.photos.push(u); });
  acc.gifs.forEach((u) => { if (u) entry.gifs.push(u); });
  acc.videos.forEach((u) => { if (u) entry.videos.push(u); });
  entry.photos = uniqueStrings(entry.photos);
  entry.gifs = uniqueStrings(entry.gifs);
  entry.videos = uniqueStrings(entry.videos);
  setBoundedRegistryEntry(cardRegistry, key, entry);
  syncMediaFlagsToPost(key);
}
function syncMediaFlagsToPost(idStr) {
  if (!idStr) return;
  const post = getPostById(idStr);
  if (!post) return;
  const reg = getRegistryEntry(mediaRegistry, idStr) || getRegistryEntry(cardRegistry, idStr);
  if (!reg) return;
  const hasPhoto = (reg.photos || []).length > 0;
  const hasVid = (reg.videos || []).length > 0 || (reg.gifs || []).length > 0;
  if (hasPhoto || hasVid) {
    if (post.hasImage !== hasPhoto || post.hasVideo !== hasVid) {
      upsertPost({
        ...post,
        hasImage: hasPhoto,
        hasVideo: hasVid,
      }, { countCapture: false });
    }
  }
}
function pickEntityMedia(m, acc) {
  if (!m || typeof m !== 'object') return false;
  if (m.type === 'photo' && m.media_url_https) { acc.photos.push(m.media_url_https); return true; }
  if ((m.type === 'video' || m.type === 'animated_gif') && m.video_info && Array.isArray(m.video_info.variants)) {
    const mp4s = m.video_info.variants.filter((v) => v && v.content_type === 'video/mp4' && v.url);
    mp4s.sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0));
    if (mp4s[0]) {
      (m.type === 'animated_gif' ? acc.gifs : acc.videos).push(mp4s[0].url);
      registerVideoPosterMedia(m, mp4s[0].url);
      return true;
    }
  }
  return false;
}
function readCookieValue(name) {
  const prefix = `${name}=`;
  try {
    const part = String(document.cookie || '').split(';').map((item) => item.trim()).find((item) => item.startsWith(prefix));
    return part ? decodeURIComponent(part.slice(prefix.length)) : '';
  } catch (err) { return ''; }
}
function isFirefoxCompatibilityActive() {
  return IS_FIREFOX && firefoxCompatibilityMode === 'compat';
}
function buildFirefoxTweetDetailHeaders() {
  const headers = {
    authorization: 'Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA',
    'x-twitter-client-language': 'en',
    'x-twitter-active-user': 'yes',
    'content-type': 'application/json',
  };
  const csrfToken = readCookieValue('ct0');
  const guestToken = readCookieValue('gt');
  if (csrfToken) headers['x-csrf-token'] = csrfToken;
  if (guestToken) headers['x-guest-token'] = guestToken;
  else headers['x-twitter-auth-type'] = 'OAuth2Session';
  return headers;
}
function getCurrentViewerId() {
  const twid = readCookieValue('twid');
  const match = String(twid || '').match(/(?:^|=)u?=?([0-9]{1,30})$/i)
    || String(twid || '').match(/u=([0-9]{1,30})/i);
  return match ? match[1] : '';
}
async function requestXSessionJson(pathOrUrl, options) {
  const opts = options || {};
  const url = new URL(pathOrUrl, location.origin).href;
  const headers = buildFirefoxTweetDetailHeaders();
  if (readCookieValue('ct0')) headers['x-twitter-auth-type'] = 'OAuth2Session';
  if (opts.form) headers['content-type'] = 'application/x-www-form-urlencoded';
  const controller = typeof AbortController === 'function' ? new AbortController() : null;
  const timer = controller ? setTimeout(() => controller.abort(), 30000) : null;
  try {
    const pageWin = getPageWindow();
    const fetchImpl = pageWin && typeof pageWin.fetch === 'function' ? pageWin.fetch : fetch;
    const response = await fetchImpl.call(pageWin || window, url, {
      method: opts.method || 'GET',
      credentials: 'include',
      headers,
      body: opts.body || undefined,
      signal: controller ? controller.signal : undefined,
    });
    if (!response || !response.ok) throw new Error(`X 接口返回 ${response ? response.status : '未知状态'}`);
    return await response.json();
  } finally {
    if (timer) clearTimeout(timer);
  }
}
function notificationUserFromRest(raw, enabled) {
  if (!raw || typeof raw !== 'object') return null;
  return sanitizeNotificationSubscription({
    id: raw.id_str || raw.id,
    username: raw.screen_name,
    displayName: raw.name,
    avatarUrl: raw.profile_image_url_https || raw.profile_image_url,
    enabled,
    updatedAt: now(),
  });
}
async function syncNotificationSubscriptions() {
  if (state.notificationSyncInProgress) return;
  const viewerId = getCurrentViewerId();
  if (!viewerId) {
    showToast('⚠️ 无法读取当前 X 用户 ID，请确认已经登录');
    return;
  }
  state.notificationSyncInProgress = true;
  renderNotificationSubscriptions();
  const collected = new Map();
  let cursor = '-1';
  let pageCount = 0;
  try {
    do {
      const params = new URLSearchParams({
        include_profile_interstitial_type: '1',
        include_blocking: '1',
        include_blocked_by: '1',
        include_followed_by: '1',
        include_want_retweets: '1',
        include_mute_edge: '1',
        include_can_dm: '1',
        include_can_media_tag: '1',
        include_ext_is_blue_verified: '1',
        include_ext_verified_type: '1',
        include_ext_profile_image_shape: '1',
        skip_status: '1',
        cursor,
        user_id: viewerId,
        count: '200',
        with_total_count: 'true',
      });
      const payload = await requestXSessionJson(`/i/api/1.1/friends/following/list.json?${params}`);
      const users = Array.isArray(payload && payload.users) ? payload.users : [];
      for (const rawUser of users) {
        const username = safeString(rawUser && rawUser.screen_name, 30).replace(/^@+/, '');
        if (username) rememberFollowingRelation(username, true);
        if (rawUser && rawUser.notifications === true) {
          const item = notificationUserFromRest(rawUser, true);
          if (item) collected.set(item.username.toLowerCase(), item);
        }
      }
      cursor = safeString((payload && (payload.next_cursor_str || payload.next_cursor)) || '0', 200);
      pageCount++;
      if (pageCount >= 50 && cursor && cursor !== '0') throw new Error('关注账号过多，已达到 50 页安全上限');
    } while (cursor && cursor !== '0');
    for (const [key, item] of collected) {
      const existing = notificationSubscriptions.get(key);
      notificationSubscriptions.set(key, { ...(existing || {}), ...item, enabled: true, updatedAt: now() });
    }
    state.settings.notificationSubscriptionsSyncedAt = now();
    scheduleNotificationSubscriptionsPersist();
    const enabledTotal = [...notificationSubscriptions.values()].filter((item) => item.enabled).length;
    showToast(`✅ 本次识别 ${collected.size} 个，当前保留 ${enabledTotal} 个订阅`);
  } catch (err) {
    console.error('[BetterX] sync notification subscriptions failed:', err);
    showToast(`⚠️ 同步失败：${safeString(err && err.message, 120) || '未知错误'}`);
  } finally {
    state.notificationSyncInProgress = false;
    renderNotificationSubscriptions();
  }
}
async function updateNotificationSubscription(username, enabled) {
  const key = safeString(username, 30).replace(/^@+/, '').toLowerCase();
  const existing = notificationSubscriptions.get(key);
  if (!existing || !/^\d{1,30}$/.test(existing.id) || state.notificationMutationUsers.has(key)) return;
  const desiredEnabled = enabled === true;
  const mutationGuard = beginNotificationMutationGuard(key, desiredEnabled);
  const body = new URLSearchParams({
    include_profile_interstitial_type: '1',
    include_blocking: '1',
    include_blocked_by: '1',
    include_followed_by: '1',
    include_want_retweets: '1',
    include_mute_edge: '1',
    include_can_dm: '1',
    include_can_media_tag: '1',
    include_ext_is_blue_verified: '1',
    include_ext_verified_type: '1',
    include_ext_profile_image_shape: '1',
    skip_status: '1',
    cursor: '-1',
    id: existing.id,
    device: desiredEnabled ? 'true' : 'false',
  });
  state.notificationMutationUsers.add(key);
  renderNotificationSubscriptions();
  try {
    await requestXSessionJson('/i/api/1.1/friendships/update.json', {
      method: 'POST',
      form: true,
      body: body.toString(),
    });
    rememberNotificationSubscription(existing, desiredEnabled, {
      trackDisabled: true,
      authoritative: true,
    });
    mutationGuard.pending = false;
    mutationGuard.expiresAt = now() + NOTIFICATION_MUTATION_GUARD_MS;
    renderNotificationSubscriptions();
    showToast(desiredEnabled ? `✅ 已开启 @${existing.username} 的帖子通知` : `已关闭 @${existing.username} 的帖子通知`);
  } catch (err) {
    if (notificationMutationGuards.get(key) === mutationGuard) notificationMutationGuards.delete(key);
    console.error('[BetterX] update notification subscription failed:', err);
    showToast(`⚠️ 修改失败：${safeString(err && err.message, 120) || '未知错误'}`);
  } finally {
    state.notificationMutationUsers.delete(key);
    renderNotificationSubscriptions();
  }
}
function extractMediaFromTweetDetail(payload, statusId) {
  const targetId = String(statusId || '');
  if (!payload || !targetId) return false;
  const stack = [payload];
  let scanned = 0;
  let foundMedia = false;
  while (stack.length && scanned < 12000) {
    const current = stack.pop();
    scanned++;
    if (!current || typeof current !== 'object') continue;
    const candidates = [current, current.tweet, current.tweet_results && current.tweet_results.result].filter(Boolean);
    for (const candidate of candidates) {
      if (!candidate || typeof candidate !== 'object') continue;
      const legacy = candidate.legacy && typeof candidate.legacy === 'object' ? candidate.legacy : null;
      const candidateId = String(candidate.rest_id || candidate.id_str || candidate.id || (legacy && legacy.id_str) || '');
      const media = (candidate.extended_entities && candidate.extended_entities.media)
        || (legacy && legacy.extended_entities && legacy.extended_entities.media);
      if (candidateId && Array.isArray(media) && media.length) {
        registerMedia(candidateId, media);
        foundMedia = true;
      }
      const card = candidate.card || (legacy && legacy.card);
      if (candidateId && card) {
        harvestCard(candidateId, card);
        const cardMedia = cardRegistry.get(candidateId);
        if (cardMedia && (cardMedia.photos.length || cardMedia.gifs.length || cardMedia.videos.length)) foundMedia = true;
      }
    }
    const children = Array.isArray(current) ? current : Object.values(current);
    for (const child of children) {
      if (child && typeof child === 'object') stack.push(child);
    }
  }
  return foundMedia;
}
function requestTweetDetailMediaWithGm(url, statusId) {
  if (typeof GM_xmlhttpRequest !== 'function') return Promise.resolve(false);
  return new Promise((resolve) => {
    try {
      GM_xmlhttpRequest({
        method: 'GET',
        url,
        headers: buildFirefoxTweetDetailHeaders(),
        responseType: 'json',
        timeout: 30000,
        onload: (response) => {
          if (!response || response.status < 200 || response.status >= 300) { resolve(false); return; }
          let payload = response.response;
          if ((!payload || typeof payload === 'string') && response.responseText) payload = response.responseText;
          if (typeof payload === 'string') {
            try { payload = JSON.parse(payload); } catch (err) { resolve(false); return; }
          }
          resolve(extractMediaFromTweetDetail(payload, statusId));
        },
        onerror: () => resolve(false),
        ontimeout: () => resolve(false),
        onabort: () => resolve(false),
      });
    } catch (err) { resolve(false); }
  });
}
function requestTweetDetailMedia(statusId) {
  const id = String(statusId || '');
  if (!id) return Promise.resolve(false);
  if (tweetDetailMediaLookupJobs.has(id)) return tweetDetailMediaLookupJobs.get(id);
  const variables = { tweetId: id, withCommunity: false, includePromotedContent: false, withVoice: false };
  const fieldToggles = { withArticleRichContentState: true, withArticlePlainText: false, withGrokAnalyze: false, withDisallowedReplyControls: false };
  const url = `https://x.com/i/api/graphql/${TWEET_DETAIL_QUERY_ID}/TweetResultByRestId?variables=${encodeURIComponent(JSON.stringify(variables))}&features=${encodeURIComponent(JSON.stringify(TWEET_DETAIL_FEATURES))}&fieldToggles=${encodeURIComponent(JSON.stringify(fieldToggles))}`;
  const task = (async () => {
    if (await requestTweetDetailMediaWithGm(url, id)) return true;
    try {
      const payload = await requestXSessionJson(url);
      return extractMediaFromTweetDetail(payload, id);
    } catch (err) {
      debugLog('same-origin tweet detail lookup failed:', err);
      return false;
    }
  })().finally(() => tweetDetailMediaLookupJobs.delete(id));
  tweetDetailMediaLookupJobs.set(id, task);
  return task;
}
function harvestCard(id, card) {
  if (!id || !card || typeof card !== 'object') return;
  const legacy = card.legacy || card;
  const bvs = legacy.binding_values;
  const entries = [];
  if (Array.isArray(bvs)) { for (const e of bvs) if (e && e.key) entries.push(e); }
  else if (bvs && typeof bvs === 'object') { for (const k in bvs) entries.push({ key: k, value: bvs[k] }); }
  if (!entries.length) return;
  const acc = { photos: [], gifs: [], videos: [] };
  const thumbs = [];
  let gotReal = false;
  for (const e of entries) {
    const key = e.key || '';
    const val = e.value || {};
    if (key === 'unified_card' && val.string_value) {
      try {
        const uc = JSON.parse(val.string_value);
        const me = uc && uc.media_entities;
        if (me && typeof me === 'object') { for (const mk in me) { if (pickEntityMedia(me[mk], acc)) gotReal = true; } }
      } catch (e2) {}
    }
    const sv = val.string_value;
    if (typeof sv === 'string' && sv.indexOf('.mp4') !== -1 && /^https?:/i.test(sv)) { acc.videos.push(sv); gotReal = true; }
    if (val.image_value && val.image_value.url) { thumbs.push({ key: key, url: val.image_value.url, w: val.image_value.width || 0 }); }
  }
  if (!gotReal && thumbs.length) {
    thumbs.sort((a, b) => {
      const score = (t) => (/large|orig|full/i.test(t.key) ? 100000 : 0) + (t.w || 0);
      return score(b) - score(a);
    });
    acc.photos.push(thumbs[0].url);
  }
  pushCardEntry(id, acc);
}
function harvestFollowingRelationship(obj) {
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return;
  const legacy = obj.legacy && typeof obj.legacy === 'object' ? obj.legacy : null;
  const handle = safeString(
    (legacy && legacy.screen_name) || obj.screen_name || obj.screenName || '',
    30
  ).replace(/^@+/, '').toLowerCase();
  if (!/^[a-z0-9_]{1,15}$/.test(handle)) return;
  const perspectives = obj.relationship_perspectives && typeof obj.relationship_perspectives === 'object'
    ? obj.relationship_perspectives
    : null;
  const candidates = [
    legacy && legacy.following,
    obj.following,
    perspectives && perspectives.following,
  ];
  const following = candidates.find((value) => typeof value === 'boolean');
  if (typeof following !== 'boolean') return;
  rememberFollowingRelation(handle, following);
}
function harvestNotificationRelationship(obj) {
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return;
  const relationship = obj.relationship && typeof obj.relationship === 'object' ? obj.relationship : null;
  const relationshipSource = relationship && relationship.source && typeof relationship.source === 'object'
    ? relationship.source
    : null;
  const relationshipTarget = relationship && relationship.target && typeof relationship.target === 'object'
    ? relationship.target
    : null;
  if (relationshipSource && relationshipTarget && typeof relationshipSource.notifications_enabled === 'boolean') {
    const targetUser = notificationUserFromRest(relationshipTarget, relationshipSource.notifications_enabled);
    if (targetUser) {
      rememberNotificationSubscription(targetUser, relationshipSource.notifications_enabled, { trackDisabled: true });
    }
  }
  const legacy = obj.legacy && typeof obj.legacy === 'object' ? obj.legacy : null;
  const core = obj.core && typeof obj.core === 'object' ? obj.core : null;
  const settings = obj.notifications_settings && typeof obj.notifications_settings === 'object'
    ? obj.notifications_settings
    : null;
  const enabled = settings && typeof settings.notifications_enabled === 'boolean'
    ? settings.notifications_enabled
    : (obj.notifications === true || (legacy && legacy.notifications === true) ? true : null);
  if (typeof enabled !== 'boolean') return;
  const username = safeString(
    (legacy && legacy.screen_name) || (core && core.screen_name) || obj.screen_name || obj.username || '',
    30
  ).replace(/^@+/, '');
  const id = safeString(obj.rest_id || obj.id_str || obj.id || (legacy && legacy.id_str) || '', 30);
  if (!/^[a-z0-9_]{1,15}$/i.test(username) || !/^\d{1,30}$/.test(id)) return;
  const avatar = obj.avatar && typeof obj.avatar === 'object' ? obj.avatar : null;
  rememberNotificationSubscription({
    id,
    username,
    displayName: safeString((core && core.name) || obj.name || (legacy && legacy.name) || '', 100),
    avatarUrl: safeImportedAssetUrl(
      (avatar && (avatar.image_url || avatar.imageUrl))
      || (legacy && (legacy.profile_image_url_https || legacy.profile_image_url))
      || obj.profile_image_url_https || obj.profile_image_url || ''
    ),
  }, enabled);
}
function getHandleFromFollowControl(control) {
  if (!control || !control.getAttribute) return '';
  const labelText = `${control.getAttribute('aria-label') || ''} ${control.innerText || ''}`;
  const labelMatch = labelText.match(/@([a-z0-9_]{1,15})/i);
  if (labelMatch) return labelMatch[1].toLowerCase();
  const href = control.closest('a[href]')?.getAttribute('href') || control.getAttribute('href') || '';
  const hrefMatch = href.match(/^\/([a-z0-9_]{1,15})(?:[/?#]|$)/i);
  if (hrefMatch && !RESERVED_TOP_PATHS.has(hrefMatch[1].toLowerCase())) return hrefMatch[1].toLowerCase();
  const testId = control.getAttribute('data-testid') || '';
  const testIdMatch = testId.match(/^([a-z0-9_]{1,15})-(?:un)?follow$/i);
  return testIdMatch ? testIdMatch[1].toLowerCase() : '';
}
function harvestFollowingControlsFromRoot(root) {
  if (!root || !root.querySelectorAll) return false;
  const selector = '[data-testid$="-follow"], [data-testid$="-unfollow"]';
  const controls = [];
  if (root.matches && root.matches(selector)) controls.push(root);
  root.querySelectorAll(selector).forEach((control) => controls.push(control));
  let changed = false;
  for (const control of controls) {
    const testId = control.getAttribute('data-testid') || '';
    const following = testId.endsWith('-unfollow') ? true : (testId.endsWith('-follow') ? false : null);
    const handle = getHandleFromFollowControl(control);
    if (handle && typeof following === 'boolean') {
      changed = rememberFollowingRelation(handle, following) || changed;
    }
  }
  return changed;
}
const networkHarvestQueue = [];
let networkHarvestQueuedChars = 0;
let networkHarvestScheduled = false;
let networkHarvestDroppedJobs = 0;
function textMayContainHarvestData(txt) {
  return txt.indexOf('extended_entities') !== -1 || txt.indexOf('binding_values') !== -1
    || txt.indexOf('"following"') !== -1 || txt.indexOf('relationship_perspectives') !== -1
    || txt.indexOf('notifications_settings') !== -1 || txt.indexOf('notifications_enabled') !== -1
    || txt.indexOf('"notifications"') !== -1;
}
function scheduleNetworkHarvestDrain() {
  if (networkHarvestScheduled || !networkHarvestQueue.length) return;
  networkHarvestScheduled = true;
  const run = (deadline) => {
    networkHarvestScheduled = false;
    drainNetworkHarvestQueue(deadline);
    if (networkHarvestQueue.length) scheduleNetworkHarvestDrain();
  };
  if (typeof window.requestIdleCallback === 'function') {
    window.requestIdleCallback(run, { timeout: 750 });
  } else {
    setTimeout(() => run({ didTimeout: false, timeRemaining: () => 8 }), 16);
  }
}
function enqueueNetworkHarvestObject(root) {
  if (!root || typeof root !== 'object') return;
  if (networkHarvestQueue.length >= MAX_NETWORK_HARVEST_JOBS) {
    networkHarvestDroppedJobs++;
    return;
  }
  networkHarvestQueue.push({ type: 'object', stack: [{ value: root, depth: 0 }], processedNodes: 0 });
  scheduleNetworkHarvestDrain();
}
function tryHarvest(txt) {
  if (!txt || txt.length > MAX_NETWORK_RESPONSE_BYTES || !textMayContainHarvestData(txt)) return;
  if (networkHarvestQueue.length >= MAX_NETWORK_HARVEST_JOBS
      || networkHarvestQueuedChars + txt.length > MAX_NETWORK_HARVEST_QUEUE_CHARS) {
    networkHarvestDroppedJobs++;
    return;
  }
  networkHarvestQueuedChars += txt.length;
  networkHarvestQueue.push({ type: 'text', text: txt, charLength: txt.length });
  scheduleNetworkHarvestDrain();
}
function processHarvestObjectNode(value, depth, stack) {
  if (!value || typeof value !== 'object' || depth > 40) return;
  if (!Array.isArray(value)) {
    harvestFollowingRelationship(value);
    harvestNotificationRelationship(value);
    const idStr = value.id_str;
    const ext = value.extended_entities;
    if (idStr && ext && Array.isArray(ext.media)) registerMedia(idStr, ext.media);
    if (value.card && typeof value.card === 'object') {
      const cid = value.rest_id || idStr || (value.legacy && value.legacy.id_str);
      if (cid) { try { harvestCard(String(cid), value.card); } catch (err) {} }
    }
  }
  const children = Array.isArray(value) ? value : Object.values(value);
  for (let i = children.length - 1; i >= 0; i--) {
    const child = children[i];
    if (child && typeof child === 'object') stack.push({ value: child, depth: depth + 1 });
    if (stack.length >= MAX_NETWORK_HARVEST_NODES_PER_JOB) break;
  }
}
function drainNetworkHarvestQueue(deadline) {
  let nodeBudget = NETWORK_HARVEST_SLICE_NODES;
  while (networkHarvestQueue.length && nodeBudget > 0) {
    if (typeof deadline.timeRemaining === 'function' && deadline.timeRemaining() <= 2 && nodeBudget < NETWORK_HARVEST_SLICE_NODES) break;
    let job = networkHarvestQueue[0];
    if (job.type === 'text') {
      networkHarvestQueuedChars = Math.max(0, networkHarvestQueuedChars - (job.charLength || 0));
      let parsed;
      try { parsed = JSON.parse(job.text); } catch (err) { networkHarvestQueue.shift(); continue; }
      job = { type: 'object', stack: [{ value: parsed, depth: 0 }], processedNodes: 0 };
      networkHarvestQueue[0] = job;
      nodeBudget = Math.max(1, nodeBudget - 50);
    }
    while (job.stack.length && nodeBudget > 0 && job.processedNodes < MAX_NETWORK_HARVEST_NODES_PER_JOB) {
      const node = job.stack.pop();
      job.processedNodes++;
      nodeBudget--;
      try { processHarvestObjectNode(node.value, node.depth, job.stack); } catch (err) {}
      if (typeof deadline.timeRemaining === 'function' && deadline.timeRemaining() <= 2) break;
    }
    if (!job.stack.length || job.processedNodes >= MAX_NETWORK_HARVEST_NODES_PER_JOB) {
      if (job.processedNodes >= MAX_NETWORK_HARVEST_NODES_PER_JOB) networkHarvestDroppedJobs++;
      networkHarvestQueue.shift();
    } else {
      break;
    }
  }
}
function declaredResponseTooLarge(getHeader) {
  try {
    const raw = getHeader('content-length');
    const size = Number(raw);
    return Number.isFinite(size) && size > MAX_NETWORK_RESPONSE_BYTES;
  } catch (err) { return false; }
}
function harvestXhrResponse(xhr) {
  const url = xhr && xhr.__xvUrl ? String(xhr.__xvUrl) : '';
  if (!/(graphql|\/2\/timeline|\/i\/api\/)/i.test(url)) return;
  try {
    if (typeof xhr.getResponseHeader === 'function'
        && declaredResponseTooLarge((name) => xhr.getResponseHeader(name))) return;
    if (xhr.responseType === '' || xhr.responseType === 'text') {
      tryHarvest(xhr.responseText);
    } else if (xhr.responseType === 'json' && xhr.response && typeof xhr.response === 'object') {
      enqueueNetworkHarvestObject(xhr.response);
    } else if (xhr.responseType === 'arraybuffer' && xhr.response && typeof xhr.response.byteLength === 'number' && xhr.response.byteLength <= MAX_NETWORK_RESPONSE_BYTES) {
      tryHarvest(new TextDecoder('utf-8').decode(new Uint8Array(xhr.response)));
    } else if (xhr.responseType === 'blob' && xhr.response && typeof xhr.response.size === 'number' && typeof xhr.response.text === 'function' && xhr.response.size <= MAX_NETWORK_RESPONSE_BYTES) {
      xhr.response.text().then(tryHarvest).catch(() => {});
    }
  } catch (e) {}
}
function warnNetworkHooksDisabled(reason) {
  if (networkHookWarningShown) return;
  networkHookWarningShown = true;
  console.warn('[BetterX] 为避免阻断 X 页面启动，已停用网络媒体采集：', reason);
}
function warnNetworkRehookLimit(apiName) {
  if (networkRehookWarningShown) return;
  networkRehookWarningShown = true;
  console.warn(`[BetterX] ${apiName} 被其他脚本反复替换，已停止继续套娃 Hook；可导出 Firefox 兼容诊断。`);
}
function installNetworkHooks() {
  if (IS_FIREFOX && firefoxCompatibilityMode !== 'normal') {
    warnNetworkHooksDisabled(firefoxCompatibilityMode === 'compat'
      ? 'Firefox 兼容模式不改写 fetch/XMLHttpRequest'
      : 'Firefox 首次兼容性选择前暂缓改写 fetch/XMLHttpRequest');
    return;
  }
  const pageWin = getPageWindow();
  try {
    const origFetch = pageWin.fetch;
    if (origFetch && !origFetch.__xvHooked) {
      if (networkHookInstallCounts.fetch >= MAX_NETWORK_REHOOKS_PER_API) {
        warnNetworkRehookLimit('fetch');
      } else {
        const hooked = function (...args) {
          const p = origFetch.apply(this, args);
          try {
            p.then((res) => {
              try {
                const url = (res && res.url) || '';
                if (res && res.clone && /(graphql|\/2\/timeline|\/i\/api\/)/i.test(url)) {
                  if (res.headers && declaredResponseTooLarge((name) => res.headers.get(name))) return;
                  const contentType = res.headers && res.headers.get ? (res.headers.get('content-type') || '') : '';
                  if (contentType && !/(?:json|javascript|text)/i.test(contentType)) return;
                  res.clone().text().then(tryHarvest).catch(() => {});
                }
              } catch (e) {}
            }).catch(() => {});
          } catch (e) {}
          return p;
        };
        hooked.__xvHooked = true;
        pageWin.fetch = hooked;
        if (pageWin.fetch === hooked) networkHookInstallCounts.fetch++;
      }
    }
  } catch (e) {}
  try {
    const XHR = pageWin.XMLHttpRequest;
    if (XHR && XHR.prototype && XHR.prototype.open && !XHR.prototype.open.__xvHooked) {
      if (networkHookInstallCounts.xhrOpen >= MAX_NETWORK_REHOOKS_PER_API) {
        warnNetworkRehookLimit('XMLHttpRequest.open');
      } else {
        const origOpen = XHR.prototype.open;
        const hookedOpen = function (method, url) {
          this.__xvUrl = url;
          return origOpen.apply(this, arguments);
        };
        hookedOpen.__xvHooked = true;
        XHR.prototype.open = hookedOpen;
        if (XHR.prototype.open === hookedOpen) networkHookInstallCounts.xhrOpen++;
      }
    }
    if (XHR && XHR.prototype && XHR.prototype.send && !XHR.prototype.send.__xvHooked) {
      if (networkHookInstallCounts.xhrSend >= MAX_NETWORK_REHOOKS_PER_API) {
        warnNetworkRehookLimit('XMLHttpRequest.send');
      } else {
        const origSend = XHR.prototype.send;
        const hookedSend = function () {
          try {
            this.addEventListener('load', () => harvestXhrResponse(this), { once: true });
          } catch (e) {}
          return origSend.apply(this, arguments);
        };
        hookedSend.__xvHooked = true;
        XHR.prototype.send = hookedSend;
        if (XHR.prototype.send === hookedSend) networkHookInstallCounts.xhrSend++;
      }
    }
  } catch (e) {}
}
const DOWNLOAD_NAME_TOKENS = [
  { token: '{用户名}', key: 'user-name' },
  { token: '{用户ID}', key: 'user-id' },
  { token: '{帖子ID}', key: 'status-id' },
  { token: '{发布时间}', key: 'date-time' },
  { token: '{帖子正文}', key: 'full-text' },
  { token: '{文件类型}', key: 'file-type' },
  { token: '{原文件名}', key: 'file-name' },
  { token: '{序号}', key: 'index' },
];
const DOWNLOAD_NAME_LEGACY_TOKENS = {
  'user-name': 'user-name', 'user-id': 'user-id', 'status-id': 'status-id', 'date-time': 'date-time',
  'full-text': 'full-text', 'file-type': 'file-type', 'file-name': 'file-name', index: 'index',
};
const DOWNLOAD_NAME_CHINESE_TOKENS = {
  用户名: 'user-name', 用户ID: 'user-id', 帖子ID: 'status-id', 发布时间: 'date-time',
  帖子正文: 'full-text', 文件类型: 'file-type', 原文件名: 'file-name', 序号: 'index',
};
const DOWNLOAD_NAME_LOCALIZED_TOKENS = {
  'zh-TW': {
    'user-name': '使用者名稱', 'user-id': '使用者ID', 'status-id': '貼文ID', 'date-time': '發布時間',
    'full-text': '貼文內文', 'file-type': '檔案類型', 'file-name': '原檔名', index: '序號',
  },
  ja: {
    'user-name': 'ユーザー名', 'user-id': 'ユーザーID', 'status-id': 'ポストID', 'date-time': '投稿日時',
    'full-text': 'ポスト本文', 'file-type': 'ファイル種別', 'file-name': '元ファイル名', index: '連番',
  },
  en: Object.fromEntries(Object.keys(DOWNLOAD_NAME_LEGACY_TOKENS).map((key) => [key, key])),
};
const DOWNLOAD_NAME_TOKEN_KEYS = new Map([
  ...Object.entries(DOWNLOAD_NAME_CHINESE_TOKENS), ...Object.entries(DOWNLOAD_NAME_LEGACY_TOKENS),
  ...Object.values(DOWNLOAD_NAME_LOCALIZED_TOKENS).flatMap((labels) => (
    Object.entries(labels).map(([key, label]) => [label, key])
  )),
]);
const DOWNLOAD_NAME_CANONICAL_TOKENS = new Map(DOWNLOAD_NAME_TOKENS.map(({ token, key }) => [key, token]));
function localizeDownloadNameToken(token, key) {
  const label = DOWNLOAD_NAME_LOCALIZED_TOKENS[UI_LANGUAGE]?.[key];
  return label ? `{${label}}` : token;
}
function rewriteDownloadNameTemplateTokens(template, localized) {
  return String(template || '').replace(/\{([^{}]+)\}/g, (all, rawKey) => {
    const key = DOWNLOAD_NAME_TOKEN_KEYS.get(rawKey);
    const token = key && DOWNLOAD_NAME_CANONICAL_TOKENS.get(key);
    return token ? (localized ? localizeDownloadNameToken(token, key) : token) : all;
  });
}
function localizeDownloadNameTemplate(template) { return rewriteDownloadNameTemplateTokens(template, true); }
function normalizeDownloadNameTemplate(template) { return rewriteDownloadNameTemplateTokens(template, false); }
function formatDownloadNameDate(value) {
  const date = new Date(value || Date.now());
  const safeDate = Number.isFinite(date.getTime()) ? date : new Date();
  const pad = (number) => String(number).padStart(2, '0');
  return `${safeDate.getFullYear()}-${pad(safeDate.getMonth() + 1)}-${pad(safeDate.getDate())}_${pad(safeDate.getHours())}-${pad(safeDate.getMinutes())}-${pad(safeDate.getSeconds())}`;
}
function sanitizeDownloadName(value, fallback) {
  let name = String(value == null ? '' : value);
  try { name = name.normalize('NFKC'); } catch (err) {}
  name = name
    .replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '_')
    .replace(/\s+/g, ' ')
    .replace(/[. ]+$/g, '')
    .trim();
  return (name || fallback || 'x_download').slice(0, 160);
}
function getDownloadSourceName(url, ext) {
  let raw = '';
  try { raw = new URL(url).pathname.split('/').pop() || ''; } catch (err) {}
  raw = raw.replace(new RegExp(`\\.${escapeRegExp(String(ext || ''))}$`, 'i'), '');
  return sanitizeDownloadName(raw, 'media');
}
function renderDownloadNameTemplate(template, values) {
  return String(template || '').replace(/\{([^{}]+)\}/g, (all, rawKey) => {
    const key = DOWNLOAD_NAME_TOKEN_KEYS.get(rawKey);
    return key && values[key] != null ? String(values[key]) : all;
  });
}
function downloadTemplateIncludesIndex(template) {
  return /\{序号\}/.test(normalizeDownloadNameTemplate(template));
}
function applyDownloadNameRegex(name, regexSource, replacement) {
  const source = String(regexSource || '').trim();
  const regex = source ? safeRegex(source, 'g') : null;
  if (!regex) return name;
  try { return name.replace(regex, String(replacement || '')); } catch (err) { return name; }
}
function buildDownloadNameBase(job, purpose, item) {
  const isZip = purpose === 'zip';
  const mediaType = isZip ? 'zip' : (item && item.mediaType) || 'media';
  const values = {
    'user-name': job.displayName || job.username || 'x',
    'user-id': job.username || 'x',
    'status-id': job.statusId || 'post',
    'date-time': formatDownloadNameDate(job.postDate || job.createdAt),
    'full-text': String(job.postText || '').replace(/\s+/g, ' ').trim().slice(0, 80) || '无正文',
    'file-type': mediaType,
    'file-name': isZip ? 'media' : getDownloadSourceName(item && item.url, item && item.ext),
    'index': isZip ? '' : String((item && item.index != null ? item.index : 0) + 1),
  };
  const template = isZip ? job.zipNameTemplate : job.fileNameTemplate;
  const rendered = renderDownloadNameTemplate(template, values);
  return sanitizeDownloadName(
    applyDownloadNameRegex(rendered, job.downloadNameRegex, job.downloadNameReplacement),
    `${values['user-id']}_${values['status-id']}`
  );
}
function appendDownloadExtension(baseName, ext) {
  const extension = String(ext || 'bin').replace(/^\.+/, '').toLowerCase() || 'bin';
  const duplicateExtension = new RegExp(`\\.${escapeRegExp(extension)}$`, 'i');
  return `${String(baseName || 'download').replace(duplicateExtension, '')}.${extension}`;
}
function getDownloadItemFilename(job, item) {
  let baseName = buildDownloadNameBase(job, 'file', item);
  if (job.items.length > 1 && !downloadTemplateIncludesIndex(job.fileNameTemplate)) {
    baseName = sanitizeDownloadName(`${baseName}_${(item.index || 0) + 1}`, baseName);
  }
  return appendDownloadExtension(baseName, item.ext);
}
function getDownloadZipFilename(job) {
  return appendDownloadExtension(buildDownloadNameBase(job, 'zip'), 'zip');
}
function updateDownloadNamingPreview() {
  if (!state.downloadNamePreviewEl) return;
  const fileTemplate = state.downloadFileNameTemplateEl
    ? state.downloadFileNameTemplateEl.value
    : state.settings.downloadFileNameTemplate;
  const zipTemplate = state.downloadZipNameTemplateEl
    ? state.downloadZipNameTemplateEl.value
    : state.settings.downloadZipNameTemplate;
  const regex = state.downloadNameRegexEl ? state.downloadNameRegexEl.value : state.settings.downloadNameRegex;
  const replacement = state.downloadNameReplacementEl ? state.downloadNameReplacementEl.value : state.settings.downloadNameReplacement;
  const demoJob = {
    username: 'BetterX', displayName: uiText('示例用户'), statusId: '1234567890',
    postText: uiText('这是用于预览下载文件名的帖子正文'), postDate: new Date(2026, 0, 2, 3, 4, 5), createdAt: Date.now(),
    fileNameTemplate: fileTemplate, zipNameTemplate: zipTemplate,
    downloadNameRegex: isSafeRegexSource(regex) ? regex : '', downloadNameReplacement: replacement,
    items: [{ url: 'https://pbs.twimg.com/media/example.jpg', ext: 'jpg', mediaType: 'image', index: 0 }],
  };
  const item = demoJob.items[0];
  state.downloadNamePreviewEl.textContent = `${uiText('命名效果预览：')}${getDownloadItemFilename(demoJob, item)} · ${getDownloadZipFilename(demoJob)}`;
}
function insertDownloadNameToken(token) {
  const inputs = [state.downloadFileNameTemplateEl, state.downloadZipNameTemplateEl].filter(Boolean);
  const remembered = state.downloadNameTemplateTargetEl;
  const target = inputs.includes(remembered) ? remembered : state.downloadFileNameTemplateEl;
  if (!target) return;
  const start = Number.isFinite(target.selectionStart) ? target.selectionStart : target.value.length;
  const end = Number.isFinite(target.selectionEnd) ? target.selectionEnd : start;
  target.value = `${target.value.slice(0, start)}${token}${target.value.slice(end)}`;
  target.focus();
  target.selectionStart = target.selectionEnd = start + token.length;
  updateDownloadNamingPreview();
}
function extOfUrl(u, def) {
  const base = String(u || '').split('?')[0];
  const m = base.match(/\.([a-zA-Z0-9]{2,4})$/);
  return m ? m[1].toLowerCase() : (def || 'bin');
}
const AGE_PLACEHOLDER_RE = /\/media\/GxJIrSUagAAK-ZP\b/;
function upgradePhoto(u) {
  const base = String(u).split('?')[0];
  const ext = extOfUrl(base, 'jpg');
  return base + '?format=' + ext + '&name=orig';
}
function photoKey(u) {
  const m = String(u || '').match(/\/media\/([A-Za-z0-9_-]+)/);
  return m ? m[1] : String(u || '').split('?')[0];
}
function collectMedia(article, statusId) {
  const out = { photos: [], gifs: [], videos: [] };
  const seenPhoto = new Set();
  const seenGif = new Set();
  const seenVideo = new Set();
  const addPhoto = (u) => { if (!u) return; const k = photoKey(u); if (seenPhoto.has(k)) return; seenPhoto.add(k); out.photos.push(upgradePhoto(u)); };
  const addGif = (u) => { if (!u || seenGif.has(u)) return; seenGif.add(u); out.gifs.push(u); };
  const addVideo = (u) => { if (!u || seenVideo.has(u)) return; seenVideo.add(u); out.videos.push(u); };
  const reg = statusId ? getRegistryEntry(mediaRegistry, String(statusId)) : null;
  if (reg) {
    reg.photos.forEach(addPhoto);
    reg.gifs.forEach(addGif);
    reg.videos.forEach(addVideo);
  }
  article.querySelectorAll('video').forEach((video) => {
    const directUrl = safeHttpsUrl(video.currentSrc || video.src || video.getAttribute('src') || '', ['video.twimg.com']);
    if (!directUrl) return;
    if (/video\.twimg\.com\/tweet_video\//i.test(directUrl)) addGif(directUrl);
    else if (/video\.twimg\.com\/(?:ext_tw_video|amplify_tw_video|amplify_video)\//i.test(directUrl)) addVideo(directUrl);
  });
  article.querySelectorAll('[data-testid="tweetPhoto"] img, img[src*="pbs.twimg.com/media/"]').forEach((img) => {
    const src = img.currentSrc || img.src || '';
    if (AGE_PLACEHOLDER_RE.test(src)) return; // X 年龄限制通用占位图，不是真实媒体，跳过
    if (/pbs\.twimg\.com\/media\//.test(src)) addPhoto(src);
  });
  article.querySelectorAll('video[poster]').forEach((v) => {
    const poster = v.getAttribute('poster') || '';
    const g = poster.match(/tweet_video_thumb\/([A-Za-z0-9_-]+)\.(?:jpg|png|webp)/);
    if (g) addGif('https://video.twimg.com/tweet_video/' + g[1] + '.mp4');
  });
  article.querySelectorAll(
    'video[poster], img[src*="/amplify_tw_video_thumb/"], img[src*="/amplify_video_thumb/"], '
    + 'img[src*="/ext_tw_video_thumb/"], img[src*="/tweet_video_thumb/"]'
  ).forEach((element) => {
    const poster = element.getAttribute('poster') || element.currentSrc || element.src || '';
    const posterKey = getVideoPosterKey(poster);
    const matched = posterKey ? getRegistryEntry(videoPosterRegistry, posterKey) : null;
    if (!matched || !matched.url) return;
    if (matched.type === 'gif') addGif(matched.url);
    else addVideo(matched.url);
  });
  return out;
}
function makeDownloadTimeoutError() {
  const error = new Error('下载超时');
  error.code = 'DOWNLOAD_TIMEOUT';
  return error;
}
function makeDownloadCancelledError() {
  const error = new Error('下载已取消');
  error.code = 'DOWNLOAD_CANCELLED';
  return error;
}
function fetchBlob(url, options) {
  const opts = options || {};
  const timeoutMs = state.settings.downloadTimeout || DEFAULT_SETTINGS.downloadTimeout;
  if (opts.signal && opts.signal.aborted) return Promise.reject(makeDownloadCancelledError());
  if (typeof GM_xmlhttpRequest !== 'undefined') {
    return new Promise((resolve, reject) => {
      let settled = false;
      let request = null;
      const finish = (callback, value) => {
        if (settled) return;
        settled = true;
        if (opts.signal) opts.signal.removeEventListener('abort', abortRequest);
        if (typeof opts.onRequestHandle === 'function') opts.onRequestHandle(request, false);
        callback(value);
      };
      const abortRequest = () => {
        try { if (request && typeof request.abort === 'function') request.abort(); } catch (err) {}
        finish(reject, makeDownloadCancelledError());
      };
      try {
        request = GM_xmlhttpRequest({
          method: 'GET', url, responseType: 'arraybuffer', timeout: timeoutMs,
          onprogress: (event) => {
            if (settled || (opts.signal && opts.signal.aborted)) return;
            if (typeof opts.onProgress === 'function') {
              opts.onProgress(Number(event.loaded) || 0, Number(event.total) || 0, event.lengthComputable === true);
            }
          },
          onload: (response) => {
            if (opts.signal && opts.signal.aborted) {
              finish(reject, makeDownloadCancelledError());
              return;
            }
            if (response.status >= 200 && response.status < 300 && response.response) {
              const ct = ((response.responseHeaders || '').match(/content-type:\s*([^\r\n;]+)/i) || [])[1];
              finish(resolve, new Blob([response.response], ct ? { type: ct.trim() } : undefined));
            } else {
              finish(reject, new Error('HTTP ' + response.status));
            }
          },
          onerror: () => finish(reject, new Error('网络错误')),
          ontimeout: () => finish(reject, makeDownloadTimeoutError()),
          onabort: () => finish(reject, makeDownloadCancelledError()),
        });
        if (typeof opts.onRequestHandle === 'function') opts.onRequestHandle(request, true);
        if (opts.signal) {
          opts.signal.addEventListener('abort', abortRequest, { once: true });
          if (opts.signal.aborted) abortRequest();
        }
      } catch (error) {
        finish(reject, error);
      }
    });
  }
  return (async () => {
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    let didTimeout = false;
    const relayAbort = () => { if (controller) controller.abort(); };
    if (opts.signal && controller) opts.signal.addEventListener('abort', relayAbort, { once: true });
    const timer = controller ? setTimeout(() => { didTimeout = true; controller.abort(); }, timeoutMs) : null;
    try {
      const response = await fetch(url, controller ? { signal: controller.signal } : undefined);
      if (!response.ok) throw new Error('HTTP ' + response.status);
      const total = Number(response.headers && response.headers.get('content-length')) || 0;
      const contentType = (response.headers && response.headers.get('content-type')) || '';
      if (response.body && typeof response.body.getReader === 'function') {
        const reader = response.body.getReader();
        const chunks = [];
        let loaded = 0;
        while (true) {
          const part = await reader.read();
          if (part.done) break;
          chunks.push(part.value);
          loaded += part.value.byteLength;
          if (typeof opts.onProgress === 'function') opts.onProgress(loaded, total, total > 0);
        }
        return new Blob(chunks, contentType ? { type: contentType } : undefined);
      }
      const blob = await response.blob();
      if (typeof opts.onProgress === 'function') opts.onProgress(blob.size, blob.size, true);
      return blob;
    } catch (error) {
      if (opts.signal && opts.signal.aborted) throw makeDownloadCancelledError();
      if (didTimeout || (error && error.name === 'AbortError')) throw makeDownloadTimeoutError();
      if (error && /^HTTP /.test(error.message || '')) throw error;
      throw new Error('跨域下载失败：请使用支持 GM_xmlhttpRequest 的脚本管理器');
    } finally {
      if (timer) clearTimeout(timer);
      if (opts.signal && controller) opts.signal.removeEventListener('abort', relayAbort);
    }
  })();
}
async function fetchBlobWithRetry(url, options) {
  let lastError = null;
  for (let attempt = 0; attempt <= DOWNLOAD_MAX_RETRIES; attempt++) {
    try {
      return await fetchBlob(url, options);
    } catch (error) {
      lastError = error;
      if (error && error.code === 'DOWNLOAD_CANCELLED') throw error;
      if (attempt >= DOWNLOAD_MAX_RETRIES || /^HTTP 4\d\d/.test((error && error.message) || '')) throw error;
      if (options && typeof options.onRetry === 'function') options.onRetry(attempt + 1, error);
    }
  }
  throw lastError || new Error('下载失败');
}
function blobToArrayBuffer(blob) {
  if (blob && typeof blob.arrayBuffer === 'function') return blob.arrayBuffer();
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(fr.result);
    fr.onerror = () => reject(fr.error || new Error('读取失败'));
    fr.readAsArrayBuffer(blob);
  });
}
const GIF_CONVERSION_MAX_DIMENSION = 480;
const GIF_CONVERSION_TARGET_FPS = 10;
const GIF_CONVERSION_MAX_FRAMES = 180;
const GIF_CONVERSION_TIMEOUT_MS = 30000;
const GIF_DITHER_MATRIX = [
  0, 8, 2, 10,
  12, 4, 14, 6,
  3, 11, 1, 9,
  15, 7, 13, 5,
];
function buildGifPalette332() {
  const palette = new Uint8Array(256 * 3);
  for (let index = 0; index < 256; index++) {
    palette[index * 3] = Math.round(((index >> 5) & 7) * 255 / 7);
    palette[index * 3 + 1] = Math.round(((index >> 2) & 7) * 255 / 7);
    palette[index * 3 + 2] = Math.round((index & 3) * 255 / 3);
  }
  return palette;
}
const GIF_PALETTE_332 = buildGifPalette332();
function quantizeRgbaToGif332(rgba, width) {
  const pixels = new Uint8Array(Math.floor(rgba.length / 4));
  for (let index = 0; index < pixels.length; index++) {
    const x = index % width;
    const y = Math.floor(index / width);
    const adjustment = (GIF_DITHER_MATRIX[(y & 3) * 4 + (x & 3)] - 7.5) * 2;
    const offset = index * 4;
    const red = Math.max(0, Math.min(255, rgba[offset] + adjustment));
    const green = Math.max(0, Math.min(255, rgba[offset + 1] + adjustment));
    const blue = Math.max(0, Math.min(255, rgba[offset + 2] + adjustment));
    pixels[index] = ((red >> 5) << 5) | ((green >> 5) << 2) | (blue >> 6);
  }
  return pixels;
}
function gifLzwEncode(indices) {
  const clearCode = 256;
  const endCode = 257;
  let codeSize = 9;
  let nextCode = 258;
  let dictionary = new Map();
  const bytes = [];
  let bitBuffer = 0;
  let bitCount = 0;
  const writeCode = (code) => {
    bitBuffer |= code << bitCount;
    bitCount += codeSize;
    while (bitCount >= 8) {
      bytes.push(bitBuffer & 0xFF);
      bitBuffer >>>= 8;
      bitCount -= 8;
    }
  };
  const resetDictionary = () => {
    dictionary = new Map();
    codeSize = 9;
    nextCode = 258;
  };
  writeCode(clearCode);
  if (indices.length) {
    let prefix = indices[0];
    for (let index = 1; index < indices.length; index++) {
      const suffix = indices[index];
      const key = prefix * 256 + suffix;
      const combined = dictionary.get(key);
      if (combined !== undefined) {
        prefix = combined;
        continue;
      }
      writeCode(prefix);
      if (nextCode < 4096) {
        dictionary.set(key, nextCode++);
        if (nextCode > (1 << codeSize) && codeSize < 12) codeSize++;
      } else {
        writeCode(clearCode);
        resetDictionary();
      }
      prefix = suffix;
    }
    writeCode(prefix);
  }
  writeCode(endCode);
  if (bitCount > 0) bytes.push(bitBuffer & 0xFF);
  return new Uint8Array(bytes);
}
function createAnimatedGifEncoder(width, height) {
  const chunks = [];
  const pushBytes = (...values) => chunks.push(Uint8Array.from(values));
  const pushWord = (value) => pushBytes(value & 0xFF, (value >>> 8) & 0xFF);
  chunks.push(new TextEncoder().encode('GIF89a'));
  pushWord(width); pushWord(height);
  pushBytes(0xF7, 0x00, 0x00);
  chunks.push(GIF_PALETTE_332);
  chunks.push(Uint8Array.from([
    0x21, 0xFF, 0x0B, 0x4E, 0x45, 0x54, 0x53, 0x43, 0x41, 0x50, 0x45, 0x32, 0x2E, 0x30,
    0x03, 0x01, 0x00, 0x00, 0x00,
  ]));
  return {
    addFrame(indices, delayCentiseconds) {
      const delay = Math.max(1, Math.min(65535, Math.round(delayCentiseconds) || 1));
      pushBytes(0x21, 0xF9, 0x04, 0x04, delay & 0xFF, (delay >>> 8) & 0xFF, 0x00, 0x00);
      pushBytes(0x2C, 0x00, 0x00, 0x00, 0x00);
      pushWord(width); pushWord(height); pushBytes(0x00, 0x08);
      const encoded = gifLzwEncode(indices);
      for (let offset = 0; offset < encoded.length; offset += 255) {
        const block = encoded.subarray(offset, Math.min(offset + 255, encoded.length));
        pushBytes(block.length);
        chunks.push(block);
      }
      pushBytes(0x00);
    },
    finish() {
      pushBytes(0x3B);
      return new Blob(chunks, { type: 'image/gif' });
    },
  };
}
function waitForVideoEvent(video, eventName, signal, timeoutMs = GIF_CONVERSION_TIMEOUT_MS) {
  return new Promise((resolve, reject) => {
    let timer = null;
    const cleanup = () => {
      video.removeEventListener(eventName, onReady);
      video.removeEventListener('error', onError);
      if (signal) signal.removeEventListener('abort', onAbort);
      if (timer) clearTimeout(timer);
    };
    const finish = (callback, value) => { cleanup(); callback(value); };
    const onReady = () => finish(resolve);
    const onError = () => finish(reject, new Error('GIF 视频解码失败'));
    const onAbort = () => finish(reject, makeDownloadCancelledError());
    video.addEventListener(eventName, onReady, { once: true });
    video.addEventListener('error', onError, { once: true });
    if (signal) signal.addEventListener('abort', onAbort, { once: true });
    timer = setTimeout(() => finish(reject, new Error('GIF 转换超时')), timeoutMs);
    if (signal && signal.aborted) onAbort();
  });
}
async function seekGifVideo(video, time, signal) {
  if (signal && signal.aborted) throw makeDownloadCancelledError();
  if (Math.abs(video.currentTime - time) < 0.002 && video.readyState >= 2) return;
  const ready = waitForVideoEvent(video, 'seeked', signal);
  video.currentTime = time;
  await ready;
}
async function convertMp4BlobToGif(blob, options) {
  const opts = options || {};
  const video = document.createElement('video');
  const objectUrl = URL.createObjectURL(blob);
  video.muted = true;
  video.playsInline = true;
  video.preload = 'auto';
  video.src = objectUrl;
  try {
    if (video.readyState < 1) { const metadata = waitForVideoEvent(video, 'loadedmetadata', opts.signal); video.load(); await metadata; }
    if (video.readyState < 2) await waitForVideoEvent(video, 'loadeddata', opts.signal);
    const duration = Number(video.duration);
    const sourceWidth = Number(video.videoWidth);
    const sourceHeight = Number(video.videoHeight);
    if (!Number.isFinite(duration) || duration <= 0 || !sourceWidth || !sourceHeight) {
      throw new Error('无法读取 GIF 视频尺寸或时长');
    }
    const scale = Math.min(1, GIF_CONVERSION_MAX_DIMENSION / Math.max(sourceWidth, sourceHeight));
    const width = Math.max(1, Math.round(sourceWidth * scale));
    const height = Math.max(1, Math.round(sourceHeight * scale));
    const targetFrames = Math.max(1, Math.ceil(duration * GIF_CONVERSION_TARGET_FPS));
    const frameCount = Math.min(GIF_CONVERSION_MAX_FRAMES, targetFrames);
    const frameDuration = duration / frameCount;
    const canvas = document.createElement('canvas');
    canvas.width = width; canvas.height = height;
    const context = canvas.getContext('2d', { alpha: false, willReadFrequently: true });
    if (!context) throw new Error('浏览器不支持 GIF 画布转换');
    const encoder = createAnimatedGifEncoder(width, height);
    for (let frame = 0; frame < frameCount; frame++) {
      if (opts.signal && opts.signal.aborted) throw makeDownloadCancelledError();
      const time = Math.min(Math.max(0, duration - 0.001), (frame + 0.5) * frameDuration);
      await seekGifVideo(video, time, opts.signal);
      context.drawImage(video, 0, 0, width, height);
      const rgba = context.getImageData(0, 0, width, height).data;
      encoder.addFrame(quantizeRgbaToGif332(rgba, width), frameDuration * 100);
      if (typeof opts.onProgress === 'function') opts.onProgress(frame + 1, frameCount);
    }
    return encoder.finish();
  } finally {
    video.removeAttribute('src');
    try { video.load(); } catch (err) {}
    URL.revokeObjectURL(objectUrl);
  }
}
function saveBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 3000);
}
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    t[i] = c >>> 0;
  }
  return t;
})();
function crc32(bytes) {
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < bytes.length; i++) crc = (crc >>> 8) ^ CRC_TABLE[(crc ^ bytes[i]) & 0xFF];
  return (crc ^ 0xFFFFFFFF) >>> 0;
}
function toDosDateTime(value) {
  const input = value instanceof Date ? new Date(value.getTime()) : new Date(value || Date.now());
  const date = Number.isFinite(input.getTime()) ? input : new Date();
  const year = Math.max(1980, Math.min(2107, date.getFullYear()));
  const month = year === 1980 && date.getFullYear() < 1980 ? 1 : date.getMonth() + 1;
  const day = year === 1980 && date.getFullYear() < 1980 ? 1 : date.getDate();
  const dosTime = ((date.getHours() & 0x1F) << 11)
    | ((date.getMinutes() & 0x3F) << 5)
    | (Math.floor(date.getSeconds() / 2) & 0x1F);
  const dosDate = ((year - 1980) << 9) | ((month & 0x0F) << 5) | (day & 0x1F);
  return { dosTime, dosDate };
}
function makeClassicZipLimitError() {
  const error = new Error('媒体总量超出经典 ZIP 范围，请改为逐个下载');
  error.code = 'ZIP_CLASSIC_LIMIT';
  return error;
}
function prepareClassicZipEntries(files, modifiedAt) {
  if (!Array.isArray(files) || files.length > CLASSIC_ZIP_MAX_FILES) throw makeClassicZipLimitError();
  const enc = new TextEncoder();
  const fallbackTime = modifiedAt || new Date();
  let offset = 0;
  let centralSize = 0;
  const prepared = files.map((file) => {
    const nameBytes = enc.encode(file.name);
    const size = Number(file.data && file.data.length);
    if (!Number.isSafeInteger(size) || size < 0 || size > CLASSIC_ZIP_MAX_VALUE
        || nameBytes.length > CLASSIC_ZIP_MAX_FILES) throw makeClassicZipLimitError();
    const localSize = 30 + nameBytes.length + size;
    const centralEntrySize = 46 + nameBytes.length;
    if (offset + localSize > CLASSIC_ZIP_MAX_VALUE
        || centralSize + centralEntrySize > CLASSIC_ZIP_MAX_VALUE) throw makeClassicZipLimitError();
    const entry = {
      nameBytes,
      data: file.data,
      size,
      offset,
      ...toDosDateTime(file.modifiedAt || fallbackTime),
    };
    offset += localSize;
    centralSize += centralEntrySize;
    return entry;
  });
  if (offset + centralSize + 22 > CLASSIC_ZIP_MAX_VALUE) throw makeClassicZipLimitError();
  return { prepared, centralStart: offset, centralSize };
}
function buildStoreZip(files, modifiedAt) {
  const layout = prepareClassicZipEntries(files, modifiedAt);
  const chunks = [];
  const central = [];
  for (const entry of layout.prepared) {
    const { nameBytes, data, size, offset, dosTime, dosDate } = entry;
    const crc = crc32(data);
    const lh = new DataView(new ArrayBuffer(30));
    lh.setUint32(0, 0x04034b50, true);
    lh.setUint16(4, 20, true);
    lh.setUint16(6, 0x0800, true);
    lh.setUint16(8, 0, true);
    lh.setUint16(10, dosTime, true);
    lh.setUint16(12, dosDate, true);
    lh.setUint32(14, crc, true);
    lh.setUint32(18, size, true);
    lh.setUint32(22, size, true);
    lh.setUint16(26, nameBytes.length, true);
    lh.setUint16(28, 0, true);
    chunks.push(new Uint8Array(lh.buffer), nameBytes, data);
    const ch = new DataView(new ArrayBuffer(46));
    ch.setUint32(0, 0x02014b50, true);
    ch.setUint16(4, 20, true);
    ch.setUint16(6, 20, true);
    ch.setUint16(8, 0x0800, true);
    ch.setUint16(10, 0, true);
    ch.setUint16(12, dosTime, true);
    ch.setUint16(14, dosDate, true);
    ch.setUint32(16, crc, true);
    ch.setUint32(20, size, true);
    ch.setUint32(24, size, true);
    ch.setUint16(28, nameBytes.length, true);
    ch.setUint16(30, 0, true);
    ch.setUint16(32, 0, true);
    ch.setUint16(34, 0, true);
    ch.setUint16(36, 0, true);
    ch.setUint32(38, 0, true);
    ch.setUint32(42, offset, true);
    central.push({ header: new Uint8Array(ch.buffer), name: nameBytes });
  }
  for (const c of central) chunks.push(c.header, c.name);
  const eo = new DataView(new ArrayBuffer(22));
  eo.setUint32(0, 0x06054b50, true);
  eo.setUint16(4, 0, true);
  eo.setUint16(6, 0, true);
  eo.setUint16(8, files.length, true);
  eo.setUint16(10, files.length, true);
  eo.setUint32(12, layout.centralSize, true);
  eo.setUint32(16, layout.centralStart, true);
  eo.setUint16(20, 0, true);
  chunks.push(new Uint8Array(eo.buffer));
  return new Blob(chunks, { type: 'application/zip' });
}
const downloadJobs = new Map();
const pendingDownloadStarts = new Set();
const pendingDownloadSelections = new Set();
const downloadTransferQueue = [];
let activeDownloadTransfers = 0;
let downloadUiRaf = 0;
function isDownloadedPostRecorded(statusId) {
  if (!state.settings.trackDownloadedPosts) return false;
  return (state.settings.downloadedPostIds || []).includes(String(statusId || ''));
}
function recordDownloadedPost(statusId) {
  const id = String(statusId || '');
  if (!state.settings.trackDownloadedPosts || !/^\d{1,30}$/.test(id)) return;
  const existing = state.settings.downloadedPostIds || [];
  const next = [...existing.filter((item) => item !== id), id].slice(-MAX_DOWNLOADED_POST_IDS);
  if (next.length === existing.length && next.every((item, index) => item === existing[index])) return;
  state.settings.downloadedPostIds = next;
  queueDbWrite(async () => { await persistSettings(); });
  scheduleDownloadUiRefresh();
}
function collectDownloadItems(article, statusId) {
  const media = collectMedia(article, statusId);
  const items = [];
  const convertGifs = state.settings.gifDownloadFormatEnabled !== false
    && state.settings.gifDownloadFormat === 'gif';
  const addGif = (url) => items.push({
    url,
    ext: convertGifs ? 'gif' : 'mp4',
    mediaType: 'gif',
    convertToGif: convertGifs,
  });
  media.photos.forEach((u) => items.push({ url: u, ext: extOfUrl(u, 'jpg'), mediaType: 'image' }));
  media.gifs.forEach(addGif);
  media.videos.forEach((u) => items.push({ url: u, ext: 'mp4', mediaType: 'video' }));
  if (!items.length) {
    const card = statusId ? getRegistryEntry(cardRegistry, String(statusId)) : null;
    if (card) {
      card.photos.forEach((u) => items.push({ url: u, ext: extOfUrl(u, 'jpg'), mediaType: 'image' }));
      card.gifs.forEach(addGif);
      card.videos.forEach((u) => items.push({ url: u, ext: 'mp4', mediaType: 'video' }));
    }
  }
  return items;
}
function articleMayContainVideo(article) {
  if (!article || !article.querySelector) return false;
  return !!article.querySelector(
    'video, [data-testid="videoComponent"], [data-testid="videoPlayer"], [data-testid="playButton"], '
    + 'img[src*="ext_tw_video_thumb"], img[src*="amplify_tw_video_thumb"], '
    + 'img[src*="amplify_video_thumb"], img[src*="tweet_video_thumb"]'
  );
}
function needsOnDemandVideoLookup(article, statusId) {
  if (!articleMayContainVideo(article)) return false;
  const id = String(statusId || '');
  const registered = mediaRegistry.get(id) || cardRegistry.get(id);
  return !registered || !((registered.videos && registered.videos.length) || (registered.gifs && registered.gifs.length));
}
function getMissingMediaMessage(article) {
  if (IS_VIOLENTMONKEY && articleMayContainVideo(article)) {
    return '⚠️ 未能取得视频地址：检测到 Violentmonkey。安卓 Firefox 上可能无法正确携带 X 登录态，请改用 Tampermonkey 后重试';
  }
  return isFirefoxCompatibilityActive()
    ? '未能取得媒体地址，请确认已登录 X 后重试'
    : '未找到可下载的媒体，若为视频请先点开或播放一下再试';
}
function formatDownloadBytes(value) {
  const bytes = Math.max(0, Number(value) || 0);
  if (bytes < 1024) return `${bytes.toFixed(0)} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(bytes < 10240 ? 1 : 0)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(bytes < 10485760 ? 1 : 0)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}
function isActiveDownloadJob(job) {
  return !!job && ['queued', 'downloading', 'packing', 'saving', 'cancelling'].includes(job.status);
}
function getDownloadJobProgress(job) {
  if (!job) return { loaded: 0, total: 0, percent: 0, allKnown: false };
  let loaded = 0;
  let total = 0;
  let allKnown = job.itemProgress.length > 0;
  for (const progress of job.itemProgress) {
    loaded += progress.loaded || 0;
    total += progress.total || 0;
    if (!progress.totalKnown) allKnown = false;
  }
  const percent = allKnown && total > 0 ? Math.max(0, Math.min(100, Math.round((loaded / total) * 100))) : 0;
  return { loaded, total, percent, allKnown };
}
function describeDownloadJob(job, compact) {
  const progress = getDownloadJobProgress(job);
  if (job.status === 'queued') return compact ? '排队' : '排队中';
  if (job.itemProgress.some((item) => item.status === 'converting-gif')) {
    return compact ? '转 GIF' : '正在转换 GIF';
  }
  if (job.status === 'packing') return compact ? '打包' : `正在打包 ${job.packCompleted || 0}/${job.packTotal || job.items.length}`;
  if (job.status === 'saving') return compact ? '保存' : '正在保存';
  if (job.status === 'cancelling') return compact ? '取消中' : '正在取消下载';
  if (job.status === 'done') return job.failedCount ? `完成，跳过 ${job.failedCount}` : '下载完成';
  if (job.status === 'cancelled') return job.savedCount ? `已取消，已保存 ${job.savedCount}` : '已取消';
  if (job.status === 'error') return `失败：${job.errorMessage || '未知错误'}`;
  if (progress.allKnown) return `${progress.percent}%`;
  if (progress.loaded > 0) return formatDownloadBytes(progress.loaded);
  return compact ? '下载' : `下载中 ${job.completedCount || 0}/${job.items.length}`;
}
function scheduleDownloadUiRefresh() {
  if (downloadUiRaf) return;
  const run = () => { downloadUiRaf = 0; refreshDownloadUi(); };
  downloadUiRaf = typeof requestAnimationFrame === 'function' ? requestAnimationFrame(run) : setTimeout(run, 16);
}
function renderDownloadButtonContent(button, label, downloadedBefore) {
  const renderKey = downloadedBefore ? 'downloaded' : `text:${label}`;
  if (button.dataset.renderKey === renderKey) return;
  if (downloadedBefore) {
    button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M11 3h2v9.17l3.59-3.59L18 10l-6 6-6-6 1.41-1.42L11 12.17V3zM4 14v4a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-4h-2v4a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-4z"/></svg>';
  } else {
    button.textContent = label;
  }
  button.dataset.renderKey = renderKey;
}
function renderDownloadTaskPopover() {
  if (!state.downloadPopoverEl || state.downloadPopoverEl.hidden) return;
  const jobs = [...downloadJobs.values()].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  if (!jobs.length) {
    if (state.downloadPopoverEl.dataset.renderSignature !== 'empty') {
      state.downloadPopoverEl.innerHTML = '<div class="BetterX-download-empty">暂无下载任务</div>';
      state.downloadPopoverEl.dataset.renderSignature = 'empty';
    }
    return;
  }
  const models = jobs.map((job) => ({
    job,
    canCancel: isActiveDownloadJob(job) && job.status !== 'cancelling',
    canRetry: job.status === 'error' || job.status === 'cancelled',
  }));
  const renderSignature = models.map(({ job, canCancel, canRetry }) => `${job.id}:${canCancel ? 1 : 0}:${canRetry ? 1 : 0}`).join('|');
  if (state.downloadPopoverEl.dataset.renderSignature !== renderSignature) {
    state.downloadPopoverEl.innerHTML = `
        <div class="BetterX-download-popover-title">下载任务</div>
        ${models.map(({ job, canCancel, canRetry }) => `<div class="BetterX-download-task" data-job-id="${escapeHtml(job.id)}">
            <div class="BetterX-download-task-main">
              <strong>${escapeHtml(job.baseName)}</strong>
              <span></span>
            </div>
            <div class="BetterX-download-task-actions">
              ${canCancel ? `<button type="button" data-action="download-cancel" data-job-id="${escapeHtml(job.id)}">取消</button>` : ''}
              ${canRetry ? `<button type="button" data-action="download-retry" data-job-id="${escapeHtml(job.id)}">重试</button>` : ''}
            </div>
          </div>`).join('')}
      `;
    state.downloadPopoverEl.dataset.renderSignature = renderSignature;
  }
  const taskElements = new Map(
    [...state.downloadPopoverEl.querySelectorAll('.BetterX-download-task[data-job-id]')]
      .map((element) => [element.dataset.jobId || '', element])
  );
  models.forEach(({ job }) => {
    const task = taskElements.get(String(job.id));
    if (!task) return;
    const progress = getDownloadJobProgress(job);
    task.style.setProperty('--xv-task-progress', progress.allKnown ? `${progress.percent}%` : '0%');
    const status = task.querySelector('.BetterX-download-task-main span');
    if (status) status.textContent = describeDownloadJob(job, false);
  });
}
function refreshDownloadUi() {
  const controls = document.querySelectorAll('.BetterX-download-controls[data-status-id]');
  controls.forEach((control) => {
    const statusId = control.dataset.statusId || '';
    const job = downloadJobs.get(statusId);
    const button = control.querySelector('.BetterX-dl-btn');
    const cancel = control.querySelector('.BetterX-dl-cancel');
    if (!button) return;
    const active = isActiveDownloadJob(job);
    const lookingUp = pendingDownloadStarts.has(statusId);
    const selecting = pendingDownloadSelections.has(statusId);
    const downloadedBefore = !active && !lookingUp && !selecting && isDownloadedPostRecorded(statusId);
    const progress = getDownloadJobProgress(job);
    control.dataset.downloadState = lookingUp ? 'looking-up' : selecting ? 'selecting' : job ? job.status : 'idle';
    button.classList.toggle('is-progress', active || lookingUp);
    button.classList.toggle('is-downloaded', downloadedBefore);
    button.style.setProperty('--xv-download-progress', `${progress.percent * 3.6}deg`);
    renderDownloadButtonContent(button,
      lookingUp ? uiText('获取中') : selecting ? uiText('选择中') : job && !downloadedBefore ? uiText(describeDownloadJob(job, true)) : '⬇',
      downloadedBefore);
    button.title = lookingUp ? uiText('正在获取视频地址…') : selecting ? uiText('正在选择下载内容') : job && !downloadedBefore
      ? uiText(describeDownloadJob(job, false))
      : downloadedBefore ? `${uiText('已下载过媒体；点击可再次下载')} · ${uiText(DOWNLOAD_BUTTON_HINT)}`
        : uiText(DOWNLOAD_BUTTON_HINT);
    button.setAttribute('aria-label', button.title);
    if (cancel) cancel.hidden = !active;
    localizeBetterXTree(control);
  });
  if (!state.downloadPillEl) return;
  const jobs = [...downloadJobs.values()];
  const activeJobs = jobs.filter(isActiveDownloadJob);
  state.downloadPillEl.hidden = !!state.settings.silentDownload || jobs.length === 0;
  if (state.downloadPillEl.hidden) {
    if (state.downloadPopoverEl) state.downloadPopoverEl.hidden = true;
    return;
  }
  const loaded = activeJobs.reduce((sum, job) => sum + getDownloadJobProgress(job).loaded, 0);
  const total = activeJobs.reduce((sum, job) => sum + getDownloadJobProgress(job).total, 0);
  const allKnown = activeJobs.length > 0 && activeJobs.every((job) => getDownloadJobProgress(job).allKnown);
  const percent = allKnown && total > 0 ? Math.round((loaded / total) * 100) : 0;
  const isMobile = state.rootEl && state.rootEl.classList.contains('BetterX-mobile');
  const recentJob = jobs.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0))[0];
  const label = uiText(activeJobs.length
    ? `${activeJobs.length} 个任务 · ${allKnown ? percent + '%' : formatDownloadBytes(loaded)}`
    : describeDownloadJob(recentJob, false));
  const labelEl = state.downloadPillEl.querySelector('.BetterX-download-pill-label');
  const countEl = state.downloadPillEl.querySelector('.BetterX-download-pill-count');
  if (labelEl) labelEl.textContent = label;
  if (countEl) {
    countEl.hidden = !isMobile || activeJobs.length === 0;
    countEl.textContent = activeJobs.length > 99 ? '99+' : String(activeJobs.length);
  }
  state.downloadPillEl.setAttribute('aria-label', uiText(activeJobs.length ? `查看下载任务：${label}` : `查看下载任务：${describeDownloadJob(recentJob, false)}`));
  state.downloadPillEl.style.setProperty('--xv-download-progress', `${percent * 3.6}deg`);
  state.downloadPillEl.classList.toggle('is-progress', activeJobs.length > 0);
  renderDownloadTaskPopover();
}
function toggleDownloadPopover(force) {
  if (!state.downloadPopoverEl) return;
  if (state.settings.silentDownload || !downloadJobs.size) {
    state.downloadPopoverEl.hidden = true;
    return;
  }
  const next = typeof force === 'boolean' ? force : state.downloadPopoverEl.hidden;
  state.downloadPopoverEl.hidden = !next;
  if (next) renderDownloadTaskPopover();
}
function getDownloadConcurrencyLimit() {
  return clampInt(
    state.settings.downloadConcurrency,
    DOWNLOAD_MIN_CONCURRENCY,
    DOWNLOAD_MAX_CONCURRENCY,
    DEFAULT_SETTINGS.downloadConcurrency
  );
}
function pumpDownloadTransferQueue() {
  const concurrencyLimit = getDownloadConcurrencyLimit();
  while (activeDownloadTransfers < concurrencyLimit && downloadTransferQueue.length) {
    const entry = downloadTransferQueue.shift();
    if (entry.job.cancelRequested) { entry.reject(makeDownloadCancelledError()); continue; }
    activeDownloadTransfers++;
    Promise.resolve().then(entry.task).then(entry.resolve, entry.reject).finally(() => {
      activeDownloadTransfers--;
      pumpDownloadTransferQueue();
    });
  }
}
function runWithDownloadSlot(job, task) {
  return new Promise((resolve, reject) => {
    downloadTransferQueue.push({ job, task, resolve, reject });
    pumpDownloadTransferQueue();
  });
}
function cancelDownloadJob(jobId) {
  const job = downloadJobs.get(String(jobId || ''));
  if (!isActiveDownloadJob(job) || job.cancelRequested || job.status === 'cancelling') return;
  job.cancelRequested = true;
  job.status = 'cancelling';
  job.cancelHandles = new Set([...(job.cancelHandles || []), ...(job.requests || [])]);
  job.controllers.forEach((controller) => { try { controller.abort(); } catch (err) {} });
  (job.requests || []).forEach((request) => { try { if (request && typeof request.abort === 'function') request.abort(); } catch (err) {} });
  const repeatAbort = () => {
    (job.cancelHandles || []).forEach((request) => {
      try { if (request && typeof request.abort === 'function') request.abort(); } catch (err) {}
    });
  };
  (job.cancelAbortTimers || []).forEach((timer) => clearTimeout(timer));
  job.cancelAbortTimers = [80, 250, 700, 1500].map((delay) => setTimeout(repeatAbort, delay));
  job.cancelAbortTimers.push(setTimeout(() => {
    if (job.cancelHandles) job.cancelHandles.clear();
    job.cancelAbortTimers = [];
  }, 2500));
  for (let index = downloadTransferQueue.length - 1; index >= 0; index--) {
    const queued = downloadTransferQueue[index];
    if (queued.job !== job) continue;
    downloadTransferQueue.splice(index, 1);
    queued.reject(makeDownloadCancelledError());
  }
  job.updatedAt = now();
  scheduleDownloadUiRefresh();
}
function scheduleDownloadJobCleanup(job, delay) {
  if (job.cleanupTimer) clearTimeout(job.cleanupTimer);
  job.cleanupTimer = setTimeout(() => {
    if (downloadJobs.get(job.id) === job && !isActiveDownloadJob(job)) downloadJobs.delete(job.id);
    scheduleDownloadUiRefresh();
  }, delay);
}
function saveIndividualDownload(job, result) {
  if (!result || !result.blob) return;
  job.updatedAt = now();
  saveBlob(result.blob, getDownloadItemFilename(job, result));
  result.blob = null;
  result.saved = true;
  job.savedCount++;
  scheduleDownloadUiRefresh();
}
async function runDownloadJob(job) {
  job.status = 'downloading';
  job.updatedAt = now();
  scheduleDownloadUiRefresh();
  const zipMemoryLimit = isMobileBadgeViewport()
    ? DOWNLOAD_ZIP_MEMORY_LIMIT_MOBILE
    : DOWNLOAD_ZIP_MEMORY_LIMIT_DESKTOP;
  const retainedResults = [];
  let retainedBytes = 0;
  let individualMode = job.zipEnabled === false;
  const acceptResult = (result) => {
    if (job.items.length === 1) {
      job.status = 'saving';
      saveBlob(result.blob, getDownloadItemFilename(job, result));
      result.blob = null;
      result.saved = true;
      job.savedCount++;
      return;
    }
    if (!individualMode && retainedBytes + result.blob.size > zipMemoryLimit) {
      individualMode = true;
      job.fallbackIndividual = true;
      retainedResults.splice(0).forEach((saved) => saveIndividualDownload(job, saved));
      retainedBytes = 0;
    }
    if (individualMode) saveIndividualDownload(job, result);
    else {
      retainedResults.push(result);
      retainedBytes += result.blob.size;
    }
  };
  const outcomes = await Promise.all(job.items.map((item, index) => runWithDownloadSlot(job, async () => {
    if (job.cancelRequested) throw makeDownloadCancelledError();
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    if (controller) job.controllers.add(controller);
    job.itemProgress[index].status = 'downloading';
    try {
      let blob = await fetchBlobWithRetry(item.url, {
        signal: controller ? controller.signal : null,
        onRequestHandle: (request, active) => {
          if (!request || !job.requests) return;
          if (active) {
            job.requests.add(request);
            if (job.cancelRequested && typeof request.abort === 'function') {
              job.cancelHandles.add(request);
              try { request.abort(); } catch (err) {}
            }
          } else job.requests.delete(request);
        },
        onProgress: (loaded, total, totalKnown) => {
          if (job.cancelRequested) return;
          const progress = job.itemProgress[index];
          progress.loaded = loaded;
          progress.total = totalKnown ? total : 0;
          progress.totalKnown = totalKnown && total > 0;
          job.updatedAt = now();
          scheduleDownloadUiRefresh();
        },
        onRetry: () => {
          const progress = job.itemProgress[index];
          progress.loaded = 0;
          progress.total = 0;
          progress.totalKnown = false;
          job.retryCount++;
          scheduleDownloadUiRefresh();
        },
      });
      const progress = job.itemProgress[index];
      if (item.convertToGif) {
        progress.status = 'converting-gif';
        job.updatedAt = now();
        scheduleDownloadUiRefresh();
        blob = await convertMp4BlobToGif(blob, {
          signal: controller ? controller.signal : null,
          onProgress: (completed, total) => {
            progress.gifFramesCompleted = completed;
            progress.gifFramesTotal = total;
            job.updatedAt = now();
            scheduleDownloadUiRefresh();
          },
        });
      }
      progress.loaded = blob.size;
      progress.total = blob.size;
      progress.totalKnown = true;
      progress.status = 'done';
      job.completedCount++;
      const result = { blob, ext: item.ext, mediaType: item.mediaType, url: item.url, index };
      acceptResult(result);
      return { ok: true, result };
    } catch (error) {
      job.itemProgress[index].status = error && error.code === 'DOWNLOAD_CANCELLED' ? 'cancelled' : 'error';
      return { ok: false, error, index };
    } finally {
      if (controller) job.controllers.delete(controller);
      job.updatedAt = now();
      scheduleDownloadUiRefresh();
    }
  }).catch((error) => {
    job.itemProgress[index].status = error && error.code === 'DOWNLOAD_CANCELLED' ? 'cancelled' : 'error';
    return { ok: false, error, index };
  })));
  if (job.cancelRequested) {
    retainedResults.forEach((result) => { result.blob = null; });
    job.status = 'cancelled';
    job.updatedAt = now();
    scheduleDownloadJobCleanup(job, 5000);
    scheduleDownloadUiRefresh();
    return;
  }
  const failures = outcomes.filter((outcome) => !outcome.ok && (!outcome.error || outcome.error.code !== 'DOWNLOAD_CANCELLED'));
  job.failedCount = failures.length;
  if (!job.savedCount && !retainedResults.length) {
    job.status = 'error';
    job.errorMessage = failures[0] && failures[0].error ? failures[0].error.message : '全部媒体下载失败';
    job.updatedAt = now();
    scheduleDownloadJobCleanup(job, 30000);
    scheduleDownloadUiRefresh();
    return;
  }
  if (!individualMode && retainedResults.length === 1) {
    saveIndividualDownload(job, retainedResults[0]);
    retainedResults.length = 0;
  } else if (!individualMode && retainedResults.length > 1) {
    job.status = 'packing';
    job.packCompleted = 0;
    job.packTotal = retainedResults.length;
    scheduleDownloadUiRefresh();
    const files = [];
    try {
      for (const result of retainedResults) {
        if (job.cancelRequested) throw makeDownloadCancelledError();
        const buffer = await blobToArrayBuffer(result.blob);
        if (job.cancelRequested) throw makeDownloadCancelledError();
        result.blob = null;
        files.push({ resultIndex: result.index, name: getDownloadItemFilename(job, result), data: new Uint8Array(buffer), modifiedAt: new Date() });
        job.packCompleted++;
        scheduleDownloadUiRefresh();
      }
      if (job.cancelRequested) throw makeDownloadCancelledError();
      const content = buildStoreZip(files, new Date());
      if (job.cancelRequested) throw makeDownloadCancelledError();
      job.status = 'saving';
      saveBlob(content, getDownloadZipFilename(job));
      job.savedCount = files.length;
      files.length = 0;
    } catch (error) {
      if (error && error.code === 'DOWNLOAD_CANCELLED') {
        retainedResults.forEach((result) => { result.blob = null; });
        files.length = 0;
        throw error;
      }
      job.fallbackIndividual = true;
      job.status = 'saving';
      let fallbackSaved = 0;
      for (let index = 0; index < retainedResults.length; index++) {
        const result = retainedResults[index];
        const prepared = files.find((file) => file.resultIndex === result.index);
        const fallbackBlob = result.blob || (prepared ? new Blob([prepared.data]) : null);
        if (fallbackBlob) {
          saveBlob(fallbackBlob, getDownloadItemFilename(job, result));
          fallbackSaved++;
        }
        result.blob = null;
      }
      job.savedCount += fallbackSaved;
      files.length = 0;
      if (error && error.code !== 'ZIP_CLASSIC_LIMIT') console.error('[BetterX] ZIP 打包失败，已改为逐个保存:', error);
    }
    retainedResults.length = 0;
  }
  job.status = 'done';
  job.updatedAt = now();
  job.errorMessage = '';
  if (job.savedCount > 0) recordDownloadedPost(job.statusId);
  scheduleDownloadJobCleanup(job, 8000);
  scheduleDownloadUiRefresh();
  showToast(job.fallbackIndividual || job.individualDownloads
    ? `✅ 下载完成：已逐个保存 ${job.savedCount} 个文件`
    : `✅ 下载完成${job.failedCount ? `，跳过 ${job.failedCount} 个失败项` : ''}`,
  5000);
}
function startDownloadJob(items, author, statusId, postText, postDate) {
  const id = String(statusId || '');
  const previous = downloadJobs.get(id);
  if (isActiveDownloadJob(previous)) { toggleDownloadPopover(true); return previous; }
  if (previous && previous.cleanupTimer) clearTimeout(previous.cleanupTimer);
  const uname = String((author && author.username) || 'x').replace(/^@/, '') || 'x';
  const job = {
    id, statusId: id, username: uname, displayName: String((author && author.displayName) || '').trim(),
    postText: String(postText || '').slice(0, 2000), postDate: postDate || '', items: items.map((item) => ({ ...item })),
    fileNameTemplate: state.settings.downloadFileNameTemplate || DEFAULT_SETTINGS.downloadFileNameTemplate,
    zipNameTemplate: state.settings.downloadZipNameTemplate || DEFAULT_SETTINGS.downloadZipNameTemplate,
    downloadNameRegex: state.settings.downloadNameRegex || '',
    downloadNameReplacement: state.settings.downloadNameReplacement || '',
    itemProgress: items.map(() => ({ loaded: 0, total: 0, totalKnown: false, status: 'queued' })),
    status: 'queued', createdAt: now(), updatedAt: now(), completedCount: 0, failedCount: 0,
    savedCount: 0, retryCount: 0, packCompleted: 0, packTotal: 0, fallbackIndividual: false,
    zipEnabled: state.settings.downloadZip !== false, individualDownloads: state.settings.downloadZip === false,
    cancelRequested: false, controllers: new Set(), requests: new Set(), cancelHandles: new Set(),
    cancelAbortTimers: [], cleanupTimer: null, errorMessage: '',
  };
  job.baseName = buildDownloadNameBase(job, 'zip');
  downloadJobs.set(id, job);
  scheduleDownloadUiRefresh();
  Promise.resolve(runDownloadJob(job)).catch((error) => {
    job.status = error && error.code === 'DOWNLOAD_CANCELLED' ? 'cancelled' : 'error';
    job.errorMessage = (error && error.message) || '未知错误';
    job.updatedAt = now();
    scheduleDownloadJobCleanup(job, job.status === 'cancelled' ? 5000 : 30000);
    scheduleDownloadUiRefresh();
  });
  return job;
}
function retryDownloadJob(jobId) {
  const previous = downloadJobs.get(String(jobId || ''));
  if (!previous || isActiveDownloadJob(previous)) return;
  return startDownloadJob(previous.items, {
    username: previous.username,
    displayName: previous.displayName,
  }, previous.statusId, previous.postText, previous.postDate);
}
async function handleDownloadClick(article, author, statusId, options) {
  const id = String(statusId || '');
  const selectMedia = options?.selectMedia === true;
  if (pendingDownloadSelections.has(id)) return;
  if (pendingDownloadStarts.has(id)) { showToast('正在获取视频地址…'); return; }
  const existing = downloadJobs.get(id);
  if (isActiveDownloadJob(existing)) { toggleDownloadPopover(true); return; }
  if (isDownloadedPostRecorded(statusId)
    && !uiConfirm('该帖子内媒体文件曾下载过，是否继续下载？')) return;
  if (selectMedia) pendingDownloadSelections.add(id);
  try {
    const postText = extractText(article);
    const postDate = article.querySelector('time')?.getAttribute('datetime') || '';
    let items = collectDownloadItems(article, statusId);
    if (needsOnDemandVideoLookup(article, statusId)) {
      pendingDownloadStarts.add(id);
      scheduleDownloadUiRefresh();
      showToast('正在获取视频地址…');
      try {
        const found = await requestTweetDetailMedia(statusId);
        const currentId = extractStatusIdFromUrl(getStatusLink(article));
        if (currentId && currentId !== id) return;
        if (found) items = collectDownloadItems(article, statusId);
      } catch (error) {
        debugLog('download media lookup failed:', error);
      } finally {
        pendingDownloadStarts.delete(id);
        scheduleDownloadUiRefresh();
      }
    }
    if (state.settings.mediaDownload === false) return;
    if (!items.length) {
      showToast(getMissingMediaMessage(article), IS_VIOLENTMONKEY ? 7000 : undefined);
      return;
    }
    if (selectMedia) {
      scheduleDownloadUiRefresh();
      items = await showDownloadMediaPicker(items, article);
      if (!items?.length || state.settings.mediaDownload === false) return;
    }
    const activeAfterLookup = downloadJobs.get(id);
    if (isActiveDownloadJob(activeAfterLookup)) { toggleDownloadPopover(true); return; }
    startDownloadJob(items, author, statusId, postText, postDate);
  } finally {
    pendingDownloadSelections.delete(id);
    scheduleDownloadUiRefresh();
  }
}
function isDownloadExcludedArticle(article) {
  if (!article) return false;
  if (article.matches && article.matches('[data-testid="notification"]')) return true;
  return !!(article.closest && article.closest('[data-testid="notification"]'));
}
function findTopLevelArticleElement(article, selector) {
  return [...article.querySelectorAll(selector)].find((element) => (
    !element.closest || element.closest('article') === article
  )) || null;
}
function findGuestDownloadActionPlacement(article) {
  const reply = findTopLevelArticleElement(article, '[data-engagement-action="reply"]');
  const repost = findTopLevelArticleElement(article, '[data-engagement-action="retweet"]');
  const like = findTopLevelArticleElement(article, '[data-engagement-action="like"]');
  const share = findTopLevelArticleElement(article, '[data-engagement-action="share"]');
  const row = reply && reply.parentElement;
  if (!row || repost?.parentElement !== row || like?.parentElement !== row || !share) return null;
  let trailing = share;
  for (let depth = 0; depth < 4 && trailing.parentElement && trailing.parentElement !== row; depth++) {
    trailing = trailing.parentElement;
  }
  if (trailing.parentElement !== row) return null;
  return { host: row, before: trailing };
}
function placeDownloadControls(article, controls) {
  const group = findTopLevelArticleElement(article, '[role="group"]');
  if (group) {
    controls.classList.remove('guest-actions', 'floating');
    controls.classList.add('in-group');
    if (controls.parentElement !== group) group.appendChild(controls);
    return;
  }
  const guestPlacement = findGuestDownloadActionPlacement(article);
  if (guestPlacement) {
    controls.classList.remove('floating');
    controls.classList.add('in-group', 'guest-actions');
    if (controls.parentElement !== guestPlacement.host || controls.nextSibling !== guestPlacement.before) {
      guestPlacement.host.insertBefore(controls, guestPlacement.before);
    }
    return;
  }
  controls.classList.remove('in-group', 'guest-actions');
  controls.classList.add('floating');
  if (!article.style.position) article.style.position = 'relative';
  if (controls.parentElement !== article) article.appendChild(controls);
}
function injectDownloadButtons(scope) {
  if (!state.settings.mediaDownload) return;
  const root = (scope && scope.querySelectorAll) ? scope : document;
  const articles = (root.matches && root.matches('article')) ? [root] : root.querySelectorAll('article');
  articles.forEach((article) => {
    if (article.closest('#BetterX-root')) return;
    if (isDownloadExcludedArticle(article)) {
      article.querySelectorAll('.BetterX-download-controls').forEach((control) => control.remove());
      return;
    }
    const existingControls = article.querySelector('.BetterX-download-controls');
    const statusId = extractStatusIdFromUrl(getStatusLink(article));
    if (!statusId) { existingControls?.remove(); return; }
    if (existingControls) {
      existingControls.dataset.statusId = statusId;
      placeDownloadControls(article, existingControls);
      return;
    }
    const hasDomMedia = article.querySelector('[data-testid="tweetPhoto"], [data-testid="videoComponent"], [data-testid="videoPlayer"], img[src*="pbs.twimg.com/media/"], video[poster]');
    const hasReg = statusId && (mediaRegistry.has(String(statusId)) || cardRegistry.has(String(statusId)));
    if (!hasDomMedia && !hasReg) return;
    const controls = document.createElement('span');
    controls.className = 'BetterX-download-controls';
    controls.dataset.statusId = String(statusId || '');
    const btn = document.createElement('button');
    btn.className = 'BetterX-dl-btn';
    btn.type = 'button';
    btn.title = uiText(DOWNLOAD_BUTTON_HINT);
    btn.textContent = '⬇';
    bindDownloadButtonGestures(btn, article, controls);
    const cancel = document.createElement('button');
    cancel.className = 'BetterX-dl-cancel';
    cancel.type = 'button';
    cancel.title = '取消下载';
    cancel.textContent = '×';
    cancel.hidden = true;
    cancel.addEventListener('click', (event) => {
      event.preventDefault(); event.stopPropagation(); cancelDownloadJob(controls.dataset.statusId);
    }, true);
    controls.append(btn, cancel);
    localizeBetterXTree(controls);
    placeDownloadControls(article, controls);
  });
  scheduleDownloadUiRefresh();
}
function removeDownloadButtons() {
  closeDownloadMediaPicker();
  document.querySelectorAll('.BetterX-download-controls, .BetterX-dl-btn').forEach((el) => el.remove());
}
function applyMediaDownload() {
  if (state.settings.mediaDownload) injectDownloadButtons(document);
  else removeDownloadButtons();
}
const DOWNLOAD_LONG_PRESS_MS = 500;
const DOWNLOAD_BUTTON_HINT = '点击下载全部，长按或 Shift+点击选择下载';
let downloadMediaPicker = null;
function getDownloadMediaThumbnails(article, items) {
  const previews = new Map();
  for (const entry of videoPosterRegistry.values()) {
    if (entry.thumbnailUrl) previews.set(entry.url, entry.thumbnailUrl);
  }
  article.querySelectorAll('video[poster]').forEach((video) => {
    const poster = video.getAttribute('poster') || '';
    const directUrl = safeHttpsUrl(video.currentSrc || video.src || '', ['video.twimg.com']);
    if (directUrl) previews.set(directUrl, poster);
    const matched = getRegistryEntry(videoPosterRegistry, getVideoPosterKey(poster));
    if (matched) previews.set(matched.url, poster);
  });
  return items.map((item) => {
    const gifId = item.mediaType === 'gif' && item.url.match(/\/tweet_video\/([A-Za-z0-9_-]+)\.mp4(?:\?|$)/);
    const raw = item.mediaType === 'image' ? item.url : previews.get(item.url)
      || (gifId ? `https://pbs.twimg.com/tweet_video_thumb/${gifId[1]}.jpg` : '');
    const safe = safeHttpsUrl(raw, ['pbs.twimg.com']);
    if (!safe) return '';
    const url = new URL(safe);
    if (url.pathname.startsWith('/media/')) url.searchParams.set('name', 'small');
    return url.href;
  });
}
function closeDownloadMediaPicker() {
  if (downloadMediaPicker) downloadMediaPicker.cancel();
}
function showDownloadMediaPicker(items, article) {
  closeDownloadMediaPicker();
  if (!state.rootEl || !items.length) return Promise.resolve(null);
  return new Promise((resolve) => {
    const previousFocus = document.activeElement;
    const overlay = document.createElement('div');
    overlay.id = 'BetterX-media-picker';
    overlay.className = 'BetterX-dialog-overlay BetterX-media-picker-overlay';
    overlay.innerHTML = uiHtml`
        <div class="BetterX-dialog BetterX-media-picker" role="dialog" aria-modal="true" aria-labelledby="BetterX-media-picker-title">
          <div class="BetterX-dialog-title" id="BetterX-media-picker-title">选择要下载的媒体</div>
          <div class="BetterX-media-picker-toolbar">
            <span class="BetterX-media-picker-count" aria-live="polite"></span>
            <button type="button" class="BetterX-btn" data-media-toggle>全不选</button>
          </div>
          <div class="BetterX-media-picker-grid"></div>
          <div class="BetterX-dialog-actions">
            <button type="button" class="BetterX-btn" data-media-cancel>取消</button>
            <button type="button" class="BetterX-btn primary" data-media-confirm>下载所选</button>
          </div>
        </div>
      `;
    const grid = overlay.querySelector('.BetterX-media-picker-grid');
    const count = overlay.querySelector('.BetterX-media-picker-count');
    const toggle = overlay.querySelector('[data-media-toggle]');
    const confirm = overlay.querySelector('[data-media-confirm]');
    const inputs = [];
    const thumbnails = getDownloadMediaThumbnails(article, items);
    items.forEach((item, index) => {
      const kind = item.mediaType === 'gif' ? 'GIF' : uiText(item.mediaType === 'video' ? '视频' : '图片');
      const entry = document.createElement('label');
      entry.className = 'BetterX-media-picker-item';
      const input = document.createElement('input');
      input.type = 'checkbox';
      input.checked = true;
      input.setAttribute('aria-label', `${kind} ${index + 1}`);
      const thumb = document.createElement('span');
      thumb.className = 'BetterX-media-picker-thumb';
      const placeholder = document.createElement('span');
      placeholder.className = 'BetterX-media-picker-placeholder';
      placeholder.textContent = uiText('无预览');
      thumb.appendChild(placeholder);
      if (thumbnails[index]) {
        const image = document.createElement('img');
        image.src = thumbnails[index];
        image.alt = '';
        image.loading = 'lazy';
        image.decoding = 'async';
        image.referrerPolicy = 'no-referrer';
        image.draggable = false;
        image.addEventListener('error', () => image.remove(), { once: true });
        thumb.appendChild(image);
      }
      const caption = document.createElement('span');
      caption.className = 'BetterX-media-picker-caption';
      caption.textContent = `${kind} ${index + 1}`;
      entry.append(input, thumb, caption);
      grid.appendChild(entry);
      inputs.push(input);
    });
    const update = () => {
      const selected = inputs.filter((input) => input.checked).length;
      count.textContent = `${uiText('已选')} ${selected} / ${items.length}`;
      toggle.textContent = uiText(selected === items.length ? '全不选' : '全选');
      confirm.textContent = `${uiText('下载所选')} (${selected})`;
      confirm.disabled = selected === 0;
    };
    let settled = false;
    const finish = (selection) => {
      if (settled) return;
      settled = true;
      document.removeEventListener('keydown', onKeyDown, true);
      window.removeEventListener('pagehide', cancel);
      window.removeEventListener('popstate', cancel);
      overlay.remove();
      downloadMediaPicker = null;
      if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
      resolve(selection);
    };
    const cancel = () => finish(null);
    const onKeyDown = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault(); event.stopImmediatePropagation(); cancel();
      } else if (event.key === 'Tab') {
        const focusable = [...overlay.querySelectorAll('input, button:not(:disabled)')];
        const first = focusable[0], last = focusable[focusable.length - 1];
        if (event.shiftKey && (document.activeElement === first || !overlay.contains(document.activeElement))) {
          event.preventDefault(); last.focus();
        } else if (!event.shiftKey && (document.activeElement === last || !overlay.contains(document.activeElement))) {
          event.preventDefault(); first.focus();
        }
      }
    };
    grid.addEventListener('change', update);
    toggle.addEventListener('click', () => {
      const selectAll = !inputs.every((input) => input.checked);
      inputs.forEach((input) => { input.checked = selectAll; });
      update();
    });
    confirm.addEventListener('click', () => {
      const selected = items.filter((_item, index) => inputs[index].checked);
      if (selected.length) finish(selected);
    });
    overlay.querySelector('[data-media-cancel]').addEventListener('click', cancel);
    let pointerInteractionStarted = false;
    overlay.addEventListener('pointerdown', () => { pointerInteractionStarted = true; }, true);
    overlay.addEventListener('pointercancel', () => { pointerInteractionStarted = false; }, true);
    overlay.addEventListener('click', (event) => {
      if (event.detail > 0 && !pointerInteractionStarted) {
        event.preventDefault(); event.stopImmediatePropagation();
      }
    }, true);
    overlay.addEventListener('click', (event) => {
      event.stopPropagation();
      if (event.target === overlay) cancel();
    });
    const preventBackgroundScroll = (event) => {
      if (!grid.contains(event.target)) event.preventDefault();
    };
    overlay.addEventListener('wheel', preventBackgroundScroll, { passive: false });
    overlay.addEventListener('touchmove', preventBackgroundScroll, { passive: false });
    document.addEventListener('keydown', onKeyDown, true);
    window.addEventListener('pagehide', cancel);
    window.addEventListener('popstate', cancel);
    downloadMediaPicker = { cancel };
    update();
    state.rootEl.appendChild(overlay);
    inputs[0].focus({ preventScroll: true });
  });
}
function bindDownloadButtonGestures(button, article, controls) {
  let press = null, timer = null, suppressClick = false;
  const clearPress = () => {
    if (timer !== null) clearTimeout(timer);
    timer = null;
    press = null;
  };
  const activate = (selectMedia) => {
    if (!button.isConnected || !state.settings.mediaDownload || isDownloadExcludedArticle(article)) return;
    const statusId = extractStatusIdFromUrl(getStatusLink(article));
    if (!statusId) return;
    controls.dataset.statusId = statusId;
    handleDownloadClick(article, extractAuthor(article), statusId, { selectMedia }).catch((error) => {
      debugLog('download start failed:', error);
      showToast('无法开始下载，请重试');
    });
  };
  button.addEventListener('pointerdown', (event) => {
    if (event.button !== 0 || event.isPrimary === false || press) return;
    event.stopPropagation();
    suppressClick = false;
    press = { id: event.pointerId, x: event.clientX, y: event.clientY,
      statusId: extractStatusIdFromUrl(getStatusLink(article)) };
    const started = press;
    timer = setTimeout(() => {
      timer = null;
      if (press !== started) return;
      if (started.statusId !== extractStatusIdFromUrl(getStatusLink(article))) {
        suppressClick = true;
        clearPress();
        return;
      }
      suppressClick = true;
      activate(true);
    }, DOWNLOAD_LONG_PRESS_MS);
  });
  button.addEventListener('pointermove', (event) => {
    if (!press || event.pointerId !== press.id) return;
    if (Math.hypot(event.clientX - press.x, event.clientY - press.y) > 10) {
      suppressClick = true;
      clearPress();
    }
  });
  button.addEventListener('pointerup', (event) => {
    if (press?.id === event.pointerId) clearPress();
  });
  for (const type of ['pointercancel', 'pointerleave', 'lostpointercapture']) {
    button.addEventListener(type, (event) => {
      if (!press || press.id !== event.pointerId) return;
      suppressClick = true;
      clearPress();
    });
  }
  button.addEventListener('contextmenu', (event) => { event.preventDefault(); event.stopPropagation(); });
  button.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === ' ') suppressClick = false;
  });
  button.addEventListener('click', (event) => {
    event.preventDefault(); event.stopPropagation();
    if (suppressClick) { suppressClick = false; return; }
    activate(!!event.shiftKey);
  }, true);
}
const SCREENSHOT_MAX_PIXELS = 16 * 1024 * 1024;
const SCREENSHOT_MAX_DIMENSION = 16384;
const SCREENSHOT_MAX_ASSET_BYTES = 12 * 1024 * 1024;
let screenshotInFlight = false;
let lastScreenshotReport = null;
function screenshotImageType(bytes, declared) {
  if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return 'image/png';
  if (bytes[0] === 0xff && bytes[1] === 0xd8) return 'image/jpeg';
  const head = new TextDecoder().decode(bytes.subarray(0, 2048)).replace(/^\uFEFF/, '').trim();
  if (/^GIF8[79]a/.test(head)) return 'image/gif';
  if (/^RIFF[\s\S]{4}WEBP/.test(head)) return 'image/webp';
  if (/^(?:<\?xml[^>]*>\s*)?(?:<!--[\s\S]*?-->\s*)*<svg[\s>]/i.test(head)) return 'image/svg+xml';
  return /^image\/(?:avif|bmp|x-icon)$/i.test(declared || '') ? declared : '';
}
function screenshotAssetUrl(raw) {
  if (typeof raw !== 'string' || !raw.trim()) return '';
  if (/^data:image\//i.test(raw || '')) return raw;
  try {
    const url = new URL(raw, location.href);
    if (url.protocol === 'blob:' && url.origin === location.origin) return url.href;
    if (url.origin === location.origin && /^https?:$/.test(url.protocol)) return url.href;
    return safeHttpsUrl(url.href, ['twimg.com']);
  } catch { return ''; }
}
function screenshotScale(width, height) {
  return Math.min(2, SCREENSHOT_MAX_DIMENSION / width, SCREENSHOT_MAX_DIMENSION / height,
    Math.sqrt(SCREENSHOT_MAX_PIXELS / (width * height)));
}
function screenshotAbortError() {
  const error = new Error('Screenshot cancelled or timed out');
  error.name = 'AbortError';
  return error;
}
function screenshotRequestBytes(url, signal) {
  if (signal.aborted) return Promise.reject(screenshotAbortError());
  if (typeof GM_xmlhttpRequest !== 'function' || /^blob:/.test(url)) {
    return screenshotFetchBytes(url, signal);
  }
  return new Promise((resolve, reject) => {
    let request, settled = false;
    const finish = (callback, value) => {
      if (settled) return;
      settled = true;
      signal.removeEventListener('abort', abort);
      callback(value);
    };
    const abort = () => {
      finish(reject, screenshotAbortError());
      try { request?.abort(); } catch {}
    };
    signal.addEventListener('abort', abort, { once: true });
    try {
      request = GM_xmlhttpRequest({
        method: 'GET', url, responseType: 'arraybuffer', timeout: 12000, anonymous: true,
        onload: async (response) => {
          if (settled) return;
          try {
            if (!(response.status >= 200 && response.status < 300)) throw new Error(`HTTP ${response.status}`);
            if (response.finalUrl && !screenshotAssetUrl(response.finalUrl)) throw new Error('Unexpected image redirect');
            const raw = response.response;
            if (!raw || typeof raw !== 'object') throw new Error('Empty image response');
            const buffer = typeof raw.arrayBuffer === 'function' ? await raw.arrayBuffer() : raw;
            const bytes = ArrayBuffer.isView(buffer)
              ? new Uint8Array(buffer.buffer, buffer.byteOffset, buffer.byteLength) : new Uint8Array(buffer);
            if (!bytes.length || bytes.length > SCREENSHOT_MAX_ASSET_BYTES) throw new Error('Invalid image size');
            const type = ((response.responseHeaders || '').match(/content-type:\s*([^;\r\n]+)/i) || [])[1] || '';
            finish(resolve, { bytes, type: type.trim().toLowerCase() });
          } catch (error) { finish(reject, error); }
        },
        onprogress: (event) => {
          if (event.loaded > SCREENSHOT_MAX_ASSET_BYTES) {
            finish(reject, new Error('Image exceeds size limit'));
            try { request?.abort(); } catch {}
          }
        },
        onerror: () => finish(reject, new Error('Image request failed')),
        ontimeout: () => finish(reject, new Error('Image request timed out')),
        onabort: () => finish(reject, screenshotAbortError()),
      });
      if (signal.aborted) abort();
    } catch (error) { finish(reject, error); }
  });
}
async function screenshotFetchBytes(url, signal) {
  const response = await fetch(url, { signal, credentials: 'omit', redirect: 'error' });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  if (Number(response.headers.get('content-length')) > SCREENSHOT_MAX_ASSET_BYTES) throw new Error('Image exceeds size limit');
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (!bytes.length || bytes.length > SCREENSHOT_MAX_ASSET_BYTES) throw new Error('Invalid image size');
  return { bytes, type: (response.headers.get('content-type') || '').split(';')[0].toLowerCase() };
}
function screenshotLoadImage(source, signal) {
  return new Promise((resolve, reject) => {
    if (signal.aborted) { reject(screenshotAbortError()); return; }
    const image = new Image();
    const finish = (callback, value) => {
      image.onload = image.onerror = null;
      signal.removeEventListener('abort', abort);
      callback(value);
    };
    const abort = () => { image.src = ''; finish(reject, screenshotAbortError()); };
    image.onload = () => finish(resolve, image);
    image.onerror = () => finish(reject, new Error('Image decode failed'));
    signal.addEventListener('abort', abort, { once: true });
    image.src = source;
  });
}
function screenshotRasterImage(image) {
  const width = image.naturalWidth || image.videoWidth || image.width;
  const height = image.naturalHeight || image.videoHeight || image.height;
  if (!width || !height) throw new Error('Image has no decoded pixels');
  const scale = Math.min(1, 2048 / Math.max(width, height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(width * scale));
  canvas.height = Math.max(1, Math.round(height * scale));
  try {
    const context = canvas.getContext('2d');
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/png');
  } finally { canvas.width = canvas.height = 1; }
}
async function screenshotEmbedAsset(raw, context, kind) {
  const url = screenshotAssetUrl(raw);
  if (!url) throw new Error('Unsupported image URL');
  if (context.assets.has(url)) return context.assets.get(url);
  const task = (async () => {
    const entry = { kind, host: /^data:/.test(url) ? 'data' : new URL(url).hostname, ok: false };
    context.report.resources.push(entry);
    try {
      let source = url;
      if (!/^data:image\//.test(url)) {
        let result;
        try { result = await screenshotRequestBytes(url, context.signal); }
        catch (error) {
          if (context.signal.aborted || typeof GM_xmlhttpRequest !== 'function') throw error;
          entry.fallback = 'cors-fetch';
          result = await screenshotFetchBytes(url, context.signal);
        }
        const type = screenshotImageType(result.bytes, result.type);
        if (!type) throw new Error('Response is not a supported image');
        entry.bytes = result.bytes.length;
        entry.type = type;
        context.bytes += result.bytes.length;
        if (context.bytes > 36 * 1024 * 1024) throw new Error('Screenshot images exceed size limit');
        const blob = new Blob([result.bytes], { type });
        source = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result);
          reader.onerror = () => reject(new Error('Image encoding failed'));
          reader.readAsDataURL(blob);
        });
      }
      const image = await screenshotLoadImage(source, context.signal);
      const png = screenshotRasterImage(image);
      context.encodedBytes += png.length;
      if (context.encodedBytes > 48 * 1024 * 1024) throw new Error('Encoded screenshot images exceed size limit');
      entry.ok = true;
      return png;
    } catch (error) {
      entry.error = String(error.message || error).slice(0, 160);
      context.assets.delete(url);
      throw error;
    }
  })();
  context.assets.set(url, task);
  return task;
}
function copyScreenshotStyle(source, target, context, pseudo) {
  const computed = getComputedStyle(source, pseudo || null);
  for (const property of computed) {
    const value = computed.getPropertyValue(property);
    if (property === 'content' || property === 'cursor' || !value) continue;
    target.style.setProperty(property, value, computed.getPropertyPriority(property));
    if (!/url\(/i.test(value)) continue;
    const matches = [...value.matchAll(/url\(\s*(?:"([^"]*)"|'([^']*)'|([^)]*))\s*\)/gi)];
    const external = [];
    let localValue = value;
    for (const match of matches) {
      const raw = (match[1] || match[2] || match[3] || '').trim();
      const reference = screenshotLocalReference(raw);
      if (reference) {
        localValue = localValue.replace(match[0], `url("${reference}")`);
        context.definitions.add(reference.slice(1));
      } else external.push(match);
    }
    target.style.setProperty(property, localValue);
    if (!external.length) continue;
    context.jobs.push(async () => {
      let embedded = localValue;
      for (const match of external) {
        const raw = (match[1] || match[2] || match[3] || '').trim();
        if (!raw || raw.startsWith('#')) continue;
        const png = await screenshotEmbedAsset(raw, context, 'css');
        embedded = embedded.replace(match[0], `url("${png}")`);
      }
      target.style.setProperty(property, embedded);
    });
  }
  target.style.setProperty('animation', 'none', 'important');
  target.style.setProperty('transition', 'none', 'important');
  target.style.setProperty('caret-color', 'transparent', 'important');
  target.style.setProperty('content-visibility', 'visible', 'important');
  return computed;
}
function screenshotLocalReference(raw) {
  if (raw.startsWith('#')) return raw;
  try {
    const url = new URL(raw, location.href), page = new URL(location.href);
    if (url.hash && url.origin === page.origin && url.pathname === page.pathname && url.search === page.search) return url.hash;
  } catch {}
  return '';
}
function screenshotPseudo(source, type, context) {
  if (!(source instanceof HTMLElement)) return null;
  const content = getComputedStyle(source, type).content;
  if (!content || content === 'none' || content === 'normal' || !/^["']/.test(content)) return null;
  const node = document.createElement('span');
  node.textContent = content.slice(1, -1).replace(/\\([0-9a-f]{1,6})\s?/gi, (_all, hex) => {
    const value = parseInt(hex, 16); return value && value <= 0x10ffff ? String.fromCodePoint(value) : '';
  }).replace(/\\([\s\S])/g, '$1');
  copyScreenshotStyle(source, node, context, type);
  return node;
}
function cloneScreenshotNode(source, context, inheritSvg = false) {
  if (source.nodeType === 3) return document.createTextNode(source.nodeValue || '');
  if (source.nodeType !== 1 || /^(SCRIPT|STYLE|LINK|IFRAME|NOSCRIPT|SOURCE)$/.test(source.tagName)) return null;
  if (source.matches('.BetterX-download-controls, [data-betterx-screenshot-menu], [role="tooltip"]')) return null;
  if (++context.nodes > 3000) throw new Error('Post is too complex to capture');
  const style = getComputedStyle(source);
  if (style.display === 'none') return null;
  const tag = source.tagName.toUpperCase();
  const replaceMedia = tag === 'VIDEO' || tag === 'CANVAS';
  const clone = replaceMedia ? document.createElement('img') : source.cloneNode(false);
  for (const attribute of [...clone.attributes]) {
    if (['href', 'xlink:href'].includes(attribute.name) && clone.namespaceURI === 'http://www.w3.org/2000/svg'
        && !['USE', 'IMAGE'].includes(tag) && screenshotLocalReference(attribute.value)) {
      const reference = screenshotLocalReference(attribute.value);
      clone.setAttribute(attribute.name, reference);
      context.definitions.add(reference.slice(1));
      continue;
    }
    if (/^on/i.test(attribute.name) || ['src', 'srcset', 'sizes', 'href', 'xlink:href', 'loading', 'autofocus'].includes(attribute.name)) clone.removeAttribute(attribute.name);
  }
  copyScreenshotStyle(source, clone, context);
  if (style.visibility === 'hidden' || Number(style.opacity) === 0) return clone;
  if (inheritSvg && !source.hasAttribute('class')) {
    for (const property of ['color', 'fill', 'stroke', 'fill-opacity', 'stroke-opacity', 'stroke-width']) {
      if (!source.hasAttribute(property) && !source.style.getPropertyValue(property)) clone.style.setProperty(property, 'inherit');
    }
  }
  if (tag === 'IMG' || tag === 'IMAGE' || replaceMedia) {
    let raw = tag === 'IMG' ? source.currentSrc || source.src
      : tag === 'IMAGE' ? source.getAttribute('href') || source.getAttribute('xlink:href') : '';
    let pixels = '';
    if ((tag === 'IMG' && source.complete) || tag === 'CANVAS' || (tag === 'VIDEO' && source.readyState >= 2)) {
      try { pixels = screenshotRasterImage(source); } catch {}
    }
    if (pixels) {
      context.encodedBytes += pixels.length;
      if (context.encodedBytes > 48 * 1024 * 1024) throw new Error('Encoded screenshot images exceed size limit');
    }
    if (tag === 'VIDEO' && !pixels) {
      const thumbnail = [...(source.parentElement?.querySelectorAll('img[src]') || [])]
        .find(image => getVideoPosterKey(image.currentSrc || image.src));
      raw = source.poster || thumbnail?.currentSrc || thumbnail?.src || '';
      context.report.videoPosters++;
    }
    clone.removeAttribute('crossorigin');
    context.jobs.push(async () => {
      const image = pixels || await screenshotEmbedAsset(raw, context, tag.toLowerCase());
      if (tag === 'IMAGE') clone.setAttribute('href', image);
      else clone.setAttribute('src', image);
    });
    return clone;
  }
  if (tag === 'USE') {
    const href = source.getAttribute('href') || source.getAttribute('xlink:href') || '';
    if (href.startsWith('#')) {
      const referenced = document.getElementById(href.slice(1));
      if (referenced && !context.references.has(referenced)) {
        context.references.add(referenced);
        const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        copyScreenshotStyle(source, group, context);
        const content = cloneScreenshotNode(referenced, context, true);
        if (content?.tagName.toUpperCase() === 'SYMBOL') {
          const inner = document.createElementNS(group.namespaceURI, 'g');
          inner.style.cssText = content.style.cssText;
          inner.append(...content.childNodes); group.appendChild(inner);
        } else if (content) group.appendChild(content);
        context.references.delete(referenced);
        return group;
      }
    }
    return null;
  }
  const before = screenshotPseudo(source, '::before', context);
  if (before) clone.appendChild(before);
  for (const child of source.childNodes) {
    const cloned = cloneScreenshotNode(child, context, inheritSvg);
    if (cloned) clone.appendChild(cloned);
  }
  const after = screenshotPseudo(source, '::after', context);
  if (after) clone.appendChild(after);
  if (source.scrollLeft || source.scrollTop) {
    for (const child of clone.children) {
      child.style.transform = `translate(${-source.scrollLeft}px, ${-source.scrollTop}px) ${child.style.transform === 'none' ? '' : child.style.transform}`;
    }
  }
  return clone;
}
function screenshotBackground(article) {
  for (let element = article; element; element = element.parentElement) {
    const color = getComputedStyle(element).backgroundColor;
    if (color && color !== 'transparent' && !/^rgba\([^)]*,\s*0\)$/.test(color)) return color;
  }
  return getComputedStyle(article).color === 'rgb(231, 233, 234)' ? '#000000' : '#ffffff';
}
async function capturePostScreenshot(article, expectedId) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 45000);
  const report = { version: '4.1.0', startedAt: new Date().toISOString(), browser: navigator.userAgent,
    resources: [], videoPosters: 0, ok: false };
  lastScreenshotReport = report;
  const context = { signal: controller.signal, report, assets: new Map(), jobs: [], references: new Set(), definitions: new Set(), nodes: 0, bytes: 0, encodedBytes: 0 };
  let canvas;
  try {
    if (!article?.isConnected || (expectedId && extractStatusIdFromUrl(getStatusLink(article)) !== expectedId)) throw new Error('Post is no longer available');
    const rect = article.getBoundingClientRect();
    const width = Math.ceil(rect.width), height = Math.ceil(rect.height);
    if (!(width > 0 && height > 0)) throw new Error('Post has no visible layout');
    const author = extractAuthor(article);
    const background = screenshotBackground(article);
    const clone = cloneScreenshotNode(article, context);
    const definitions = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    for (const id of context.definitions) {
      const definition = document.getElementById(id);
      if (definition && !article.contains(definition)) {
        const cloned = cloneScreenshotNode(definition, context);
        if (cloned) definitions.appendChild(cloned);
      }
      if (context.definitions.size > 100) throw new Error('Too many SVG references');
    }
    const scale = screenshotScale(width, height);
    report.width = width; report.height = height; report.scale = scale;
    if (!clone || scale < 0.1) throw new Error('Post exceeds screenshot limits');
    Object.assign(clone.style, { position: 'relative', margin: '0', left: '0', top: '0', right: 'auto', bottom: 'auto',
      width: `${width}px`, height: `${height}px`, boxSizing: 'border-box', transform: 'none', backgroundColor: background });
    let cursor = 0;
    const worker = async () => {
      while (cursor < context.jobs.length) {
        if (controller.signal.aborted) throw screenshotAbortError();
        await context.jobs[cursor++]();
      }
    };
    const outcomes = await Promise.allSettled(Array.from({ length: Math.min(4, context.jobs.length) }, worker));
    const failure = outcomes.find((result) => result.status === 'rejected');
    if (failure) throw failure.reason;
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', width); svg.setAttribute('height', height);
    svg.appendChild(definitions);
    const foreign = document.createElementNS(svg.namespaceURI, 'foreignObject');
    foreign.setAttribute('width', '100%'); foreign.setAttribute('height', '100%');
    foreign.appendChild(clone); svg.appendChild(foreign);
    const xml = new XMLSerializer().serializeToString(svg);
    const image = await screenshotLoadImage(`data:image/svg+xml;charset=utf-8,${encodeURIComponent(xml)}`, controller.signal);
    canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.floor(width * scale)); canvas.height = Math.max(1, Math.floor(height * scale));
    const drawing = canvas.getContext('2d');
    drawing.fillStyle = background; drawing.fillRect(0, 0, canvas.width, canvas.height);
    drawing.drawImage(image, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise((resolve, reject) => canvas.toBlob(value => value ? resolve(value) : reject(new Error('PNG encoding failed')), 'image/png'));
    report.ok = true; report.outputBytes = blob.size;
    const name = String(author.username || 'x').replace(/[^a-z0-9_-]/gi, '').slice(0, 40) || 'x';
    const id = expectedId || extractStatusIdFromUrl(getStatusLink(article)) || Date.now();
    return { blob, filename: `BetterX_${name}_${id}.png`, report };
  } catch (error) {
    report.error = String(error.message || error).slice(0, 200);
    controller.abort();
    throw error;
  } finally {
    clearTimeout(timer);
    if (canvas) canvas.width = canvas.height = 1;
    context.assets.clear(); context.jobs.length = 0;
  }
}
function exportScreenshotDiagnostic() {
  if (!lastScreenshotReport) return;
  saveBlob(new Blob([JSON.stringify(lastScreenshotReport, null, 2)], { type: 'application/json' }), 'BetterX_screenshot_diagnostic.json');
}
async function runPostScreenshot(article, statusId) {
  if (screenshotInFlight) { showToast('正在生成另一张截图，请稍候'); return; }
  screenshotInFlight = true;
  showToast('正在生成帖子截图…', 0);
  try {
    const result = await capturePostScreenshot(article, statusId);
    saveBlob(result.blob, result.filename);
    showToast('帖子截图已保存');
    return result;
  } catch (error) {
    console.error('[BetterX] screenshot failed:', lastScreenshotReport);
    showToast('帖子截图失败，请重试');
    showBetterXDialog({ title: '无法生成完整截图',
      bodyHtml: `<p>${escapeHtml(uiText('部分图片未能读取或渲染失败。请重试；仍有问题时可导出诊断信息。'))}</p>`,
      primaryText: '重试', secondaryText: '关闭', tertiaryText: '导出截图诊断',
      onPrimary: () => runPostScreenshot(article, statusId), onTertiary: exportScreenshotDiagnostic });
  } finally { screenshotInFlight = false; }
}
let screenshotMenuCleanup = null;
let screenshotMenuInstalled = false;
let screenshotClosingMenu = false;
function findScreenshotMenuTrigger(target) {
  const element = target?.nodeType === 1 ? target : target?.parentElement;
  if (!element || element.closest('#BetterX-root')) return null;
  const button = element.closest('[data-testid="caret"], button[aria-haspopup="menu"]');
  if (!button || !button.closest('article')) return null;
  if (button.matches('[data-testid="caret"]')) return button;
  const label = (button.getAttribute('aria-label') || '').trim().toLowerCase();
  const use = button.querySelector('svg use');
  return ['more', '更多', '詳細', '详细'].includes(label)
    || (use?.getAttribute('href') || use?.getAttribute('xlink:href')) === '#icon-more' ? button : null;
}
function scheduleScreenshotMenu(trigger) {
  screenshotMenuCleanup?.();
  const article = trigger.closest('article');
  const statusId = extractStatusIdFromUrl(getStatusLink(article));
  if (!statusId || isDownloadExcludedArticle(article)) return;
  const priorMenus = new Set([...document.querySelectorAll('[role="menu"]')].filter(menu => {
    const rect = menu.getBoundingClientRect(); return rect.width > 0 && rect.height > 0;
  }));
  let menu = null, item = null, timer = null, stopped = false;
  const observer = new MutationObserver(() => inject());
  const cleanup = () => {
    if (stopped) return;
    stopped = true;
    observer.disconnect();
    clearTimeout(timer);
    if (screenshotMenuCleanup === cleanup) screenshotMenuCleanup = null;
  };
  const inject = () => {
    if (stopped || !trigger.isConnected) { cleanup(); return; }
    if (menu && !menu.isConnected) { cleanup(); return; }
    if (!menu) {
      const triggerRect = trigger.getBoundingClientRect();
      const candidates = [...document.querySelectorAll('[role="menu"]')].filter(candidate => {
        const rect = candidate.getBoundingClientRect();
        return !candidate.closest('#BetterX-root') && (!priorMenus.has(candidate)
          || candidate.id === trigger.getAttribute('aria-controls')) && rect.width > 0 && rect.height > 0;
      });
      candidates.sort((a, b) => {
        const distance = candidate => { const rect = candidate.getBoundingClientRect(); return Math.hypot(rect.left - triggerRect.left, rect.top - triggerRect.top); };
        return distance(a) - distance(b);
      });
      menu = candidates[0] || null;
      if (!menu) return;
      observer.disconnect();
      observer.observe(menu, { childList: true, subtree: true });
    }
    if (item?.isConnected) return;
    const nativeItem = menu.querySelector('[role="menuitem"]:not([data-betterx-screenshot-menu])');
    if (!nativeItem) return;
    menu.querySelectorAll('[data-betterx-screenshot-menu]').forEach(element => element.remove());
    item = document.createElement('div');
    item.setAttribute('role', 'menuitem'); item.tabIndex = 0;
    item.setAttribute('data-betterx-screenshot-menu', '');
    item.className = 'BetterX-screenshot-menu-item';
    item.style.color = getComputedStyle(nativeItem).color;
    item.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 4h6l2 2h3a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h3l2-2Zm3 4a5 5 0 1 0 0 10 5 5 0 0 0 0-10Zm0 2a3 3 0 1 1 0 6 3 3 0 0 1 0-6Z"/></svg><span></span>`;
    item.querySelector('span').textContent = uiText('保存帖子截图');
    const activate = (event) => {
      event.preventDefault(); event.stopPropagation();
      cleanup();
      screenshotClosingMenu = true;
      try { trigger.click(); } finally { screenshotClosingMenu = false; }
      runPostScreenshot(article, statusId);
    };
    item.addEventListener('click', activate);
    item.addEventListener('keydown', event => {
      if (event.key === 'Enter' || event.key === ' ') activate(event);
    });
    nativeItem.parentElement.insertBefore(item, nativeItem);
  };
  screenshotMenuCleanup = cleanup;
  observer.observe(document.body, { childList: true, subtree: true });
  timer = setTimeout(cleanup, 5000);
  queueMicrotask(inject);
}
function installPostScreenshotMenu() {
  if (screenshotMenuInstalled) return;
  screenshotMenuInstalled = true;
  const open = event => {
    if (screenshotClosingMenu || (event.type === 'keydown' && !['Enter', ' '].includes(event.key))) return;
    const trigger = findScreenshotMenuTrigger(event.target);
    if (trigger) scheduleScreenshotMenu(trigger);
  };
  document.addEventListener('click', open, true);
  document.addEventListener('keydown', open, true);
  window.addEventListener('pagehide', () => screenshotMenuCleanup?.());
}
function getArticlesFromScope(scope) {
  const root = (scope && scope.querySelectorAll) ? scope : document;
  return root.matches && root.matches('article') ? [root] : [...root.querySelectorAll('article')];
}
function removeMediaGridLayout(scope) {
  const root = (scope && scope.querySelectorAll) ? scope : document;
  root.querySelectorAll('.BetterX-media-grid').forEach((el) => {
    el.classList.remove('BetterX-media-grid', 'BetterX-media-grid-count-2', 'BetterX-media-grid-count-3', 'BetterX-media-grid-count-4');
  });
  root.querySelectorAll('.BetterX-media-grid-box').forEach((el) => el.classList.remove('BetterX-media-grid-box'));
}
function restoreMediaGridInArticle(article) {
  if (!article || article.closest('#BetterX-root')) return;
  article.querySelectorAll('[data-testid="ScrollSnap-List"]').forEach((list) => {
    const items = [...list.children].filter((child) => child.getAttribute('role') === 'presentation');
    const nav = list.closest('nav[role="navigation"]');
    if (!nav) return;
    nav.classList.remove('BetterX-media-grid', 'BetterX-media-grid-count-2', 'BetterX-media-grid-count-3', 'BetterX-media-grid-count-4');
    if (nav.parentElement) nav.parentElement.classList.remove('BetterX-media-grid-box');
    if (items.length < 2) return;
    nav.classList.add('BetterX-media-grid', `BetterX-media-grid-count-${Math.min(items.length, 4)}`);
    if (nav.parentElement) nav.parentElement.classList.add('BetterX-media-grid-box');
  });
}
function applyMediaGridLayout(scope) {
  if (!state.settings.restoreMediaGrid) {
    removeMediaGridLayout(scope);
    return;
  }
  getArticlesFromScope(scope).forEach(restoreMediaGridInArticle);
}
const AGE_WARN_RE = /年龄限制|成人内容|敏感内容|敏感媒体|可能不适合|验证.{0,6}年龄|个人资料验证|age[- ]?restricted|adult content|sensitive (?:media|content)|might not be suitable|verify your age|profile to view/i;
function findAgeWarnEl(article) {
  const nodes = article.querySelectorAll('span, div[dir="ltr"]');
  for (const el of nodes) {
    if (el.closest('[data-testid="tweetText"]')) continue;
    const t = (el.textContent || '').trim();
    if (t && t.length <= 400 && AGE_WARN_RE.test(t)) return el;
  }
  return null;
}
function getAgeMaskBlock(warnEl, article) {
  let best = warnEl;
  let el = warnEl.parentElement;
  for (let i = 0; i < 10 && el && el !== article; i++, el = el.parentElement) {
    if (el.querySelector('[data-testid="tweetText"]')) break;
    if ((el.textContent || '').length <= 500) best = el; else break;
  }
  return best;
}
function buildUnlockedMediaEl(media, statusUrl) {
  const box = document.createElement('div');
  box.className = 'BetterX-unlocked BetterX-native-media-grid';
  const total = media.photos.length + media.gifs.length + media.videos.length;
  if (total === 1) {
    box.classList.add('xv-n1');
  } else {
    box.classList.add('xv-multi');
    if (total === 2) box.classList.add('xv-n2');
    else if (total === 3) box.classList.add('xv-n3');
    else if (total === 4) box.classList.add('xv-n4');
    else box.classList.add('xv-nm');
  }
  const nativeStatusUrl = normalizeUrl(statusUrl || '').replace(/\/photo\/\d+$/i, '');
  media.photos.forEach((u, index) => {
    const a = document.createElement('a');
    a.href = nativeStatusUrl ? `${nativeStatusUrl}/photo/${index + 1}` : u;
    a.className = 'BetterX-unlocked-tile BetterX-unlocked-photo';
    a.setAttribute('role', 'link');
    if (!nativeStatusUrl) { a.target = '_blank'; a.rel = 'noopener'; }
    const mediaEl = document.createElement('div');
    mediaEl.className = 'BetterX-unlocked-media';
    mediaEl.setAttribute('data-testid', 'tweetPhoto');
    mediaEl.setAttribute('aria-label', '图像');
    const img = document.createElement('img');
    img.src = u; img.loading = 'lazy'; img.referrerPolicy = 'no-referrer'; img.alt = '';
    mediaEl.appendChild(img); a.appendChild(mediaEl); box.appendChild(a);
  });
  media.gifs.forEach((u) => {
    const tile = document.createElement('div');
    tile.className = 'BetterX-unlocked-tile BetterX-unlocked-video';
    tile.setAttribute('data-testid', 'videoComponent');
    const v = document.createElement('video');
    v.src = u; v.autoplay = true; v.loop = true; v.muted = true; v.playsInline = true;
    tile.appendChild(v); box.appendChild(tile);
  });
  media.videos.forEach((u) => {
    const tile = document.createElement('div');
    tile.className = 'BetterX-unlocked-tile BetterX-unlocked-video';
    tile.setAttribute('data-testid', 'videoComponent');
    const v = document.createElement('video');
    v.src = u; v.controls = true; v.playsInline = true; v.preload = 'metadata';
    tile.appendChild(v); box.appendChild(tile);
  });
  return box;
}
const CARD_CONTENT_SEL = [ '[data-testid="card.wrapper"]', '[data-testid^="card.layout"]', '[data-testid="videoComponent"]', '[data-testid="videoPlayer"]', 'img[src*="/card_img/"]', 'video[poster*="amplify_tw_video_thumb"]', 'video[poster*="amplify_video_thumb"]', 'video[poster*="ext_tw_video_thumb"]', 'video[poster*="tweet_video_thumb"]', 'video[src^="blob:"]', ].join(', ');
function revealCardUnderMask(warnEl, article) {
  if (!warnEl || !article) return;
  if (warnEl.closest('.BetterX-mask-hidden')) return; // 已揭掉，避免重复处理
  if (!article.querySelector(CARD_CONTENT_SEL)) return;
  let overlay = warnEl;
  let el = warnEl.parentElement;
  for (let i = 0; i < 14 && el && el !== article; i++, el = el.parentElement) {
    if (el.querySelector(CARD_CONTENT_SEL)) break; // 到达含真实内容的层，停止上移
    overlay = el;
  }
  if (!overlay || overlay === article) return;
  if (overlay.querySelector(CARD_CONTENT_SEL)) return; // 安全兑底：绝不隐藏含真实内容的层
  overlay.classList.add('BetterX-mask-hidden');
}
function unlockAgeRestricted(article) {
  if (!article || !article.querySelector) return;
  if (article.closest('#BetterX-root')) return;
  if (article.querySelector('.BetterX-unlocked')) return; // 已处理，避免重复注入
  const warnEl = findAgeWarnEl(article);
  if (!warnEl) return;
  const statusId = extractStatusIdFromUrl(getStatusLink(article));
  const media = collectMedia(article, statusId);
  if (!media.photos.length && !media.gifs.length && !media.videos.length) {
    const card = statusId ? cardRegistry.get(String(statusId)) : null;
    if (card && (card.photos.length || card.gifs.length || card.videos.length)) {
      const cblock = getAgeMaskBlock(warnEl, article);
      if (!cblock || !cblock.parentElement) return;
      cblock.classList.add('BetterX-mask-hidden');
      cblock.insertAdjacentElement('afterend', buildUnlockedMediaEl(card, getStatusLink(article)));
      return;
    }
    revealCardUnderMask(warnEl, article);
    return;
  }
  const block = getAgeMaskBlock(warnEl, article);
  if (!block || !block.parentElement) return;
  block.classList.add('BetterX-mask-hidden');
  block.insertAdjacentElement('afterend', buildUnlockedMediaEl(media, getStatusLink(article)));
}
function revealAgeRestricted(scope) {
  if (!state.settings.bypassAgeRestriction) return;
  getArticlesFromScope(scope).forEach(unlockAgeRestricted);
}
function removeUnlockedMedia() {
  document.querySelectorAll('.BetterX-unlocked').forEach((el) => el.remove());
  document.querySelectorAll('.BetterX-mask-hidden').forEach((el) => el.classList.remove('BetterX-mask-hidden'));
}
function applyAgeBypass() {
  if (state.settings.bypassAgeRestriction) revealAgeRestricted(document);
  else removeUnlockedMedia();
}
const LOGGED_OUT_POST_DIALOG_SELECTOR = '[role="dialog"][aria-modal="true"][data-interaction="app-store-obstruction"]';
const LOGGED_OUT_POST_PANEL_SELECTOR = '[data-interaction="app-store-obstruction-panel"]';
const LOGGED_OUT_POST_FOOTER_SELECTOR = 'aside.fixed.bottom-0.isolate.z-40';
const LOGGED_OUT_POST_FOOTER_LINK_SELECTOR = 'a[href*="launch_app_store=true"][href*="ct=post-timeline"]';
const LOGGED_OUT_POST_DISMISS_MAX_ATTEMPTS = 8;
const loggedOutPostDialogAttempts = new WeakMap();
function getLoggedOutPostDialogs(root) {
  const scope = root && root.querySelectorAll ? root : document;
  const dialogs = new Set(scope.querySelectorAll(LOGGED_OUT_POST_DIALOG_SELECTOR));
  if (scope.matches && scope.matches(LOGGED_OUT_POST_DIALOG_SELECTOR)) dialogs.add(scope);
  const ancestor = scope.closest && scope.closest(LOGGED_OUT_POST_DIALOG_SELECTOR);
  if (ancestor) dialogs.add(ancestor);
  return dialogs;
}
function removeLoggedOutPostFooterPanels(root) {
  const scope = root && root.querySelectorAll ? root : document;
  const panels = new Set(scope.querySelectorAll(LOGGED_OUT_POST_FOOTER_SELECTOR));
  if (scope.matches && scope.matches(LOGGED_OUT_POST_FOOTER_SELECTOR)) panels.add(scope);
  const ancestor = scope.closest && scope.closest(LOGGED_OUT_POST_FOOTER_SELECTOR);
  if (ancestor) panels.add(ancestor);
  let removed = 0;
  for (const panel of panels) {
    if (panel.isConnected === false || !panel.querySelector(LOGGED_OUT_POST_FOOTER_LINK_SELECTOR)) continue;
    panel.remove();
    removed++;
  }
  return removed;
}
function dismissLoggedOutPostObstructions(root = document) {
  let dismissed = removeLoggedOutPostFooterPanels(root);
  for (const dialog of getLoggedOutPostDialogs(root)) {
    if ((dialog.getAttribute && dialog.getAttribute('data-state') === 'closed')
        || dialog.isConnected === false
        || !dialog.querySelector(LOGGED_OUT_POST_PANEL_SELECTOR)) continue;
    const current = loggedOutPostDialogAttempts.get(dialog) || { attempts: 0, timer: null };
    if (current.timer || current.attempts >= LOGGED_OUT_POST_DISMISS_MAX_ATTEMPTS) continue;
    let button = dialog.querySelector('button[data-slot="xds-button"][aria-label="Dismiss"]');
    if (!button) {
      const closeIcon = dialog.querySelector('button[data-slot="xds-button"] svg[data-icon="icon-close-md"]');
      button = closeIcon && closeIcon.closest ? closeIcon.closest('button') : null;
    }
    if (!button || button.disabled || button.getAttribute('aria-disabled') === 'true') continue;
    current.attempts++;
    loggedOutPostDialogAttempts.set(dialog, current);
    try {
      if (typeof button.dispatchEvent === 'function') {
        for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup']) {
          const EventConstructor = type.startsWith('pointer')
            ? globalThis.PointerEvent : globalThis.MouseEvent;
          if (typeof EventConstructor !== 'function') continue;
          button.dispatchEvent(new EventConstructor(type, {
            bubbles: true, cancelable: true, composed: true, button: 0,
          }));
        }
      }
      button.click();
      dismissed++;
    } catch (err) {
      console.error('[BetterX] logged-out post dialog dismissal failed:', err);
    }
    current.timer = setTimeout(() => {
      current.timer = null;
      if (dialog.isConnected === false
          || (dialog.getAttribute && dialog.getAttribute('data-state') === 'closed')) return;
      dismissLoggedOutPostObstructions(dialog);
    }, Math.min(250 + current.attempts * 100, 700));
  }
  return dismissed;
}
let xvToastTimer = null;
function showToast(msg, duration) {
  let t = document.getElementById('BetterX-toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'BetterX-toast';
    (state.rootEl || document.body).appendChild(t);
  }
  t.textContent = uiText(msg);
  t.classList.add('show');
  if (xvToastTimer) clearTimeout(xvToastTimer);
  xvToastTimer = null;
  const timeoutMs = duration === undefined ? 2600 : Math.max(0, Number(duration) || 0);
  if (timeoutMs > 0) xvToastTimer = setTimeout(() => t.classList.remove('show'), timeoutMs);
}
function closeBetterXDialog() {
  const dialog = document.getElementById('BetterX-choice-dialog');
  if (dialog) dialog.remove();
}
function showBetterXDialog(options) {
  if (!state.rootEl) return;
  closeBetterXDialog();
  const overlay = document.createElement('div');
  overlay.id = 'BetterX-choice-dialog';
  overlay.className = 'BetterX-dialog-overlay';
  overlay.innerHTML = `
      <div class="BetterX-dialog${options.showCloseIcon ? ' has-close-icon' : ''}" role="dialog" aria-modal="true" aria-labelledby="BetterX-dialog-title">
        <button type="button" class="BetterX-dialog-close" data-dialog-close hidden aria-label="${escapeHtml(uiText(options.closeIconLabel || '关闭'))}" title="${escapeHtml(uiText(options.closeIconLabel || '关闭'))}">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.4 5.3 12 10.9l5.6-5.6 1.1 1.1-5.6 5.6 5.6 5.6-1.1 1.1-5.6-5.6-5.6 5.6-1.1-1.1 5.6-5.6-5.6-5.6z"/></svg>
        </button>
        <div class="BetterX-dialog-title" id="BetterX-dialog-title"></div>
        <div class="BetterX-dialog-body"></div>
        <div class="BetterX-dialog-actions">
          <button type="button" class="BetterX-btn" data-dialog-choice="tertiary" hidden></button>
          <button type="button" class="BetterX-btn" data-dialog-choice="secondary"></button>
          <button type="button" class="BetterX-btn primary" data-dialog-choice="primary"></button>
        </div>
      </div>
    `;
  overlay.querySelector('.BetterX-dialog-title').textContent = uiText(options.title || 'BetterX 提示');
  overlay.querySelector('.BetterX-dialog-body').innerHTML = options.bodyHtml || '';
  const primary = overlay.querySelector('[data-dialog-choice="primary"]');
  const secondary = overlay.querySelector('[data-dialog-choice="secondary"]');
  const tertiary = overlay.querySelector('[data-dialog-choice="tertiary"]');
  const closeIcon = overlay.querySelector('[data-dialog-close]');
  if (closeIcon && options.showCloseIcon) {
    closeIcon.hidden = false;
    closeIcon.addEventListener('click', () => {
      closeBetterXDialog();
      if (typeof options.onCloseIcon === 'function') options.onCloseIcon();
    });
  }
  primary.textContent = uiText(options.primaryText || '确定');
  secondary.textContent = uiText(options.secondaryText || '取消');
  if (options.tertiaryText) {
    tertiary.hidden = false;
    tertiary.textContent = uiText(options.tertiaryText);
  }
  localizeBetterXTree(overlay);
  primary.addEventListener('click', () => {
    closeBetterXDialog();
    if (typeof options.onPrimary === 'function') options.onPrimary();
  });
  secondary.addEventListener('click', () => {
    closeBetterXDialog();
    if (typeof options.onSecondary === 'function') options.onSecondary();
  });
  tertiary.addEventListener('click', () => {
    closeBetterXDialog();
    if (typeof options.onTertiary === 'function') options.onTertiary();
  });
  state.rootEl.appendChild(overlay);
  setTimeout(() => primary.focus(), 0);
}
const SENSITIVE_CONTENT_SETTINGS_URL = 'https://x.com/settings/content_you_see';
const SENSITIVE_CONTENT_NOTICE_SESSION_KEY = 'betterx_sensitive_content_notice_v1';
function showAgeBypassEnableNotice() {
  showBetterXDialog({
    bodyHtml: `<p>${escapeHtml(uiText('如果您没有勾选的话，麻烦您勾选上“显示可能含有敏感内容的媒体内容”，大部分成人内容会自动显示'))}</p>`,
    primaryText: '确定',
  });
  const overlay = document.getElementById('BetterX-choice-dialog');
  const secondary = overlay && overlay.querySelector('[data-dialog-choice="secondary"]');
  if (secondary) secondary.hidden = true;
}
function navigateToSensitiveContentSettings() {
  try { sessionStorage.setItem(SENSITIVE_CONTENT_NOTICE_SESSION_KEY, '1'); }
  catch (err) { console.error('[BetterX] sensitive content notice state failed:', err); }
  const navigate = () => {
    try {
      if (typeof location.assign === 'function') location.assign(SENSITIVE_CONTENT_SETTINGS_URL);
      else location.href = SENSITIVE_CONTENT_SETTINGS_URL;
    } catch (err) {
      console.error('[BetterX] sensitive content settings navigation failed:', err);
    }
  };
  Promise.resolve(state.dbWriteQueue).then(navigate, navigate);
}
function maybeShowAgeBypassEnableNotice() {
  if (location.pathname !== '/settings/content_you_see') return false;
  let pending = false;
  try {
    pending = sessionStorage.getItem(SENSITIVE_CONTENT_NOTICE_SESSION_KEY) === '1';
    if (pending) sessionStorage.removeItem(SENSITIVE_CONTENT_NOTICE_SESSION_KEY);
  } catch (err) {
    console.error('[BetterX] sensitive content notice read failed:', err);
  }
  if (!pending) return false;
  showAgeBypassEnableNotice();
  return true;
}
function chooseUiLanguage(language) {
  if (!SUPPORTED_UI_LANGUAGES.has(language)) return;
  if (language === UI_LANGUAGE && readUiLanguageOverride() === language) {
    closeBetterXDialog();
    return;
  }
  let saved;
  try {
    if (typeof GM_setValue !== 'function') throw new Error('GM_setValue unavailable');
    saved = GM_setValue(UI_LANGUAGE_OVERRIDE_KEY, language);
  } catch (err) {
    showToast(`⚠️ ${uiText('无法保存语言设置')}`);
    return;
  }
  closeBetterXDialog();
  showToast('正在切换语言并刷新…', 0);
  Promise.resolve(saved).then(() => location.reload()).catch(() => {
    showToast(`⚠️ ${uiText('无法保存语言设置')}`);
  });
}
function showLanguageDialog() {
  const options = [
    { value: 'zh-CN', label: '简体中文', code: '简体' },
    { value: 'zh-TW', label: '繁體中文', code: '繁體' },
    { value: 'ja', label: '日本語', code: 'JA' },
    { value: 'en', label: 'English', code: 'EN' },
  ];
  showBetterXDialog({
    title: '选择界面语言',
    bodyHtml: `
        <div class="BetterX-language-options" role="radiogroup" aria-label="${escapeHtml(uiText('选择界面语言'))}">
          ${options.map((item) => `
            <button type="button" class="BetterX-language-option${item.value === UI_LANGUAGE ? ' is-current' : ''}"
              data-ui-language="${escapeHtml(item.value)}" role="radio" aria-checked="${item.value === UI_LANGUAGE ? 'true' : 'false'}">
              <span class="BetterX-language-code">${escapeHtml(item.code)}</span>
              <span>${escapeHtml(item.label)}</span>
              <span class="BetterX-language-check" aria-hidden="true">${item.value === UI_LANGUAGE ? '✓' : ''}</span>
            </button>
          `).join('')}
        </div>
        <p class="BetterX-language-note">选择后页面会刷新，帖子与设置数据不会受到影响。</p>
      `,
    primaryText: '取消',
  });
  const overlay = document.getElementById('BetterX-choice-dialog');
  if (!overlay) return;
  const secondary = overlay.querySelector('[data-dialog-choice="secondary"]');
  if (secondary) secondary.hidden = true;
  overlay.querySelectorAll('[data-ui-language]').forEach((button) => {
    button.addEventListener('click', () => chooseUiLanguage(button.getAttribute('data-ui-language') || ''));
  });
  const current = overlay.querySelector('.BetterX-language-option.is-current');
  if (current) setTimeout(() => current.focus(), 0);
}
function setFirefoxCompatibilityChoice(enabled) {
  setSettingsPartial({
    firefoxCompatibility: !!enabled,
    firefoxCompatibilityPrompted: true,
  });
}
function reloadAfterFirefoxCompatibilityChange(enabled) {
  setFirefoxCompatibilityChoice(enabled);
  showToast(enabled ? '正在开启 Firefox 兼容模式并刷新…' : '正在关闭 Firefox 兼容模式并刷新…', 0);
  Promise.resolve(state.dbWriteQueue).then(() => location.reload()).catch(() => location.reload());
}
function showFirefoxCompatibilityToggleDialog(enable) {
  if (!IS_FIREFOX) {
    showToast('此选项仅用于 Firefox');
    return;
  }
  if (enable) {
    showBetterXDialog({
      title: '开启“兼容 Firefox”？',
      bodyHtml: `
          <p>开启后 BetterX 不再改写页面的 <code>fetch</code> / <code>XMLHttpRequest</code>，可避免部分 Firefox 环境或多个 X 脚本冲突时一直卡在 X 图标。</p>
          <p>以下能力可能降级：</p>
          <ul>
            <li>部分视频 / GIF 无法取得真实下载地址；</li>
            <li>部分年龄限制视频无法内联显示；</li>
            <li>无法从接口响应学习关注关系，主要依靠主页按钮和“正在关注”时间线。</li>
          </ul>
          <p>帖子记录、搜索、面板、内容净化、广告过滤、布局和图片 DOM 兜底不受影响。确认后页面会刷新。</p>
        `,
      primaryText: '开启并刷新',
      secondaryText: '取消',
      onPrimary: () => reloadAfterFirefoxCompatibilityChange(true),
      onSecondary: () => refreshUI({ keepScroll: true }),
    });
    return;
  }
  showBetterXDialog({
    title: '关闭“兼容 Firefox”？',
    bodyHtml: '<p>关闭后将恢复 v1.7 的网络媒体与关注关系采集。如果当前环境曾卡在只显示 X 图标的页面，建议继续保持开启。确认后页面会刷新。</p>',
    primaryText: '关闭并刷新',
    secondaryText: '取消',
    onPrimary: () => reloadAfterFirefoxCompatibilityChange(false),
    onSecondary: () => refreshUI({ keepScroll: true }),
  });
}
function maybePromptFirefoxCompatibility() {
  if (!IS_FIREFOX || firefoxCompatibilityMode !== 'unset' || state.settings.firefoxCompatibilityPrompted) return;
  showBetterXDialog({
    title: '检测到 Firefox',
    bodyHtml: `
        <p>请问你在使用 BetterX 时，能否正常进入 X？</p>
        <p>目前已知部分 Firefox 用户会一直卡在<strong>只显示 X 图标</strong>的启动页面，常见于广告过滤、媒体下载等多个 X 脚本同时运行的环境。</p>
        <p>如果遇到异常，请点击 <strong>有异常</strong>，BetterX 会开启<strong>“设置 → 其他功能 → 兼容 Firefox”</strong>。该模式会停用页面网络 Hook；部分视频 / GIF 下载、年龄限制视频和接口关注关系识别可能降级，其他主体功能不受影响。</p>
      `,
    primaryText: '有异常',
    secondaryText: '目前正常',
    onPrimary: () => {
      setFirefoxCompatibilityChoice(true);
      showToast('已开启 Firefox 兼容模式');
    },
    onSecondary: () => {
      setFirefoxCompatibilityChoice(false);
      installNetworkHookTimer();
      showToast('已使用 Firefox 完整功能模式');
    },
  });
}
function switchFirefoxCompatibilityFromMenu(enabled) {
  if (!IS_FIREFOX) return;
  writeFirefoxCompatibilityMode(enabled ? 'compat' : 'normal');
  const reload = () => {
    try { location.reload(); } catch (err) { console.error('[BetterX] reload failed:', err); }
  };
  if (!state.settingsLoaded) { reload(); return; }
  state.settings.firefoxCompatibility = !!enabled;
  state.settings.firefoxCompatibilityPrompted = true;
  queueSettingsPersist(['firefoxCompatibility', 'firefoxCompatibilityPrompted']);
  Promise.resolve(state.dbWriteQueue).then(reload).catch(reload);
}
function buildFirefoxCompatibilityDiagnostic() {
  const diagnostic = {
    generatedAt: new Date().toISOString(),
    scriptVersion: (typeof GM_info !== 'undefined' && GM_info.script && GM_info.script.version) || '4.1.0',
    userscriptManager: USERSCRIPT_MANAGER || 'unknown',
    userAgent: navigator.userAgent || '',
    page: `${location.origin || ''}${location.pathname || ''}`,
    readyState: document.readyState || '',
    visibilityState: document.visibilityState || '',
    firefoxCompatibilityMode,
    settingsLoaded: !!state.settingsLoaded,
    settingsCompatibilityEnabled: !!state.settings.firefoxCompatibility,
    postsInMemory: state.posts.length,
    mediaRegistrySize: mediaRegistry.size,
    cardRegistrySize: cardRegistry.size,
    followedHandlesSize: followedHandles.size,
    networkHookInstallCounts: { ...networkHookInstallCounts },
    networkHarvestQueueSize: networkHarvestQueue.length,
    networkHarvestQueuedChars,
    networkHarvestDroppedJobs,
    networkHookStatus: { fetch: 'not-inspected', xhrOpen: 'not-inspected', xhrSend: 'not-inspected' },
  };
  if (firefoxCompatibilityMode === 'normal') {
    try {
      const pageWin = getPageWindow();
      diagnostic.networkHookStatus.fetch = !!(pageWin.fetch && pageWin.fetch.__xvHooked);
      const proto = pageWin.XMLHttpRequest && pageWin.XMLHttpRequest.prototype;
      diagnostic.networkHookStatus.xhrOpen = !!(proto && proto.open && proto.open.__xvHooked);
      diagnostic.networkHookStatus.xhrSend = !!(proto && proto.send && proto.send.__xvHooked);
    } catch (error) {
      diagnostic.networkHookStatus.error = String((error && error.message) || error || 'unknown');
    }
  }
  return diagnostic;
}
function downloadFirefoxCompatibilityDiagnostic() {
  const diagnostic = buildFirefoxCompatibilityDiagnostic();
  const json = JSON.stringify(diagnostic, null, 2);
  console.info('[BetterX] Firefox compatibility diagnostic:', diagnostic);
  if (!document.body) {
    uiAlert('页面尚未就绪，诊断信息已输出到控制台。');
    return;
  }
  download(`betterx-firefox-diagnostic-${new Date().toISOString().replace(/[:.]/g, '-')}.json`, json);
  if (state.rootEl) showToast('已导出 Firefox 兼容诊断');
}
function toggleAppBadgeFromMenu() {
  const hidden = !state.settings.hideAppBadge;
  setSettingsPartial({ hideAppBadge: hidden });
  if (state.rootEl) {
    showToast(hidden
      ? (isMobileBadgeViewport() ? '点击屏幕右侧小蓝条可显示徽标' : '已隐藏应用徽标 · Alt+X 可打开面板')
      : '已显示应用徽标');
  }
}
function registerMenuCommands() {
  if (typeof GM_registerMenuCommand !== 'function') return;
  try {
    GM_registerMenuCommand(uiText('BetterX：显示 / 隐藏应用徽标'), toggleAppBadgeFromMenu);
    if (IS_FIREFOX) {
      GM_registerMenuCommand(uiText('BetterX：强制开启 Firefox 兼容模式并刷新'), () => {
        switchFirefoxCompatibilityFromMenu(true);
      });
      GM_registerMenuCommand(uiText('BetterX：恢复 Firefox 完整模式并刷新'), () => {
        switchFirefoxCompatibilityFromMenu(false);
      });
      GM_registerMenuCommand(uiText('BetterX：导出 Firefox 兼容诊断'), downloadFirefoxCompatibilityDiagnostic);
    }
  } catch (err) {
    console.error('[BetterX] register menu commands failed:', err);
  }
}
const AD_LABELS = ['广告', '推广', 'Ad', 'Promoted', 'Publicidad', 'Anúncio', '広告', '광고'];
const STANDALONE_AD_SELECTOR = '[data-testid="whoToFollowSspAd"], [data-testid$="SspAd"]';
const PREMIUM_UPSELL_SELECTOR = 'aside[role="complementary"][aria-label], a[href*="/i/premium_sign_up"]';
const PREMIUM_UPSELL_LABELS = new Set([ '订阅 Premium', '訂閱 Premium', 'Subscribe to Premium', 'プレミアムにサブスクライブ', 'Premium 구독하기', ]); const PREMIUM_UPSELL_ACTION_LABELS = new Set([ '订阅', '訂閱', 'Subscribe', 'サブスクライブ', '구독하기', ]); const NFL_SCORES_SELECTOR = '[data-testid="nfl_scores_sidebar"]';
function isAdArticle(article) {
  if (!article || !article.querySelector) return false;
  const cell = article.closest('[data-testid="cellInnerDiv"]') || article;
  if (cell.querySelector && cell.querySelector('[data-testid$="impression-pixel"]')) return true;
  const nodes = article.querySelectorAll('span, div[dir="ltr"]');
  for (const el of nodes) {
    if (el.closest && el.closest('[data-testid="tweetText"]')) continue;
    const t = (el.textContent || '').trim();
    if (t && t.length <= 12 && AD_LABELS.includes(t)) return true;
  }
  return false;
}
function hideAdElement(article) {
  const cell = article.closest('[data-testid="cellInnerDiv"]') || article;
  if (cell && cell.classList) cell.classList.add('BetterX-ad-hidden');
  else if (cell) cell.style.display = 'none';
}
function hideStandaloneAdElement(element) {
  if (!element) return;
  const container = element.matches && element.matches(STANDALONE_AD_SELECTOR)
    ? element
    : (element.closest ? element.closest(STANDALONE_AD_SELECTOR) : null);
  if (!container) return;
  if (container.classList) container.classList.add('BetterX-ad-hidden');
  else if (container.style) container.style.display = 'none';
}
function hidePremiumUpsellElement(element) {
  if (!element || !element.closest) return;
  const aside = element.matches && element.matches('aside[role="complementary"]')
    ? element
    : element.closest('aside[role="complementary"]');
  if (aside) {
    const label = (aside.getAttribute('aria-label') || '').trim();
    const hasPremiumSignupLink = !!aside.querySelector('a[href*="/i/premium_sign_up"]');
    if (!hasPremiumSignupLink && !PREMIUM_UPSELL_LABELS.has(label)) return;
    const wrapper = aside.parentElement && aside.parentElement.children.length === 1
      ? aside.parentElement
      : aside;
    wrapper.classList.add('BetterX-ad-hidden');
    return;
  }
  const signupLink = element.matches && element.matches('a[href*="/i/premium_sign_up"]')
    ? element
    : element.closest('a[href*="/i/premium_sign_up"]');
  const actionLabel = (signupLink && (signupLink.innerText || signupLink.textContent) || '').trim();
  if (!signupLink || !PREMIUM_UPSELL_ACTION_LABELS.has(actionLabel)) return;
  let wrapper = signupLink;
  for (let depth = 0; depth < 3; depth++) {
    const parent = wrapper.parentElement;
    if (!parent || parent.children.length !== 1
        || parent.matches('body, main, header, nav, [role="navigation"]')) break;
    wrapper = parent;
  }
  wrapper.classList.add('BetterX-ad-hidden');
}
function sweepStandaloneAds(root) {
  if (!state.settings.hideAds) return;
  const scope = root && root.querySelectorAll ? root : document;
  if (scope.matches && scope.matches(STANDALONE_AD_SELECTOR)) hideStandaloneAdElement(scope);
  if (scope.closest) hideStandaloneAdElement(scope.closest(STANDALONE_AD_SELECTOR));
  scope.querySelectorAll(STANDALONE_AD_SELECTOR).forEach(hideStandaloneAdElement);
  if (scope.matches && scope.matches(PREMIUM_UPSELL_SELECTOR)) hidePremiumUpsellElement(scope);
  if (scope.closest) hidePremiumUpsellElement(scope.closest(PREMIUM_UPSELL_SELECTOR));
  scope.querySelectorAll(PREMIUM_UPSELL_SELECTOR).forEach(hidePremiumUpsellElement);
}
function sweepAds(root) {
  if (!state.settings.hideAds) return;
  getArticlesFromScope(root).forEach((a) => {
    if (isAdArticle(a)) hideAdElement(a);
  });
  sweepStandaloneAds(root);
}
function unhideAds() {
  document.querySelectorAll('.BetterX-ad-hidden').forEach((el) => el.classList.remove('BetterX-ad-hidden'));
}
function applyAdHiding() {
  if (state.settings.hideAds) sweepAds();
  else unhideAds();
}
function getNflEntryContainer(element) {
  if (!element) return null;
  const marker = element.matches && element.matches(NFL_SCORES_SELECTOR)
    ? element
    : (element.closest ? element.closest(NFL_SCORES_SELECTOR) : null);
  if (!marker) return null;
  const container = marker.parentElement;
  return container && !container.matches('body, main, [data-testid="sidebarColumn"]')
    ? container
    : marker;
}
function hideNflEntryElement(element) {
  const container = getNflEntryContainer(element);
  if (container && container.classList) container.classList.add('BetterX-nfl-hidden');
}
function sweepNflEntries(root = document) {
  if (!state.settings.hideNfl) return;
  const scope = root && root.querySelectorAll ? root : document;
  if (scope.matches && scope.matches(NFL_SCORES_SELECTOR)) hideNflEntryElement(scope);
  if (scope.closest) hideNflEntryElement(scope.closest(NFL_SCORES_SELECTOR));
  scope.querySelectorAll(NFL_SCORES_SELECTOR).forEach(hideNflEntryElement);
}
function unhideNflEntries() {
  document.querySelectorAll('.BetterX-nfl-hidden')
    .forEach((element) => element.classList.remove('BetterX-nfl-hidden'));
}
function applyNflHiding() {
  if (state.settings.hideNfl) sweepNflEntries();
  else unhideNflEntries();
}
const LAYOUT_EXCLUDED_PATHS = ['/messages', '/settings'];
const LAYOUT_NAV_LABELS = new Set([ '书签', '書籤', 'Bookmarks', 'ブックマーク', '북마크', '工作机会', '工作機會', 'Careers', '求人', '채용 정보', '创作者工作室', '創作者工作室', 'Creator Studio', 'クリエイタースタジオ', '크리에이터 스튜디오', '社区', '社群', 'Communities', 'コミュニティ', '커뮤니티', '商业', '商業', 'Business', 'ビジネス', '비즈니스', 'Premium', 'プレミアム', '认证组织', '認證組織', 'Verified Orgs', '認証済み組織', '인증된 조직', '营利', '營利', 'Monetization', '収益化', '수익 창출', '广告', '廣告', 'Ads', '広告', '광고', ]); const LAYOUT_SUBSCRIBE_LABELS = new Set([ '订阅 Premium', '訂閱 Premium', 'Subscribe to Premium', 'プレミアムにサブスクライブ', 'Premium 구독하기', ]); const LAYOUT_FOOTER_LABELS = new Set(['页脚', '頁尾', 'Footer', 'フッター', '바닥글']); const LAYOUT_SHOW_MORE_LABELS = new Set(['显示更多', '顯示更多', 'Show more', 'さらに表示', '더 보기']); const LAYOUT_STRUCTURE_SELECTOR = 'main, header[role="banner"], [data-testid="primaryColumn"]'; const LAYOUT_STRUCTURE_CLASSES = [ 'BetterX-layout-primary', 'BetterX-layout-row', 'BetterX-layout-main', 'BetterX-layout-shell', 'BetterX-layout-left-width-target', ]; const LAYOUT_DOM_CLASSES = [ 'BetterX-layout-clean-hidden', 'BetterX-layout-showmore-hidden', ...LAYOUT_STRUCTURE_CLASSES, ];
function layoutEnhancementsActive() {
  return !!state.settings.layoutEnabled
    && !LAYOUT_EXCLUDED_PATHS.some((path) => location.pathname.startsWith(path));
}
function ensureLayoutStyle() {
  let style = state.layoutStyleEl;
  if (!style || !style.isConnected) {
    style = document.getElementById('BetterX-layout-style') || document.createElement('style');
    style.id = 'BetterX-layout-style';
    if (!style.isConnected) (document.head || document.documentElement).appendChild(style);
    state.layoutStyleEl = style;
  }
  return style;
}
function clearLayoutClasses(classes) {
  const selector = classes.map((className) => `.${className}`).join(', ');
  document.querySelectorAll(selector).forEach((el) => el.classList.remove(...classes));
}
function clearLayoutDomClasses() { clearLayoutClasses(LAYOUT_DOM_CLASSES); }
function clearLayoutStructureClasses() { clearLayoutClasses(LAYOUT_STRUCTURE_CLASSES); }
function getLayoutElements() {
  const primaryCandidates = [...document.querySelectorAll('main [data-testid="primaryColumn"]')];
  const primary = primaryCandidates.find((el) => {
    const rect = el.getBoundingClientRect();
    const css = getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && css.display !== 'none' && css.visibility !== 'hidden';
  }) || primaryCandidates[0] || null;
  const main = primary ? primary.closest('main') : [...document.querySelectorAll('main[role="main"]')].find((el) => {
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && getComputedStyle(el).display !== 'none';
  }) || null;
  const row = primary ? primary.parentElement : null;
  const leftWidthTarget = document.querySelector('header[role="banner"] > div > div')
    || document.querySelector('header[role="banner"] > div:first-child');
  return { primary, main, row, leftWidthTarget };
}
function updateDetectedLayoutWidthInputs() {
  if (state.settings.layoutAutoWidth === false) return;
  if (state.timelineWidthEl && document.activeElement !== state.timelineWidthEl && state.detectedTimelineWidth) {
    state.timelineWidthEl.value = String(state.detectedTimelineWidth);
  }
  if (state.leftbarWidthEl && document.activeElement !== state.leftbarWidthEl && state.detectedLeftbarWidth) {
    state.leftbarWidthEl.value = String(state.detectedLeftbarWidth);
  }
}
function detectNativeLayoutWidths(elements) {
  const { primary, leftWidthTarget } = elements;
  if (primary && !primary.classList.contains('BetterX-layout-primary')) {
    const width = Math.round(primary.getBoundingClientRect().width);
    if (width >= 300 && width <= 3000) state.detectedTimelineWidth = width;
  }
  if (leftWidthTarget && !leftWidthTarget.classList.contains('BetterX-layout-left-width-target')) {
    const width = Math.round(leftWidthTarget.getBoundingClientRect().width);
    if (width >= 120 && width <= 600) state.detectedLeftbarWidth = width;
  }
  updateDetectedLayoutWidthInputs();
}
function bindLayoutStructureClasses(elements, needsStructure, expandCenter, manualWidth) {
  clearLayoutStructureClasses();
  if (!needsStructure) return;
  const { primary, main, row, leftWidthTarget } = elements;
  if (primary) primary.classList.add('BetterX-layout-primary');
  if (row) row.classList.add('BetterX-layout-row');
  if (main) main.classList.add('BetterX-layout-main');
  if (manualWidth && leftWidthTarget) leftWidthTarget.classList.add('BetterX-layout-left-width-target');
  if (expandCenter && main) {
    let ancestor = row ? row.parentElement : main.parentElement;
    while (ancestor && ancestor !== document.body) {
      if (ancestor !== main) ancestor.classList.add('BetterX-layout-shell');
      if (ancestor.id === 'react-root') break;
      ancestor = ancestor.parentElement;
    }
  }
}
function buildLayoutCss(options) {
  const {
    autoWidth, timelineWidth, leftbarWidth, effectiveLeftbarWidth,
    hideLeftbar, hideSidebar, expandCenter,
  } = options;
  const rules = [
    '.BetterX-layout-clean-hidden, .BetterX-layout-showmore-hidden { display: none !important; }',
  ];
  if (hideLeftbar) rules.push('header[role="banner"] { display: none !important; }');
  if (hideSidebar) rules.push('[data-testid="sidebarColumn"] { display: none !important; }');
  if (!autoWidth && !hideLeftbar) {
    rules.push(`
        header[role="banner"] {
          box-sizing: border-box !important;
          width: ${leftbarWidth}px !important;
          min-width: ${leftbarWidth}px !important;
          max-width: ${leftbarWidth}px !important;
          flex: 0 0 ${leftbarWidth}px !important;
        }
        header[role="banner"] > div,
        header[role="banner"] > div > div,
        .BetterX-layout-left-width-target {
          box-sizing: border-box !important;
          width: ${leftbarWidth}px !important;
          min-width: 0 !important;
          max-width: ${leftbarWidth}px !important;
        }
      `);
    if (leftbarWidth <= 120) {
      rules.push(`
          /* 窄左栏进入仅图标模式，避免 X 的文字标签撑回原宽度。 */
          header[role="banner"] nav[role="navigation"] a[role="link"] div[dir="ltr"],
          header[role="banner"] nav[role="navigation"] [data-testid="AppTabBar_More_Menu"] div[dir="ltr"],
          header[role="banner"] [data-testid="SideNav_AccountSwitcher_Button"] div[dir="ltr"],
          header[role="banner"] [data-testid="SideNav_NewTweet_Button"] span {
            display: none !important;
          }
          header[role="banner"] nav[role="navigation"] a[role="link"],
          header[role="banner"] nav[role="navigation"] [data-testid="AppTabBar_More_Menu"],
          header[role="banner"] [data-testid="SideNav_AccountSwitcher_Button"],
          header[role="banner"] [data-testid="SideNav_NewTweet_Button"] {
            box-sizing: border-box !important;
            max-width: ${Math.max(44, leftbarWidth)}px !important;
          }
        `);
    }
  }
  if (expandCenter) {
    rules.push(`
        .BetterX-layout-shell {
          width: 100% !important; max-width: none !important; min-width: 0 !important;
          margin-inline: 0 !important;
        }
        .BetterX-layout-main {
          width: 100% !important; max-width: none !important; min-width: 0 !important;
          flex: 1 1 0% !important; margin-inline: auto !important;
        }
        .BetterX-layout-row {
          width: 100% !important; max-width: none !important; min-width: 0 !important;
          margin-inline: auto !important;
        }
        .BetterX-layout-primary {
          width: auto !important; max-width: none !important; min-width: 0 !important;
          flex: 1 1 0% !important; margin-inline: 0 !important;
        }
        .BetterX-layout-primary > div,
        .BetterX-layout-primary > div > div,
        .BetterX-layout-primary .r-1ye8kvj,
        .BetterX-layout-primary [data-testid="cellInnerDiv"],
        .BetterX-layout-primary [data-testid="cellInnerDiv"] > div,
        .BetterX-layout-primary [data-testid="cellInnerDiv"] article,
        .BetterX-layout-primary [data-testid="cellInnerDiv"] article > div {
          box-sizing: border-box !important;
          width: 100% !important; max-width: none !important; min-width: 0 !important;
          margin-inline: 0 !important;
        }
      `);
    if (hideSidebar && !hideLeftbar) {
      rules.push(`
          /* 右栏消失后让“左栏 + 主列”从视口左边开始，避免外层居中布局留下大块空白。 */
          .BetterX-layout-shell {
            justify-content: flex-start !important;
            align-items: flex-start !important;
          }
          header[role="banner"] {
            box-sizing: border-box !important;
            width: ${effectiveLeftbarWidth}px !important;
            min-width: ${effectiveLeftbarWidth}px !important;
            max-width: ${effectiveLeftbarWidth}px !important;
            flex: 0 0 ${effectiveLeftbarWidth}px !important;
          }
        `);
    }
  } else if (!autoWidth) {
    rules.push(`
        .BetterX-layout-main { max-width: none !important; min-width: 0 !important; flex: 1 1 auto !important; }
        .BetterX-layout-row { width: max-content !important; max-width: none !important; margin-inline: auto !important; }
        .BetterX-layout-primary {
          width: ${timelineWidth}px !important; max-width: none !important;
          flex: 0 0 ${timelineWidth}px !important; margin-inline: auto !important;
        }
        .BetterX-layout-left-width-target { width: ${leftbarWidth}px !important; }
      `);
  }
  if (state.settings.layoutHideMessageGrok !== false) {
    rules.push(`
        [data-testid="chat-drawer-root"], [data-testid="GrokDrawer"] {
          opacity: 0 !important; pointer-events: none !important;
          transform: translate(200px, 200px) !important;
        }
      `);
  }
  return rules.join('\n');
}
function getLayoutScopeElements(root, selector) {
  const scope = root && root.querySelectorAll ? root : document;
  const elements = new Set(scope.querySelectorAll(selector));
  if (scope.matches && scope.matches(selector)) elements.add(scope);
  const ancestor = scope.closest && scope.closest(selector);
  if (ancestor) elements.add(ancestor);
  return elements;
}
function layoutRootAffectsStructure(root) {
  return !!(root && ((root.matches && root.matches(LAYOUT_STRUCTURE_SELECTOR))
    || (root.querySelector && root.querySelector(LAYOUT_STRUCTURE_SELECTOR))));
}
function applyLayoutDomCleanup(root = document) {
  getLayoutScopeElements(root, '.BetterX-layout-clean-hidden, .BetterX-layout-showmore-hidden')
    .forEach((el) => el.classList.remove('BetterX-layout-clean-hidden', 'BetterX-layout-showmore-hidden'));
  if (state.settings.layoutCleanNavigation !== false) {
    getLayoutScopeElements(root, 'nav[role="navigation"] div[dir="ltr"]').forEach((item) => {
      const label = (item.textContent || '').trim();
      if (!LAYOUT_NAV_LABELS.has(label)) return;
      const target = item.closest('a, div[role="link"]');
      if (target) target.classList.add('BetterX-layout-clean-hidden');
    });
    getLayoutScopeElements(root, '[data-testid="super-upsell-UpsellCardRenderProperties"]')
      .forEach((el) => el.classList.add('BetterX-layout-clean-hidden'));
    getLayoutScopeElements(root, '[aria-label]').forEach((element) => {
      const label = (element.getAttribute('aria-label') || '').trim();
      if (LAYOUT_SUBSCRIBE_LABELS.has(label)
          || (element.matches('nav[role="navigation"]') && LAYOUT_FOOTER_LABELS.has(label))) {
        element.classList.add('BetterX-layout-clean-hidden');
      }
    });
  }
  if (state.settings.layoutHideShowMore && !state.settings.autoExpandPostText) {
    getLayoutScopeElements(root, 'article a[role="link"]').forEach((link) => {
      if (LAYOUT_SHOW_MORE_LABELS.has((link.textContent || '').trim())) link.classList.add('BetterX-layout-showmore-hidden');
    });
  }
}
function applyLayoutEnhancements() {
  if (!document.documentElement) return;
  const style = ensureLayoutStyle();
  if (!layoutEnhancementsActive()) {
    style.textContent = '';
    clearLayoutDomClasses();
    return;
  }
  const autoWidth = state.settings.layoutAutoWidth !== false;
  const timelineWidth = clampInt(state.settings.timelineWidth, 100, 3000, DEFAULT_SETTINGS.timelineWidth);
  const leftbarWidth = clampInt(state.settings.leftbarWidth, 50, 500, DEFAULT_SETTINGS.leftbarWidth);
  const fillCenter = !!state.settings.layoutFillCenter;
  const hideLeftbar = fillCenter || !!state.settings.layoutHideLeftbar;
  const hideSidebar = fillCenter || !!state.settings.layoutHideSidebar;
  const expandCenter = hideLeftbar || hideSidebar;
  const needsStructure = expandCenter || !autoWidth;
  let elements = getLayoutElements();
  if (autoWidth && !needsStructure && elements.primary && elements.primary.classList.contains('BetterX-layout-primary')) {
    style.textContent = '';
    clearLayoutStructureClasses();
    elements = getLayoutElements();
  }
  if (autoWidth) detectNativeLayoutWidths(elements);
  const effectiveLeftbarWidth = autoWidth
    ? clampInt(state.detectedLeftbarWidth, 120, 600, leftbarWidth)
    : leftbarWidth;
  bindLayoutStructureClasses(elements, needsStructure, expandCenter, !autoWidth);
  const css = buildLayoutCss({
    autoWidth, timelineWidth, leftbarWidth, effectiveLeftbarWidth,
    hideLeftbar, hideSidebar, expandCenter,
  });
  if (style.textContent !== css) style.textContent = css;
  applyLayoutDomCleanup();
}
const ADULT_SPAM_STRONG_TERMS = [ '抽插', '淫叫', '母狗', '肉便器', '母猪', '反差婊', '小穴', '穴穴', '性奴', '蜜穴', '爆菊', '性交', '爆操', '福利姬', '里番', '裸照', '裸体', '阴茎', '做愛','嫩穴', '做爱', '自慰', '精液', '打飞机', '果照', '约炮', '裸聊','美鲍', '援交', '包夜', '成人视频', '成人影片', '黄片', '黄网', '色情网站', '看片网站', 'porn', 'nudes', 'onlyfans leak','网黄', 'sex video', 'sex videos', 'wataa', 'Wataa', '私处', '尤物', '人妻', '口交', '内射', '阴道', '淫趴', '屁眼', '迷奸', '小烧货', '骚货', 'sao货', '破处', '陪睡', '后入', '肛交', '催情','约啪','跳蛋','Chudai','chudai', '露B','潮喷','龟头','射精','肉棒','鸡巴','被操','榨精','撸管','深喉', '足交','乳交','烧姬','淫窝','车震', '约p','阴唇','秒射','飞机杯','屁穴','性爱','鸡鸡','磨豆腐','双头龙','没她骚','爱几把', ]; const ADULT_SPAM_WEAK_TERMS = [ 'ts', 'TS', 'ntr', 'NTR', '91', '69', '3p', '4i', 'p眼', 'G点', '皮炎', '子宫', '手冲', '外围', '无套', '全套服务', '发情', '性欲', '晨勃', '糖心', '麻豆', '50度灰', '字母圈', '戴套', '偷拍', '艹', '幹', '同城可约', '附近可约', '私密视频', '大尺度视频', '成人直播', '上门约', '约爱', '福不黑', '我的福', '顶不住', '瓜', '线下', '同城', '妈妈', '儿子', '一夜', '进入身', 'sao', '全国牵', 't.cn', '👆', '👉', '联系', '主页', '快手', '抖音', '免费', '我好看', '寻', ]; const ADULT_SPAM_SENSITIVE_TERMS = [ '一发入魂', '调教', '高潮', '翘臀', '奶子', '反差', '巨乳', '嫩妹', '尿尿', '痴女', '黑丝', '白丝', '玉足', '喷了', '涩涩', '私房', '纯欲', '蜜桃臀', '可瑟瑟', '固炮', '炮友', '找主人', '大一学生', '白虎', '烧鸡', '好色', '色色', '熟女', '少妇', '嫩模', '学生妹', '商k', '白给', '处男', '野战', '射出来','魅魔','性瘾','打桩','喷出来','射出来','戴套','福照','无码','蛋蛋', '有码','情趣','丝袜','刺激','娇喘','罩杯','早泄','失禁','毛毛','绝顶', '肉欲','黑森林','制服','赤裸','粉嫩','水多','喷水','呻吟','吸吮','成人', ]; const ADULT_SPAM_BOT_BAIT_TERMS = [ '陪我聊聊天', '有没有单男', '有没有单女', '我是真人', '互关', '互粉', '互fo', '体制内老师', '体制内护士', '体制内医生', '在线等哥哥', '在线等弟弟', ]; const ADULT_SPAM_SUGGESTIVE_TERMS = [ '福利视频', '萝莉资源', '少女资源', '嫩模资源', '看片入口', '成人视频资源', '可瑟瑟', '推特第一骚', ]; const ADULT_SPAM_MARKETING_TERMS = [ '免费领取', '点击领取', '立即加入', '频道入口', '群组入口', '资源合集', '试看', '解锁', '置顶获取', '主页获取', '进群', '电报群', ]; const ADULT_SPAM_CONTACT_TERMS = [ '私信', '私聊', '联系我', '加我', '主页', '简介', '置顶', 'telegram', 'whatsapp', '电报', '飞机群', 'tg群', '订阅' ]; const ADULT_SPAM_CONTEXT_EXEMPTIONS = [ '黄推机器人', '举报黄推', '屏蔽黄推', '黄推太多', '垃圾黄推', '清理黄推', '色情诈骗', '反诈', '曝光骗子', ]; const ADULT_SPAM_NAME_RE = /(?:福利姬|约炮|裸聊|看片|成人视频|黄网|反差婊|巨乳|痴女|(?:^|[^a-z0-9])(?:porn|nudes|onlyfans|sex(?:y|cam)?|xxx)(?![a-z0-9]))/i; const ADULT_SPAM_EXACT_AMBIGUOUS_RE = /^(?:骚|逼|肏|doi|spa|全套|处女|chu男|cchu男|c男)$/i; const ADULT_SPAM_AMBIGUOUS_RES = [ /(?<!离)骚(?!操作|扰|包|话|客|气)/, /(?<!牛|装|傻|苦|逗|懵|被)逼(?!迫|真|近|问|债|婚|供|退)/, /处女(?!作|航|座|秀)/, ]; const ADULT_SPAM_BOT_HANDLE_RES = [ /^[a-z]{4,10}\d{5,12}$/i, /^[a-z]+_[a-z]+\d{4,}$/i, /^[A-Z][a-z]+[A-Z][a-z]+\d{2,}$/, /^(?=[a-z]*[bcdfghjklmnpqrstvwxyz]{4})[a-z]+\d+$/i, ]; const ADULT_SPAM_TEMPLATE_RES = [ /快领我回家|扣1白给|推特第一骚|我约过她|姐姐在等你|视频要吗|满足我|可瑟瑟/, /懂[得的].{0,3}(?:来|私|入|dd|联系|撩|进|加)/i, /(?:找|来|想要).{0,5}(?:哥哥|主人).{0,5}(?:调教|私聊|联系|带走)/, /(?:在线等|蹲一个|急需一位).{0,6}(?:哥哥|弟弟|单男|主人)/, /(?:主页|简介).{0,5}(?:打飞|打飞机|打✈️?|有资源|有福利|可约)|(?:打飞|打飞机|打✈️?).{0,5}(?:主页|简介)/, /(?:刷了半天|就她|点开|快看).{0,5}(?:主页|简介)/, /(?:👉|⬆|↑|✈️?).{0,4}@[a-z0-9_]+|@[a-z0-9_]+.{0,4}(?:👉|⬆|↑|✈️?)/i, /(?:包夜|上门|外围|服务|按摩).{0,5}(?:全套|spa)|(?:全套|spa).{0,5}(?:包夜|上门|外围|服务)/i, /(?:酒店|约|想|一起).{0,5}doi|doi.{0,5}(?:酒店|约|一起)/i, /(?:c\s*\/?\s*chu男|chu男|c男)/i, ]; const ADULT_SPAM_COMBO_RES = [ /(?:同城|附近).{0,5}(?:可约|约炮|上门)/, /(?:私信|私聊|联系|加我).{0,8}(?:约炮|裸聊|看片|黄网|成人视频)/, /(?:约炮|裸聊|看片|黄网|成人视频).{0,8}(?:私信|私聊|联系|加我|主页|电报)/, /(?:萝莉|少女|嫩模|空姐|学生妹|少妇).{0,6}(?:资源|上门|可约|视频|福利)/, /(?:免费|最新|海量).{0,6}(?:成人视频|黄片|色情视频|看片资源)/, /(?:成人视频|黄片|色情视频).{0,5}(?:资源|入口|合集|频道|群)/, ]; const ADULT_SPAM_REPOST_CONTEXT_RE = /(?:已转帖|已轉帖|转帖|轉帖|转发|轉發|reposted|retweeted|リポスト|재게시|리트윗)/i;
function normalizeAdultSpamText(value) {
  let text = String(value || '').slice(0, 5000);
  try { text = text.normalize('NFKC'); } catch (err) {}
  return text.toLowerCase()
    .replace(/[\u200b-\u200f\u202a-\u202e\u2060\ufeff\ufe0e\ufe0f]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}
function compactAdultSpamText(value) {
  return normalizeAdultSpamText(value).replace(/[\s\p{P}\p{S}_]+/gu, '');
}
function compileAdultSpamTerms(terms, allowObfuscation = true) {
  const compiled = new Map();
  for (const raw of terms) {
    const normalized = normalizeAdultSpamText(raw);
    if (!normalized) continue;
    const compact = compactAdultSpamText(normalized);
    const key = compact || normalized;
    let patternSource = '';
    if (/^[\x00-\x7F]+$/.test(normalized) && /[a-z0-9]/.test(normalized)) {
      const escape = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      let literal = escape(normalized);
      if (allowObfuscation && compact.length >= 4 && /^[a-z0-9 ]+$/.test(normalized) && /[a-z]/.test(normalized)) {
        literal = normalized.split(' ').map((word) => [...word].map(escape).join('[\\p{P}\\p{S}_]*'))
          .join('[\\s\\p{P}\\p{S}_]*');
      }
      patternSource = `(?:^|[^a-z0-9_])${literal}(?![a-z0-9_])`;
    }
    const variantKey = patternSource || compact || normalized;
    if (!compiled.has(key)) compiled.set(key, new Map());
    const variants = compiled.get(key);
    if (!variants.has(variantKey)) variants.set(variantKey, {
      normalized, compact, pattern: patternSource ? new RegExp(patternSource, 'u') : null,
    });
  }
  return [...compiled].map(([key, variants]) => ({ key, variants: [...variants.values()] }));
}
const ADULT_SPAM_WEAK_KEYS = new Set(ADULT_SPAM_WEAK_TERMS.map((term) => compactAdultSpamText(term) || normalizeAdultSpamText(term)));
const withoutWeakTerms = (terms) => terms.filter((term) => !ADULT_SPAM_WEAK_KEYS.has(compactAdultSpamText(term)));
const COMPILED_ADULT_SPAM_TERMS = (() => {
  const groups = {
    strong: compileAdultSpamTerms(withoutWeakTerms(ADULT_SPAM_STRONG_TERMS)),
    sensitive: compileAdultSpamTerms(withoutWeakTerms(ADULT_SPAM_SENSITIVE_TERMS)),
    botBait: compileAdultSpamTerms(ADULT_SPAM_BOT_BAIT_TERMS),
    suggestive: compileAdultSpamTerms(ADULT_SPAM_SUGGESTIVE_TERMS),
    marketing: compileAdultSpamTerms(ADULT_SPAM_MARKETING_TERMS),
    contact: compileAdultSpamTerms(ADULT_SPAM_CONTACT_TERMS),
    exemptions: compileAdultSpamTerms(ADULT_SPAM_CONTEXT_EXEMPTIONS),
    weak: compileAdultSpamTerms(ADULT_SPAM_WEAK_TERMS, false),
  };
  const claimed = new Map();
  const variantKey = (variant) => variant.pattern?.source || variant.compact || variant.normalized;
  for (const group of ['strong', 'suggestive', 'sensitive', 'botBait', 'marketing', 'contact', 'weak']) {
    groups[group] = groups[group].filter((term) => {
      const existing = claimed.get(term.key);
      if (existing) {
        const variants = new Set(existing.variants.map(variantKey));
        for (const variant of term.variants) {
          if (!variants.has(variantKey(variant))) {
            existing.variants.push(variant);
            variants.add(variantKey(variant));
          }
        }
        return false;
      }
      claimed.set(term.key, term);
      return true;
    });
  }
  return groups;
})();
let compiledAdultSpamCustomRulesVersion = -1;
let compiledAdultSpamCustomRules = [];
function getCompiledAdultSpamCustomRules() {
  if (compiledAdultSpamCustomRulesVersion === adultSpamRulesVersion) {
    return compiledAdultSpamCustomRules;
  }
  compiledAdultSpamCustomRules = (state.settings.adultSpamKeywords || []).map((raw) => ({
    raw,
    normalized: normalizeAdultSpamText(raw),
    compact: compactAdultSpamText(raw),
  }));
  compiledAdultSpamCustomRulesVersion = adultSpamRulesVersion;
  return compiledAdultSpamCustomRules;
}
function countCompiledTerms(normalized, compact, terms) {
  let count = 0;
  for (const term of terms) {
    if (term.variants.some((variant) => variant.pattern
      ? variant.pattern.test(normalized)
      : variant.compact ? compact.includes(variant.compact) : normalized.includes(variant.normalized))) count++;
  }
  return count;
}
function getAdultSpamInput(article) {
  const author = extractAuthor(article);
  const fullText = (extractText(article) || '').trim();
  const text = fullText.slice(0, 2500);
  const socialContextEl = article.querySelector('[data-testid="socialContext"]');
  const repostContext = (socialContextEl?.innerText || '').trim().slice(0, 300);
  const isRepost = ADULT_SPAM_REPOST_CONTEXT_RE.test(repostContext);
  let reposterUsername = '';
  if (isRepost && socialContextEl) {
    const actorLinks = [socialContextEl.closest('a[href]'), ...socialContextEl.querySelectorAll('a[href]')].filter(Boolean);
    const actorLink = actorLinks.find((link) => {
      const href = link.getAttribute('href') || '';
      return /^\/[a-z0-9_]{1,15}(?:[/?#]|$)/i.test(href);
    });
    const actorMatch = (actorLink?.getAttribute('href') || '').match(/^\/([a-z0-9_]{1,15})(?:[/?#]|$)/i);
    const actorHandle = (actorMatch?.[1] || '').toLowerCase();
    if (actorHandle && !RESERVED_TOP_PATHS.has(actorHandle)) reposterUsername = actorHandle;
  }
  const rawUsername = String(author.username || '').replace(/^@/, '');
  const username = rawUsername.toLowerCase();
  const externalLinkCount = [...article.querySelectorAll('a[href]')].filter((link) => {
    const href = link.getAttribute('href') || '';
    if (!href || href.startsWith('/') || /^(?:https?:\/\/)?(?:www\.)?(?:x|twitter)\.com\//i.test(href)) return false;
    return /^(?:https?:\/\/|\/\/)/i.test(href);
  }).length;
  const mentionCount = (text.match(/@[a-z0-9_]{1,15}/gi) || []).length;
  const hasMedia = !!article.querySelector('video, [data-testid="tweetPhoto"], img[src*="pbs.twimg.com/media"]');
  const isFollowingTimeline = getCurrentSourceInfo().type === 'following';
  if (isFollowingTimeline) {
    if (isRepost && reposterUsername) rememberFollowingRelation(reposterUsername, true);
    else if (!isRepost && username) rememberFollowingRelation(username, true);
  }
  return {
    author, text, fullText, displayName: author.displayName || '', username, rawUsername,
    repostContext, isRepost, reposterUsername, externalLinkCount, mentionCount, hasMedia, isFollowingTimeline,
  };
}
function scoreAdultSpam(input) {
  const normalized = normalizeAdultSpamText(`${input.displayName}\n${input.repostContext || ''}\n${input.text}`);
  const compact = compactAdultSpamText(normalized);
  const usernameText = normalizeAdultSpamText(input.username);
  const customRulesEnabled = state.settings.adultSpamCustomRulesEnabled !== false;
  const whitelist = customRulesEnabled ? (state.settings.adultSpamWhitelist || []) : [];
  if (input.username && whitelist.includes(input.username)) {
    return { hidden: false, score: 0, reasons: ['账号白名单'] };
  }
  if (customRulesEnabled) {
    for (const customRule of getCompiledAdultSpamCustomRules()) {
      if ((customRule.normalized && normalized.includes(customRule.normalized))
        || (customRule.compact && compact.includes(customRule.compact))) {
        return { hidden: true, score: 99, reasons: [`自定义词：${customRule.raw}`] };
      }
    }
  }
  if (!state.settings.hideAdultSpam) return { hidden: false, score: 0, reasons: [] };
  const contentAuthorFollowed = !!(input.username && followedHandles.has(input.username));
  const reposterFollowed = !!(input.reposterUsername && followedHandles.has(input.reposterUsername));
  const originalPostInFollowingTimeline = input.isFollowingTimeline && !input.isRepost;
  const followedAccountRepost = input.isRepost
    && state.settings.adultSpamSkipFollowingReposts === true
    && (input.isFollowingTimeline || reposterFollowed);
  if (state.settings.adultSpamSkipFollowing !== false
    && (originalPostInFollowingTimeline || contentAuthorFollowed || followedAccountRepost)) {
    return {
      hidden: false,
      score: 0,
      reasons: [followedAccountRepost
        ? '已关注账号的转发内容'
        : (contentAuthorFollowed ? '正文原作者已关注' : '正在关注时间线的原创帖')],
    };
  }
  const reasons = [];
  let score = 0;
  const strongCount = countCompiledTerms(normalized, compact, COMPILED_ADULT_SPAM_TERMS.strong);
  const sensitiveCount = countCompiledTerms(normalized, compact, COMPILED_ADULT_SPAM_TERMS.sensitive);
  const botBaitCount = countCompiledTerms(normalized, compact, COMPILED_ADULT_SPAM_TERMS.botBait);
  const suggestiveCount = countCompiledTerms(normalized, compact, COMPILED_ADULT_SPAM_TERMS.suggestive);
  const marketingCount = countCompiledTerms(normalized, compact, COMPILED_ADULT_SPAM_TERMS.marketing);
  const contactCount = countCompiledTerms(normalized, compact, COMPILED_ADULT_SPAM_TERMS.contact);
  const weakCount = countCompiledTerms(normalized, compact, COMPILED_ADULT_SPAM_TERMS.weak);
  const comboCount = ADULT_SPAM_COMBO_RES.filter((re) => re.test(compact)).length;
  const templateCount = ADULT_SPAM_TEMPLATE_RES.filter((re) => re.test(normalized) || re.test(compact)).length;
  const exactAmbiguous = ADULT_SPAM_EXACT_AMBIGUOUS_RE.test(compactAdultSpamText(input.text));
  const ambiguousCount = ADULT_SPAM_AMBIGUOUS_RES.filter((re) => re.test(compact)).length;
  const riskyName = ADULT_SPAM_NAME_RE.test(input.displayName) || ADULT_SPAM_NAME_RE.test(usernameText);
  const syntheticHandle = ADULT_SPAM_BOT_HANDLE_RES.some((re) => re.test(input.rawUsername || input.username || ''));
  if (strongCount) { score += Math.min(14, strongCount * 10); reasons.push('强成人内容词'); }
  if (sensitiveCount) { score += Math.min(10, sensitiveCount * 4); reasons.push('敏感暗示词'); }
  if (botBaitCount) { score += Math.min(6, botBaitCount * 3); reasons.push('机器人诱导短句'); }
  if (suggestiveCount) { score += Math.min(6, suggestiveCount * 3); reasons.push('成人引流短语'); }
  if (comboCount) { score += Math.min(8, comboCount * 4); reasons.push('高风险组合话术'); }
  if (templateCount) { score += Math.min(10, templateCount * 8); reasons.push('黄推模板话术'); }
  if (exactAmbiguous) { score += 2; reasons.push('多义词（需语境）'); }
  if (ambiguousCount) { score += Math.min(6, ambiguousCount * 4); reasons.push('语境敏感词'); }
  if (weakCount) { score += Math.min(2, weakCount); reasons.push('多义词/引流辅助词'); }
  if (marketingCount) { score += Math.min(4, marketingCount * 2); reasons.push('营销引导'); }
  if (contactCount) { score += Math.min(4, contactCount * 2); reasons.push('站外联系引导'); }
  if (riskyName) {
    score += 3;
    reasons.push('账号名特征');
  }
  if (syntheticHandle) { score += 3; reasons.push('机器用户名结构'); }
  if (input.externalLinkCount > 0) { score += 2; reasons.push('外部链接'); }
  if ((input.mentionCount || 0) > 0 && (contactCount || templateCount)) {
    score += 3;
    reasons.push('@账号引流');
  }
  const riskEmojiCount = (normalized.match(/[✈️🔞💦🈲👅🍑👙🙇❣️❤️🍓🎀💋🥵]/gu) || []).length;
  if (riskEmojiCount >= 2 || normalized.includes('🔞')) { score += 3; reasons.push('高风险表情组合'); }
  const hasPromotionContext = contactCount || marketingCount || comboCount || templateCount;
  const hasAdultContext = strongCount > 0 || suggestiveCount > 0
    || ((sensitiveCount >= 2 || riskyName) && hasPromotionContext);
  if (input.hasMedia && hasAdultContext) { score += 2; reasons.push('敏感媒体组合'); }
  if (input.text && input.text.length <= 120 && hasAdultContext) score += 1;
  const exemptionCount = countCompiledTerms(normalized, compact, COMPILED_ADULT_SPAM_TERMS.exemptions);
  if (exemptionCount) { score = Math.max(0, score - 6); reasons.push('讨论/反诈语境降权'); }
  const threshold = state.settings.adultSpamLevel === 'balanced' ? 6 : 9;
  return { hidden: !!hasAdultContext && score >= threshold, score, reasons };
}
function captureAdultSpamScrollAnchors(articles = document.querySelectorAll('article')) {
  const viewportHeight = Math.max(1, window.innerHeight || document.documentElement.clientHeight || 1);
  const candidates = [...articles]
    .map((article) => {
      const rect = article.getBoundingClientRect();
      return {
        article,
        statusId: extractStatusIdFromUrl(getStatusLink(article)) || '',
        top: rect.top,
        bottom: rect.bottom,
        height: rect.height,
      };
    })
    .filter((item) => item.height > 0 && item.bottom > -viewportHeight && item.top < viewportHeight * 2)
    .sort((a, b) => {
      const score = (item) => item.bottom > 0 && item.top < viewportHeight
        ? Math.max(0, item.top)
        : viewportHeight + Math.min(Math.abs(item.top), Math.abs(item.bottom));
      return score(a) - score(b);
    });
  candidates.fallbackY = Math.max(0, window.scrollY || 0);
  return candidates;
}
function resolveAdultSpamScrollAnchor(candidate) {
  let article = candidate.article;
  if ((!article || !article.isConnected) && candidate.statusId) {
    article = [...document.querySelectorAll('article')].find((item) => (
      extractStatusIdFromUrl(getStatusLink(item)) === String(candidate.statusId)
    )) || null;
  }
  if (!article || !article.isConnected || article.classList.contains('BetterX-adult-spam-hidden')) return null;
  const rect = article.getBoundingClientRect();
  return rect.height > 0 ? { article, top: rect.top } : null;
}
function restoreAdultSpamScrollAnchor(candidates) {
  if (isPageScrollBusy()) return false;
  for (const candidate of candidates || []) {
    const current = resolveAdultSpamScrollAnchor(candidate);
    if (!current) continue;
    const delta = current.top - candidate.top;
    if (Math.abs(delta) > 1) window.scrollBy(0, delta);
    return true;
  }
  if (candidates && Number.isFinite(candidates.fallbackY)) {
    const delta = candidates.fallbackY - (window.scrollY || 0);
    if (Math.abs(delta) > 1) window.scrollTo(0, candidates.fallbackY);
  }
  return false;
}
function stabilizeAdultSpamScroll(candidates) {
  const token = ++adultSpamScrollToken;
  if (!candidates || !candidates.length || isPageScrollBusy()) return;
  if (typeof requestAnimationFrame !== 'function') return;
  requestAnimationFrame(() => {
    if (token !== adultSpamScrollToken || isPageScrollBusy()) return;
    restoreAdultSpamScrollAnchor(candidates);
  });
}
function setAdultSpamHidden(article, decision) {
  const target = article;
  if (!target || !target.classList) return { hidden: false, changed: false };
  const wasHidden = target.classList.contains('BetterX-adult-spam-hidden');
  if (decision.hidden) {
    target.classList.add('BetterX-adult-spam-hidden');
    target.dataset.BetterXAdultSpamReason = `${decision.score} 分：${decision.reasons.join('、')}`;
    adultSpamHiddenArticles.add(target);
  } else {
    target.classList.remove('BetterX-adult-spam-hidden');
    delete target.dataset.BetterXAdultSpamReason;
    adultSpamHiddenArticles.delete(target);
  }
  return { hidden: !!decision.hidden, changed: wasHidden !== !!decision.hidden };
}
function evaluateAndApplyAdultSpam(article, outcome, deferLayoutWhileScrolling) {
  if (!adultSpamFilteringEnabled() || !article || !article.querySelector) return false;
  const input = getAdultSpamInput(article);
  const statusUrl = getStatusLink(article);
  const statusId = extractStatusIdFromUrl(statusUrl) || '';
  if (outcome && typeof outcome === 'object') Object.assign(outcome, { input, url: statusUrl, id: statusId });
  const fingerprint = `${statusId}\n${input.username}\n${input.rawUsername}\n${input.displayName}\n${input.repostContext}\n${input.isRepost}\n${input.reposterUsername}\n${input.text}\n${input.externalLinkCount}\n${input.mentionCount}\n${input.hasMedia}\n${input.isFollowingTimeline}`;
  const statsKey = statusId || fingerprint;
  adultSpamScannedIdsCapped = addBoundedSessionStat(
    adultSpamScannedIds, statsKey, adultSpamScannedIdsCapped
  );
  const cached = adultSpamCache.get(article);
  const decision = cached && cached.version === adultSpamRulesVersion && cached.fingerprint === fingerprint
    ? cached.decision
    : scoreAdultSpam(input);
  if (!cached || cached.version !== adultSpamRulesVersion || cached.fingerprint !== fingerprint) {
    adultSpamCache.set(article, { version: adultSpamRulesVersion, fingerprint, decision });
  }
  const currentlyHidden = article.classList.contains('BetterX-adult-spam-hidden');
  if (deferLayoutWhileScrolling && isPageScrollBusy() && currentlyHidden !== !!decision.hidden) {
    scheduleAdultSpamLayoutFlush(article);
    if (outcome && typeof outcome === 'object') {
      outcome.hidden = !!decision.hidden;
      outcome.changed = false;
      outcome.deferred = true;
    }
    return !!decision.hidden;
  }
  const applied = setAdultSpamHidden(article, decision);
  if (outcome && typeof outcome === 'object') {
    outcome.hidden = applied.hidden;
    outcome.changed = applied.changed;
  }
  if (applied.hidden) {
    adultSpamSessionHiddenIdsCapped = addBoundedSessionStat(
      adultSpamSessionHiddenIds, statsKey, adultSpamSessionHiddenIdsCapped
    );
  }
  if (applied.hidden && applied.changed) {
    debugLog('内容净化已隐藏帖子', statusId || '(无 ID)', decision.score, decision.reasons);
  }
  return applied.hidden;
}
function updateAdultSpamCount() {
  if (!state.adultSpamCountEl) return;
  for (const article of adultSpamHiddenArticles) {
    if (article.isConnected && article.classList.contains('BetterX-adult-spam-hidden')) continue;
    article.classList.remove('BetterX-adult-spam-hidden');
    delete article.dataset.BetterXAdultSpamReason;
    adultSpamHiddenArticles.delete(article);
  }
  const currentCount = adultSpamHiddenArticles.size;
  const hiddenCount = `${adultSpamSessionHiddenIds.size}${adultSpamSessionHiddenIdsCapped ? '+' : ''}`;
  const scannedCount = `${adultSpamScannedIds.size}${adultSpamScannedIdsCapped ? '+' : ''}`;
  state.adultSpamCountEl.textContent = uiText(`当前隐藏 ${currentCount} · 本次累计 ${hiddenCount} · 已扫描 ${scannedCount} · 已识别关注 ${followedHandles.size}`);
}
function unhideAdultSpam() {
  adultSpamHiddenArticles.forEach((el) => {
    el.classList.remove('BetterX-adult-spam-hidden');
    delete el.dataset.BetterXAdultSpamReason;
  });
  adultSpamHiddenArticles.clear();
  updateAdultSpamCount();
}
function sweepAdultSpam(articles = document.querySelectorAll('article')) {
  if (!adultSpamFilteringEnabled()) return;
  harvestFollowingControlsFromRoot(document);
  articles.forEach((article) => evaluateAndApplyAdultSpam(article));
  updateAdultSpamCount();
}
function applyAdultSpamFiltering() {
  const articles = document.querySelectorAll('article');
  if (isPageScrollBusy()) {
    articles.forEach(scheduleAdultSpamLayoutFlush);
    return;
  }
  const anchors = captureAdultSpamScrollAnchors(articles);
  if (adultSpamFilteringEnabled()) {
    sweepAdultSpam(articles);
  } else {
    unhideAdultSpam();
  }
  stabilizeAdultSpamScroll(anchors);
}
function adultSpamFilteringEnabled() {
  const hasCustomKeywords = state.settings.adultSpamCustomRulesEnabled !== false
    && (state.settings.adultSpamKeywords || []).length > 0;
  return !!(state.settings.hideAdultSpam || hasCustomKeywords);
}
function parseAdultSpamWhitelist(raw) {
  return uniqueStrings(parseKeywords(raw)
    .map((item) => item.replace(/^https?:\/\/(?:www\.)?(?:x|twitter)\.com\//i, ''))
    .map((item) => item.replace(/^@+/, '').replace(/\/$/, '').toLowerCase())
    .filter((item) => /^[a-z0-9_]{1,15}$/.test(item)));
}
function markPostViewed(id) {
  const index = getPostIndexById(id);
  if (index < 0) return;
  const existing = state.posts[index];
  const timestamp = now();
  if (existing.lastViewedAt && timestamp - existing.lastViewedAt < 500) return;
  const updated = {
    ...existing,
    firstViewedAt: existing.firstViewedAt || timestamp,
    lastViewedAt: timestamp,
  };
  state.posts[index] = updated;
  queuePostPatch(id, {
    firstViewedAt: updated.firstViewedAt,
    lastViewedAt: updated.lastViewedAt,
  });
  debouncedRefreshUI();
}
function observeArticleView(article, id) {
  if (!article || !id || !state.viewObserver) return;
  state.viewedArticleIds.set(article, String(id));
  state.viewObserver.observe(article);
}
function unobserveArticleViews(root) {
  if (!root || !state.viewObserver || !(root instanceof HTMLElement)) return;
  if (root.matches('article')) state.viewObserver.unobserve(root);
  root.querySelectorAll('article').forEach((article) => state.viewObserver.unobserve(article));
}
function selectRicherPostText(existingText, candidateText) {
  const existing = String(existingText || '');
  const candidate = String(candidateText || '');
  if (!candidate || candidate === existing) return existing;
  if (!existing || candidate.length > existing.length) return candidate;
  return existing;
}
function captureArticle(article) {
  if (state.settings.hideAds && isAdArticle(article)) { hideAdElement(article); return; }
  let adultSpamResult;
  if (adultSpamFilteringEnabled() && evaluateAndApplyAdultSpam(article, adultSpamResult = {}, true)) return;
  if (!(article instanceof HTMLElement)) return;
  const url = adultSpamResult?.url ?? getStatusLink(article);
  const id = adultSpamResult?.id ?? extractStatusIdFromUrl(url);
  if (!id) return;
  observeArticleView(article, id);
  const sourceInfo = getCurrentSourceInfo();
  if (sourceInfo.type === 'compose') return;
  if ((state.settings.skipSources || []).includes(sourceInfo.type)) return;
  const isFirstVisibleCapture = !state.visibleMap.has(id);
  const author = adultSpamResult?.input?.author || extractAuthor(article);
  const text = adultSpamResult?.input?.fullText ?? extractText(article);
  const media = detectMedia(article, id);
  const avatarUrl = extractAvatar(article);
  if (isFirstVisibleCapture) {
    upsertPost({
      id, url,
      displayName: author.displayName,
      username: author.username,
      timeLabel: author.timeLabel,
      text: selectRicherPostText(getPostById(id)?.text, text),
      hasImage: media.hasImage,
      hasVideo: media.hasVideo,
      mediaThumbs: media.thumbs,
      avatarUrl,
      sourceType: sourceInfo.type,
      sourceLabel: sourceInfo.label,
      capturedPath: location.pathname + location.search,
      firstSeenInDomAt: now(),
      lastSeenInDomAt: now(),
    }, { countCapture: true });
    state.visibleMap.set(id, { firstSeenInDomAt: now(), lastSeenInDomAt: now(), articleEl: article });
  } else {
    const info = state.visibleMap.get(id);
    if (info) { info.lastSeenInDomAt = now(); info.articleEl = article; }
    const existing = getPostById(id);
    if (existing) {
      const richerText = selectRicherPostText(existing.text, text);
      const hasImage = !!(existing.hasImage || media.hasImage);
      const hasVideo = !!(existing.hasVideo || media.hasVideo);
      const needsPatch =
        richerText !== (existing.text || '') ||
        (author.displayName && existing.displayName !== author.displayName) ||
        (author.username && existing.username !== author.username) ||
        (author.timeLabel && existing.timeLabel !== author.timeLabel) ||
        (!(existing.mediaThumbs || []).length && media.thumbs.length) ||
        (!existing.avatarUrl && avatarUrl) ||
        existing.hasImage !== hasImage ||
        existing.hasVideo !== hasVideo ||
        (sourceInfo.type === 'page'
          ? existing.sourceLabel !== '' || existing.sourceType !== 'page'
          : sourceInfo.label && existing.sourceLabel !== sourceInfo.label) ||
        existing.url !== url;
      if (needsPatch) {
        upsertPost({
          ...existing,
          url,
          displayName: author.displayName || existing.displayName,
          username: author.username || existing.username,
          timeLabel: author.timeLabel || existing.timeLabel || '',
          text: richerText,
          hasImage,
          hasVideo,
          mediaThumbs: (existing.mediaThumbs || []).length ? existing.mediaThumbs : media.thumbs,
          avatarUrl: existing.avatarUrl || avatarUrl,
          sourceType: sourceInfo.type,
          sourceLabel: sourceInfo.label,
          capturedPath: location.pathname + location.search,
          lastSeenInDomAt: now(),
        }, { countCapture: false });
      }
    }
  }
}
function expandPostShowMore(scope) {
  if (!state.settings.autoExpandPostText) return 0;
  const articles = getArticlesFromScope(scope);
  let expanded = 0;
  articles.forEach((article) => {
    if (article.closest('#BetterX-root')) return;
    article.querySelectorAll('button, a[role="link"], [role="button"]').forEach((control) => {
      if (autoExpandedPostShowMoreControls.has(control)) return;
      const label = (control.innerText || control.textContent || '').trim();
      if (!POST_SHOW_MORE_LABELS.has(label)) return;
      autoExpandedPostShowMoreControls.add(control);
      try {
        control.click();
        expanded++;
      } catch (err) {}
    });
  });
  return expanded;
}
function scanArticles(root) {
  const scope = root && root.querySelectorAll ? root : document;
  if (state.settings.hideAds) sweepStandaloneAds(scope);
  getArticlesFromScope(scope).forEach(captureArticle);
  if (state.settings.mediaDownload) injectDownloadButtons(scope);
  if (state.settings.restoreMediaGrid) applyMediaGridLayout(scope);
  if (state.settings.bypassAgeRestriction) revealAgeRestricted(scope);
  if (state.settings.autoExpandPostText) expandPostShowMore(scope);
  if (adultSpamFilteringEnabled()) updateAdultSpamCount();
}
function checkDisappearedPosts() {
  if (document.hidden) return;
  const ts = now();
  const flashMs = state.settings.flashMs || DEFAULT_SETTINGS.flashMs;
  const currentId = extractStatusIdFromUrl(location.href);
  if (currentId) {
    const p = getPostById(currentId);
    if (p && !p.clicked) markClicked(currentId);
  }
  for (const [id, info] of state.visibleMap.entries()) {
    const el = info.articleEl;
    const stillInDom = !!(el && document.contains(el));
    if (stillInDom) { info.lastSeenInDomAt = ts; continue; }
    const visibleDuration = (info.lastSeenInDomAt || ts) - (info.firstSeenInDomAt || ts);
    if (visibleDuration >= 0 && visibleDuration <= flashMs) markFlashLost(id);
    state.visibleMap.delete(id);
  }
}
function closeImagePreview() {
  const preview = document.getElementById('BetterX-image-preview');
  if (!preview) return;
  try {
    if (typeof preview._betterxCleanup === 'function') preview._betterxCleanup();
  } catch (err) {}
  preview.remove();
}
function showImagePreview(rawUrl, rawUrls, rawIndex) {
  const clickedSrc = safeImportedAssetUrl(rawUrl);
  const sources = uniqueStrings(
    (Array.isArray(rawUrls) ? rawUrls : [rawUrl])
      .map(safeImportedAssetUrl)
      .filter(Boolean)
  ).slice(0, 4);
  if (clickedSrc && !sources.includes(clickedSrc)) sources.unshift(clickedSrc);
  if (!sources.length) return;
  let currentIndex = Number.parseInt(rawIndex, 10);
  if (!Number.isFinite(currentIndex) || currentIndex < 0 || currentIndex >= sources.length) {
    currentIndex = clickedSrc ? sources.indexOf(clickedSrc) : 0;
    if (currentIndex < 0) currentIndex = 0;
  }
  closeImagePreview();
  const overlay = document.createElement('div');
  overlay.id = 'BetterX-image-preview';
  overlay.className = 'BetterX-image-preview';
  overlay.tabIndex = -1;
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.setAttribute('aria-label', '图片预览；电脑端可滚轮缩放并用左右按钮或方向键切图，移动端可双指缩放并左右滑动切图；按 Esc 或点击空白处关闭');
  const box = document.createElement('div');
  box.className = 'BetterX-image-preview-box';
  const image = document.createElement('img');
  image.referrerPolicy = 'no-referrer';
  image.alt = '帖子图片预览';
  image.draggable = false;
  const close = document.createElement('button');
  close.type = 'button';
  close.className = 'BetterX-image-preview-close';
  close.innerHTML = '<span aria-hidden="true">×</span>';
  close.setAttribute('aria-label', '关闭图片预览');
  close.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    closeImagePreview();
  });
  const previous = document.createElement('button');
  previous.type = 'button';
  previous.className = 'BetterX-image-preview-nav BetterX-image-preview-prev';
  previous.innerHTML = '<span aria-hidden="true">‹</span>';
  previous.setAttribute('aria-label', '上一张图片');
  const next = document.createElement('button');
  next.type = 'button';
  next.className = 'BetterX-image-preview-nav BetterX-image-preview-next';
  next.innerHTML = '<span aria-hidden="true">›</span>';
  next.setAttribute('aria-label', '下一张图片');
  box.appendChild(image);
  overlay.append(box, previous, next, close);
  const zoom = {
    scale: 1,
    x: 0,
    y: 0,
    min: 1,
    max: 6,
    pointers: new Map(),
    panStart: null,
    pinchStart: null,
    swipeStart: null,
  };
  let navRaf = 0;
  const clampScale = (value) => Math.max(zoom.min, Math.min(zoom.max, value));
  const isFinePointer = () => {
    try { return window.matchMedia('(hover: hover) and (pointer: fine)').matches; }
    catch (err) { return !isMobileBadgeViewport(); }
  };
  const updateNavVisibility = () => {
    const multi = sources.length > 1;
    previous.hidden = !multi;
    next.hidden = !multi;
    previous.disabled = currentIndex <= 0;
    next.disabled = currentIndex >= sources.length - 1;
  };
  const updateNavPositions = () => {
    if (sources.length <= 1 || !isFinePointer() || !image.isConnected || !image.complete) return;
    const rect = image.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const size = 44;
    const gap = 14;
    const edge = 12;
    const viewportWidth = Math.max(1, window.innerWidth || document.documentElement.clientWidth || 1);
    const viewportHeight = Math.max(1, window.innerHeight || document.documentElement.clientHeight || 1);
    const top = Math.max(edge, Math.min(viewportHeight - edge - size, rect.top + rect.height / 2 - size / 2));
    const prevLeft = Math.max(edge, Math.min(viewportWidth - edge - size, rect.left - gap - size));
    const nextLeft = Math.max(edge, Math.min(viewportWidth - edge - size, rect.right + gap));
    previous.style.left = `${Math.round(prevLeft)}px`;
    previous.style.top = `${Math.round(top)}px`;
    next.style.left = `${Math.round(nextLeft)}px`;
    next.style.top = `${Math.round(top)}px`;
  };
  const scheduleNavPositions = () => {
    if (navRaf) return;
    navRaf = requestAnimationFrame(() => {
      navRaf = 0;
      updateNavPositions();
    });
  };
  const constrainTranslation = () => {
    if (zoom.scale <= 1.0001) {
      zoom.scale = 1;
      zoom.x = 0;
      zoom.y = 0;
      return;
    }
    const baseWidth = image.offsetWidth || 0;
    const baseHeight = image.offsetHeight || 0;
    const viewWidth = box.clientWidth || window.innerWidth;
    const viewHeight = box.clientHeight || window.innerHeight;
    const maxX = Math.max(0, (baseWidth * zoom.scale - viewWidth) / 2);
    const maxY = Math.max(0, (baseHeight * zoom.scale - viewHeight) / 2);
    zoom.x = Math.max(-maxX, Math.min(maxX, zoom.x));
    zoom.y = Math.max(-maxY, Math.min(maxY, zoom.y));
  };
  const applyZoom = () => {
    constrainTranslation();
    image.style.transform = `translate3d(${zoom.x}px, ${zoom.y}px, 0) scale(${zoom.scale})`;
    box.classList.toggle('is-zoomed', zoom.scale > 1.0001);
    scheduleNavPositions();
  };
  const resetZoom = () => {
    zoom.scale = 1;
    zoom.x = 0;
    zoom.y = 0;
    zoom.panStart = null;
    zoom.pinchStart = null;
    zoom.swipeStart = null;
    box.classList.remove('is-panning');
    applyZoom();
  };
  const getStageCenter = () => {
    const rect = box.getBoundingClientRect();
    return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
  };
  const zoomAt = (nextScale, clientX, clientY) => {
    const previousScale = zoom.scale;
    const scale = clampScale(nextScale);
    if (Math.abs(scale - previousScale) < 0.0001) return;
    const center = getStageCenter();
    const focalX = (clientX - center.x - zoom.x) / previousScale;
    const focalY = (clientY - center.y - zoom.y) / previousScale;
    zoom.scale = scale;
    zoom.x = clientX - center.x - focalX * scale;
    zoom.y = clientY - center.y - focalY * scale;
    applyZoom();
  };
  const pointerPair = () => [...zoom.pointers.values()].slice(0, 2);
  const startPinch = () => {
    const pair = pointerPair();
    if (pair.length < 2) { zoom.pinchStart = null; return; }
    const [a, b] = pair;
    const midpointX = (a.x + b.x) / 2;
    const midpointY = (a.y + b.y) / 2;
    const distance = Math.hypot(b.x - a.x, b.y - a.y) || 1;
    const center = getStageCenter();
    zoom.pinchStart = {
      distance,
      scale: zoom.scale,
      focalX: (midpointX - center.x - zoom.x) / zoom.scale,
      focalY: (midpointY - center.y - zoom.y) / zoom.scale,
    };
    zoom.panStart = null;
    zoom.swipeStart = null;
  };
  const preloadNeighbors = () => {
    [currentIndex - 1, currentIndex + 1].forEach((index) => {
      if (index < 0 || index >= sources.length) return;
      const preload = new Image();
      preload.referrerPolicy = 'no-referrer';
      preload.src = sources[index];
    });
  };
  const setCurrentImage = (index) => {
    if (index < 0 || index >= sources.length || index === currentIndex && image.src) return false;
    currentIndex = index;
    resetZoom();
    image.alt = sources.length > 1 ? `帖子图片预览，第 ${currentIndex + 1} 张，共 ${sources.length} 张` : '帖子图片预览';
    image.src = sources[currentIndex];
    updateNavVisibility();
    preloadNeighbors();
    scheduleNavPositions();
    return true;
  };
  const navigateImage = (step) => setCurrentImage(currentIndex + step);
  previous.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    navigateImage(-1);
  });
  next.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    navigateImage(1);
  });
  overlay.addEventListener('wheel', (event) => {
    if (event.target && event.target.closest && event.target.closest('button')) return;
    event.preventDefault();
    const factor = event.deltaY < 0 ? 1.16 : (1 / 1.16);
    zoomAt(zoom.scale * factor, event.clientX, event.clientY);
  }, { passive: false });
  box.addEventListener('pointerdown', (event) => {
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    if (event.pointerType === 'mouse' && zoom.scale <= 1.0001) return;
    if (event.target === box && zoom.scale <= 1.0001 && zoom.pointers.size === 0) return;
    if (event.pointerType !== 'mouse') event.preventDefault();
    if (event.pointerType !== 'mouse' && zoom.scale <= 1.0001 && zoom.pointers.size === 0) {
      zoom.swipeStart = {
        id: event.pointerId,
        x: event.clientX,
        y: event.clientY,
        time: Date.now(),
      };
    }
    zoom.pointers.set(event.pointerId, { x: event.clientX, y: event.clientY, type: event.pointerType });
    try { box.setPointerCapture(event.pointerId); } catch (err) {}
    if (zoom.pointers.size >= 2) {
      startPinch();
    } else if (zoom.scale > 1.0001) {
      zoom.swipeStart = null;
      zoom.panStart = { id: event.pointerId, x: event.clientX, y: event.clientY, tx: zoom.x, ty: zoom.y };
      box.classList.add('is-panning');
    }
  });
  box.addEventListener('pointermove', (event) => {
    if (!zoom.pointers.has(event.pointerId)) return;
    if (event.pointerType !== 'mouse') event.preventDefault();
    zoom.pointers.set(event.pointerId, { x: event.clientX, y: event.clientY, type: event.pointerType });
    if (zoom.pointers.size >= 2) {
      if (!zoom.pinchStart) startPinch();
      const pair = pointerPair();
      if (pair.length < 2 || !zoom.pinchStart) return;
      const [a, b] = pair;
      const midpointX = (a.x + b.x) / 2;
      const midpointY = (a.y + b.y) / 2;
      const distance = Math.hypot(b.x - a.x, b.y - a.y) || 1;
      const nextScale = clampScale(zoom.pinchStart.scale * (distance / zoom.pinchStart.distance));
      const center = getStageCenter();
      zoom.scale = nextScale;
      zoom.x = midpointX - center.x - zoom.pinchStart.focalX * nextScale;
      zoom.y = midpointY - center.y - zoom.pinchStart.focalY * nextScale;
      applyZoom();
      return;
    }
    if (zoom.panStart && zoom.panStart.id === event.pointerId && zoom.scale > 1.0001) {
      zoom.x = zoom.panStart.tx + event.clientX - zoom.panStart.x;
      zoom.y = zoom.panStart.ty + event.clientY - zoom.panStart.y;
      applyZoom();
    }
  }, { passive: false });
  const endPointer = (event, cancelled) => {
    if (!zoom.pointers.has(event.pointerId)) return;
    const pointerCountBeforeEnd = zoom.pointers.size;
    const swipe = !cancelled && zoom.swipeStart && zoom.swipeStart.id === event.pointerId
      && pointerCountBeforeEnd === 1 && zoom.scale <= 1.0001
      ? {
          dx: event.clientX - zoom.swipeStart.x,
          dy: event.clientY - zoom.swipeStart.y,
          elapsed: Date.now() - zoom.swipeStart.time,
        }
      : null;
    zoom.pointers.delete(event.pointerId);
    try { if (box.hasPointerCapture(event.pointerId)) box.releasePointerCapture(event.pointerId); } catch (err) {}
    zoom.pinchStart = null;
    zoom.swipeStart = null;
    box.classList.remove('is-panning');
    if (swipe && swipe.elapsed <= 900 && Math.abs(swipe.dx) >= 52 && Math.abs(swipe.dx) > Math.abs(swipe.dy) * 1.15) {
      if (swipe.dx < 0) navigateImage(1);
      else navigateImage(-1);
    }
    if (zoom.pointers.size >= 2) {
      startPinch();
    } else if (zoom.pointers.size === 1 && zoom.scale > 1.0001) {
      const [id, point] = zoom.pointers.entries().next().value;
      zoom.panStart = { id, x: point.x, y: point.y, tx: zoom.x, ty: zoom.y };
      box.classList.add('is-panning');
    } else {
      zoom.panStart = null;
    }
  };
  box.addEventListener('pointerup', (event) => endPointer(event, false));
  box.addEventListener('pointercancel', (event) => endPointer(event, true));
  overlay.addEventListener('click', (event) => {
    if (event.target === overlay || event.target === box) closeImagePreview();
  });
  overlay.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      event.preventDefault();
      closeImagePreview();
      return;
    }
    if (event.key === 'ArrowLeft' && sources.length > 1) {
      event.preventDefault();
      navigateImage(-1);
    } else if (event.key === 'ArrowRight' && sources.length > 1) {
      event.preventDefault();
      navigateImage(1);
    }
  });
  const onViewportChange = () => scheduleNavPositions();
  window.addEventListener('resize', onViewportChange, { passive: true });
  window.addEventListener('orientationchange', onViewportChange, { passive: true });
  image.addEventListener('load', () => {
    applyZoom();
    scheduleNavPositions();
  });
  overlay._betterxCleanup = () => {
    window.removeEventListener('resize', onViewportChange);
    window.removeEventListener('orientationchange', onViewportChange);
    if (navRaf) cancelAnimationFrame(navRaf);
    navRaf = 0;
  };
  localizeBetterXTree(overlay);
  (document.body || document.documentElement).appendChild(overlay);
  updateNavVisibility();
  image.src = sources[currentIndex];
  image.alt = sources.length > 1 ? `帖子图片预览，第 ${currentIndex + 1} 张，共 ${sources.length} 张` : '帖子图片预览';
  preloadNeighbors();
  overlay.focus();
}
function openRecordedPost(post) {
  if (!post || !post.url || !post.id) return;
  const safeUrl = safeImportedStatusUrl(post.url, post.id);
  if (!safeUrl) return;
  markClicked(post.id);
  if (!isMobileBadgeViewport()) {
    window.open(safeUrl, '_blank', 'noopener');
    return;
  }
  try {
    const target = new URL(safeUrl, location.href);
    const relativeHref = `${target.pathname}${target.search}${target.hash}`;
    const anchor = document.createElement('a');
    anchor.href = relativeHref;
    anchor.target = '_self';
    anchor.setAttribute('data-betterx-internal-nav', 'true');
    anchor.style.display = 'none';
    (document.body || document.documentElement).appendChild(anchor);
    anchor.click();
    anchor.remove();
  } catch (err) {
    const id = encodeURIComponent(String(post.id));
    location.assign(`/i/status/${id}`);
  }
}
function handleDocumentClick(e) {
  const target = e.target;
  if (!target || !target.closest) return;
  if (state.downloadPopoverEl && !state.downloadPopoverEl.hidden
    && !target.closest('#BetterX-download-popover') && !target.closest('#BetterX-download-pill')) {
    toggleDownloadPopover(false);
  }
  if (state.panelOpen && !target.closest('#BetterX-root') && !target.closest('#BetterX-image-preview')) {
    togglePanel(false);
  }
  const anchor = target.closest('a[href*="/status/"]');
  if (anchor) {
    const id = extractStatusIdFromUrl(anchor.href || anchor.getAttribute('href') || '');
    if (id) { markClicked(id); return; }
  }
  const interactive = target.closest('a, button, [role="button"], [role="link"], [role="menuitem"], [data-testid="caret"]');
  if (!interactive) {
    const article = target.closest('article');
    if (article) {
      const id = extractStatusIdFromUrl(getStatusLink(article));
      if (id) markClicked(id);
    }
  }
}
function handleKeydown(e) {
  if (e.altKey && !e.ctrlKey && !e.metaKey && (e.key === 'x' || e.key === 'X')) {
    e.preventDefault();
    togglePanel();
  }
}
function updateSettingsDependencyUI() {
  if (!state.panelEl) return;
  const setGroupDisabled = (selector, disabled) => {
    const group = state.panelEl.querySelector(selector);
    if (!group) return;
    group.classList.toggle('is-disabled', disabled);
    group.querySelectorAll('input, select, button').forEach((control) => {
      control.disabled = disabled;
    });
  };
  const adultSpamDisabled = !state.settings.hideAdultSpam;
  const layoutDisabled = !state.settings.layoutEnabled;
  const adultSpamCustomDisabled = state.settings.adultSpamCustomRulesEnabled === false;
  setGroupDisabled('#BetterX-adultspam-auto-options', adultSpamDisabled);
  setGroupDisabled('#BetterX-adultspam-custom-options', adultSpamCustomDisabled);
  setGroupDisabled('#BetterX-layout-options', layoutDisabled);
  if (state.adultSpamLevelEl) state.adultSpamLevelEl.disabled = adultSpamDisabled;
  if (state.adultSpamSkipFollowingRepostsEl) {
    const repostOptionDisabled = adultSpamDisabled || state.settings.adultSpamSkipFollowing === false;
    state.adultSpamSkipFollowingRepostsEl.disabled = repostOptionDisabled;
    const repostLabel = state.adultSpamSkipFollowingRepostsEl.closest('.BetterX-field');
    if (repostLabel) {
      repostLabel.classList.toggle('is-disabled', !adultSpamDisabled && state.settings.adultSpamSkipFollowing === false);
    }
  }
  const manualWidthDisabled = layoutDisabled || state.settings.layoutAutoWidth !== false;
  [state.timelineWidthEl, state.leftbarWidthEl].forEach((control) => {
    if (control) control.disabled = manualWidthDisabled;
  });
  const saveLayoutButton = state.panelEl.querySelector('[data-action="save-layout"]');
  if (saveLayoutButton) saveLayoutButton.disabled = manualWidthDisabled;
  if (state.firefoxCompatibilityEl) {
    state.panelEl.querySelectorAll('.BetterX-firefox-only-setting').forEach((element) => {
      element.hidden = !IS_FIREFOX;
    });
  }
  const downloadControlsDisabled = !state.settings.mediaDownload;
  [
    state.gifDownloadFormatEnabledEl, state.downloadZipEl, state.downloadFileNameTemplateEl, state.downloadZipNameTemplateEl,
    state.downloadNameRegexEl, state.downloadNameReplacementEl, state.trackDownloadedPostsEl,
  ].forEach((control) => {
    if (control) control.disabled = downloadControlsDisabled;
  });
  if (state.gifDownloadFormatEl) {
    state.gifDownloadFormatEl.disabled = downloadControlsDisabled || state.settings.gifDownloadFormatEnabled === false;
  }
  if (state.gifDownloadFormatEnabledEl) {
    const label = state.gifDownloadFormatEnabledEl.closest('label');
    if (label) label.classList.toggle('is-disabled', downloadControlsDisabled);
  }
  if (state.downloadZipEl) {
    const label = state.downloadZipEl.closest('label');
    if (label) label.classList.toggle('is-disabled', downloadControlsDisabled);
  }
  if (state.trackDownloadedPostsEl) {
    const label = state.trackDownloadedPostsEl.closest('label');
    if (label) label.classList.toggle('is-disabled', downloadControlsDisabled);
  }
  const saveDownloadNamingButton = state.panelEl.querySelector('[data-action="save-download-naming"]');
  if (saveDownloadNamingButton) saveDownloadNamingButton.disabled = downloadControlsDisabled;
  state.panelEl.querySelectorAll('.BetterX-download-name-tokens button').forEach((button) => {
    button.disabled = downloadControlsDisabled;
  });
}
function formatNotificationSyncTime(timestamp) {
  if (!timestamp) return '尚未完整同步';
  try { return `上次同步：${new Date(timestamp).toLocaleString()}`; } catch (err) { return '已同步'; }
}
function renderNotificationSubscriptions(force = false) {
  if (!state.notificationListEl || state.panelView !== 'notifications' || (!state.panelOpen && !force)) return;
  const syncButton = state.panelEl && state.panelEl.querySelector('[data-action="sync-notification-users"]');
  if (syncButton) {
    syncButton.disabled = state.notificationSyncInProgress;
    syncButton.textContent = uiText(state.notificationSyncInProgress ? '正在同步…' : '同步订阅用户');
  }
  const allItems = [...notificationSubscriptions.values()]
    .sort((a, b) => Number(b.pinned === true) - Number(a.pinned === true)
      || Number(b.enabled) - Number(a.enabled)
      || String(a.username).localeCompare(String(b.username), undefined, { sensitivity: 'base' }));
  const query = safeString(state.notificationSearchQuery, 120).trim();
  const items = query ? allItems.filter((item) => notificationMatchesSearch(item, query)) : allItems;
  const enabledCount = allItems.filter((item) => item.enabled).length;
  const pinnedCount = allItems.filter((item) => item.pinned === true).length;
  if (state.notificationStatusEl) {
    const filterSummary = query ? ` · 筛选到 ${items.length}/${allItems.length}` : '';
    state.notificationStatusEl.textContent = uiText(state.notificationSyncInProgress
      ? `正在读取关注列表… 已发现 ${enabledCount} 个订阅${filterSummary}`
      : `已订阅 ${enabledCount} · 已置顶 ${pinnedCount} · 本地保留 ${allItems.length}${filterSummary} · ${formatNotificationSyncTime(state.settings.notificationSubscriptionsSyncedAt)}`);
  }
  if (!allItems.length) {
    state.notificationListEl.innerHTML = uiHtml`<div class="BetterX-empty">还没有读取到帖子通知订阅。点击“同步订阅用户”，或浏览已开启铃铛的用户主页后再查看。</div>`;
    return;
  }
  if (!items.length) {
    state.notificationListEl.innerHTML = uiHtml`<div class="BetterX-empty">没有找到与“<span class="BetterX-i18n-user-text">${escapeHtml(query)}</span>”匹配的用户名或 @用户名。</div>`;
    return;
  }
  state.notificationListEl.innerHTML = items.map((item) => {
    const avatar = safeImportedAssetUrl(item.avatarUrl);
    const profileUrl = `https://x.com/${encodeURIComponent(item.username)}`;
    const pending = state.notificationMutationUsers.has(item.username.toLowerCase());
    const pinned = item.pinned === true;
    const pinMark = pinned
      ? uiHtml`<span class="BetterX-notification-pin-mark" title="已置顶" aria-label="已置顶"> 📌</span>` : '';
    const forgetButton = item.enabled ? ''
      : uiHtml`<button class="BetterX-btn" data-action="forget-notification-user" data-username="${escapeHtml(item.username)}">移除记录</button>`;
    return uiHtml`
        <div class="BetterX-notification-user ${item.enabled ? '' : 'is-disabled'} ${pinned ? 'is-pinned' : ''}">
          <a class="BetterX-notification-user-main" href="${escapeHtml(profileUrl)}" target="_blank" rel="noopener noreferrer">
            ${avatar ? `<img src="${escapeHtml(avatar)}" alt="" referrerpolicy="no-referrer" />` : '<span class="BetterX-notification-avatar-fallback">@</span>'}
            <span><b>${escapeHtml(item.displayName || item.username)}${pinMark}</b><small>@${escapeHtml(item.username)}</small></span>
          </a>
          <div class="BetterX-notification-user-actions">
            <button class="BetterX-btn ${item.enabled ? 'danger' : 'primary'}" data-action="toggle-notification-user" data-username="${escapeHtml(item.username)}" data-enabled="${item.enabled ? 'false' : 'true'}" ${pending ? 'disabled' : ''}>${uiText(pending ? '处理中…' : (item.enabled ? '关闭通知' : '重新开启'))}</button>
            <button class="BetterX-btn ${pinned ? 'notification-pinned' : ''}" data-action="toggle-notification-pin" data-username="${escapeHtml(item.username)}">${uiText(pinned ? '取消置顶' : '置顶')}</button>
            ${forgetButton}
          </div>
        </div>`;
  }).join('');
}
function setPanelView(view) {
  if (!state.panelEl) return;
  const nextView = view === 'settings' || view === 'notifications' ? view : 'vault';
  const enteringSettings = nextView === 'settings' && state.panelView !== 'settings';
  state.panelView = nextView;
  if (enteringSettings) {
    state.panelEl.querySelectorAll('.BetterX-settings-card[open]').forEach((detailsEl) => {
      detailsEl.removeAttribute('open');
    });
  }
  state.panelEl.classList.toggle('is-settings-view', nextView !== 'vault');
  state.panelEl.querySelectorAll('[data-view-panel]').forEach((viewEl) => {
    viewEl.hidden = viewEl.getAttribute('data-view-panel') !== nextView;
  });
  state.panelEl.querySelectorAll('[data-action="set-panel-view"]').forEach((tabEl) => {
    const active = tabEl.getAttribute('data-view') === nextView;
    tabEl.classList.toggle('active', active);
    tabEl.setAttribute('aria-selected', active ? 'true' : 'false');
    tabEl.tabIndex = active ? 0 : -1;
  });
  if (state.panelOpen) refreshUI({ keepScroll: true });
}
function togglePanel(force) {
  const next = typeof force === 'boolean' ? force : !state.panelOpen;
  state.panelOpen = next;
  if (next) updatePanelPlacement();
  if (state.panelEl) state.panelEl.style.display = next ? 'flex' : 'none';
  if (state.rootEl) state.rootEl.classList.toggle('is-open', next);
  updateBadgeToggleLabel();
  if (next) { resetPaging(); refreshUI(); }
}
function updateBadgeToggleLabel() {
  if (!state.badgeEl || !state.rootEl) return;
  const revealOnly = state.rootEl.classList.contains('BetterX-mobile-badge-collapsed')
    && !!state.settings.hideAppBadge;
  const label = revealOnly ? '显示 BetterX 应用徽标'
    : state.panelOpen ? '关闭 BetterX 面板' : '打开 BetterX 面板';
  state.badgeEl.setAttribute('aria-label', uiText(label));
  state.badgeEl.title = uiText(revealOnly ? '点按显示 BetterX 徽标' : label);
}
function markPostsRead(ids) {
  const targetIds = new Set((ids || []).map(String));
  if (!targetIds.size) return;
  let changed = false;
  state.posts = state.posts.map((p) => {
    if (!p.clicked && targetIds.has(String(p.id))) {
      changed = true;
      const updated = { ...p, clicked: true, lastClickedAt: now() };
      queuePostPatch(updated.id, { clicked: true, lastClickedAt: updated.lastClickedAt });
      return updated;
    }
    return p;
  });
  if (changed) refreshUI({ keepScroll: true });
}
function download(filename, text) {
  const blob = new Blob([text], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
function exportPosts() {
  const data = filterPosts(state.posts);
  if (!data.length) { uiAlert('当前筛选结果为空，没有可导出的内容。'); return; }
  savePostExport(data, null, `BetterX-filtered-${new Date().toISOString().slice(0, 10)}`);
}
function buildPostExportBlob(posts, metadata, backupPart) {
  const header = metadata ? { ...metadata, ...(backupPart ? { backupPart } : {}) } : null;
  const chunks = [header ? JSON.stringify({ ...header, posts: [] }).slice(0, -2) : '['];
  posts.forEach((post, index) => {
    if (index) chunks.push(',');
    chunks.push(JSON.stringify(post));
  });
  chunks.push(header ? ']}' : ']');
  return new Blob(chunks, { type: 'application/json' });
}
function partitionPostExport(posts, metadata, maxBytes = MAX_IMPORT_FILE_BYTES, maxPosts = MAX_IMPORT_POSTS) {
  const placeholder = { index: Number.MAX_SAFE_INTEGER, total: Number.MAX_SAFE_INTEGER };
  const overhead = buildPostExportBlob([], metadata, placeholder).size;
  if (overhead > maxBytes) throw new Error('EXPORT_RECORD_TOO_LARGE');
  const encoder = new TextEncoder();
  const groups = [];
  let group = [];
  let bytes = overhead;
  for (const post of posts) {
    const recordBytes = encoder.encode(JSON.stringify(post)).byteLength;
    if (overhead + recordBytes > maxBytes) throw new Error('EXPORT_RECORD_TOO_LARGE');
    if (group.length && (bytes + 1 + recordBytes > maxBytes || group.length >= maxPosts)) {
      groups.push(group);
      group = [];
      bytes = overhead;
    }
    bytes += (group.length ? 1 : 0) + recordBytes;
    group.push(post);
  }
  if (group.length || !groups.length) groups.push(group);
  return groups;
}
function savePostExport(posts, metadata, baseName) {
  let groups;
  try { groups = partitionPostExport(posts, metadata); }
  catch (err) { uiAlert('无法导出：单条记录或设置超过备份容量限制。'); return; }
  const savePart = (index) => {
    const suffix = groups.length > 1 ? `-part-${index + 1}-of-${groups.length}` : '';
    const part = groups.length > 1 ? { index: index + 1, total: groups.length } : null;
    download(`${baseName}${suffix}.json`, buildPostExportBlob(groups[index], metadata, part));
  };
  if (groups.length === 1) { savePart(0); return; }
  showBetterXDialog({
    title: '备份已分卷',
    bodyHtml: uiHtml`<p>数据较大，请保存全部分卷；恢复时可同时选择这些 JSON 文件。</p>
        ${groups.map((group, index) => uiHtml`<p><button type="button" class="BetterX-btn" data-backup-part="${index}">下载分卷 ${index + 1} / ${groups.length}</button></p>`).join('')}`,
    primaryText: '完成', secondaryText: '关闭',
  });
  const dialog = document.getElementById('BetterX-choice-dialog');
  dialog.addEventListener('click', (event) => {
    const button = event.target.closest('[data-backup-part]');
    if (!button) return;
    const index = Number(button.getAttribute('data-backup-part'));
    if (Number.isInteger(index) && index >= 0 && index < groups.length) savePart(index);
  });
}
function backupAll() {
  const portableSettings = { ...state.settings };
  delete portableSettings.firefoxCompatibility;
  delete portableSettings.firefoxCompatibilityPrompted;
  const payload = {
    type: 'x-post-vault-backup',
    version: '1.2.0',
    exportedAt: new Date().toISOString(),
    settings: portableSettings,
  };
  savePostExport([...state.posts], payload, `BetterX-backup-${new Date().toISOString().slice(0, 10)}`);
}
function sanitizeImportedPost(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const id = typeof raw.id === 'string' && /^\d{1,30}$/.test(raw.id) ? raw.id : '';
  if (!id) return null;
  const timestamp = now();
  const finiteInt = (value, min, max, fallback) => {
    const n = Number(value);
    return Number.isFinite(n) ? Math.min(max, Math.max(min, Math.floor(n))) : fallback;
  };
  const username = safeString(raw.username, 100);
  const usernamePart = username.replace(/^@/, '');
  const fallbackUrl = /^[A-Za-z0-9_]{1,15}$/.test(usernamePart)
    ? `https://x.com/${usernamePart}/status/${id}`
    : `https://x.com/i/web/status/${id}`;
  const mediaThumbs = uniqueStrings(
    (Array.isArray(raw.mediaThumbs) ? raw.mediaThumbs : []).map(safeImportedAssetUrl).filter(Boolean)
  ).slice(0, 4);
  const firstCapturedAt = finiteInt(raw.firstCapturedAt, 0, Number.MAX_SAFE_INTEGER, timestamp);
  const lastCapturedAt = finiteInt(raw.lastCapturedAt, 0, Number.MAX_SAFE_INTEGER, firstCapturedAt);
  const firstViewedAt = finiteInt(raw.firstViewedAt, 0, Number.MAX_SAFE_INTEGER, 0);
  const lastViewedAt = finiteInt(raw.lastViewedAt, 0, Number.MAX_SAFE_INTEGER, firstViewedAt);
  const authorInfo = cleanAuthorInfo(raw.displayName, raw.username, raw.timeLabel);
  return {
    id,
    url: safeImportedStatusUrl(raw.url, id) || fallbackUrl,
    displayName: safeString(authorInfo.displayName || raw.displayName, 200),
    username: safeString(authorInfo.username || username, 100),
    timeLabel: safeString(authorInfo.timeLabel || raw.timeLabel, 80),
    text: safeString(raw.text, 100000),
    hasImage: (() => {
      const hasVideo = raw.hasVideo === true;
      if (raw.hasImage === undefined || raw.hasImage === null) {
        return !hasVideo && mediaThumbs.length > 0;
      }
      if (hasVideo && raw.hasImage === true) {
        const onlyVideoThumbs = mediaThumbs.length > 0 && mediaThumbs.every((u) => /(?:ext_tw_video_thumb|amplify_tw_video_thumb|amplify_video_thumb|tweet_video_thumb)/i.test(u));
        if (onlyVideoThumbs) return false;
      }
      return raw.hasImage === true;
    })(),
    hasVideo: raw.hasVideo === true,
    mediaThumbs,
    avatarUrl: safeImportedAssetUrl(raw.avatarUrl),
    ...normalizePostSourceFields(raw),
    capturedPath: typeof raw.capturedPath === 'string' && raw.capturedPath.startsWith('/')
      ? raw.capturedPath.slice(0, 2000)
      : '',
    favorite: raw.favorite === true,
    pinned: raw.pinned === true,
    clicked: raw.clicked === true,
    flashLost: raw.flashLost === true,
    note: safeString(raw.note, 20000),
    capturedCount: finiteInt(raw.capturedCount, 1, 1000000, 1),
    firstCapturedAt,
    lastCapturedAt: Math.max(firstCapturedAt, lastCapturedAt),
    firstViewedAt,
    lastViewedAt: Math.max(firstViewedAt, lastViewedAt),
    firstSeenInDomAt: finiteInt(raw.firstSeenInDomAt, 0, Number.MAX_SAFE_INTEGER, firstCapturedAt),
    lastSeenInDomAt: finiteInt(raw.lastSeenInDomAt, 0, Number.MAX_SAFE_INTEGER, lastCapturedAt),
    lastClickedAt: finiteInt(raw.lastClickedAt, 0, Number.MAX_SAFE_INTEGER, 0),
  };
}
async function importPosts(fileOrFiles) {
  if (state.importInProgress) return;
  const files = Array.isArray(fileOrFiles) ? fileOrFiles : [fileOrFiles];
  if (!files.length) return;
  if (files.some((file) => !file || file.size > MAX_IMPORT_FILE_BYTES)) {
    uiAlert('导入失败：备份文件不能超过 25 MB。');
    return;
  }
  state.importInProgress = true;
  const initialDbWriteFailureVersion = state.dbWriteFailureVersion || 0;
  const session = { settingsHandled: false, added: 0, merged: 0, skipped: 0, trimmed: 0, completed: 0 };
  try {
    for (const file of files) {
      const result = await importPostFile(file, session);
      if ((state.dbWriteFailureVersion || 0) !== initialDbWriteFailureVersion) {
        throw state.lastDbWriteError || new Error('IndexedDB write failed');
      }
      for (const key of ['added', 'merged', 'skipped', 'trimmed']) session[key] += result[key];
      session.completed++;
    }
    state.posts = (await dbGetAllPosts()).map(sanitizeImportedPost).filter(Boolean)
      .sort((a, b) => (b.lastCapturedAt || 0) - (a.lastCapturedAt || 0));
    rebuildPostIndex();
    bumpKeywordCache();
    resetPaging();
    refreshUI();
    const trimmedMessage = session.trimmed ? `，按最大条数清理 ${session.trimmed} 条` : '';
    uiAlert(`导入完成：新增 ${session.added} 条，合并 ${session.merged} 条，跳过 ${session.skipped} 条无效记录${trimmedMessage}。`);
    return true;
  } catch (err) {
    console.error('[BetterX] import failed:', err);
    const message = (state.dbWriteFailureVersion || 0) !== initialDbWriteFailureVersion
      ? '导入失败：数据未能写入浏览器存储，请检查可用空间后重试。'
      : err.message === 'IMPORT_POST_LIMIT'
        ? `导入失败：单次最多允许 ${MAX_IMPORT_POSTS} 条帖子。`
        : '导入失败：文件解析出错。';
    uiAlert(session.completed ? `${uiText(message)}\n${uiText('此前已导入的分卷会保留，可重新选择文件继续恢复。')}` : message);
    return false;
  } finally {
    state.importInProgress = false;
  }
}
async function importPostFile(file, session) {
  const parsed = JSON.parse(await file.text());
  let posts = [];
  let importedSettings = null;
  if (Array.isArray(parsed)) posts = parsed;
  else if (parsed && Array.isArray(parsed.posts)) { posts = parsed.posts; importedSettings = parsed.settings || null; }
  else throw new Error('IMPORT_FORMAT');
  if (posts.length > MAX_IMPORT_POSTS) throw new Error('IMPORT_POST_LIMIT');
  let added = 0, merged = 0, skipped = 0;
  const postIndexById = new Map(state.posts.map((post, index) => [post.id, index]));
  const postsToPersist = new Map();
  for (const raw of posts) {
    const imported = sanitizeImportedPost(raw);
    if (!imported) { skipped++; continue; }
    const existingIndex = postIndexById.get(imported.id);
    const existing = existingIndex == null ? null : state.posts[existingIndex];
    if (existing) {
      const combined = {
        ...existing,
        ...imported,
        id: existing.id,
        favorite: existing.favorite || imported.favorite,
        pinned: existing.pinned || imported.pinned,
        clicked: existing.clicked || imported.clicked,
        flashLost: existing.flashLost || imported.flashLost,
        note: existing.note || imported.note,
        sourceHistory: uniqueStrings([...(existing.sourceHistory || []), ...imported.sourceHistory]).slice(-8),
        mediaThumbs: imported.mediaThumbs.length ? imported.mediaThumbs : (existing.mediaThumbs || []),
        avatarUrl: existing.avatarUrl || imported.avatarUrl,
        capturedCount: Math.max(existing.capturedCount || 1, imported.capturedCount),
        firstCapturedAt: Math.min(existing.firstCapturedAt || now(), imported.firstCapturedAt),
        lastCapturedAt: Math.max(existing.lastCapturedAt || 0, imported.lastCapturedAt),
        firstViewedAt: existing.firstViewedAt && imported.firstViewedAt
          ? Math.min(existing.firstViewedAt, imported.firstViewedAt)
          : Math.max(existing.firstViewedAt || 0, imported.firstViewedAt || 0),
        lastViewedAt: Math.max(existing.lastViewedAt || 0, imported.lastViewedAt || 0),
        lastClickedAt: Math.max(existing.lastClickedAt || 0, imported.lastClickedAt || 0),
      };
      state.posts[existingIndex] = combined;
      postsToPersist.set(combined.id, combined);
      merged++;
    } else {
      state.posts.push(imported);
      postIndexById.set(imported.id, state.posts.length - 1);
      postsToPersist.set(imported.id, imported);
      added++;
    }
  }
  rebuildPostIndex();
  if (importedSettings && !session.settingsHandled) {
    session.settingsHandled = true;
    if (uiConfirm('是否同时恢复备份中的设置？')) {
      applySettingsSnapshot(importedSettings, { preserveFirefoxCompatibility: true, force: true });
      queueSettingsPersist();
    }
  }
  const trimmedIds = trimPostsToMax();
  const liveIds = new Set(state.posts.map((post) => post.id));
  const survivingPosts = [...postsToPersist.values()].filter((post) => liveIds.has(post.id));
  queueDbWrite(async () => {
    await dbPutPosts(survivingPosts, { mergeUserState: true });
    await dbDeleteMany(trimmedIds, { preserveProtected: true });
  });
  await state.dbWriteQueue;
  return { added, merged, skipped, trimmed: trimmedIds.length };
}
async function runAutoClean() {
  const days = state.settings.autoCleanDays || 0;
  if (days <= 0) return;
  const cutoff = now() - days * 86400000;
  const toDelete = state.posts.filter((p) => !protectedPost(p) && (p.lastCapturedAt || 0) < cutoff);
  if (!toDelete.length) return;
  state.posts = state.posts.filter((p) => protectedPost(p) || (p.lastCapturedAt || 0) >= cutoff);
  rebuildPostIndex();
  prunePostRuntimeCaches(toDelete.map((p) => p.id));
  await dbDeleteMany(toDelete.map((p) => p.id), { preserveProtected: true });
  debugLog(`自动清理 ${toDelete.length} 条超过 ${days} 天的帖子`);
  refreshUI();
}
function applyTheme() {
  if (!state.rootEl) return;
  let theme = state.settings.theme || 'auto';
  if (theme === 'auto') {
    theme = (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) ? 'light' : 'dark';
  }
  state.rootEl.classList.toggle('BetterX-light', theme === 'light');
}
function applyBadgePos() {
  const pos = state.settings.badgePos;
  if (!state.rootEl || !pos || typeof pos.left !== 'number' || typeof pos.bottom !== 'number') return;
  const badgeWidth = state.badgeEl ? Math.max(1, state.badgeEl.offsetWidth) : 60;
  const badgeHeight = state.badgeEl ? Math.max(1, state.badgeEl.offsetHeight) : 60;
  const anchorRight = Number.isFinite(pos.right) && pos.right < pos.left;
  state.rootEl.style.left = anchorRight ? 'auto'
    : Math.max(4, Math.min(window.innerWidth - badgeWidth - 4, pos.left)) + 'px';
  state.rootEl.style.right = anchorRight
    ? Math.max(4, Math.min(window.innerWidth - badgeWidth - 4, pos.right)) + 'px' : 'auto';
  state.rootEl.style.bottom = Math.max(4, Math.min(window.innerHeight - badgeHeight - 4, pos.bottom)) + 'px';
}
function isMobileBadgeViewport() {
  return window.innerWidth <= 640 || /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
}
function stopMobileComposeTracking() {
  if (state.mobileComposeObserver) state.mobileComposeObserver.disconnect();
  if (state.mobileComposeResizeObserver) state.mobileComposeResizeObserver.disconnect();
  state.mobileComposeObserver = null;
  state.mobileComposeResizeObserver = null;
  state.mobileComposeEl = null;
  state.mobileComposeOpacityEl = null;
  if (state.mobileBadgeRaf) cancelAnimationFrame(state.mobileBadgeRaf);
  state.mobileBadgeRaf = 0;
}
function findMobileComposeButton() {
  const isVisibleCandidate = (el) => {
    if (!(el instanceof HTMLElement) || !el.isConnected) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  };
  const primary = [...document.querySelectorAll('[data-testid="FloatingActionButtons_Tweet_Button"]')]
    .find(isVisibleCandidate);
  if (primary) return primary;
  return [...document.querySelectorAll('a[href="/compose/post"][role="link"]')]
    .find(isVisibleCandidate) || null;
}
function ensureMobileComposeTracking(composeEl, opacityEl) {
  if (state.mobileComposeEl === composeEl && state.mobileComposeOpacityEl === opacityEl) return;
  if (state.mobileComposeObserver) state.mobileComposeObserver.disconnect();
  if (state.mobileComposeResizeObserver) state.mobileComposeResizeObserver.disconnect();
  state.mobileComposeEl = composeEl;
  state.mobileComposeOpacityEl = opacityEl;
  state.mobileComposeObserver = new MutationObserver(() => scheduleMobileBadgeSync());
  state.mobileComposeObserver.observe(opacityEl, {
    attributes: true,
    attributeFilter: ['style', 'class'],
  });
  if (typeof ResizeObserver === 'function') {
    state.mobileComposeResizeObserver = new ResizeObserver(() => scheduleMobileBadgeSync());
    state.mobileComposeResizeObserver.observe(composeEl);
    if (opacityEl !== composeEl) state.mobileComposeResizeObserver.observe(opacityEl);
  }
}
function syncMobileBadgeToComposeButton() {
  if (!state.rootEl || !state.badgeEl || !state.rootEl.classList.contains('BetterX-mobile')) return;
  if (state.rootEl.classList.contains('BetterX-mobile-badge-collapsed')) return;
  const composeEl = findMobileComposeButton();
  if (!composeEl) {
    if (state.mobileComposeEl) stopMobileComposeTracking();
    state.rootEl.style.left = 'auto';
    state.rootEl.style.right = '16px';
    state.rootEl.style.bottom = '84px';
    state.rootEl.style.setProperty('--xv-mobile-badge-opacity', '1');
    state.rootEl.classList.remove('BetterX-mobile-badge-inactive');
    return;
  }
  const opacityEl = composeEl.closest('[data-testid="FloatingActionButtonBase"]') || composeEl;
  ensureMobileComposeTracking(composeEl, opacityEl);
  const rect = composeEl.getBoundingClientRect();
  const badgeWidth = Math.max(1, state.badgeEl.offsetWidth || 52);
  const badgeHeight = Math.max(1, state.badgeEl.offsetHeight || 52);
  const safeDistance = 8;
  const gap = 10;
  const desiredLeft = rect.left + (rect.width - badgeWidth) / 2;
  const clampedLeft = Math.max(safeDistance, Math.min(window.innerWidth - badgeWidth - safeDistance, desiredLeft));
  const desiredBottom = window.innerHeight - rect.top + gap;
  const clampedBottom = Math.max(safeDistance, Math.min(window.innerHeight - badgeHeight - safeDistance, desiredBottom));
  state.rootEl.style.left = 'auto';
  state.rootEl.style.right = Math.max(safeDistance, window.innerWidth - clampedLeft - badgeWidth) + 'px';
  state.rootEl.style.bottom = clampedBottom + 'px';
  const inlineOpacity = parseFloat(opacityEl.style.opacity);
  const computedOpacity = parseFloat(getComputedStyle(opacityEl).opacity);
  const opacity = Math.max(0, Math.min(1,
    Number.isFinite(inlineOpacity) ? inlineOpacity : (Number.isFinite(computedOpacity) ? computedOpacity : 1)
  ));
  state.rootEl.style.setProperty('--xv-mobile-badge-opacity', String(opacity));
  state.rootEl.classList.toggle('BetterX-mobile-badge-inactive', opacity <= 0.05);
}
function scheduleMobileBadgeSync() {
  if (state.mobileBadgeRaf || !state.rootEl || !state.rootEl.classList.contains('BetterX-mobile')) return;
  state.mobileBadgeRaf = requestAnimationFrame(() => {
    state.mobileBadgeRaf = 0;
    syncMobileBadgeToComposeButton();
  });
}
function updatePanelPlacement() {
  if (!state.rootEl || !state.badgeEl || !state.panelEl) return;
  if (state.rootEl.classList.contains('BetterX-mobile')) {
    state.rootEl.classList.remove('BetterX-panel-right');
    state.panelEl.style.width = '';
    state.panelEl.style.left = '';
    state.panelEl.style.right = '';
    state.panelEl.style.top = '';
    state.panelEl.style.bottom = '';
    return;
  }
  const rect = state.badgeEl.getBoundingClientRect();
  const panelWidth = Math.min(window.innerWidth - 24,
    clampInt(state.settings.panelWidth, 420, 1200, DEFAULT_SETTINGS.panelWidth));
  const safeDistance = 12;
  const maxLeft = Math.max(safeDistance, window.innerWidth - panelWidth - safeDistance);
  const preferredLeft = rect.left + panelWidth > window.innerWidth - safeDistance
    ? rect.right - panelWidth
    : rect.left;
  const panelLeft = Math.max(safeDistance, Math.min(maxLeft, preferredLeft));
  const alignRight = preferredLeft < rect.left;
  state.rootEl.classList.toggle('BetterX-panel-right', alignRight);
  state.panelEl.style.width = panelWidth + 'px';
  state.panelEl.style.left = panelLeft + 'px';
  state.panelEl.style.right = 'auto';
  state.panelEl.style.top = safeDistance + 'px';
  state.panelEl.style.bottom = safeDistance + 'px';
}
function makePanelResizable() {
  const panel = state.panelEl;
  if (!panel) return;
  panel.querySelectorAll('[data-resize-edge]').forEach((handle) => {
    const edge = handle.getAttribute('data-resize-edge');
    let pointerId = null;
    let startX = 0, startLeft = 0, startWidth = 0, currentWidth = 0, maxWidth = 0;
    handle.addEventListener('pointerdown', (event) => {
      if (event.button !== 0 || isMobileBadgeViewport() || !state.panelOpen) return;
      event.preventDefault();
      event.stopPropagation();
      const rect = panel.getBoundingClientRect();
      pointerId = event.pointerId;
      startX = event.clientX;
      startLeft = rect.left;
      startWidth = rect.width;
      currentWidth = startWidth;
      maxWidth = Math.max(420, Math.min(1200, edge === 'left'
        ? rect.right - 12 : window.innerWidth - rect.left - 12));
      try { handle.setPointerCapture(pointerId); } catch (err) {}
    });
    handle.addEventListener('pointermove', (event) => {
      if (pointerId !== event.pointerId) return;
      event.preventDefault();
      const delta = edge === 'left' ? startX - event.clientX : event.clientX - startX;
      currentWidth = Math.round(Math.max(420, Math.min(maxWidth, startWidth + delta)));
      panel.style.width = currentWidth + 'px';
      if (edge === 'left') panel.style.left = Math.round(startLeft + startWidth - currentWidth) + 'px';
    });
    const endResize = (event) => {
      if (pointerId !== event.pointerId) return;
      if (event.type === 'pointercancel') {
        panel.style.width = Math.round(startWidth) + 'px';
        panel.style.left = Math.round(startLeft) + 'px';
      } else if (currentWidth !== startWidth) {
        state.settings.panelWidth = currentWidth;
        queueSettingsPersist(['panelWidth']);
      }
      try { handle.releasePointerCapture(pointerId); } catch (err) {}
      pointerId = null;
    };
    handle.addEventListener('pointerup', endResize);
    handle.addEventListener('pointercancel', endResize);
  });
}
function getMobileBadgeHandleTop(preferredTop) {
  const badgeHeight = Math.max(1, state.badgeEl ? state.badgeEl.offsetHeight : 74);
  const minTop = 12;
  const maxTop = Math.max(minTop, window.innerHeight - badgeHeight - 12);
  const fallbackTop = Math.round(window.innerHeight / 2 - badgeHeight / 2);
  const storedTop = state.settings.mobileBadgeHandleTop;
  const savedTop = Number.isFinite(preferredTop)
    ? Number(preferredTop)
    : (Number.isFinite(storedTop) ? Number(storedTop) : NaN);
  const desiredTop = Number.isFinite(savedTop) ? savedTop : fallbackTop;
  return Math.round(Math.max(minTop, Math.min(maxTop, desiredTop)));
}
function repositionBadge() {
  if (!state.badgeEl || !state.rootEl) return;
  const isMobile = isMobileBadgeViewport();
  const collapseMobileBadge = isMobile && (!!state.settings.hideAppBadge || !!state.settings.useMobileBadgeHandle);
  const hideDesktopBadge = !isMobile && !!state.settings.hideAppBadge;
  state.rootEl.classList.toggle('BetterX-desktop-badge-hidden', hideDesktopBadge);
  state.rootEl.classList.toggle('BetterX-mobile-badge-collapsed', collapseMobileBadge);
  const useIconBadge = isMobile || !!state.settings.useMobileBadgeOnDesktop;
  state.badgeEl.classList.toggle('mobile-mode', useIconBadge);
  state.badgeEl.classList.toggle('desktop-icon-mode', !isMobile && useIconBadge);
  refreshBadge();
  if (isMobile) {
    state.rootEl.classList.add('BetterX-mobile');
    if (collapseMobileBadge) {
      stopMobileComposeTracking();
      state.rootEl.style.left = 'auto';
      state.rootEl.style.right = '0';
      state.rootEl.style.top = getMobileBadgeHandleTop() + 'px';
      state.rootEl.style.bottom = 'auto';
      state.rootEl.style.setProperty('--xv-mobile-badge-opacity', '1');
      state.rootEl.classList.remove('BetterX-mobile-badge-inactive');
    } else {
      state.rootEl.style.top = '';
      syncMobileBadgeToComposeButton();
    }
  } else {
    stopMobileComposeTracking();
    state.rootEl.classList.remove('BetterX-mobile');
    state.rootEl.classList.remove('BetterX-mobile-badge-collapsed');
    state.rootEl.classList.remove('BetterX-mobile-badge-inactive');
    state.rootEl.style.removeProperty('--xv-mobile-badge-opacity');
    state.rootEl.style.left = '';
    state.rootEl.style.right = '';
    state.rootEl.style.top = '';
    state.rootEl.style.bottom = '';
    applyBadgePos();
  }
  updateBadgeToggleLabel();
  updatePanelPlacement();
  scheduleDownloadUiRefresh();
}
function makeBadgeDraggable() {
  const badge = state.badgeEl;
  if (!badge) return;
  let startX = 0, startY = 0, origLeft = 0, origBottom = 0, dragging = false, moved = false;
  let desktopPointerId = null;
  let mobilePointerId = null, mobileStartX = 0, mobileStartY = 0, mobileLongPressTimer = null;
  let mobileDragging = false, mobileCaptured = false;
  const clearMobileLongPress = () => {
    if (mobileLongPressTimer) clearTimeout(mobileLongPressTimer);
    mobileLongPressTimer = null;
  };
  badge.addEventListener('dragstart', (e) => e.preventDefault());
  badge.addEventListener('contextmenu', (e) => {
    if (state.rootEl && state.rootEl.classList.contains('BetterX-mobile-badge-collapsed')) e.preventDefault();
  });
  badge.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || e.isPrimary === false || dragging || mobilePointerId !== null) return;
    if (state.rootEl && state.rootEl.classList.contains('BetterX-mobile')) {
      if (!state.rootEl.classList.contains('BetterX-mobile-badge-collapsed')) return;
      mobilePointerId = e.pointerId;
      mobileStartX = e.clientX;
      mobileStartY = e.clientY;
      mobileDragging = false;
      mobileCaptured = false;
      clearMobileLongPress();
      mobileLongPressTimer = setTimeout(() => {
        if (mobilePointerId !== e.pointerId) return;
        mobileLongPressTimer = null;
        mobileDragging = true;
        try {
          badge.setPointerCapture(e.pointerId);
          mobileCaptured = true;
        } catch (err) {}
        state.suppressNextBadgeClick = true;
        badge.classList.add('is-mobile-dragging');
      }, 450);
      return;
    }
    dragging = true; moved = false;
    desktopPointerId = e.pointerId;
    badge.classList.add('is-dragging');
    startX = e.clientX; startY = e.clientY;
    const rect = badge.getBoundingClientRect();
    origLeft = rect.left;
    origBottom = window.innerHeight - rect.bottom;
    try { badge.setPointerCapture(e.pointerId); } catch (err) {}
  });
  badge.addEventListener('pointermove', (e) => {
    if (mobilePointerId === e.pointerId) {
      if (!mobileDragging) {
        if (Math.abs(e.clientX - mobileStartX) > 10 || Math.abs(e.clientY - mobileStartY) > 10) {
          clearMobileLongPress();
          mobilePointerId = null;
        }
        return;
      }
      const badgeHeight = Math.max(1, badge.offsetHeight);
      const top = Math.max(12, Math.min(window.innerHeight - badgeHeight - 12, e.clientY - badgeHeight / 2));
      state.rootEl.style.top = Math.round(top) + 'px';
      return;
    }
    if (!dragging || desktopPointerId !== e.pointerId) return;
    if (state.rootEl.classList.contains('BetterX-mobile')) { end(e); return; }
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) moved = true;
    if (!moved) return;
    const badgeWidth = Math.max(1, badge.offsetWidth);
    const badgeHeight = Math.max(1, badge.offsetHeight);
    const left = Math.max(4, Math.min(window.innerWidth - badgeWidth - 4, origLeft + dx));
    const bottom = Math.max(4, Math.min(window.innerHeight - badgeHeight - 4, origBottom - dy));
    state.rootEl.style.left = left + 'px';
    state.rootEl.style.right = 'auto';
    state.rootEl.style.bottom = bottom + 'px';
    updatePanelPlacement();
  });
  const end = (e) => {
    if (e && mobilePointerId === e.pointerId) {
      clearMobileLongPress();
      if (mobileDragging && e.type === 'pointerup') {
        state.settings.mobileBadgeHandleTop = getMobileBadgeHandleTop(parseFloat(state.rootEl.style.top));
        queueSettingsPersist(['mobileBadgeHandleTop']);
      } else if (mobileDragging) {
        repositionBadge();
      }
      if (mobileCaptured) {
        try { badge.releasePointerCapture(e.pointerId); } catch (err) {}
      }
      mobilePointerId = null;
      mobileDragging = false;
      mobileCaptured = false;
      badge.classList.remove('is-mobile-dragging');
      return;
    }
    if (!dragging || desktopPointerId !== e.pointerId) return;
    dragging = false;
    desktopPointerId = null;
    badge.classList.remove('is-dragging');
    if (e.type !== 'pointerup' || state.rootEl.classList.contains('BetterX-mobile')) {
      repositionBadge();
    } else if (moved) {
      const rect = badge.getBoundingClientRect();
      state.settings.badgePos = { left: rect.left, bottom: window.innerHeight - rect.bottom,
        right: Math.max(0, window.innerWidth - rect.right) };
      queueSettingsPersist(['badgePos']);
      badge.addEventListener('click', (ev) => { ev.stopImmediatePropagation(); ev.preventDefault(); }, { once: true, capture: true });
    }
    try { badge.releasePointerCapture(e.pointerId); } catch (err) {}
  };
  badge.addEventListener('pointerup', end);
  badge.addEventListener('pointercancel', end);
  badge.addEventListener('lostpointercapture', end);
}
function revealMobileBadge() {
  if (!isMobileBadgeViewport() || !state.settings.hideAppBadge) return false;
  setSettingsPartial({ hideAppBadge: false });
  showToast('已恢复应用徽标');
  return true;
}
function installMobileBadgeRevealGesture() {
  let edgeStart = null;
  document.addEventListener('pointerdown', (event) => {
    if (!event.isPrimary || event.pointerType === 'mouse' || !isMobileBadgeViewport() || !state.settings.hideAppBadge) return;
    if (event.clientX < window.innerWidth - 24) return;
    edgeStart = {
      pointerId: event.pointerId,
      x: event.clientX,
      y: event.clientY,
      startsOnBadge: !!(state.badgeEl && state.badgeEl.contains(event.target)),
    };
  }, true);
  document.addEventListener('pointerup', (event) => {
    if (!edgeStart || event.pointerId !== edgeStart.pointerId) return;
    const deltaX = edgeStart.x - event.clientX;
    const deltaY = Math.abs(edgeStart.y - event.clientY);
    const startsOnBadge = edgeStart.startsOnBadge;
    edgeStart = null;
    if (deltaX >= 32 && deltaY <= 80) {
      state.suppressNextBadgeClick = startsOnBadge;
      revealMobileBadge();
    }
  }, true);
  document.addEventListener('pointercancel', () => { edgeStart = null; }, true);
}
const SETTING_REMOVE_ACTIONS = Object.freeze({ 'remove-keyword': ['keywords', 'data-keyword'], 'remove-exclude-keyword': ['excludeKeywords', 'data-keyword'], 'remove-adultspam-keyword': ['adultSpamKeywords', 'data-keyword'], 'remove-adultspam-whitelist': ['adultSpamWhitelist', 'data-username'], });
function dispatchSettingRemoveAction(action, actionEl) {
  const [settingKey, dataAttribute] = SETTING_REMOVE_ACTIONS[action] || [];
  if (!settingKey) return false;
  const value = actionEl.getAttribute(dataAttribute) || '';
  setSettingsPartial({
    [settingKey]: (state.settings[settingKey] || []).filter((item) => item !== value),
  });
  return true;
}
const PANEL_ACTION_HANDLERS = Object.freeze({ 'set-panel-view': ({ el }) => setPanelView(el.getAttribute('data-view')), 'sync-notification-users': () => syncNotificationSubscriptions(), 'search-notification-users': () => applyNotificationSearch(), 'toggle-notification-pin': ({ el }) => toggleNotificationSubscriptionPinned(el.getAttribute('data-username') || ''), 'toggle-notification-user': ({ el }) => updateNotificationSubscription( el.getAttribute('data-username') || '', el.getAttribute('data-enabled') === 'true' ), 'forget-notification-user': ({ el }) => removeRememberedNotificationSubscription(el.getAttribute('data-username') || ''), 'menu-toggle': () => { if (state.menuEl) state.menuEl.hidden = !state.menuEl.hidden; }, close: () => togglePanel(false), refresh: () => { scanArticles(document); refreshUI(); }, 'switch-language': () => showLanguageDialog(), export: () => exportPosts(), backup: () => backupAll(), import: () => state.importInputEl.click(), 'clear-non-fav': () => clearNonFavoritePosts(), 'set-filter': ({ el }) => setSettingsPartial({ filter: el.getAttribute('data-filter') }), 'toggle-skip': ({ el }) => { const key = el.getAttribute('data-skip'); const current = state.settings.skipSources || []; setSettingsPartial({ skipSources: current.includes(key) ? current.filter((item) => item !== key) : [...current, key] }); }, 'save-keywords': () => { if (!commitKeywordInput().rejected) showToast('✅ 已保存关键词'); }, 'save-exclude': () => { if (!commitExcludeKeywordInput().rejected) showToast('✅ 已保存排除词'); }, 'save-adultspam-keywords': () => { commitAdultSpamKeywordInput(); showToast('✓ 已保存自定义屏蔽词'); }, 'save-adultspam-whitelist': () => { commitAdultSpamWhitelistInput(); showToast('✓ 已保存账号白名单'); }, 'load-more': () => { state.renderLimit = (state.renderLimit || state.settings.pageSize || 60) + (state.settings.pageSize || 60); refreshUI({ keepScroll: true }); }, 'toggle-expand': ({ id }) => { if (state.expandedPosts.has(id)) state.expandedPosts.delete(id); else state.expandedPosts.add(id); refreshUI({ keepScroll: true }); }, 'save-note': ({ id }) => { const input = state.listEl.querySelector(`.BetterX-note-input[data-id="${id}"]`); updatePostNote(id, input ? input.value.trim() : ''); }, 'cancel-note': () => { state.noteDrafts.delete(state.editingNoteId); state.editingNoteId = null; refreshUI({ keepScroll: true }); }, open: ({ id }) => openRecordedPost(getPostById(id)), pin: ({ id }) => togglePin(id), fav: ({ id }) => toggleFavorite(id), delete: ({ id }) => deletePost(id), 'mark-all-read': () => { const unreadPosts = filterPosts(state.posts).filter((post) => !post.clicked); if (!unreadPosts.length) { uiAlert('当前列表没有未读的帖子喂～'); return; } if (!uiConfirm('确定要把当前列表的 ' + unreadPosts.length + ' 条未读帖子全部标为已读吗？')) return; markPostsRead(unreadPosts.map((post) => post.id)); showToast('✅ 已将当前列表全部标为已读'); }, 'preview-image': ({ el }) => { const rawUrl = el.getAttribute('data-image-url') || ''; const postId = el.getAttribute('data-post-id') || ''; const post = postId ? getPostById(postId) : null; const imageUrls = post ? uniqueStrings((post.mediaThumbs || []).map(safeImportedAssetUrl).filter(Boolean)).slice(0, 4) : [rawUrl]; const imageIndex = parseInt(el.getAttribute('data-image-index') || '0', 10); showImagePreview(rawUrl, imageUrls, imageIndex); }, 'save-layout': () => { const timelineWidth = readIntegerSetting(state.timelineWidthEl, 'timelineWidth'); const leftbarWidth = readIntegerSetting(state.leftbarWidthEl, 'leftbarWidth'); setSettingsPartial({ layoutAutoWidth: false, timelineWidth, leftbarWidth }); showToast('✓ 已切换为手动宽度并应用'); }, 'edit-note': ({ id }) => { state.editingNoteId = id; refreshUI({ keepScroll: true }); setTimeout(() => { const input = state.listEl.querySelector(`.BetterX-note-input[data-id="${id}"]`); if (input) { input.focus(); input.selectionStart = input.value.length; } }, 20); }, copy: ({ el, id }) => { const post = getPostById(id); if (!post || !post.url) return; const manualCopy = () => window.prompt(uiText('复制链接：'), post.url); try { (navigator.clipboard && navigator.clipboard.writeText) ? navigator.clipboard.writeText(post.url).then(() => { el.textContent = uiText('已复制'); setTimeout(() => { el.textContent = uiText('复制链接'); }, 1200); }).catch(manualCopy) : manualCopy(); } catch (err) { manualCopy(); } }, });
function dispatchPanelAction(action, actionEl, id) {
  if (dispatchSettingRemoveAction(action, actionEl)) return true;
  const handler = PANEL_ACTION_HANDLERS[action];
  if (!handler) return false;
  handler({ el: actionEl, id });
  return true;
}
const PANEL_ELEMENT_IDS = Object.freeze({ listEl: 'list', summaryEl: 'summary', filterBarEl: 'filter-bar', quickFilterDetailsEl: 'quick-filter', quickFilterStateEl: 'quick-filter-state', keywordInputEl: 'keywords', keywordTagsEl: 'keyword-tags', excludeInputEl: 'exclude', excludeKeywordTagsEl: 'exclude-keyword-tags', searchEl: 'search', sortHintEl: 'sort-hint', autoCleanInputEl: 'autoclean', maxPostsInputEl: 'maxposts', flashMsInputEl: 'flashms', skipSourcesEl: 'skip-sources', adultSpamKeywordsEl: 'adultspam-keywords', adultSpamKeywordTagsEl: 'adultspam-keyword-tags', adultSpamWhitelistEl: 'adultspam-whitelist', adultSpamWhitelistTagsEl: 'adultspam-whitelist-tags', adultSpamCountEl: 'adultspam-count', notificationListEl: 'notification-list', notificationStatusEl: 'notification-status', notificationSearchEl: 'notification-search', timelineWidthEl: 'timeline-width', leftbarWidthEl: 'leftbar-width', firefoxCompatibilityEl: 'firefox-compat', hideAppBadgeEl: 'hide-app-badge', postLimitWarningEl: 'post-limit-warning', useMobileBadgeHandleEl: 'mobile-badge-handle', menuEl: 'menu', downloadAdvancedDetailsEl: 'download-advanced', downloadAdvancedStateEl: 'download-advanced-state', });
function bindPanelElements(panel) {
  for (const [stateKey, id] of Object.entries(PANEL_ELEMENT_IDS)) {
    state[stateKey] = panel.querySelector(`#BetterX-${id}`);
  }
}
function bindSettingsControls(panel) {
  state.settingsControlBindings = [];
  for (const [settingKey, definition] of Object.entries(SETTINGS_SCHEMA)) {
    const [stateKey, selector, property] = definition.control || [];
    if (!stateKey || !selector || !property) continue;
    const control = panel.querySelector(selector);
    state[stateKey] = control;
    if (!control) continue;
    const view = control.closest?.('[data-view-panel]')?.getAttribute('data-view-panel') || 'settings';
    state.settingsControlBindings.push({ settingKey, definition, property, control, view });
    control.addEventListener('change', () => {
      const value = property === 'checked' ? !!control.checked : control.value;
      const manuallyEnabledAgeBypass = settingKey === 'bypassAgeRestriction'
        && value === true && state.settings.bypassAgeRestriction !== true;
      setSettingsPartial({ [settingKey]: value });
      if (manuallyEnabledAgeBypass) navigateToSensitiveContentSettings();
    });
  }
}
function syncSettingsControls(view) {
  for (const { settingKey, definition, property, control, view: controlView } of state.settingsControlBindings || []) {
    if (view && controlView !== view) continue;
    const value = state.settings[settingKey] ?? definition.default;
    control[property] = property === 'checked' ? !!value : String(value);
  }
}
function syncInactiveInput(control, value) {
  if (control && document.activeElement !== control) control.value = String(value);
}
function syncControlProperties(entries) {
  for (const [control, property, value] of entries) {
    if (control) control[property] = value;
  }
}
function readIntegerSetting(control, settingKey, scale = 1, fallbackOverride) {
  const definition = SETTINGS_SCHEMA[settingKey];
  const [, minimum, maximum] = definition.validate;
  const fallback = fallbackOverride ?? state.settings[settingKey] ?? definition.default;
  return clampInt(
    control?.value,
    Math.ceil(minimum / scale),
    Math.floor(maximum / scale),
    Math.round(fallback / scale)
  ) * scale;
}
function handleDownloadPopoverAction(event, downloadPopover) {
  if (!event || !downloadPopover) return false;
  if (event.type === 'pointerdown' && Number.isFinite(event.button) && event.button !== 0) return false;
  const actionEl = event.target && event.target.closest ? event.target.closest('[data-action]') : null;
  if (!actionEl || !downloadPopover.contains(actionEl)) return false;
  const action = actionEl.getAttribute('data-action');
  if (action !== 'download-cancel' && action !== 'download-retry') return false;
  event.preventDefault();
  event.stopPropagation();
  if (typeof event.stopImmediatePropagation === 'function') event.stopImmediatePropagation();
  const jobId = actionEl.getAttribute('data-job-id');
  if (action === 'download-cancel') cancelDownloadJob(jobId);
  else retryDownloadJob(jobId);
  return true;
}
function renderAdultSpamKeywordTags() {
  renderTagList({
    container: state.adultSpamKeywordTagsEl,
    values: state.settings.adultSpamKeywords,
    action: 'remove-adultspam-keyword',
    dataAttribute: 'data-keyword',
    removeLabel: '屏蔽词',
  });
}
function renderTagList({
  container, values, action, dataAttribute, removeLabel, formatLabel = (value) => value,
}) {
  if (!container) return;
  container.textContent = '';
  for (const value of values || []) {
    const tag = document.createElement('span');
    tag.className = 'BetterX-keyword-tag';
    const label = document.createElement('span');
    label.className = 'BetterX-keyword-tag-label';
    label.textContent = formatLabel(value);
    const removeButton = document.createElement('button');
    removeButton.type = 'button';
    removeButton.className = 'BetterX-keyword-tag-remove';
    removeButton.setAttribute('data-action', action);
    removeButton.setAttribute(dataAttribute, value);
    removeButton.setAttribute('aria-label', uiText(`删除${removeLabel} ${formatLabel(value)}`));
    removeButton.title = uiText(`删除“${formatLabel(value)}”`);
    removeButton.textContent = '×';
    tag.append(label, removeButton);
    container.appendChild(tag);
  }
}
function renderSavedKeywordTags() {
  renderTagList({
    container: state.keywordTagsEl,
    values: state.settings.keywords,
    action: 'remove-keyword',
    dataAttribute: 'data-keyword',
    removeLabel: '关键词',
  });
}
function renderSavedExcludeKeywordTags() {
  renderTagList({
    container: state.excludeKeywordTagsEl,
    values: state.settings.excludeKeywords,
    action: 'remove-exclude-keyword',
    dataAttribute: 'data-keyword',
    removeLabel: '排除词',
  });
}
function commitKeywordTagInput(input, settingKey, label) {
  if (!input) return { changed: false, rejected: 0 };
  const parsed = parseKeywordRules(input.value);
  const rejected = parsed.filter((item) => !isSafeKeywordRule(item));
  const accepted = rejected.length ? parsed.filter((item) => isSafeKeywordRule(item)) : parsed;
  input.value = '';
  if (!accepted.length) {
    if (rejected.length) showToast(`⚠️ 已忽略 ${rejected.length} 条高风险或无效正则`, 5000);
    return { changed: false, rejected: rejected.length };
  }
  const current = state.settings[settingKey] || [];
  const combined = uniqueStrings([...current, ...accepted]);
  const next = combined.slice(0, 50);
  const changed = next.length !== current.length || next.some((item, index) => item !== current[index]);
  if (changed) setSettingsPartial({ [settingKey]: next });
  if (combined.length > next.length) showToast(`最多保存 50 个${label}`);
  if (rejected.length) showToast(`⚠️ 已忽略 ${rejected.length} 条高风险或无效正则`, 5000);
  return { changed, rejected: rejected.length };
}
function commitKeywordInput() {
  return commitKeywordTagInput(state.keywordInputEl, 'keywords', '关键词');
}
function commitExcludeKeywordInput() {
  return commitKeywordTagInput(state.excludeInputEl, 'excludeKeywords', '排除词');
}
function commitPlainTagInput({
  input, settingKey, parse, maxItems, pendingLimit = Infinity, limitMessage = '', alwaysCommit = false,
}) {
  if (!input) return false;
  const pending = parse(input.value).slice(0, pendingLimit);
  input.value = '';
  if (!pending.length) return false;
  const current = state.settings[settingKey] || [];
  const combined = uniqueStrings([...current, ...pending]);
  const next = combined.slice(0, maxItems);
  const unchanged = next.length === current.length
    && next.every((item, index) => item === current[index]);
  if (unchanged && !alwaysCommit) return false;
  setSettingsPartial({ [settingKey]: next });
  if (limitMessage && combined.length > next.length) showToast(limitMessage);
  return true;
}
function commitAdultSpamKeywordInput() {
  return commitPlainTagInput({
    input: state.adultSpamKeywordsEl,
    settingKey: 'adultSpamKeywords',
    parse: (raw) => parseKeywords(raw).map((item) => item.slice(0, 80)),
    maxItems: 50,
    limitMessage: '最多保存 50 个自定义屏蔽词',
  });
}
function renderAdultSpamWhitelistTags() {
  renderTagList({
    container: state.adultSpamWhitelistTagsEl,
    values: state.settings.adultSpamWhitelist,
    action: 'remove-adultspam-whitelist',
    dataAttribute: 'data-username',
    removeLabel: '白名单账号',
    formatLabel: (username) => `@${username}`,
  });
}
function commitAdultSpamWhitelistInput() {
  return commitPlainTagInput({
    input: state.adultSpamWhitelistEl,
    settingKey: 'adultSpamWhitelist',
    parse: parseAdultSpamWhitelist,
    maxItems: 100,
    pendingLimit: 100,
    alwaysCommit: true,
  });
}
function bindTagCommitInput(input, commit) {
  if (!input) return;
  input.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter' || event.isComposing) return;
    event.preventDefault();
    commit();
  });
  input.addEventListener('blur', commit);
}
function installHorizontalFilterScroller(el) {
  if (!el) return;
  el.addEventListener('wheel', (event) => {
    if (el.scrollWidth <= el.clientWidth + 1) return;
    if (Math.abs(event.deltaX) >= Math.abs(event.deltaY) || event.deltaY === 0) return;
    const maxScrollLeft = Math.max(0, el.scrollWidth - el.clientWidth);
    const canMove = event.deltaY > 0 ? el.scrollLeft < maxScrollLeft - 1 : el.scrollLeft > 1;
    if (!canMove) return;
    event.preventDefault();
    el.scrollLeft = Math.max(0, Math.min(maxScrollLeft, el.scrollLeft + event.deltaY));
  }, { passive: false });
  let pointerId = null;
  let startX = 0;
  let startScrollLeft = 0;
  let dragged = false;
  let captured = false;
  let suppressClickUntil = 0;
  el.addEventListener('pointerdown', (event) => {
    if (event.pointerType !== 'mouse' || event.button !== 0 || el.scrollWidth <= el.clientWidth + 1) return;
    pointerId = event.pointerId;
    startX = event.clientX;
    startScrollLeft = el.scrollLeft;
    dragged = false;
    captured = false;
  });
  el.addEventListener('pointermove', (event) => {
    if (pointerId !== event.pointerId) return;
    const delta = event.clientX - startX;
    if (!dragged && Math.abs(delta) < 5) return;
    if (!dragged) {
      dragged = true;
      try {
        el.setPointerCapture(pointerId);
        captured = true;
      } catch (err) {}
      el.classList.add('is-dragging');
    }
    event.preventDefault();
    el.scrollLeft = startScrollLeft - delta;
  });
  const finishDrag = (event) => {
    if (pointerId !== event.pointerId) return;
    if (dragged) suppressClickUntil = performance.now() + 120;
    if (captured) {
      try { el.releasePointerCapture(pointerId); } catch (err) {}
    }
    pointerId = null;
    dragged = false;
    captured = false;
    el.classList.remove('is-dragging');
  };
  el.addEventListener('pointerup', finishDrag);
  el.addEventListener('pointercancel', finishDrag);
  el.addEventListener('click', (event) => {
    if (performance.now() >= suppressClickUntil) return;
    event.preventDefault();
    event.stopPropagation();
  }, true);
}
function createUI() {
  const root = document.createElement('div');
  root.id = 'BetterX-root';
  const badge = document.createElement('button');
  badge.id = 'BetterX-badge';
  badge.type = 'button';
  badge.textContent = uiText('更好的 X（BetterX）');
  const panel = document.createElement('div');
  panel.id = 'BetterX-panel';
  panel.style.display = 'none';
  panel.innerHTML = uiHtml`<div class="BetterX-panel-resize-handle BetterX-panel-resize-left" data-resize-edge="left" aria-hidden="true"></div> <div class="BetterX-panel-resize-handle BetterX-panel-resize-right" data-resize-edge="right" aria-hidden="true"></div> <div class="BetterX-header"> <div class="BetterX-title"> <div class="BetterX-title-main"> ${APP_ICON_URL ? `<img class="BetterX-title-icon" src="${escapeHtml(APP_ICON_URL)}" alt="" draggable="false" />` : ''} <span>更好的 X</span> </div> <div class="BetterX-title-sub">BetterX · Alt+X 开关</div> </div> <div class="BetterX-header-actions"> <button class="BetterX-btn BetterX-vault-action" data-action="refresh" title="重新扫描当前页面">刷新</button> <button class="BetterX-btn BetterX-vault-action" data-action="mark-all-read" title="把当前列表全部标为已读">全部已读</button> <button class="BetterX-btn" data-action="switch-language" title="切换 BetterX 界面语言">切换语言</button> <div class="BetterX-menu-wrap"> <button class="BetterX-btn BetterX-icon-btn" data-action="menu-toggle" aria-label="更多" title="更多">⋯</button> <div class="BetterX-menu" id="BetterX-menu" hidden> <button class="BetterX-menu-item" data-action="export">📤 导出筛选</button> <button class="BetterX-menu-item" data-action="backup">💾 备份全部</button> <button class="BetterX-menu-item" data-action="import">📥 导入</button> <button class="BetterX-menu-item danger" data-action="clear-non-fav">🗑️ 清空</button> </div> </div> <button class="BetterX-btn BetterX-icon-btn" data-action="close" aria-label="关闭" title="关闭">✕</button> </div> </div> <div class="BetterX-tabs" role="tablist" aria-label="BetterX 面板"> <button class="BetterX-tab active" type="button" role="tab" aria-selected="true" data-action="set-panel-view" data-view="vault">帖子</button> <button class="BetterX-tab" type="button" role="tab" aria-selected="false" data-action="set-panel-view" data-view="notifications">通知</button> <button class="BetterX-tab" type="button" role="tab" aria-selected="false" data-action="set-panel-view" data-view="settings">设置</button> </div> <section class="BetterX-view BetterX-vault-view" data-view-panel="vault"> <div class="BetterX-vault-toolbar"> <div class="BetterX-tip">提示：列表仅记录你浏览时出现过的帖子。收藏/置顶的帖子不会被上限删除或自动清理。</div> <div class="BetterX-summary" id="BetterX-summary"></div> <details class="BetterX-advanced BetterX-vault-filter-card" id="BetterX-quick-filter"> <summary><span class="BetterX-vault-filter-title">快速筛选</span><span class="BetterX-vault-filter-state" id="BetterX-quick-filter-state"></span></summary> <div class="BetterX-adv-body BetterX-vault-filter-body"> <div class="BetterX-filter-bar" id="BetterX-filter-bar"></div> <div class="BetterX-search-tools"> <input type="text" class="BetterX-input" id="BetterX-search" placeholder="搜索作者、正文或备注…" aria-label="搜索帖子" /> <div class="BetterX-toolbar-row"> <select class="BetterX-select" id="BetterX-source" aria-label="来源筛选"></select> <select class="BetterX-select" id="BetterX-media" aria-label="媒体筛选"></select> <select class="BetterX-select" id="BetterX-sort" aria-label="排序方式"> <option value="smart">智能排序</option> <option value="recent_viewed">最近浏览</option> <option value="recent_captured">最近抓取</option> <option value="first_captured">首次抓取（新→旧）</option> <option value="time_asc">首次抓取（旧→新）</option> <option value="captures">出现次数</option> <option value="author">按作者</option> <option value="source">按来源</option> </select> </div> <div class="BetterX-sort-hint" id="BetterX-sort-hint" role="status"></div> </div> </div> </details> </div> <div class="BetterX-list" id="BetterX-list"></div> </section> <section class="BetterX-view BetterX-notifications-view" data-view-panel="notifications" hidden> <div class="BetterX-notification-toolbar"> <div class="BetterX-settings-intro"> <strong>帖子通知管理</strong> <span>读取 X 的铃铛订阅状态；开关操作会同步修改 X 账号设置。本页不会抓取或显示订阅账号的帖子。</span> </div> <div class="BetterX-row BetterX-notification-search-row"> <input type="search" class="BetterX-input" id="BetterX-notification-search" placeholder="搜索用户名或 @用户名…" aria-label="搜索帖子通知用户" maxlength="120" /> <button class="BetterX-btn" data-action="search-notification-users">搜索</button> <button class="BetterX-btn primary" data-action="sync-notification-users">同步订阅用户</button> </div> <br/> <div class="BetterX-content-status" id="BetterX-notification-status">尚未读取订阅用户</div> </div> <div class="BetterX-notification-list" id="BetterX-notification-list"></div> </section> <section class="BetterX-view BetterX-settings-view" data-view-panel="settings" hidden> <div class="BetterX-settings-scroll"> <div class="BetterX-settings-intro"> <strong>设置</strong> <span>大多数设置会立即生效；带“保存”或“应用”按钮的设置需要手动确认。</span> </div> <div class="BetterX-controls"> <details class="BetterX-advanced BetterX-settings-card"> <summary>关键词与排除词</summary> <div class="BetterX-adv-body"> <div class="BetterX-adv-label">只影响 BetterX 已记录的帖子：关键词用来高亮和筛选，排除词会隐藏匹配的帖子。</div> <div class="BetterX-adv-label">普通文字可直接输入；正则表达式请写成 <code>/表达式/</code>，例如 <code>/猫|狗/</code>。两种写法可以混用。</div> <div class="BetterX-tag-editor BetterX-keyword-section"> <div class="BetterX-row BetterX-keyword-input-row"> <input type="text" class="BetterX-input" id="BetterX-keywords" placeholder="输入关键词，支持正则，按回车添加" maxlength="500" /> <select class="BetterX-select" id="BetterX-keyword-mode"> <option value="plain">任意匹配</option> <option value="and">全部匹配</option> </select> <button class="BetterX-btn primary" data-action="save-keywords">保存</button> </div> <div class="BetterX-keyword-tags BetterX-main-keyword-tags" id="BetterX-keyword-tags"></div> </div> <div class="BetterX-tag-editor BetterX-keyword-section"> <div class="BetterX-row BetterX-keyword-input-row"> <input type="text" class="BetterX-input" id="BetterX-exclude" placeholder="输入排除词，支持正则，按回车添加" maxlength="500" /> <button class="BetterX-btn primary" data-action="save-exclude">保存</button> </div> <div class="BetterX-keyword-tags BetterX-main-keyword-tags" id="BetterX-exclude-keyword-tags"></div> </div> </div> </details> <details class="BetterX-advanced BetterX-settings-card"> <summary>内容净化</summary> <div class="BetterX-adv-body"> <div class="BetterX-row BetterX-adultspam-master-row"> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-hide-adult-spam" /> 隐藏黄推 / 成人引流机器人</label> <select class="BetterX-select" id="BetterX-adultspam-level" title="检测强度"> <option value="balanced">均衡</option> <option value="conservative">保守</option> </select> </div> <div class="BetterX-dependent-options" id="BetterX-adultspam-auto-options"> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-adultspam-skip-following" /> 不审查已关注账号（转发内容除外）</label> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-adultspam-skip-following-reposts" /> 不审查已关注账号的转发内容</label> <div class="BetterX-adv-label">根据正文、账号名和引流特征综合判断，只在当前页面隐藏可疑帖子，不会拉黑账号。关闭后会恢复显示。</div> </div> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-adultspam-custom-enabled" /> 启用自定义规则（屏蔽词与账号白名单）</label> <div class="BetterX-dependent-options" id="BetterX-adultspam-custom-options"> <div class="BetterX-tag-editor"> <div class="BetterX-row"> <input type="text" class="BetterX-input" id="BetterX-adultspam-keywords" placeholder="输入自定义屏蔽词，按回车添加" maxlength="500" /> <button class="BetterX-btn primary" data-action="save-adultspam-keywords">保存</button> </div> <div class="BetterX-keyword-tags" id="BetterX-adultspam-keyword-tags"></div> </div> <div class="BetterX-tag-editor"> <div class="BetterX-row"> <input type="text" class="BetterX-input" id="BetterX-adultspam-whitelist" placeholder="输入账号白名单（如 @example），按回车添加" maxlength="500" /> <button class="BetterX-btn primary" data-action="save-adultspam-whitelist">保存</button> </div> <div class="BetterX-keyword-tags" id="BetterX-adultspam-whitelist-tags"></div> </div> </div> <div class="BetterX-content-status" id="BetterX-adultspam-count">当前隐藏 0 · 本次累计 0 · 已扫描 0 · 已识别关注 0</div> </div> </details> <details class="BetterX-advanced BetterX-settings-card"> <summary>界面简化与宽屏</summary> <div class="BetterX-adv-body"> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-layout-enabled" /> 启用界面简化与宽屏</label> <div class="BetterX-dependent-options" id="BetterX-layout-options"> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-layout-auto-width" /> 自动读取 X 当前的时间线与左侧栏宽度（默认开启）</label> <div class="BetterX-row BetterX-control-row"> <label class="BetterX-field">时间线宽度(px) <input type="number" min="100" max="3000" class="BetterX-input small" id="BetterX-timeline-width" /> </label> <label class="BetterX-field">左侧栏宽度(px) <input type="number" min="50" max="500" class="BetterX-input small" id="BetterX-leftbar-width" /> </label> <button class="BetterX-btn primary" data-action="save-layout">应用宽度</button> </div> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-layout-hide-leftbar" /> 隐藏左侧栏</label> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-layout-hide-sidebar" /> 隐藏右侧栏</label> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-layout-fill-center" /> 中间栏填满（启用时同时隐藏左右栏）</label> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-layout-clean-nav" /> 精简导航、Premium 推广与页脚</label> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-layout-hide-message" /> 隐藏右下消息栏 / Grok</label> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-layout-hide-showmore" /> 隐藏帖子“显示更多”（可能影响长文展开，默认关闭）</label> <div class="BetterX-adv-label">在消息页和设置页不会调整布局；关闭此功能即可恢复 X 原来的界面。</div> </div> </div> </details> <details class="BetterX-advanced BetterX-settings-card"> <summary>下载功能</summary> <div class="BetterX-adv-body"> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-mediadl" /> 一键下载图片 / 视频 / GIF</label> <div class="BetterX-adv-label">点击下载按钮保存全部媒体；长按或 Shift+点击可按缩略图选择图片、GIF 和视频。下载时帖子内会显示进度与取消按钮，徽标旁会显示任务提示。</div> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-silent-download" /> 下载时保持静默</label> <div class="BetterX-adv-label">默认关闭；开启后隐藏应用徽标旁的下载任务提示和任务列表，帖子内的下载进度与取消按钮仍可使用。</div> <div class="BetterX-row BetterX-gif-format-row"> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-gif-download-format-enabled" /> GIF内容下载格式</label> <select class="BetterX-select" id="BetterX-gif-download-format" aria-label="GIF内容下载格式"> <option value="mp4">MP4</option> <option value="gif">GIF</option> </select> </div> <div class="BetterX-adv-label">默认开启；关闭时 GIF 内容按原始 MP4 下载。选择 GIF 时会在浏览器内转换，耗时更长、文件更大。</div> <label class="BetterX-field inline BetterX-download-zip-option"><input type="checkbox" id="BetterX-dlzip" /> 下载多个媒体自动压缩 ZIP 包</label> <div class="BetterX-adv-label BetterX-download-zip-option">默认开启；ZIP 内的文件会使用下方“媒体文件名”模板。关闭后会同时下载多个媒体。</div> <label class="BetterX-field inline BetterX-download-history-option"><input type="checkbox" id="BetterX-track-downloaded-posts" /> 记录已经下载过的帖子</label> <div class="BetterX-adv-label BetterX-download-history-option">默认关闭；至少成功下载帖子内一个媒体后会记录并修改该帖子的下载图标。再次点击已记录帖子的下载按钮时，会先询问是否继续下载。</div> <details class="BetterX-advanced BetterX-download-advanced" id="BetterX-download-advanced"> <summary> <span class="BetterX-download-advanced-summary"> <span class="BetterX-download-advanced-title">高级设置</span> <small class="BetterX-download-advanced-subtitle">自定义下载文件/压缩包名</small> </span> <span class="BetterX-download-advanced-state" id="BetterX-download-advanced-state" hidden>已自定义</span> </summary> <div class="BetterX-adv-body"> <label class="BetterX-field">媒体文件名（不含扩展名）<input class="BetterX-input" id="BetterX-download-file-name-template" maxlength="180" spellcheck="false" placeholder="${escapeHtml(localizeDownloadNameTemplate(DEFAULT_SETTINGS.downloadFileNameTemplate))}" /></label> <label class="BetterX-field">ZIP 压缩包名（不含 .zip）<input class="BetterX-input" id="BetterX-download-zip-name-template" maxlength="180" spellcheck="false" placeholder="${escapeHtml(localizeDownloadNameTemplate(DEFAULT_SETTINGS.downloadZipNameTemplate))}" /></label> <div class="BetterX-adv-label">点击变量会插入到当前正在编辑的模板中；同时下载一个帖子内多个媒体文件时若未使用 <code>{序号}</code>，会自动追加序号避免重名。</div> <div class="BetterX-chip-row BetterX-download-name-tokens"> ${DOWNLOAD_NAME_TOKENS.map(({ token, key }) => { const label = escapeHtml(localizeDownloadNameToken(token, key)); return `<button type="button" class="BetterX-chip" data-action="insert-download-name-token" data-token="${label}">${label}</button>`; }).join('')} </div> <label class="BetterX-field">正则替换（可选）<input class="BetterX-input" id="BetterX-download-name-regex" maxlength="180" spellcheck="false" placeholder="例如：[\\s_]+" /></label> <label class="BetterX-field">替换为<input class="BetterX-input" id="BetterX-download-name-replacement" maxlength="180" spellcheck="false" placeholder="例如：_；支持 $1" /></label> <div class="BetterX-adv-label">正则会在变量展开后，对两个名称进行全局替换；支持捕获组替换（如 <code>$1</code>）。无效或高风险的正则不会保存。</div> <div class="BetterX-adv-label BetterX-download-name-preview" id="BetterX-download-name-preview"></div> <div class="BetterX-row"><button class="BetterX-btn primary" data-action="save-download-naming">保存自定义命名设置</button></div> </div> </details> </div> </details> <details class="BetterX-advanced BetterX-settings-card"> <summary>常用功能</summary> <div class="BetterX-adv-body"> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-hide-nfl" /> 关闭NFL</label> <div class="BetterX-adv-label">隐藏 X 右侧栏中的 NFL 球队、赛程和比赛入口；关闭此开关后会恢复显示。</div> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-hideads" /> 关闭广告（含“订阅 Premium”）</label> <div class="BetterX-adv-label">隐藏时间线广告、广告卡片和“订阅 Premium”提示。广告帖子不会保存到 BetterX，关闭后会重新显示。</div> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-restore-media-grid" /> 帖子内媒体改为网格视图</label> <div class="BetterX-adv-label">把帖子里的多张媒体改成网格：2 张并排，3 张左大右二，4 张按 2×2 排列。</div> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-bypassage" /> 取消年龄限制（用原图 / 视频进行替换）</label> <div class="BetterX-adv-label">移除敏感内容遮罩并显示原图或视频；在新打开的窗口里建议勾选上“显示可能含有敏感内容的媒体内容”</div> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-auto-expand-post-text" /> 自动展开帖子里“显示更多”</label> <div class="BetterX-adv-label">自动点开帖子正文里的“显示更多 / Show more”；不会展开回复或侧栏内容。</div> <div class="BetterX-row BetterX-profile-default-view-row"> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-profile-default-view-enabled" /> 进入用户主页默认查看</label> <select class="BetterX-select" id="BetterX-profile-default-view" aria-label="进入用户主页默认查看"> <option value="posts">帖子</option> <option value="all">全部</option> <option value="highlights">亮点</option> <option value="video">视频</option> <option value="photo">图片</option> </select> </div> <div class="BetterX-adv-label">进入用户主页时自动切换到所选页签；帖子详情、回复和关注者页面不受影响。</div> <div class="BetterX-row BetterX-profile-default-view-row"> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-profile-post-sort-enabled" /> 用户主页帖子排序方式</label> <select class="BetterX-select" id="BetterX-profile-post-sort" aria-label="用户主页帖子排序方式"> <option value="recent">最近</option> <option value="popular">热门</option> </select> </div> <div class="BetterX-adv-label">选择“热门”时，会使用 X 的热门排序；视频和图片页不受影响。</div> </div> </details> <details class="BetterX-advanced BetterX-settings-card"> <summary>其他功能</summary> <div class="BetterX-adv-body"> <label class="BetterX-field inline BetterX-firefox-only-setting"><input type="checkbox" id="BetterX-firefox-compat" /> 兼容 Firefox（仅 Firefox）</label> <div class="BetterX-adv-label BetterX-firefox-only-setting">如果 X 一直停在启动图标，可尝试开启。开启后会停用部分网络数据读取；点击开关可先查看影响。</div> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-post-limit-warning" /> 帖子上限提示</label> <div class="BetterX-adv-label">帖子记录接近“最大条数”时提醒你。关闭提醒后，也可以随时在这里重新开启。</div> <label class="BetterX-field inline"><input type="checkbox" id="BetterX-hide-app-badge" /> 隐藏应用徽标</label> <div class="BetterX-adv-label">在电脑上会隐藏徽标；在手机上会收成屏幕右侧的蓝色小条。点击小条、从屏幕右边缘向内滑动，或使用油猴菜单都能恢复。</div> <label class="BetterX-field inline BetterX-desktop-only-setting"><input type="checkbox" id="BetterX-desktop-mobile-badge" /> 切换为移动端徽标（仅 PC）</label> <div class="BetterX-adv-label BetterX-desktop-only-setting">在电脑上使用圆形图标和未读角标，仍可拖动位置。</div> <label class="BetterX-field inline BetterX-mobile-only-setting"><input type="checkbox" id="BetterX-mobile-badge-handle" /> 切换为半透明蓝色条（仅移动端）</label> <div class="BetterX-adv-label BetterX-mobile-only-setting">把手机上的圆形徽标收成右侧蓝色小条；点击打开面板，长按后可上下移动。</div> </div> </details> <details class="BetterX-advanced BetterX-settings-card" id="BetterX-advanced-settings"> <summary>高级设置</summary> <div class="BetterX-adv-body"> <div class="BetterX-adv-label">点亮按钮即不保存对应页面的帖子</div> <div class="BetterX-chip-row" id="BetterX-skip-sources"></div> <div class="BetterX-row"> <label class="BetterX-field">自动清理(天) <input type="number" min="0" class="BetterX-input small" id="BetterX-autoclean" /> </label> <label class="BetterX-field">最大条数 <input type="number" min="50" class="BetterX-input small" id="BetterX-maxposts" /> </label> <label class="BetterX-field">闪现阈值(秒) <input type="number" min="1" class="BetterX-input small" id="BetterX-flashms" /> </label> <label class="BetterX-field">主题 <select class="BetterX-select" id="BetterX-theme"> <option value="auto">跟随系统</option> <option value="dark">深色</option> <option value="light">浅色</option> </select> </label> </div> <div class="BetterX-row BetterX-control-row"> <label class="BetterX-field">下载超时(秒) <input type="number" min="5" class="BetterX-input small" id="BetterX-dltimeout" /> </label> <label class="BetterX-field">下载并发 <input type="number" min="1" max="6" step="1" class="BetterX-input small" id="BetterX-dlconcurrency" /> </label> <button class="BetterX-btn primary" data-action="save-advanced">应用</button> </div> <div class="BetterX-adv-label">下载并发可设为 1～6，默认 2；调高会加快多媒体任务，但也会增加带宽与内存占用。自动清理(天)为0则不自动清理。</div> </div> </details> </div> </div> </section>`;
  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = 'application/json,.json';
  fileInput.multiple = true;
  fileInput.style.display = 'none';
  const downloadPill = document.createElement('button');
  downloadPill.id = 'BetterX-download-pill';
  downloadPill.type = 'button';
  downloadPill.hidden = true;
  downloadPill.setAttribute('aria-label', uiText('查看下载任务'));
  downloadPill.title = uiText('查看下载任务');
  downloadPill.innerHTML = `
      <span class="BetterX-download-pill-icon" aria-hidden="true">⬇</span>
      <span class="BetterX-download-pill-label"></span>
      <span class="BetterX-download-pill-count" hidden></span>
    `;
  const downloadPopover = document.createElement('div');
  downloadPopover.id = 'BetterX-download-popover';
  downloadPopover.hidden = true;
  downloadPopover.setAttribute('role', 'status');
  root.appendChild(panel);
  root.appendChild(badge);
  root.appendChild(downloadPill);
  root.appendChild(downloadPopover);
  root.appendChild(fileInput);
  document.body.appendChild(root);
  state.rootEl = root;
  state.badgeEl = badge;
  state.panelEl = panel;
  state.downloadPillEl = downloadPill;
  state.downloadPopoverEl = downloadPopover;
  state.importInputEl = fileInput;
  bindPanelElements(panel);
  state.dlTimeoutInputEl = panel.querySelector('#BetterX-dltimeout');
  state.dlConcurrencyInputEl = panel.querySelector('#BetterX-dlconcurrency');
  state.mediaDownloadEl = panel.querySelector('#BetterX-mediadl');
  state.downloadZipEl = panel.querySelector('#BetterX-dlzip');
  state.downloadFileNameTemplateEl = panel.querySelector('#BetterX-download-file-name-template');
  state.downloadZipNameTemplateEl = panel.querySelector('#BetterX-download-zip-name-template');
  state.downloadNameRegexEl = panel.querySelector('#BetterX-download-name-regex');
  state.downloadNameReplacementEl = panel.querySelector('#BetterX-download-name-replacement');
  state.downloadNamePreviewEl = panel.querySelector('#BetterX-download-name-preview');
  state.trackDownloadedPostsEl = panel.querySelector('#BetterX-track-downloaded-posts');
  bindSettingsControls(panel);
  installDownloadUiLocalizationFallback(root);
  state.mediaSelectEl.innerHTML = buildMediaOptionsHtml();
  installHorizontalFilterScroller(state.filterBarEl);
  if (state.quickFilterDetailsEl) {
    state.quickFilterDetailsEl.addEventListener('toggle', () => {
      if (!state.settingsLoaded) return;
      const nextOpen = !!state.quickFilterDetailsEl.open;
      if (nextOpen === !!state.settings.quickFilterOpen) return;
      setSettingsPartial({ quickFilterOpen: nextOpen });
    });
  }
  if (state.downloadAdvancedDetailsEl) {
    state.downloadAdvancedDetailsEl.addEventListener('toggle', () => {
      if (!state.settingsLoaded) return;
      const nextOpen = !!state.downloadAdvancedDetailsEl.open;
      if (nextOpen === !!state.settings.downloadAdvancedOpen) return;
      state.settings.downloadAdvancedOpen = nextOpen;
      queueSettingsPersist(['downloadAdvancedOpen']);
    });
  }
  badge.addEventListener('click', () => {
    if (state.suppressNextBadgeClick) {
      state.suppressNextBadgeClick = false;
      return;
    }
    if (!revealMobileBadge()) togglePanel();
  });
  downloadPill.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    toggleDownloadPopover();
  });
  downloadPopover.addEventListener('pointerdown', (event) => handleDownloadPopoverAction(event, downloadPopover), true);
  downloadPopover.addEventListener('click', (event) => handleDownloadPopoverAction(event, downloadPopover), true);
  makeBadgeDraggable();
  makePanelResizable();
  installMobileBadgeRevealGesture();
  root.addEventListener('input', (event) => {
    if (!event.target.matches('.BetterX-note-input[data-id]')) return;
    state.noteDrafts.set(event.target.getAttribute('data-id'), event.target.value);
  });
  state.searchEl.addEventListener('input', debounce((e) => {
    state.searchQuery = e.target.value || '';
    resetPaging();
    refreshUI({ keepScroll: false });
  }, 200));
  [
    [state.keywordInputEl, commitKeywordInput],
    [state.excludeInputEl, commitExcludeKeywordInput],
    [state.adultSpamKeywordsEl, commitAdultSpamKeywordInput],
    [state.adultSpamWhitelistEl, commitAdultSpamWhitelistInput],
  ].forEach(([input, commit]) => bindTagCommitInput(input, commit));
  if (state.notificationSearchEl) {
    state.notificationSearchEl.addEventListener('input', () => {
      state.notificationSearchQuery = safeString(state.notificationSearchEl.value, 120).trim();
      renderNotificationSubscriptions();
    });
    state.notificationSearchEl.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter' || e.isComposing) return;
      e.preventDefault();
      applyNotificationSearch();
    });
  }
  state.firefoxCompatibilityEl.addEventListener('click', (e) => {
    e.preventDefault();
    showFirefoxCompatibilityToggleDialog(!state.settings.firefoxCompatibility);
  });
  state.mediaDownloadEl.addEventListener('change', (e) => setSettingsPartial({ mediaDownload: !!e.target.checked }));
  state.downloadZipEl.addEventListener('change', (e) => setSettingsPartial({ downloadZip: !!e.target.checked }));
  state.trackDownloadedPostsEl.addEventListener('change', (e) => {
    setSettingsPartial({ trackDownloadedPosts: !!e.target.checked });
    scheduleDownloadUiRefresh();
  });
  [state.downloadFileNameTemplateEl, state.downloadZipNameTemplateEl, state.downloadNameRegexEl, state.downloadNameReplacementEl]
    .forEach((input) => input.addEventListener('input', updateDownloadNamingPreview));
  [state.downloadFileNameTemplateEl, state.downloadZipNameTemplateEl].forEach((input) => {
    input.addEventListener('focus', () => { state.downloadNameTemplateTargetEl = input; });
  });
  state.hideAppBadgeEl.addEventListener('change', (e) => {
    setSettingsPartial({
      hideAppBadge: !!e.target.checked,
      ...(e.target.checked ? { useMobileBadgeHandle: false } : {}),
    });
    if (e.target.checked) {
      showToast(isMobileBadgeViewport()
        ? '点击屏幕右侧小蓝条可显示徽标'
        : '应用徽标已隐藏 · Alt+X 或油猴菜单可恢复');
    }
  });
  state.postLimitWarningEl.addEventListener('change', (e) => {
    const enabled = !!e.target.checked;
    postLimitWarningShownForMax = 0;
    if (postLimitWarningTimer) {
      clearTimeout(postLimitWarningTimer);
      postLimitWarningTimer = null;
    }
    setSettingsPartial({ postLimitWarningDisabled: !enabled });
    showToast(enabled ? '已恢复上限提示' : '已关闭上限提示');
    if (enabled) setTimeout(() => maybeShowPostLimitWarning(), 120);
  });
  state.useMobileBadgeHandleEl.addEventListener('change', (e) => {
    setSettingsPartial({
      useMobileBadgeHandle: !!e.target.checked,
      ...(e.target.checked ? { hideAppBadge: false } : {}),
    });
    if (e.target.checked) showToast('已切换为屏幕右侧小蓝条');
  });
  state.importInputEl.addEventListener('change', (e) => {
    const files = [...(e.target.files || [])];
    if (files.length) importPosts(files);
    e.target.value = '';
  });
  root.addEventListener('click', (e) => {
    const actionEl = e.target.closest('[data-action]');
    const clickedAction = actionEl ? actionEl.getAttribute('data-action') : null;
    if (state.menuEl && !state.menuEl.hidden && clickedAction !== 'menu-toggle') state.menuEl.hidden = true;
    if (!actionEl) return;
    const action = actionEl.getAttribute('data-action');
    const id = actionEl.getAttribute('data-id');
    if (dispatchPanelAction(action, actionEl, id)) return;
    switch (action) {
      case 'download-cancel':
        cancelDownloadJob(actionEl.getAttribute('data-job-id'));
        break;
      case 'download-retry':
        retryDownloadJob(actionEl.getAttribute('data-job-id'));
        break;
      case 'insert-download-name-token':
        insertDownloadNameToken(actionEl.getAttribute('data-token') || '');
        break;
      case 'save-download-naming': {
        const fileNameTemplate = normalizeDownloadNameTemplate(safeString(state.downloadFileNameTemplateEl.value, 180).trim()) || DEFAULT_SETTINGS.downloadFileNameTemplate;
        const zipNameTemplate = normalizeDownloadNameTemplate(safeString(state.downloadZipNameTemplateEl.value, 180).trim()) || DEFAULT_SETTINGS.downloadZipNameTemplate;
        const regex = safeString(state.downloadNameRegexEl.value, MAX_REGEX_SOURCE_LENGTH).trim();
        if (regex && !isSafeRegexSource(regex)) {
          showToast('⚠️ 正则无效或风险过高，未保存');
          break;
        }
        setSettingsPartial({
          downloadFileNameTemplate: fileNameTemplate,
          downloadZipNameTemplate: zipNameTemplate,
          downloadNameRegex: regex,
          downloadNameReplacement: safeString(state.downloadNameReplacementEl.value, 180),
        });
        showToast('✅ 已保存下载命名');
        break;
      }
      case 'save-advanced': {
        const maxPosts = readIntegerSetting(state.maxPostsInputEl, 'maxPosts');
        const flashMs = readIntegerSetting(state.flashMsInputEl, 'flashMs', 1000);
        const autoCleanDays = readIntegerSetting(state.autoCleanInputEl, 'autoCleanDays');
        const downloadTimeout = readIntegerSetting(state.dlTimeoutInputEl, 'downloadTimeout', 1000);
        const downloadConcurrency = readIntegerSetting(
          state.dlConcurrencyInputEl, 'downloadConcurrency', 1, DEFAULT_SETTINGS.downloadConcurrency
        );
        setSettingsPartial({ maxPosts, flashMs, autoCleanDays, downloadTimeout, downloadConcurrency });
        pumpDownloadTransferQueue();
        queueDbWrite(enforceMaxPosts);
        runAutoClean();
        showToast('✅ 已应用高级设置');
        break;
      }
      default: break;
    }
  });
  repositionBadge();
  setPanelView(state.panelView);
  refreshUI();
}
function addStyle(css) {
  if (typeof GM_addStyle !== 'undefined') { GM_addStyle(css); return; }
  const style = document.createElement('style');
  style.textContent = css;
  (document.head || document.documentElement).appendChild(style);
}
function installStyles() {
  addStyle(`#BetterX-root { position: fixed; display: flex; left: 16px; bottom: 16px; z-index: 2147483000; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; --xv-panel-bg: rgba(21,24,28,0.98); --xv-text: #e7e9ea; --xv-border: rgba(255,255,255,0.12); --xv-chip-bg: rgba(255,255,255,0.06); --xv-input-bg: rgba(255,255,255,0.06); --xv-muted: rgba(231,233,234,0.62); --xv-item-bg: rgba(255,255,255,0.03); --xv-accent: #1d9bf0; } #BetterX-root.BetterX-light { --xv-panel-bg: rgba(255,255,255,0.99); --xv-text: #0f1419; --xv-border: rgba(0,0,0,0.12); --xv-chip-bg: rgba(0,0,0,0.05); --xv-input-bg: rgba(0,0,0,0.04); --xv-muted: rgba(15,20,25,0.6); --xv-item-bg: rgba(0,0,0,0.02); } #BetterX-badge { background: var(--xv-accent); color: #fff; border: none; border-radius: 999px; padding: 10px 16px; font-size: 13px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 16px rgba(0,0,0,0.35); touch-action: none; user-select: none; } #BetterX-badge:hover { filter: brightness(1.08); } #BetterX-root.BetterX-desktop-badge-hidden:not(.BetterX-mobile) #BetterX-badge { visibility: hidden !important; opacity: 0 !important; pointer-events: none !important; } #BetterX-badge.mobile-mode { width: 52px; height: 52px; padding: 0; border-radius: 50%; font-size: 22px; display: flex; align-items: center; justify-content: center; position: relative; } .BetterX-mobile-icon { width: 42px; height: 42px; border-radius: 50%; object-fit: cover; border: 2px solid rgba(255,255,255,.72); box-shadow: 0 2px 8px rgba(0,0,0,.22); pointer-events: none; user-select: none; -webkit-user-drag: none; } #BetterX-badge.mobile-mode.desktop-icon-mode { width: 64px; height: 64px; } #BetterX-badge.mobile-mode.desktop-icon-mode .BetterX-mobile-icon { width: 54px; height: 54px; } #BetterX-badge.desktop-icon-mode { cursor: grab; } #BetterX-badge.desktop-icon-mode.is-dragging { cursor: grabbing; } #BetterX-badge.desktop-icon-mode .BetterX-mobile-icon-fallback { font-size: 30px; } .BetterX-mobile-icon-fallback { line-height: 1; } #BetterX-root.BetterX-mobile .BetterX-desktop-only-setting { display: none !important; } .BetterX-firefox-only-setting[hidden] { display: none !important; } .BetterX-mobile-only-setting { display: none !important; } #BetterX-root.BetterX-mobile label.BetterX-mobile-only-setting { display: flex !important; } #BetterX-root.BetterX-mobile div.BetterX-mobile-only-setting { display: block !important; } .BetterX-mobile-dot { position: absolute; top: -2px; right: -2px; background: #f4212e; color: #fff; min-width: 18px; height: 18px; border-radius: 999px; font-size: 11px; font-weight: 700; line-height: 18px; text-align: center; padding: 0 4px; } #BetterX-root.BetterX-mobile { left: auto; right: 16px; bottom: 84px; } #BetterX-root.BetterX-mobile #BetterX-badge { opacity: var(--xv-mobile-badge-opacity, 1); transition: opacity 170ms ease-out, filter .15s; } #BetterX-root.BetterX-mobile:not(.BetterX-mobile-badge-collapsed) #BetterX-badge { touch-action: manipulation; } #BetterX-root.BetterX-mobile.BetterX-mobile-badge-collapsed #BetterX-badge { width: 15px; height: 76px; min-height: 76px; padding: 0; border-radius: 999px 0 0 999px; background: #1d9bf0; box-shadow: -1px 2px 8px rgba(0,0,0,.2); opacity: .56 !important; position: relative; z-index: 2; } #BetterX-root.BetterX-mobile.BetterX-mobile-badge-collapsed #BetterX-badge::after { content: '‹'; display: block; color: rgba(255,255,255,.92); font-size: 16px; font-weight: 400; line-height: 1; transform: translateX(-1px); } #BetterX-root.BetterX-mobile.BetterX-mobile-badge-collapsed #BetterX-badge.is-mobile-dragging { opacity: .88 !important; transition: none; cursor: ns-resize; } #BetterX-root.BetterX-mobile.BetterX-mobile-badge-collapsed .BetterX-mobile-icon, #BetterX-root.BetterX-mobile.BetterX-mobile-badge-collapsed .BetterX-mobile-icon-fallback, #BetterX-root.BetterX-mobile.BetterX-mobile-badge-collapsed .BetterX-mobile-dot, #BetterX-root.BetterX-mobile.BetterX-mobile-badge-collapsed #BetterX-download-pill { display: none !important; } #BetterX-root.BetterX-mobile.BetterX-mobile-badge-inactive #BetterX-badge, #BetterX-root.BetterX-mobile.BetterX-mobile-badge-inactive #BetterX-download-pill { pointer-events: none; } article .BetterX-media-grid-box { padding-bottom: 0 !important; height: auto !important; min-height: 0 !important; } article nav.BetterX-media-grid { position: relative !important; inset: auto !important; width: 100% !important; height: auto !important; overflow: visible !important; } article nav.BetterX-media-grid [data-testid="ScrollSnap-prevButtonWrapper"], article nav.BetterX-media-grid [data-testid="ScrollSnap-nextButtonWrapper"] { display: none !important; } article nav.BetterX-media-grid [data-testid="ScrollSnap-SwipeableList"] { width: 100% !important; height: auto !important; overflow: visible !important; } article nav.BetterX-media-grid [data-testid="ScrollSnap-List"] { display: grid !important; width: 100% !important; height: auto !important; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 2px; margin: 0 !important; padding: 0 !important; overflow: hidden !important; border-radius: 16px; scroll-snap-type: none !important; } article nav.BetterX-media-grid-count-2 [data-testid="ScrollSnap-List"] { grid-template-rows: minmax(0, 1fr); aspect-ratio: 16 / 9; } article nav.BetterX-media-grid-count-3 [data-testid="ScrollSnap-List"], article nav.BetterX-media-grid-count-4 [data-testid="ScrollSnap-List"] { grid-template-rows: repeat(2, minmax(0, 1fr)); aspect-ratio: 16 / 9; } article nav.BetterX-media-grid-count-3 [data-testid="ScrollSnap-List"] > [role="presentation"]:first-child { grid-row: span 2; } article nav.BetterX-media-grid [data-testid="ScrollSnap-List"] > [role="presentation"] { display: block !important; width: auto !important; min-width: 0 !important; height: 100% !important; margin: 0 !important; overflow: hidden !important; scroll-snap-align: none !important; } article nav.BetterX-media-grid [data-testid="ScrollSnap-List"] > [role="presentation"] > div, article nav.BetterX-media-grid [data-testid="ScrollSnap-List"] > [role="presentation"] > div > div { width: 100% !important; height: 100% !important; min-height: 0 !important; } article nav.BetterX-media-grid [data-testid="ScrollSnap-List"] > [role="presentation"] > div { aspect-ratio: auto !important; } #BetterX-download-pill { position: absolute; left: calc(100% + 8px); bottom: 0; display: inline-flex; align-items: center; justify-content: center; gap: 6px; min-width: 42px; height: 36px; padding: 0 12px; border: 1px solid rgba(255,255,255,.16); border-radius: 999px; background: var(--xv-panel-bg); color: var(--xv-text); box-shadow: 0 4px 16px rgba(0,0,0,.28); font-size: 12px; font-weight: 700; white-space: nowrap; cursor: pointer; backdrop-filter: blur(10px); } .BetterX-download-pill-icon { font-size: 17px; line-height: 1; } .BetterX-download-pill-label { line-height: 1; } .BetterX-download-pill-count { display: none; } #BetterX-download-pill:hover { border-color: var(--xv-accent); } #BetterX-download-pill.is-progress { border-color: transparent; background: linear-gradient(var(--xv-panel-bg), var(--xv-panel-bg)) padding-box, conic-gradient(var(--xv-accent) var(--xv-download-progress, 0deg), var(--xv-border) 0) border-box; } #BetterX-root.BetterX-panel-right #BetterX-download-pill { left: auto; right: calc(100% + 8px); } #BetterX-download-popover { position: absolute; left: calc(100% + 8px); bottom: 44px; width: min(360px, calc(100vw - 32px)); box-sizing: border-box; max-width: calc(100vw - 16px); max-height: min(420px, calc(100vh - 120px)); overflow-x: hidden; overflow-y: auto; overscroll-behavior: contain; padding: 10px; border: 1px solid var(--xv-border); border-radius: 14px; background: var(--xv-panel-bg); color: var(--xv-text); box-shadow: 0 12px 42px rgba(0,0,0,.42); backdrop-filter: blur(12px); } #BetterX-root.BetterX-panel-right #BetterX-download-popover { left: auto; right: calc(100% + 8px); } #BetterX-download-pill[hidden], #BetterX-download-popover[hidden], .BetterX-dl-cancel[hidden] { display: none !important; } .BetterX-download-popover-title { padding: 2px 4px 8px; font-size: 13px; font-weight: 800; } .BetterX-download-empty { padding: 14px 8px; color: var(--xv-muted); text-align: center; font-size: 12px; } .BetterX-download-task { display: flex; align-items: center; gap: 8px; min-width: 0; padding: 9px 8px; margin-top: 5px; border: 1px solid var(--xv-border); border-radius: 10px; background: linear-gradient(90deg, rgba(29,155,240,.14) var(--xv-task-progress, 0%), transparent 0), var(--xv-item-bg); } .BetterX-download-task-main { display: flex; flex: 1 1 auto; min-width: 0; flex-direction: column; gap: 3px; } .BetterX-download-task-main strong { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 12px; } .BetterX-download-task-main span { min-width: 0; overflow-wrap: anywhere; color: var(--xv-muted); font-size: 11px; } .BetterX-download-task-actions { display: flex; flex: 0 0 auto; gap: 4px; } .BetterX-download-task-actions button { padding: 4px 7px; border: 1px solid var(--xv-border); border-radius: 7px; background: var(--xv-chip-bg); color: var(--xv-text); font-size: 11px; cursor: pointer; } .BetterX-download-task-actions button:hover { border-color: var(--xv-accent); } #BetterX-panel { position: absolute; bottom: calc(100% + 10px); left: 0; width: min(94vw, 480px); max-height: calc(100vh - 96px); background: var(--xv-panel-bg); color: var(--xv-text); border: 1px solid var(--xv-border); border-radius: 16px; box-shadow: 0 12px 48px rgba(0,0,0,0.5); backdrop-filter: blur(12px); display: flex; flex-direction: column; overflow: hidden; } #BetterX-root.BetterX-panel-right #BetterX-panel { left: auto; right: 0; } #BetterX-root.BetterX-mobile #BetterX-panel { position: fixed; right: 12px; left: auto; bottom: 84px; max-height: calc(100vh - 120px); } .BetterX-ad-hidden, .BetterX-nfl-hidden { display: none !important; } .BetterX-adult-spam-hidden { display: none !important; } .BetterX-download-controls { display: inline-flex; align-items: center; justify-content: center; gap: 1px; flex: 0 0 auto; } .BetterX-download-controls.floating { position: absolute; top: 8px; right: 8px; z-index: 5; padding: 2px; border-radius: 999px; background: rgba(0,0,0,.62); } .BetterX-dl-btn, .BetterX-dl-cancel { display: inline-flex; align-items: center; justify-content: center; min-width: 34px; height: 34px; margin: 0; padding: 0 8px; border: none; background: transparent; color: rgb(83,100,113); font-size: 19px; font-weight: 700; line-height: 1; cursor: pointer; border-radius: 999px; transition: background .15s, color .15s, min-width .15s; } .BetterX-download-controls:not([data-download-state="idle"]) .BetterX-dl-btn { font-size: 12px; } .BetterX-dl-btn:hover { background: rgba(29,155,240,0.12); color: rgb(29,155,240); } .BetterX-dl-btn.is-progress { color: rgb(29,155,240); background: conic-gradient(rgba(29,155,240,.24) var(--xv-download-progress, 0deg), transparent 0); } .BetterX-dl-btn.is-downloaded { color: rgb(29,155,240); text-shadow: 0 0 8px rgba(29,155,240,.28); } .BetterX-dl-btn.is-downloaded:hover { color: rgb(29,155,240); background: rgba(29,155,240,.14); } .BetterX-dl-btn.is-downloaded svg { width: 22px; height: 22px; fill: currentColor; } .BetterX-dl-cancel { min-width: 24px; width: 24px; padding: 0; color: rgb(244,33,46); font-size: 17px; } .BetterX-dl-cancel:hover { background: rgba(244,33,46,.12); } .BetterX-download-controls.in-group { align-self: center; } .BetterX-download-controls.guest-actions { min-width: 0; flex: 1 1 0%; align-self: center; } .BetterX-download-controls.guest-actions .BetterX-dl-btn, .BetterX-download-controls.guest-actions .BetterX-dl-cancel { transform: none !important; animation: none !important; } .BetterX-download-controls.floating .BetterX-dl-btn, .BetterX-download-controls.floating .BetterX-dl-cancel { color: #fff; } .BetterX-download-controls.floating .BetterX-dl-btn.is-downloaded { color: rgb(29,155,240); } .BetterX-download-controls.floating .BetterX-dl-btn:hover { background: rgba(29,155,240,.88); } .BetterX-download-controls.floating .BetterX-dl-cancel:hover { background: rgba(244,33,46,.88); } article[data-testid="notification"] .BetterX-download-controls { display: none !important; } .BetterX-mask-hidden { display: none !important; } .BetterX-unlocked.BetterX-native-media-grid { display: grid; gap: 2px; margin: 8px 0; width: 100%; max-width: 100%; border-radius: 16px; overflow: hidden; background: #000; } .BetterX-unlocked .BetterX-unlocked-tile, .BetterX-unlocked .BetterX-unlocked-media { display: block; width: 100%; height: 100%; min-width: 0; min-height: 0; overflow: hidden; } .BetterX-unlocked .BetterX-unlocked-photo { cursor: pointer; } .BetterX-unlocked.xv-n1 { grid-template-columns: 1fr; background: transparent; } .BetterX-unlocked.xv-n1 .BetterX-unlocked-tile { height: auto; background: #000; } .BetterX-unlocked.xv-n1 img, .BetterX-unlocked.xv-n1 video { display: block; margin: 0 auto; width: auto; height: auto; max-width: 100%; max-height: 510px; object-fit: contain; background: #000; } .BetterX-unlocked.xv-multi img, .BetterX-unlocked.xv-multi video { display: block; width: 100%; height: 100%; object-fit: cover; background: #000; } .BetterX-unlocked.xv-n2 { grid-template-columns: 1fr 1fr; grid-template-rows: minmax(0, 1fr); aspect-ratio: 16 / 9; } .BetterX-unlocked.xv-n3 { grid-template-columns: 1fr 1fr; grid-template-rows: repeat(2, minmax(0, 1fr)); aspect-ratio: 16 / 9; } .BetterX-unlocked.xv-n3 > *:first-child { grid-row: span 2; } .BetterX-unlocked.xv-n4 { grid-template-columns: 1fr 1fr; grid-template-rows: repeat(2, minmax(0, 1fr)); aspect-ratio: 16 / 9; } .BetterX-unlocked.xv-nm { grid-template-columns: 1fr 1fr; } .BetterX-unlocked.xv-nm .BetterX-unlocked-tile { aspect-ratio: 1 / 1; } #BetterX-toast { position: fixed; left: 50%; bottom: 90px; transform: translateX(-50%) translateY(10px); background: rgba(21,24,28,0.98); color: #fff; padding: 10px 16px; border-radius: 10px; font-size: 13px; z-index: 2147483600; box-shadow: 0 6px 24px rgba(0,0,0,0.4); opacity: 0; pointer-events: none; transition: opacity .2s, transform .2s; max-width: 80vw; } #BetterX-toast.show { opacity: 1; transform: translateX(-50%) translateY(0); } .BetterX-dialog-overlay { position: fixed; inset: 0; z-index: 2147483646; display: flex; align-items: center; justify-content: center; padding: 18px; background: rgba(0,0,0,.64); backdrop-filter: blur(4px); color: var(--xv-text); } .BetterX-dialog { position: relative; width: min(92vw, 460px); max-height: min(82vh, 640px); overflow: auto; padding: 20px; border: 1px solid var(--xv-border); border-radius: 16px; background: var(--xv-panel-bg); box-shadow: 0 18px 64px rgba(0,0,0,.55); } .BetterX-dialog.has-close-icon .BetterX-dialog-title { padding-right: 38px; } .BetterX-dialog-close { position: absolute; top: 12px; right: 12px; z-index: 1; display: inline-flex; align-items: center; justify-content: center; width: 34px; height: 34px; padding: 0; border: 0; border-radius: 999px; background: transparent; color: var(--xv-muted); cursor: pointer; } .BetterX-dialog-close[hidden] { display: none !important; } .BetterX-dialog-close:hover { background: var(--xv-chip-bg); color: var(--xv-text); } .BetterX-dialog-close:focus-visible { outline: 2px solid var(--xv-accent); outline-offset: 2px; } .BetterX-dialog-close svg { width: 20px; height: 20px; fill: currentColor; } .BetterX-dialog-title { font-size: 18px; line-height: 1.35; font-weight: 800; margin-bottom: 12px; } .BetterX-dialog-body { font-size: 14px; line-height: 1.65; color: var(--xv-text); } .BetterX-dialog-body p { margin: 0 0 10px; } .BetterX-dialog-body ul { margin: 0 0 12px; padding-left: 22px; } .BetterX-dialog-body li { margin: 4px 0; } .BetterX-dialog-body code { padding: 1px 5px; border-radius: 5px; background: var(--xv-chip-bg); font-family: ui-monospace, SFMono-Regular, Consolas, monospace; font-size: .92em; } .BetterX-dialog-actions { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 9px; margin-top: 18px; } .BetterX-dialog-actions .BetterX-btn { min-width: 104px; padding: 9px 14px; font-size: 14px; } .BetterX-screenshot-menu-item { display: flex; align-items: center; gap: 12px; padding: 12px 16px; min-height: 44px; box-sizing: border-box; font: inherit; font-weight: 700; cursor: pointer; } .BetterX-screenshot-menu-item:hover, .BetterX-screenshot-menu-item:focus-visible { background: rgba(127,127,127,.12); outline: none; } .BetterX-screenshot-menu-item svg { width: 20px; height: 20px; fill: currentColor; flex: 0 0 auto; } .BetterX-media-picker-overlay, .BetterX-media-picker-overlay * { box-sizing: border-box; } .BetterX-media-picker { display: flex; flex-direction: column; width: min(92vw, 560px); max-height: 82dvh; overflow: hidden; } .BetterX-media-picker .BetterX-dialog-title { flex: 0 0 auto; } .BetterX-media-picker-toolbar { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 12px; } .BetterX-media-picker-count { color: var(--xv-muted); font-size: 13px; } .BetterX-media-picker-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; overflow: auto; overscroll-behavior: contain; min-height: 0; padding: 3px; } .BetterX-media-picker-item { position: relative; display: flex; flex-direction: column; min-width: 0; cursor: pointer; border: 2px solid var(--xv-border); border-radius: 10px; overflow: hidden; background: var(--xv-chip-bg); } .BetterX-media-picker-item:has(input:checked) { border-color: var(--xv-accent); } .BetterX-media-picker-item:focus-within { outline: 2px solid var(--xv-accent); outline-offset: 1px; } .BetterX-media-picker-item input { position: absolute; top: 7px; right: 7px; z-index: 2; width: 18px; height: 18px; margin: 0; accent-color: var(--xv-accent); cursor: pointer; } .BetterX-media-picker-thumb { position: relative; display: block; aspect-ratio: 1; overflow: hidden; } .BetterX-media-picker-placeholder { position: absolute; inset: 0; display: grid; place-items: center; color: var(--xv-muted); font-size: 12px; } .BetterX-media-picker-thumb img { position: relative; display: block; width: 100%; height: 100%; object-fit: cover; } .BetterX-media-picker-caption { padding: 5px 6px; color: var(--xv-text); font-size: 12px; text-align: center; } .BetterX-media-picker .BetterX-dialog-actions { flex: 0 0 auto; } .BetterX-media-picker button:disabled { opacity: .45; cursor: default; } @media (max-width: 420px) { .BetterX-media-picker { padding: 14px; } .BetterX-media-picker-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); } } .BetterX-language-options { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 9px; } .BetterX-language-option { display: grid; grid-template-columns: 38px minmax(0, 1fr) 18px; align-items: center; gap: 9px; min-height: 48px; padding: 8px 10px; border: 1px solid var(--xv-border); border-radius: 10px; background: var(--xv-chip-bg); color: var(--xv-text); text-align: left; cursor: pointer; } .BetterX-language-option:hover, .BetterX-language-option:focus-visible { border-color: var(--xv-accent); outline: none; } .BetterX-language-option.is-current { border-color: var(--xv-accent); box-shadow: inset 0 0 0 1px var(--xv-accent); } .BetterX-language-code { color: var(--xv-muted); font-size: 11px; font-weight: 800; } .BetterX-language-check { color: var(--xv-accent); font-size: 16px; font-weight: 900; text-align: right; } .BetterX-language-note { margin: 12px 0 0 !important; color: var(--xv-muted); font-size: 12px; } #BetterX-panel * { box-sizing: border-box; } .BetterX-header { display: flex; justify-content: space-between; align-items: flex-start; gap: 8px; padding: 14px 14px 8px; } .BetterX-title-main { font-size: 15px; font-weight: 800; } .BetterX-title-sub { font-size: 11px; color: var(--xv-muted); margin-top: 2px; } .BetterX-header-actions { display: flex; flex-wrap: wrap; gap: 6px; justify-content: flex-end; } .BetterX-tip { padding: 0 14px 8px; font-size: 13px; color: var(--xv-muted); } .BetterX-btn { background: var(--xv-chip-bg); color: var(--xv-text); border: 1px solid var(--xv-border); border-radius: 8px; padding: 5px 10px; font-size: 12px; cursor: pointer; white-space: nowrap; } .BetterX-btn:hover { border-color: var(--xv-accent); } .BetterX-btn.primary { background: var(--xv-accent); color: #fff; border-color: var(--xv-accent); } .BetterX-btn.danger { color: #f4212e; } .BetterX-btn.danger:hover { border-color: #f4212e; } .BetterX-summary { display: flex; flex-wrap: wrap; gap: 6px; padding: 0 14px 10px; } .BetterX-stat { background: var(--xv-chip-bg); border-radius: 8px; padding: 4px 8px; font-size: 11px; color: var(--xv-muted); } .BetterX-stat b { color: var(--xv-text); font-size: 12px; } .BetterX-filter-bar, .BetterX-chip-row { display: flex; flex-wrap: wrap; gap: 6px; padding: 0 14px 10px; } .BetterX-chip-row { padding: 6px 0 0; } .BetterX-chip { background: var(--xv-chip-bg); color: var(--xv-text); border: 1px solid var(--xv-border); border-radius: 999px; padding: 4px 12px; font-size: 12px; cursor: pointer; } .BetterX-chip.active { background: var(--xv-accent); color: #fff; border-color: var(--xv-accent); } .BetterX-controls { padding: 0 14px 10px; display: flex; flex-direction: column; gap: 8px; } .BetterX-row { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; } .BetterX-control-row { align-items: flex-end; } .BetterX-control-row > .BetterX-btn, .BetterX-control-row > .BetterX-field > .BetterX-input { height: 32px; } .BetterX-control-row > .BetterX-field.inline { height: 32px; justify-content: center; align-self: flex-end; } .BetterX-row .BetterX-input { flex: 1 1 120px; } .BetterX-input { background: var(--xv-input-bg); color: var(--xv-text); border: 1px solid var(--xv-border); border-radius: 8px; padding: 7px 10px; font-size: 13px; width: 100%; } .BetterX-input.small { width: 90px; flex: 0 0 auto; } .BetterX-select { background: var(--xv-input-bg); color: var(--xv-text); border: 1px solid var(--xv-border); border-radius: 8px; padding: 6px 8px; font-size: 12px; cursor: pointer; } .BetterX-select option { color: #000; } .BetterX-light .BetterX-select option { color: #0f1419; } .BetterX-advanced { border: 1px solid var(--xv-border); border-radius: 8px; padding: 6px 10px; } .BetterX-advanced > summary { cursor: pointer; font-size: 13px; color: var(--xv-muted); } .BetterX-adv-body { display: flex; flex-direction: column; gap: 8px; padding-top: 8px; } .BetterX-field { display: flex; flex-direction: column; gap: 3px; font-size: 12px; color: var(--xv-muted); } .BetterX-field.inline { flex-direction: row; align-items: center; gap: 6px; } .BetterX-download-zip-option { margin-left: 0; } .BetterX-adv-label { font-size: 12px; color: var(--xv-muted); } .BetterX-content-status { font-size: 11px; color: var(--xv-muted); padding: 5px 8px; border-radius: 7px; background: var(--xv-chip-bg); } .BetterX-list { overflow-y: auto; padding: 4px 14px 14px; display: flex; flex-direction: column; gap: 10px; } .BetterX-empty { padding: 24px 8px; text-align: center; color: var(--xv-muted); font-size: 13px; } .BetterX-loadmore { margin-top: 4px; background: var(--xv-chip-bg); color: var(--xv-text); border: 1px dashed var(--xv-border); border-radius: 8px; padding: 8px; font-size: 12px; cursor: pointer; } .BetterX-item { background: var(--xv-item-bg); border: 1px solid var(--xv-border); border-radius: 12px; padding: 10px 12px; } .BetterX-item.is-flash-lost { border-color: rgba(244,33,46,0.5); } .BetterX-item.is-pinned { border-color: rgba(29,155,240,0.6); } .BetterX-item-top { display: flex; justify-content: space-between; gap: 8px; } .BetterX-author-head { display: flex; align-items: center; gap: 8px; } .BetterX-avatar { width: 28px; height: 28px; border-radius: 50%; object-fit: cover; flex: 0 0 auto; } .BetterX-author-line { font-size: 13px; font-weight: 700; word-break: break-word; line-height: 1.35; } .BetterX-author-profile { color: inherit; text-decoration: none; } .BetterX-author-profile:hover { color: var(--xv-accent); text-decoration: underline; } .BetterX-author-handle { color: var(--xv-muted); font-weight: 400; font-size: 12px; } .BetterX-author-time { color: var(--xv-muted); font-weight: 400; font-size: 12px; white-space: nowrap; } .BetterX-submeta { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 3px; font-size: 10px; color: var(--xv-muted); } .BetterX-actions { display: flex; flex-wrap: wrap; gap: 4px; justify-content: flex-end; align-content: flex-start; } .BetterX-text { margin: 8px 0 4px; font-size: 13px; line-height: 1.5; white-space: pre-wrap; word-break: break-word; } .BetterX-text.collapsed { display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; } .BetterX-expand-btn { background: none; border: none; color: var(--xv-accent); font-size: 12px; cursor: pointer; padding: 0; } .BetterX-hl { background: #ffd400; color: #000; border-radius: 3px; padding: 0 1px; } .BetterX-thumbs { display: flex; flex-wrap: wrap; gap: 6px; margin: 6px 0; } .BetterX-thumb-button { padding: 0; border: 0; border-radius: 8px; background: none; cursor: zoom-in; line-height: 0; } .BetterX-thumb-button:focus-visible { outline: 2px solid var(--xv-accent); outline-offset: 2px; } .BetterX-thumb { display: block; width: 72px; height: 72px; object-fit: cover; border-radius: 8px; border: 1px solid var(--xv-border); transition: transform .16s ease, box-shadow .16s ease; } .BetterX-thumb-button:hover .BetterX-thumb { transform: scale(1.04); box-shadow: 0 3px 12px rgba(0, 0, 0, .28); } .BetterX-image-preview { position: fixed; inset: 0; z-index: 2147483647; display: flex; align-items: center; justify-content: center; box-sizing: border-box; overflow: hidden; overscroll-behavior: contain; touch-action: none; padding: max(16px, env(safe-area-inset-top)) max(16px, env(safe-area-inset-right)) max(16px, env(safe-area-inset-bottom)) max(16px, env(safe-area-inset-left)); background: rgba(0, 0, 0, .86); cursor: zoom-out; } .BetterX-image-preview-box { position: relative; display: flex; align-items: center; justify-content: center; width: 100%; height: 100%; min-width: 0; min-height: 0; overflow: hidden; cursor: default; touch-action: none; user-select: none; } .BetterX-image-preview-box img { display: block; width: auto; height: auto; max-width: 100%; max-height: 100%; object-fit: contain; border-radius: 10px; box-shadow: 0 12px 46px rgba(0, 0, 0, .55); transform: translate3d(0, 0, 0) scale(1); transform-origin: center center; will-change: transform; cursor: zoom-in; touch-action: none; user-select: none; -webkit-user-drag: none; } .BetterX-image-preview-box.is-zoomed img { cursor: grab; } .BetterX-image-preview-box.is-panning img { cursor: grabbing; } .BetterX-image-preview-close { position: fixed; top: max(12px, env(safe-area-inset-top)); right: max(12px, env(safe-area-inset-right)); z-index: 3; display: grid; place-items: center; width: 38px; height: 38px; padding: 0; border: 1px solid rgba(255,255,255,.52); border-radius: 50%; background: rgba(20,20,20,.9); color: #fff; text-align: center; text-indent: 0; cursor: pointer; box-shadow: 0 3px 14px rgba(0,0,0,.38); touch-action: manipulation; } .BetterX-image-preview-close > span { display: block; margin: 0; padding: 0; font: 700 27px/1 Arial, sans-serif; line-height: 1; transform: translateY(-1px); } .BetterX-image-preview-nav { position: fixed; z-index: 2; display: grid; place-items: center; width: 44px; height: 44px; padding: 0; border: 1px solid rgba(255,255,255,.48); border-radius: 50%; background: rgba(20,20,20,.78); color: #fff; text-align: center; text-indent: 0; cursor: pointer; box-shadow: 0 3px 14px rgba(0,0,0,.34); touch-action: manipulation; transition: opacity .14s ease, background .14s ease, transform .14s ease; } .BetterX-image-preview-nav > span { display: block; font: 700 34px/1 Arial, sans-serif; line-height: 1; transform: translateY(-1px); } .BetterX-image-preview-nav:hover:not(:disabled) { background: rgba(20,20,20,.94); transform: scale(1.06); } .BetterX-image-preview-nav:disabled { opacity: .24; cursor: default; } .BetterX-image-preview-nav[hidden] { display: none !important; } @media (hover: none), (pointer: coarse) { .BetterX-image-preview-nav { display: none !important; } } .BetterX-tags { display: flex; flex-wrap: wrap; gap: 4px; margin: 6px 0; } .BetterX-tag { font-size: 10px; padding: 2px 6px; border-radius: 6px; background: var(--xv-chip-bg); color: var(--xv-muted); } .BetterX-tag.fav { background: rgba(255,212,0,0.15); color: #ffd400; } .BetterX-tag.pin { background: rgba(29,155,240,0.15); color: var(--xv-accent); } .BetterX-tag.flash { background: rgba(244,33,46,0.15); color: #f4212e; } .BetterX-tag.opened { background: rgba(0,186,124,0.15); color: #00ba7c; } .BetterX-tag.keyword { background: rgba(255,212,0,0.15); color: #ffd400; } .BetterX-note-area { margin-top: 4px; } .BetterX-note-btn { font-size: 11px; padding: 3px 8px; } .BetterX-note-text { margin-top: 4px; font-size: 12px; color: var(--xv-text); background: var(--xv-chip-bg); border-radius: 6px; padding: 6px 8px; word-break: break-word; } .BetterX-note-input { width: 100%; min-height: 60px; resize: vertical; background: var(--xv-input-bg); color: var(--xv-text); border: 1px solid var(--xv-border); border-radius: 8px; padding: 7px; font-size: 12px; } .BetterX-note-actions { display: flex; gap: 6px; margin-top: 6px; } .BetterX-bottom-meta { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 6px; font-size: 10px; color: var(--xv-muted); } .BetterX-list::-webkit-scrollbar { width: 8px; } .BetterX-list::-webkit-scrollbar-thumb { background: var(--xv-border); border-radius: 8px; } .BetterX-panel-top { flex: 0 0 auto; } .BetterX-list { flex: 1 1 auto; min-height: 120px; } .BetterX-header { padding-bottom: 10px; border-bottom: 1px solid var(--xv-border); } .BetterX-section-label { padding: 8px 14px 2px; font-size: 11px; font-weight: 700; letter-spacing: .03em; color: var(--xv-muted); } .BetterX-controls .BetterX-section-label { padding: 4px 0 0; } .BetterX-controls { border-top: 1px solid var(--xv-border); padding-top: 12px; } .BetterX-menu-wrap { position: relative; display: inline-flex; } .BetterX-icon-btn { padding: 5px 10px; font-weight: 700; line-height: 1; } .BetterX-menu { position: absolute; top: calc(100% + 6px); right: 0; z-index: 30; display: flex; flex-direction: column; gap: 2px; padding: 6px; min-width: 150px; background: var(--xv-panel-bg); border: 1px solid var(--xv-border); border-radius: 12px; box-shadow: 0 10px 32px rgba(0,0,0,0.45); backdrop-filter: blur(12px); } .BetterX-menu[hidden] { display: none; } .BetterX-menu-item { display: flex; align-items: center; gap: 8px; width: 100%; text-align: left; background: transparent; color: var(--xv-text); border: none; border-radius: 8px; padding: 8px 10px; font-size: 13px; cursor: pointer; white-space: nowrap; transition: background .15s; } .BetterX-menu-item:hover { background: var(--xv-chip-bg); } .BetterX-menu-item.danger { color: #f4212e; } .BetterX-menu-item.danger:hover { background: rgba(244,33,46,0.12); } .BetterX-btn { transition: background .15s, border-color .15s, color .15s; } .BetterX-btn:hover { background: var(--xv-chip-bg); } .BetterX-btn.primary:hover { background: var(--xv-accent); filter: brightness(1.08); } .BetterX-chip { transition: background .15s, border-color .15s, color .15s; } .BetterX-input, .BetterX-select, .BetterX-note-input { transition: border-color .15s, box-shadow .15s; } .BetterX-input:focus, .BetterX-select:focus, .BetterX-note-input:focus { outline: none; border-color: var(--xv-accent); box-shadow: 0 0 0 2px rgba(29,155,240,0.25); } .BetterX-item { transition: border-color .15s, background .15s; } .BetterX-item:hover { border-color: rgba(29,155,240,0.5); } .BetterX-advanced { transition: border-color .15s; } .BetterX-advanced[open] { border-color: rgba(29,155,240,0.4); } .BetterX-advanced > summary { list-style: none; display: flex; align-items: center; gap: 6px; font-weight: 600; user-select: none; } .BetterX-advanced > summary::-webkit-details-marker { display: none; } .BetterX-advanced > summary::before { content: '▸'; font-size: 10px; color: var(--xv-muted); transition: transform .15s; } .BetterX-advanced[open] > summary::before { transform: rotate(90deg); } #BetterX-panel { position: fixed; top: 12px; bottom: 12px; width: min(94vw, 520px); height: auto; max-height: none; } #BetterX-root:not(.BetterX-mobile) #BetterX-panel { min-width: min(420px, calc(100vw - 24px)); max-width: calc(100vw - 24px); } .BetterX-panel-resize-handle { position: absolute; top: 0; bottom: 0; width: 7px; z-index: 8; cursor: ew-resize; touch-action: none; user-select: none; } .BetterX-panel-resize-left { left: 0; } .BetterX-panel-resize-right { right: 0; } .BetterX-panel-resize-handle:hover { background: rgba(29,155,240,.25); } #BetterX-root.BetterX-mobile .BetterX-panel-resize-handle { display: none; } .BetterX-header { flex: 0 0 auto; align-items: center; min-height: 58px; padding: 11px 14px; border-bottom: none; background: var(--xv-panel-bg); } .BetterX-title { min-width: 0; } .BetterX-title-main { display: flex; align-items: center; gap: 8px; font-size: 17px; letter-spacing: -.01em; } .BetterX-title-icon { width: 26px; height: 26px; flex: 0 0 26px; border-radius: 7px; object-fit: cover; box-shadow: 0 1px 5px rgba(0,0,0,.28); pointer-events: none; user-select: none; -webkit-user-drag: none; } .BetterX-title-sub { font-size: 11px; } .BetterX-header-actions { flex-wrap: nowrap; align-items: center; } .BetterX-header-actions .BetterX-btn { display: inline-flex; align-items: center; justify-content: center; height: 30px; min-height: 30px; } .BetterX-header-actions .BetterX-icon-btn { width: 30px; padding: 0; } #BetterX-panel.is-settings-view .BetterX-vault-action { display: none; } .BetterX-btn:disabled, .BetterX-input:disabled, .BetterX-select:disabled { cursor: not-allowed; opacity: .48; filter: none; } .BetterX-tabs { flex: 0 0 auto; display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 4px; margin: 0 14px 10px; padding: 3px; border-radius: 11px; background: var(--xv-chip-bg); } .BetterX-tab { display: flex; align-items: center; justify-content: center; min-height: 32px; border: 0; border-radius: 8px; background: transparent; text-align: center; color: var(--xv-muted); font-size: 13px; font-weight: 700; cursor: pointer; transition: background .15s, color .15s, box-shadow .15s; } .BetterX-tab:hover { color: var(--xv-text); } .BetterX-tab.active { color: #fff; background: var(--xv-accent); box-shadow: 0 2px 8px rgba(29,155,240,.22); } .BetterX-view { flex: 1 1 auto; min-height: 0; } .BetterX-view[hidden] { display: none !important; } .BetterX-vault-view { display: flex; flex-direction: column; } .BetterX-notifications-view { display: flex; flex-direction: column; min-height: 0; } .BetterX-notification-toolbar { flex: 0 0 auto; padding: 0 14px 12px; border-bottom: 1px solid var(--xv-border); } .BetterX-notification-search-row { margin: 10px 0 0; gap: 8px; } .BetterX-notification-search-row .BetterX-input { flex: 1 1 240px; min-width: 0; } .BetterX-notification-actions { margin: 8px 0; flex-wrap: wrap; } .BetterX-notification-list { flex: 1 1 auto; min-height: 0; overflow: auto; padding: 10px 14px 18px; } .BetterX-notification-user { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 10px 0; border-bottom: 1px solid var(--xv-border); } .BetterX-notification-user.is-pinned { box-shadow: inset 3px 0 0 var(--xv-accent); padding-left: 8px; } .BetterX-notification-user.is-disabled { opacity: .68; } .BetterX-notification-user.is-disabled.is-pinned { opacity: .82; } .BetterX-notification-pin-mark { font-size: 12px; vertical-align: 1px; } .BetterX-btn.notification-pinned { color: var(--xv-accent); border-color: var(--xv-accent); font-weight: 700; } .BetterX-notification-user-main { display: flex; align-items: center; gap: 9px; min-width: 0; color: var(--xv-text); text-decoration: none; } .BetterX-notification-user-main img, .BetterX-notification-avatar-fallback { width: 38px; height: 38px; flex: 0 0 38px; border-radius: 50%; object-fit: cover; } .BetterX-notification-avatar-fallback { display: grid; place-items: center; background: var(--xv-chip-bg); color: var(--xv-muted); font-weight: 800; } .BetterX-notification-user-main span span, .BetterX-notification-user-main > span { min-width: 0; } .BetterX-notification-user-main b, .BetterX-notification-user-main small { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; } .BetterX-notification-user-main small { color: var(--xv-muted); font-size: 12px; } .BetterX-notification-user-actions { display: flex; justify-content: flex-end; gap: 6px; flex-wrap: wrap; } .BetterX-vault-toolbar { flex: 0 0 auto; border-top: 1px solid var(--xv-border); border-bottom: 1px solid var(--xv-border); background: var(--xv-panel-bg); } .BetterX-tip { margin: 9px 14px 7px; padding: 7px 9px; border-radius: 8px; background: rgba(29,155,240,.08); color: var(--xv-muted); font-size: 12px; line-height: 1.45; } .BetterX-summary { flex-wrap: wrap; overflow-x: visible; padding: 0 14px 8px; } .BetterX-summary::-webkit-scrollbar, .BetterX-filter-bar::-webkit-scrollbar { display: none; } .BetterX-stat { flex: 0 0 auto; border: 1px solid transparent; padding: 4px 8px; font-size: 12px; } .BetterX-stat b { font-size: 13px; } .BetterX-section-label { padding: 2px 14px 5px; font-size: 11px; text-transform: uppercase; } .BetterX-filter-bar { flex-wrap: nowrap; overflow-x: auto; overflow-y: hidden; min-width: 0; width: 100%; scrollbar-width: none; padding: 0 14px 9px; overscroll-behavior-x: contain; -webkit-overflow-scrolling: touch; } .BetterX-filter-bar.is-dragging { cursor: grabbing; user-select: none; } .BetterX-filter-bar.is-dragging .BetterX-chip { pointer-events: none; } .BetterX-chip { flex: 0 0 auto; min-height: 28px; padding: 4px 11px; } .BetterX-search-tools { display: grid; gap: 7px; padding: 0 14px 11px; } .BetterX-search-tools > .BetterX-input { height: 36px; padding-left: 12px; border-radius: 10px; } .BetterX-toolbar-row { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 7px; } .BetterX-toolbar-row .BetterX-select { width: 100%; min-width: 0; height: 32px; border-radius: 9px; font-size: 13px; } .BetterX-sort-hint { min-height: 18px; padding: 0 2px; color: var(--xv-text); font-family: SimHei, "Microsoft YaHei", "Noto Sans CJK SC", sans-serif; font-size: 12px; font-weight: 600; line-height: 1.5; } .BetterX-vault-filter-card { margin: 0 14px 10px; min-width: 0; } .BetterX-vault-filter-card > summary { min-width: 0; max-width: 100%; overflow: hidden; } .BetterX-vault-filter-title { flex: 0 0 auto; } .BetterX-vault-filter-state { flex: 1 1 auto; min-width: 0; max-width: 100%; margin-left: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--xv-muted); font-size: 11px; font-weight: 500; } .BetterX-vault-filter-card .BetterX-adv-body { min-width: 0; } .BetterX-vault-filter-card .BetterX-filter-bar { padding: 0 0 3px; } .BetterX-vault-filter-card .BetterX-search-tools { padding: 0; min-width: 0; } .BetterX-list { flex: 1 1 auto; min-height: 120px; overflow-y: auto; padding: 10px 12px 14px; gap: 8px; overscroll-behavior: contain; } .BetterX-settings-view { display: flex; flex-direction: column; border-top: 1px solid var(--xv-border); } .BetterX-settings-scroll { flex: 1 1 auto; min-height: 0; overflow-y: auto; overscroll-behavior: contain; padding: 12px 14px 18px; scrollbar-color: var(--xv-border) transparent; } .BetterX-settings-intro { display: flex; flex-direction: column; gap: 2px; padding: 0 2px 10px; } .BetterX-settings-intro strong { font-size: 15px; } .BetterX-settings-intro span { color: var(--xv-muted); font-size: 12px; line-height: 1.45; } .BetterX-settings-view .BetterX-controls { gap: 9px; padding: 0; border-top: 0; } .BetterX-settings-card, .BetterX-vault-filter-card { padding: 0; overflow: hidden; border-radius: 12px; background: var(--xv-item-bg); } .BetterX-settings-card > summary, .BetterX-vault-filter-card > summary { min-height: 43px; padding: 0 12px; color: var(--xv-text); font-size: 14px; } .BetterX-settings-card[open], .BetterX-vault-filter-card[open] { border-color: rgba(29,155,240,.34); } .BetterX-settings-card[open] > summary, .BetterX-vault-filter-card[open] > summary { border-bottom: 1px solid var(--xv-border); } .BetterX-settings-card > .BetterX-adv-body, .BetterX-vault-filter-card > .BetterX-adv-body { gap: 10px; padding: 12px; } .BetterX-settings-card .BetterX-field, .BetterX-settings-card .BetterX-adv-label { font-size: 13px; line-height: 1.45; } .BetterX-download-name-tokens { gap: 6px; } .BetterX-download-name-tokens .BetterX-chip { font-family: ui-monospace, SFMono-Regular, Consolas, monospace; color: var(--xv-text); font-weight: 650; } .BetterX-download-name-preview { color: var(--xv-text); font-weight: 650; } .BetterX-download-advanced { width: 100%; box-sizing: border-box; padding: 0; background: var(--xv-input-bg); } .BetterX-download-advanced > summary { min-height: 48px; padding: 6px 10px; } .BetterX-download-advanced[open] > summary { border-bottom: 1px solid var(--xv-border); } .BetterX-download-advanced > .BetterX-adv-body { padding: 10px; } .BetterX-download-advanced-summary { display: flex; flex: 1 1 auto; min-width: 0; flex-direction: column; gap: 1px; } .BetterX-download-advanced-title { color: var(--xv-text); font-size: 13px; } .BetterX-download-advanced-subtitle { color: var(--xv-muted); font-size: 11px; font-weight: 500; line-height: 1.35; } .BetterX-download-advanced-state { flex: 0 0 auto; padding: 2px 6px; border-radius: 999px; background: rgba(29,155,240,.12); color: var(--xv-accent); font-size: 10px; font-weight: 650; } .BetterX-settings-card .BetterX-content-status { font-size: 12px; line-height: 1.4; } .BetterX-dependent-options { display: flex; flex-direction: column; gap: 9px; } .BetterX-dependent-options.is-disabled { opacity: .5; } .BetterX-field.is-disabled { opacity: .5; } .BetterX-adultspam-master-row { flex-wrap: nowrap; justify-content: space-between; } .BetterX-adultspam-master-row > .BetterX-field { flex: 1 1 auto; min-width: 0; } .BetterX-adultspam-master-row > .BetterX-select { flex: 0 0 auto; min-width: 72px; } .BetterX-profile-default-view-row, .BetterX-gif-format-row { flex-wrap: nowrap; justify-content: space-between; } .BetterX-profile-default-view-row > .BetterX-field, .BetterX-gif-format-row > .BetterX-field { flex: 1 1 auto; min-width: 0; } .BetterX-profile-default-view-row > .BetterX-select, .BetterX-gif-format-row > .BetterX-select { flex: 0 0 auto; min-width: 72px; } .BetterX-tag-editor { display: flex; flex-direction: column; gap: 7px; min-width: 0; padding: 8px; border: 1px solid var(--xv-border); border-radius: 10px; background: var(--xv-input-bg); } .BetterX-keyword-tags { display: flex; flex-wrap: wrap; gap: 6px; min-width: 0; } .BetterX-keyword-tags:empty { display: none; } .BetterX-main-keyword-tags { padding: 0 2px; } .BetterX-keyword-section > .BetterX-row { width: 100%; } .BetterX-keyword-tag { display: inline-flex; align-items: center; gap: 5px; max-width: 100%; min-height: 26px; padding: 3px 5px 3px 9px; border: 1px solid rgba(29,155,240,.35); border-radius: 999px; background: rgba(29,155,240,.12); color: var(--xv-text); font-size: 12px; line-height: 1.3; } .BetterX-keyword-tag-label { overflow-wrap: anywhere; } .BetterX-keyword-tag-remove { display: inline-flex; align-items: center; justify-content: center; flex: 0 0 auto; width: 19px; height: 19px; padding: 0; border: 0; border-radius: 50%; background: transparent; color: var(--xv-muted); cursor: pointer; font-size: 17px; line-height: 1; } .BetterX-keyword-tag-remove:hover { background: rgba(244,33,46,.14); color: #f4212e; } .BetterX-tag-editor > .BetterX-input { width: 100%; margin: 0; background: transparent; } .BetterX-settings-view .BetterX-field.inline { position: relative; min-height: 28px; padding-left: 46px; color: var(--xv-text); line-height: 1.35; } .BetterX-settings-view .BetterX-field.inline > input[type="checkbox"] { appearance: none; -webkit-appearance: none; position: absolute; left: 0; top: 50%; width: 38px; height: 22px; margin: 0; border: 1px solid var(--xv-border); border-radius: 999px; background: var(--xv-input-bg); transform: translateY(-50%); cursor: pointer; transition: .16s ease; } .BetterX-settings-view .BetterX-field.inline > input[type="checkbox"]::after { content: ''; position: absolute; left: 2px; top: 2px; width: 16px; height: 16px; border-radius: 50%; background: var(--xv-muted); box-shadow: 0 1px 3px rgba(0,0,0,.35); transition: .16s ease; } .BetterX-settings-view .BetterX-field.inline > input[type="checkbox"]:checked { border-color: var(--xv-accent); background: var(--xv-accent); } .BetterX-settings-view .BetterX-field.inline > input[type="checkbox"]:checked::after { left: 18px; background: #fff; } .BetterX-settings-view .BetterX-field.inline > input[type="checkbox"]:focus-visible { outline: 2px solid rgba(29,155,240,.45); outline-offset: 2px; } .BetterX-settings-view .BetterX-control-row > .BetterX-field.inline { align-self: flex-end; justify-content: center; height: 32px; } .BetterX-item { position: relative; flex: 0 0 auto; padding: 11px 12px; border-radius: 13px; overflow: hidden; } .BetterX-empty, .BetterX-loadmore { flex: 0 0 auto; } .BetterX-item.is-unread::before { content: ''; position: absolute; left: 0; top: 10px; bottom: 10px; width: 3px; border-radius: 0 3px 3px 0; background: var(--xv-accent); } .BetterX-avatar { width: 32px; height: 32px; } .BetterX-author { min-width: 120px; } .BetterX-author-line { font-size: 14px; } .BetterX-submeta, .BetterX-tag, .BetterX-bottom-meta { font-size: 11px; } .BetterX-text { font-size: 14px; line-height: 1.55; } .BetterX-note-btn { font-size: 12px; } .BetterX-item-top { align-items: flex-start; } .BetterX-actions { max-width: 58%; } .BetterX-actions .BetterX-btn { min-height: 28px; padding: 4px 8px; } .BetterX-bottom-meta { padding-top: 7px; border-top: 1px solid var(--xv-border); } @media (max-width: 640px) { #BetterX-root.BetterX-mobile #BetterX-panel { inset: 8px; width: auto; height: calc(100dvh - 16px); max-height: none; border-radius: 18px; } #BetterX-root.BetterX-mobile #BetterX-download-pill { left: auto; right: 0; bottom: calc(100% + 10px); width: 52px; min-width: 52px; height: 52px; padding: 0; overflow: visible; border: 0; background: var(--xv-accent); color: var(--xv-accent); box-shadow: 0 4px 16px rgba(0,0,0,.35); opacity: var(--xv-mobile-badge-opacity, 1); transition: opacity 170ms ease-out, filter .15s; } #BetterX-root.BetterX-mobile #BetterX-download-pill.is-progress { border: 0; background: var(--xv-accent); } #BetterX-root.BetterX-mobile .BetterX-download-pill-icon { display: flex; align-items: center; justify-content: center; width: 40px; height: 40px; border-radius: 50%; background: #fff; color: var(--xv-accent); font-size: 24px; font-weight: 900; box-shadow: 0 1px 5px rgba(0,0,0,.18); } #BetterX-root.BetterX-mobile .BetterX-download-pill-label { display: none; } #BetterX-root.BetterX-mobile .BetterX-download-pill-count { position: absolute; display: block; top: -2px; right: -2px; min-width: 18px; height: 18px; padding: 0 4px; border-radius: 999px; background: #f4212e; color: #fff; font-size: 11px; font-weight: 700; line-height: 18px; text-align: center; } #BetterX-root.BetterX-mobile .BetterX-download-pill-count[hidden] { display: none !important; } #BetterX-root.BetterX-mobile #BetterX-download-popover { position: absolute; left: auto; right: 0; bottom: calc(200% + 20px); width: min(360px, calc(100vw - 16px)); max-width: calc(100vw - 16px); max-height: min(52dvh, 420px); } #BetterX-root.BetterX-mobile.is-open:not(.BetterX-mobile-badge-collapsed) #BetterX-badge, #BetterX-root.BetterX-mobile.is-open #BetterX-download-pill { opacity: 0; pointer-events: none; } .BetterX-header { min-height: 54px; padding: 9px 11px; } .BetterX-title-icon { display: none; } .BetterX-title-sub { display: none; } .BetterX-header-actions { gap: 4px; } .BetterX-header-actions .BetterX-btn { padding: 5px 7px; } .BetterX-tabs { margin: 0 10px 8px; } .BetterX-tip { margin: 7px 10px 6px; } .BetterX-summary, .BetterX-filter-bar { padding-left: 10px; padding-right: 10px; } .BetterX-section-label { padding-left: 10px; padding-right: 10px; } .BetterX-search-tools { padding: 0 10px 9px; } .BetterX-vault-filter-card { margin: 0 10px 8px; } .BetterX-vault-filter-card .BetterX-filter-bar, .BetterX-vault-filter-card .BetterX-search-tools { padding-left: 0; padding-right: 0; } .BetterX-toolbar-row { grid-template-columns: 1fr 1fr; } .BetterX-toolbar-row .BetterX-select:last-child { grid-column: 1 / -1; } .BetterX-list { padding: 8px 9px 12px; } .BetterX-notification-toolbar { padding: 0 10px 10px; } .BetterX-notification-search-row { flex-wrap: nowrap; } .BetterX-notification-search-row .BetterX-btn { flex: 0 0 auto; } .BetterX-notification-list { padding: 8px 10px 14px; } .BetterX-notification-user { align-items: center; flex-direction: row; flex-wrap: wrap; } .BetterX-notification-user-main { width: auto; flex: 1 1 96px; min-width: 0; } .BetterX-notification-user-actions { width: auto; max-width: 100%; flex: 0 1 auto; justify-content: flex-start; } .BetterX-settings-scroll { padding: 10px 10px 16px; } .BetterX-item-top { flex-direction: column; } .BetterX-actions { max-width: none; justify-content: flex-start; } .BetterX-thumb { width: 64px; height: 64px; } .BetterX-image-preview { padding: max(8px, env(safe-area-inset-top)) max(8px, env(safe-area-inset-right)) max(8px, env(safe-area-inset-bottom)) max(8px, env(safe-area-inset-left)); } .BetterX-image-preview-close { top: max(8px, env(safe-area-inset-top)); right: max(8px, env(safe-area-inset-right)); width: 40px; height: 40px; } }`);
}
function startViewObserver() {
  if (state.viewObserver) state.viewObserver.disconnect();
  state.viewedArticleIds = new WeakMap();
  if (typeof IntersectionObserver !== 'function') {
    state.viewObserver = null;
    return;
  }
  state.viewObserver = new IntersectionObserver((entries) => {
    for (const entry of entries) {
      if (!entry.isIntersecting || entry.intersectionRatio < 0.15) continue;
      const article = entry.target;
      const id = state.viewedArticleIds.get(article)
        || extractStatusIdFromUrl(getStatusLink(article));
      if (id) markPostViewed(id);
    }
  }, {
    threshold: [0.15],
  });
}
function startObserver() {
  if (state.observer) state.observer.disconnect();
  if (state.observerCleanup) state.observerCleanup();
  startViewObserver();
  const throttledDisappear = throttle(checkDisappearedPosts, 400);
  const throttledAdultSpamCount = throttle(updateAdultSpamCount, 300);
  const throttledLayoutRefresh = throttle(applyLayoutEnhancements, 250);
  const pendingRoots = new Set();
  let addedRootsTimer = null;
  state.observerCleanup = () => {
    if (addedRootsTimer !== null) clearTimeout(addedRootsTimer);
    addedRootsTimer = null;
    pendingRoots.clear();
  };
  const collectArticlesFromRoot = (root, articles) => {
    if (!root || !root.isConnected || root.closest('#BetterX-root')) return;
    if (root.matches('article')) { articles.add(root); return; }
    const parentArticle = root.closest('article');
    if (parentArticle) { articles.add(parentArticle); return; }
    root.querySelectorAll('article').forEach((article) => articles.add(article));
  };
  const flushPendingRoots = () => {
    const articles = new Set();
    let layoutNeedsFullRefresh = false;
    const deferAutoExpand = state.settings.autoExpandPostText && isPageScrollBusy();
    for (const root of pendingRoots) {
      collectArticlesFromRoot(root, articles);
      if (layoutEnhancementsActive()) {
        applyLayoutDomCleanup(root);
        if (layoutRootAffectsStructure(root)) layoutNeedsFullRefresh = true;
      }
    }
    pendingRoots.clear();
    for (const article of articles) {
      captureArticle(article);
      if (state.settings.mediaDownload) injectDownloadButtons(article);
      if (state.settings.restoreMediaGrid) applyMediaGridLayout(article);
      if (state.settings.bypassAgeRestriction) revealAgeRestricted(article);
      if (state.settings.autoExpandPostText && !deferAutoExpand) expandPostShowMore(article);
    }
    if (deferAutoExpand) schedulePostShowMoreExpansion();
    if (adultSpamFilteringEnabled()) throttledAdultSpamCount();
    if (layoutNeedsFullRefresh) throttledLayoutRefresh();
  };
  const flushAddedRoots = () => {
    if (addedRootsTimer !== null) return;
    addedRootsTimer = setTimeout(() => {
      addedRootsTimer = null;
      flushPendingRoots();
    }, 100);
  };
  state.observer = new MutationObserver((mutations) => {
    let hadRemoval = false;
    const immediateAdultArticles = new Set();
    for (const mutation of mutations) {
      const mutationElement = mutation.target instanceof HTMLElement
        ? mutation.target
        : mutation.target && mutation.target.parentElement;
      let hasTextUpdate = mutation.type === 'characterData';
      if (!hasTextUpdate) {
        for (const node of mutation.addedNodes) {
          if (node && node.nodeType === 3) { hasTextUpdate = true; break; }
        }
      }
      if (hasTextUpdate && mutationElement
          && mutationElement.id !== 'BetterX-root'
          && !mutationElement.closest('#BetterX-root')) {
        pendingRoots.add(mutationElement);
      }
      for (const node of mutation.addedNodes) {
        if (!(node instanceof HTMLElement)) continue;
        if (node.id === 'BetterX-root' || node.closest && node.closest('#BetterX-root')) continue;
        dismissLoggedOutPostObstructions(node);
        if (state.settings.hideAds) sweepStandaloneAds(node);
        if (state.settings.hideNfl) sweepNflEntries(node);
        harvestFollowingControlsFromRoot(node);
        pendingRoots.add(node);
        if (adultSpamFilteringEnabled()) collectArticlesFromRoot(node, immediateAdultArticles);
      }
      if (adultSpamFilteringEnabled() && mutation.addedNodes.length && mutation.target instanceof HTMLElement) {
        collectArticlesFromRoot(mutation.target, immediateAdultArticles);
      }
      if (mutation.removedNodes && mutation.removedNodes.length) {
        hadRemoval = true;
        for (const node of mutation.removedNodes) unobserveArticleViews(node);
      }
    }
    if (immediateAdultArticles.size) {
      const anchors = isPageScrollBusy() ? null : captureAdultSpamScrollAnchors();
      let layoutChanged = false;
      for (const article of immediateAdultArticles) {
        const outcome = {};
        evaluateAndApplyAdultSpam(article, outcome, true);
        if (outcome.changed) layoutChanged = true;
      }
      if (layoutChanged && anchors) stabilizeAdultSpamScroll(anchors);
    }
    if (hadRemoval) {
      throttledDisappear();
      if (adultSpamFilteringEnabled()) throttledAdultSpamCount();
    }
    if (pendingRoots.size) flushAddedRoots();
    if (state.rootEl && state.rootEl.classList.contains('BetterX-mobile')) scheduleMobileBadgeSync();
  });
  state.observer.observe(document.body, { childList: true, subtree: true, characterData: true });
}
function stopCleanupTimer() {
  if (!state.cleanupTimer) return;
  clearInterval(state.cleanupTimer);
  state.cleanupTimer = null;
}
function installCleanupTimer() {
  stopCleanupTimer();
  if (document.hidden) return;
  state.cleanupTimer = setInterval(checkDisappearedPosts, CLEANUP_INTERVAL_MS);
}
function stopNetworkHookTimer() {
  if (!state.networkHookTimer) return;
  clearInterval(state.networkHookTimer);
  state.networkHookTimer = null;
}
function installNetworkHookTimer() {
  stopNetworkHookTimer();
  if (document.hidden) return;
  installNetworkHooks();
  state.networkHookTimer = setInterval(installNetworkHooks, NETWORK_HOOK_CHECK_INTERVAL_MS);
}
function handleVisibilityChange() {
  if (document.hidden) {
    stopCleanupTimer();
    stopNetworkHookTimer();
  }
  else {
    checkDisappearedPosts();
    installCleanupTimer();
    installNetworkHookTimer();
  }
}
async function loadStateFromDb() {
  const savedSettings = await dbGetSetting('settings');
  const mirroredSettings = readSettingsMirror();
  const hasDbSettings = !!(savedSettings && typeof savedSettings === 'object' && !Array.isArray(savedSettings));
  const sourceSettings = hasDbSettings ? savedSettings : mirroredSettings;
  if (sourceSettings && typeof sourceSettings === 'object') {
    const migratedSettings = migrateSettingsDefaults(sourceSettings);
    state.settings = sanitizeSettings(migratedSettings);
    if (!hasDbSettings || Number(sourceSettings.settingsRevision || 0) < DEFAULT_SETTINGS.settingsRevision) {
      await dbPutSetting('settings', state.settings);
    }
    writeSettingsMirror(state.settings);
  } else {
    state.settings = sanitizeSettings(state.settings);
    writeSettingsMirror(state.settings);
  }
  if (IS_FIREFOX) {
    if (firefoxCompatibilityMode === 'compat' || firefoxCompatibilityMode === 'normal') {
      const compatibilityEnabled = firefoxCompatibilityMode === 'compat';
      const needsSync = state.settings.firefoxCompatibility !== compatibilityEnabled
        || !state.settings.firefoxCompatibilityPrompted;
      state.settings.firefoxCompatibility = compatibilityEnabled;
      state.settings.firefoxCompatibilityPrompted = true;
      if (needsSync) {
        const sanitized = sanitizeSettings(state.settings);
        writeSettingsMirror(sanitized);
        await dbPutSetting('settings', sanitized);
      }
    } else if (state.settings.firefoxCompatibilityPrompted) {
      writeFirefoxCompatibilityMode(state.settings.firefoxCompatibility ? 'compat' : 'normal');
    }
  }
  const persistedFollowedHandles = state.settings.knownFollowedHandles || [];
  persistedFollowedHandles.forEach((handle) => followedHandles.add(handle));
  trimFollowedHandlesToMax();
  const earlyNotificationSubscriptions = new Map(notificationSubscriptions);
  notificationSubscriptions.clear();
  for (const item of state.settings.notificationSubscriptions || []) {
    const sanitized = sanitizeNotificationSubscription(item);
    if (sanitized) notificationSubscriptions.set(sanitized.username.toLowerCase(), sanitized);
  }
  for (const [key, item] of earlyNotificationSubscriptions) notificationSubscriptions.set(key, item);
  state.settingsLoaded = true;
  if (earlyNotificationSubscriptions.size) scheduleNotificationSubscriptionsPersist();
  if (followedHandles.size !== persistedFollowedHandles.length) scheduleFollowedHandlesPersist();
  const rawPosts = (await dbGetAllPosts()).filter(Boolean);
  const all = rawPosts.map(sanitizeImportedPost).filter(Boolean)
    .sort((a, b) => (b.lastCapturedAt || 0) - (a.lastCapturedAt || 0));
  if (all.length !== rawPosts.length) debugLog('已忽略', rawPosts.length - all.length, '条无效本地记录');
  state.posts = all;
  rebuildPostIndex();
  await enforceMaxPosts();
}
const layoutScrollPositions = new Map();
let layoutNavigationToken = 0;
function usesExpandedLayout() {
  return !!(state.settings.layoutEnabled && (
    state.settings.layoutFillCenter
    || state.settings.layoutHideLeftbar
    || state.settings.layoutHideSidebar
  ));
}
function getTopVisibleStatusAnchor() {
  const { primary } = getLayoutElements();
  if (!primary) return null;
  const visible = [...primary.querySelectorAll('article[data-testid="tweet"], article')]
    .map((article) => ({ article, rect: article.getBoundingClientRect() }))
    .filter(({ rect }) => rect.width > 0 && rect.height > 0 && rect.bottom > 0 && rect.top < innerHeight)
    .sort((a, b) => a.rect.top - b.rect.top)[0];
  if (!visible) return null;
  const statusId = extractStatusIdFromUrl(getStatusLink(visible.article));
  return statusId ? { statusId: String(statusId), top: visible.rect.top } : null;
}
function rememberLayoutScrollPosition(url) {
  if (!usesExpandedLayout() || !url) return;
  layoutScrollPositions.set(url, {
    y: Math.max(0, window.scrollY || 0),
    anchor: getTopVisibleStatusAnchor(),
  });
  while (layoutScrollPositions.size > 20) {
    layoutScrollPositions.delete(layoutScrollPositions.keys().next().value);
  }
}
function findStatusArticle(statusId) {
  if (!statusId) return null;
  const { primary } = getLayoutElements();
  if (!primary) return null;
  return [...primary.querySelectorAll('article[data-testid="tweet"], article')].find((article) => (
    extractStatusIdFromUrl(getStatusLink(article)) === String(statusId)
  )) || null;
}
function restoreLayoutScrollPosition(saved, restoreState) {
  if (!saved || !usesExpandedLayout()) return;
  if (!restoreState.anchorFound) window.scrollTo(0, saved.y);
  if (!saved.anchor) return;
  const article = findStatusArticle(saved.anchor.statusId);
  if (!article) return;
  const delta = article.getBoundingClientRect().top - saved.anchor.top;
  if (Math.abs(delta) > 1) window.scrollBy(0, delta);
  restoreState.anchorFound = true;
}
function scheduleNavigationRefresh(savedPosition) {
  const token = ++layoutNavigationToken;
  const restoreState = { anchorFound: false };
  [0, 60, 180, 420, 800].forEach((delay, index) => {
    setTimeout(() => {
      if (token !== layoutNavigationToken) return;
      applyLayoutEnhancements();
      if (savedPosition) restoreLayoutScrollPosition(savedPosition, restoreState);
      if (index >= 2) scanArticles(document);
    }, delay);
  });
}
function getConfiguredProfileDefaultView() {
  const settings = state.settingsLoaded ? state.settings : (readSettingsMirror() || DEFAULT_SETTINGS);
  if (settings.profileDefaultViewEnabled === false) return 'posts';
  return PROFILE_DEFAULT_VIEW_OPTIONS.includes(settings.profileDefaultView)
    ? settings.profileDefaultView
    : DEFAULT_SETTINGS.profileDefaultView;
}
function getConfiguredProfilePostSort() {
  const settings = state.settingsLoaded ? state.settings : (readSettingsMirror() || DEFAULT_SETTINGS);
  if (settings.profilePostSortEnabled === false) return 'recent';
  return PROFILE_POST_SORT_OPTIONS.includes(settings.profilePostSort)
    ? settings.profilePostSort
    : DEFAULT_SETTINGS.profilePostSort;
}
function readProfileDefaultViewRedirectGuard() {
  try {
    const raw = sessionStorage.getItem(PROFILE_DEFAULT_VIEW_REDIRECT_GUARD_KEY);
    const guard = raw ? JSON.parse(raw) : null;
    if (!guard || typeof guard !== 'object'
        || !/^[a-z0-9_]{1,15}$/i.test(guard.handle || '')
        || !PROFILE_DEFAULT_VIEW_OPTIONS.includes(guard.view)
        || !Number.isFinite(guard.createdAt)
        || now() - guard.createdAt > PROFILE_DEFAULT_VIEW_REDIRECT_GUARD_MS) {
      if (raw) sessionStorage.removeItem(PROFILE_DEFAULT_VIEW_REDIRECT_GUARD_KEY);
      return null;
    }
    return {
      ...guard,
      sort: PROFILE_POST_SORT_OPTIONS.includes(guard.sort) ? guard.sort : DEFAULT_SETTINGS.profilePostSort,
    };
  } catch (err) { return null; }
}
function armProfileDefaultViewRedirectGuard(handle, view, sort) {
  try {
    sessionStorage.setItem(PROFILE_DEFAULT_VIEW_REDIRECT_GUARD_KEY, JSON.stringify({
      handle: String(handle || '').toLowerCase(), view,
      sort: PROFILE_POST_SORT_OPTIONS.includes(sort) ? sort : DEFAULT_SETTINGS.profilePostSort,
      createdAt: now(),
    }));
  } catch (err) {}
}
function consumeProfileDefaultViewRedirectGuard(handle, view, sort) {
  const guard = readProfileDefaultViewRedirectGuard();
  const normalizedSort = PROFILE_POST_SORT_OPTIONS.includes(sort) ? sort : DEFAULT_SETTINGS.profilePostSort;
  if (!guard || guard.handle !== String(handle || '').toLowerCase()
      || guard.view !== view || guard.sort !== normalizedSort) return false;
  try { sessionStorage.removeItem(PROFILE_DEFAULT_VIEW_REDIRECT_GUARD_KEY); } catch (err) {}
  return true;
}
function getBareProfileHandle(pathname) {
  const normalizedPath = String(pathname == null ? location.pathname : pathname)
    .replace(/^\/+|\/+$/g, '');
  if (!normalizedPath || normalizedPath.includes('/')) return '';
  let handle = '';
  try { handle = decodeURIComponent(normalizedPath); } catch (err) { return ''; }
  if (!/^[a-z0-9_]{1,15}$/i.test(handle)) return '';
  if (PROFILE_ROOT_ROUTE_EXCLUSIONS.has(handle.toLowerCase())) return '';
  return handle;
}
function applyPreferredProfileViewToUrl(targetUrl, handle, view, sort) {
  const isMediaView = view === 'video' || view === 'photo';
  if (isMediaView) targetUrl.pathname = `/${handle}/media`;
  else targetUrl.pathname = view === 'posts' ? `/${handle}` : `/${handle}/${view}`;
  if (view === 'photo') targetUrl.searchParams.set('filter', 'photo');
  else if (isMediaView) targetUrl.searchParams.delete('filter');
  if (!isMediaView && sort === 'popular') targetUrl.searchParams.set('sort', 'popular');
  else targetUrl.searchParams.delete('sort');
  return targetUrl;
}
function getPreferredProfileViewUrl(rawUrl) {
  const view = getConfiguredProfileDefaultView();
  const sort = getConfiguredProfilePostSort();
  if (view === 'posts' && sort === 'recent') return '';
  let targetUrl;
  try { targetUrl = new URL(rawUrl, location.href); } catch (err) { return ''; }
  if (!/^(?:x|twitter)\.com$/i.test(targetUrl.hostname)) return '';
  const handle = getBareProfileHandle(targetUrl.pathname);
  if (!handle) return '';
  applyPreferredProfileViewToUrl(targetUrl, handle, view, sort);
  return targetUrl.href;
}
function navigateToPreferredProfileView(targetUrl, replace) {
  try {
    const method = replace ? 'replaceState' : 'pushState';
    history[method](history.state, '', targetUrl);
    if (document.readyState !== 'loading') {
      const event = typeof PopStateEvent === 'function' ? new PopStateEvent('popstate') : new Event('popstate');
      window.dispatchEvent(event);
    }
    return true;
  } catch (err) {
    try {
      if (replace) location.replace(targetUrl);
      else location.assign(targetUrl);
    } catch (fallbackError) {}
    return false;
  }
}
function isExplicitProfileTabLink(link) {
  return !!(link && (link.getAttribute('role') === 'tab' || link.closest('[role="tab"]')));
}
function isProfileLinkRewriteExcludedTarget(target) {
  return !!(target && target.closest && target.closest(PROFILE_LINK_REWRITE_EXCLUSION_SELECTOR));
}
function armProfileNavigationBypassGuard() {
  try {
    sessionStorage.setItem(
      PROFILE_NAVIGATION_BYPASS_GUARD_KEY,
      String(now() + PROFILE_NAVIGATION_BYPASS_GUARD_MS)
    );
  } catch (err) {}
}
function shouldBypassProfileNavigationRedirect() {
  try {
    const expiresAt = Number(sessionStorage.getItem(PROFILE_NAVIGATION_BYPASS_GUARD_KEY));
    if (Number.isFinite(expiresAt) && expiresAt > now()) return true;
    sessionStorage.removeItem(PROFILE_NAVIGATION_BYPASS_GUARD_KEY);
  } catch (err) {}
  return false;
}
function getSearchResultProfileHandle(resultContainer) {
  if (!resultContainer || !resultContainer.querySelector) return '';
  const avatar = resultContainer.querySelector('[data-testid^="UserAvatar-Container-"]');
  const avatarTestId = avatar ? (avatar.getAttribute('data-testid') || '') : '';
  const avatarMatch = avatarTestId.match(/^UserAvatar-Container-([a-z0-9_]{1,15})$/i);
  if (avatarMatch && !PROFILE_ROOT_ROUTE_EXCLUSIONS.has(avatarMatch[1].toLowerCase())) return avatarMatch[1];
  const handleMatch = String(resultContainer.innerText || resultContainer.textContent || '')
    .match(/(?:^|\s)@([a-z0-9_]{1,15})(?=\s|$)/i);
  return handleMatch && !PROFILE_ROOT_ROUTE_EXCLUSIONS.has(handleMatch[1].toLowerCase())
    ? handleMatch[1]
    : '';
}
function getProfileTargetFromClickTarget(target) {
  if (!target || !target.closest) return null;
  if (isProfileLinkRewriteExcludedTarget(target)) return null;
  const directLink = target.closest('a[href]');
  const directHandle = directLink ? getBareProfileHandle(directLink.pathname) : '';
  if (directHandle) return { link: directLink, handle: directHandle, url: directLink.href };
  const resultContainer = target.closest('[data-testid="UserCell"], [data-testid="typeaheadResult"]');
  if (!resultContainer) return null;
  const interactive = target.closest('button, [role="button"], [role="menuitem"], input, select, textarea');
  const interactiveTestId = interactive ? (interactive.getAttribute('data-testid') || '') : '';
  const isPrimaryResultControl = interactive === resultContainer
    || interactiveTestId === 'UserCell'
    || interactiveTestId === 'TypeaheadUser';
  if (interactive && !isPrimaryResultControl) return null;
  const nestedLink = [...resultContainer.querySelectorAll('a[href]')].find((candidate) => (
    !!getBareProfileHandle(candidate.pathname)
  ));
  if (nestedLink) {
    return { link: nestedLink, handle: getBareProfileHandle(nestedLink.pathname), url: nestedLink.href };
  }
  const handle = getSearchResultProfileHandle(resultContainer);
  return handle
    ? { link: null, handle, url: new URL(`/${handle}`, location.origin).href }
    : null;
}
function redirectBareProfileToPreferredView() {
  const view = getConfiguredProfileDefaultView();
  const sort = getConfiguredProfilePostSort();
  if (view === 'posts' && sort === 'recent') return false;
  const handle = getBareProfileHandle();
  if (!handle) return false;
  if (shouldBypassProfileNavigationRedirect()) return false;
  if (consumeProfileDefaultViewRedirectGuard(handle, view, sort)) return false;
  const targetUrl = new URL(location.href);
  applyPreferredProfileViewToUrl(targetUrl, handle, view, sort);
  if (targetUrl.href === new URL(location.href).href) return false;
  armProfileDefaultViewRedirectGuard(handle, view, sort);
  navigateToPreferredProfileView(targetUrl.href, true);
  return true;
}
function installProfileDefaultViewLinkRewrite() {
  document.addEventListener('click', (event) => {
    if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const target = event.target;
    if (!target || !target.closest) return;
    if (isProfileLinkRewriteExcludedTarget(target)) {
      armProfileNavigationBypassGuard();
      return;
    }
    if (shouldBypassProfileNavigationRedirect()) return;
    const profileTarget = getProfileTargetFromClickTarget(target);
    if (!profileTarget) return;
    const { link, handle } = profileTarget;
    if (link && link.hasAttribute('download')) return;
    const view = getConfiguredProfileDefaultView();
    const sort = getConfiguredProfilePostSort();
    if (handle && (view !== 'posts' || sort !== 'recent') && link && isExplicitProfileTabLink(link)) {
      armProfileDefaultViewRedirectGuard(handle, view, sort);
      return;
    }
    const preferredUrl = getPreferredProfileViewUrl(profileTarget.url);
    if (preferredUrl && (!link || link.href !== preferredUrl)) {
      if (!handle) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      armProfileDefaultViewRedirectGuard(handle, view, sort);
      navigateToPreferredProfileView(preferredUrl, false);
    }
  }, true);
}
function installNavigationListener() {
  let lastUrl = location.href;
  const onNav = (restorePosition) => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      if (redirectBareProfileToPreferredView()) return;
      installNetworkHooks();
      scheduleNavigationRefresh(restorePosition ? layoutScrollPositions.get(lastUrl) : null);
    }
  };
  window.addEventListener('popstate', () => {
    rememberLayoutScrollPosition(lastUrl);
    onNav(true);
  });
  const origPush = history.pushState;
  history.pushState = function (...args) {
    const previousUrl = location.href;
    rememberLayoutScrollPosition(previousUrl);
    const r = origPush.apply(this, args);
    onNav(false);
    return r;
  };
  const origReplace = history.replaceState;
  history.replaceState = function (...args) {
    const previousUrl = location.href;
    rememberLayoutScrollPosition(previousUrl);
    const r = origReplace.apply(this, args);
    onNav(false);
    return r;
  };
}
async function boot() {
  installPageScrollActivityTracking();
  try { installStyles(); } catch (err) { console.error('[BetterX] style init failed:', err); }
  createUI();
  installPostScreenshotMenu();
  document.addEventListener('keydown', handleKeydown, true);
  applyTheme();
  try {
    await openDb();
    await loadStateFromDb();
  } catch (err) {
    console.error('[BetterX] DB init failed:', err);
  }
  installCrossTabSync();
  bumpKeywordCache();
  resetPaging();
  applyTheme();
  repositionBadge();
  refreshUI();
  redirectBareProfileToPreferredView();
  harvestFollowingControlsFromRoot(document);
  startObserver();
  dismissLoggedOutPostObstructions(document);
  scanArticles(document);
  applyAdHiding();
  applyNflHiding();
  applyAdultSpamFiltering();
  applyMediaDownload();
  applyMediaGridLayout();
  applyAgeBypass();
  applyLayoutEnhancements();
  maybeShowAgeBypassEnableNotice();
  installCleanupTimer();
  installNetworkHookTimer();
  document.addEventListener('visibilitychange', handleVisibilityChange);
  installNavigationListener();
  await runAutoClean();
  setTimeout(maybePromptFirefoxCompatibility, 250);
  setTimeout(() => {
    postLimitWarningReady = true;
    maybeShowPostLimitWarning();
  }, 600);
  const throttledReposition = throttle(repositionBadge, 500);
  const throttledLayoutResize = throttle(applyLayoutEnhancements, 250);
  const handleMobileBadgeViewportChange = throttle(scheduleMobileBadgeSync, 80);
  window.addEventListener('resize', throttledReposition);
  window.addEventListener('resize', throttledLayoutResize);
  window.addEventListener('scroll', handleMobileBadgeViewportChange, { passive: true });
  document.addEventListener('scroll', handleMobileBadgeViewportChange, { passive: true, capture: true });
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', handleMobileBadgeViewportChange, { passive: true });
    window.visualViewport.addEventListener('scroll', handleMobileBadgeViewportChange, { passive: true });
  }
  document.addEventListener('click', handleDocumentClick, true);
  if (window.matchMedia) {
    try {
      window.matchMedia('(prefers-color-scheme: light)').addEventListener('change', () => {
        if ((state.settings.theme || 'auto') === 'auto') applyTheme();
      });
    } catch (err) {}
  }
  debugLog('v4.1.0 started');
}
function waitForPageReady() {
  if (document.body) { boot(); return; }
  const timer = setInterval(() => {
    if (document.body) { clearInterval(timer); boot(); }
  }, 100);
}
redirectBareProfileToPreferredView();
installProfileDefaultViewLinkRewrite();
registerMenuCommands();
installNetworkHooks();
waitForPageReady();
})();
