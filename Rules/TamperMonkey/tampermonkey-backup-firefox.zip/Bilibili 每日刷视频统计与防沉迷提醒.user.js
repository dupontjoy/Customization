// ==UserScript==
// @name         Bilibili 每日刷视频统计与防沉迷提醒
// @name:en      Bilibili Daily Watch Counter & Goal Reminder
// @namespace    https://github.com/sankerXD/bilibili-video-counter
// @version      1.6.2
// @description  统计每天在 B 站刷了多少个视频、总观看时长与独立视频数，可设定每日时长目标和连续观看休息提醒，附带数据看板与近 7 天趋势图。所有数据仅存储在浏览器本地，不上传任何服务器。
// @description:en  Tracks how many Bilibili videos you watch each day, plus total watch time and unique video count. Set a daily time goal with break reminders, and review everything in a built-in dashboard with a 7-day chart. All data stays in your browser and is never uploaded.
// @author       sankerXD
// @license      GPL-3.0-or-later
// @icon         https://www.bilibili.com/favicon.ico
// @homepageURL https://github.com/sankerXD/bilibili-video-counter
// @supportURL  https://github.com/sankerXD/bilibili-video-counter/issues
// @match        *://www.bilibili.com/video/*
// @match        *://www.bilibili.com/bangumi/play/*
// @match        *://www.bilibili.com/medialist/play/*
// @match        *://www.bilibili.com/festival/*
// @match        *://www.bilibili.com/blackboard/*
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_registerMenuCommand
// @run-at       document-idle
// @noframes
// @downloadURL https://update.greasyfork.org/scripts/593124/Bilibili%20%E6%AF%8F%E6%97%A5%E5%88%B7%E8%A7%86%E9%A2%91%E7%BB%9F%E8%AE%A1%E4%B8%8E%E9%98%B2%E6%B2%89%E8%BF%B7%E6%8F%90%E9%86%92.user.js
// @updateURL https://update.greasyfork.org/scripts/593124/Bilibili%20%E6%AF%8F%E6%97%A5%E5%88%B7%E8%A7%86%E9%A2%91%E7%BB%9F%E8%AE%A1%E4%B8%8E%E9%98%B2%E6%B2%89%E8%BF%B7%E6%8F%90%E9%86%92.meta.js
// ==/UserScript==

/*
 * Bilibili 每日刷视频统计与时长提醒
 * Copyright (C) 2026 sankerXD
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <https://www.gnu.org/licenses/>.
 */

(function () {
    'use strict';

    // ==========================================
    // 1. 配置项与数据存储
    // ==========================================
    const DEFAULT_CONFIG = {
        minWatchSeconds: 5,             // 有效观看门槛（秒），播放满此时间才计入有效刷过
        showFloatingBadge: true,        // 是否显示悬浮胶囊
        badgePositionMode: 'title',     // 位置模式：'title' (固定在标题栏右侧，随页面滚动) 或 'fixed' (屏幕全局固定悬浮)
        badgePosition: { top: '80px', right: '20px' }, // 屏幕固定模式下的位置
        maxHistoryDays: 30,             // 历史数据保留天数
        dailyGoalMinutes: 60,           // 每日刷视频目标时长（分钟，0为不限制）
        continuousAlertMinutes: 45,     // 连续观看防沉迷提醒（分钟，0为不开启）
        alertSound: true,               // 是否开启提醒提示音
        snoozeMinutes: 15               // 点击“稍后提醒”延后分钟数
    };

    const STORAGE_KEYS = {
        DATA: 'bili_watch_stats_v1',
        CONFIG: 'bili_watch_config_v1'
    };

    // 配置几乎不变，但 getConfig() 在心跳里每秒会被调好几次，
    // 每次都要走一遍 GM_getValue + Object.assign，所以缓存在内存里。
    let configCache = null;

    function readConfigFromStorage() {
        try {
            if (typeof GM_getValue !== 'undefined') {
                return Object.assign({}, DEFAULT_CONFIG, GM_getValue(STORAGE_KEYS.CONFIG, {}));
            }
            const local = localStorage.getItem(STORAGE_KEYS.CONFIG);
            return Object.assign({}, DEFAULT_CONFIG, local ? JSON.parse(local) : {});
        } catch (e) {
            return Object.assign({}, DEFAULT_CONFIG);
        }
    }

    function getConfig() {
        if (!configCache) configCache = readConfigFromStorage();
        return configCache;
    }

    // 配置改动频率极低（只有用户在设置面板里操作时），所以照旧立即落盘
    function saveConfig(cfg) {
        configCache = cfg;
        try {
            if (typeof GM_setValue !== 'undefined') {
                GM_setValue(STORAGE_KEYS.CONFIG, cfg);
            }
            localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(cfg));
        } catch (e) {}
    }

    // ------------------------------------------------------------------
    // 统计数据：内存为准 + 节流落盘
    //
    // 改之前：视频每播放 1 秒就 accumulateWatchTime() 一次，而它一路会触发
    // 3 次全量读（getTodayStats / updateBadgeUI / checkReminders 各读一遍）
    // 加 1 次全量写（JSON.stringify 整个对象 → GM_setValue + localStorage）。
    // videos 数组越攒越大，这个 1Hz 的读写会明显拖慢页面，Safari 上尤其明显
    // （GM_* 在 Safari 版油猴里要过扩展的消息通道）。
    //
    // 改之后：statsCache 是唯一权威副本，读全部走内存；写只打脏标记，
    // 由 flushStats 按 STATS_FLUSH_INTERVAL 节流落盘。低频的关键节点
    // （计入一个视频、触发提醒、清空数据等）仍然立即落盘，另外在页面
    // 隐藏 / 卸载时强制 flush 一次，保证不丢数据。
    // ------------------------------------------------------------------
    const STATS_FLUSH_INTERVAL = 10000; // 秒级累加最多 10 秒落一次盘
    let statsCache = null;
    let statsDirty = false;
    let lastFlushAt = 0;

    function readStatsFromStorage() {
        try {
            if (typeof GM_getValue !== 'undefined') {
                return GM_getValue(STORAGE_KEYS.DATA, {});
            }
            const local = localStorage.getItem(STORAGE_KEYS.DATA);
            return local ? JSON.parse(local) : {};
        } catch (e) {
            return {};
        }
    }

    function getAllStats() {
        if (!statsCache) statsCache = readStatsFromStorage();
        return statsCache;
    }

    function flushStats() {
        if (!statsDirty || !statsCache) return;
        try {
            if (typeof GM_setValue !== 'undefined') {
                GM_setValue(STORAGE_KEYS.DATA, statsCache);
            }
            localStorage.setItem(STORAGE_KEYS.DATA, JSON.stringify(statsCache));
            statsDirty = false;
            lastFlushAt = Date.now();
        } catch (e) {}
    }

    // immediate = true 用于低频关键写入；省略则按 STATS_FLUSH_INTERVAL 节流。
    // 注意 getAllStats() 返回的就是 statsCache 本身，调用方对 todayData 的
    // 修改已经直接落在缓存上了，这里的 data 参数只是保持原有调用形式。
    function saveAllStats(data, immediate) {
        statsCache = data;
        statsDirty = true;
        if (immediate || Date.now() - lastFlushAt >= STATS_FLUSH_INTERVAL) flushStats();
    }

    function getTodayKey() {
        const d = new Date();
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    function getTodayStats() {
        const all = getAllStats();
        const today = getTodayKey();
        if (!all[today]) {
            all[today] = {
                totalCount: 0,         // 总播放/刷过次数
                uniqueCount: 0,        // 独立视频数
                totalWatchSeconds: 0,  // 总观看时长（秒）
                videos: [],            // 视频记录列表: [{ id, title, up, url, watchSeconds, firstTime, lastTime, playTimes, counted }]
                remindedDailyGoal: false, // 是否已触发过今日达标提醒
                lastRemindedTime: 0      // 上次提醒时间戳
            };
        }
        return { todayKey: today, all, todayData: all[today] };
    }

    function cleanExpiredData() {
        const cfg = getConfig();
        const all = getAllStats();
        const keys = Object.keys(all).sort();
        if (keys.length > cfg.maxHistoryDays) {
            const deleteCount = keys.length - cfg.maxHistoryDays;
            for (let i = 0; i < deleteCount; i++) {
                delete all[keys[i]];
            }
            saveAllStats(all, true);
        }
    }

    // ==========================================
    // 2. 音效与提醒系统 (Safari 兼容)
    // ==========================================
    let snoozeUntilTimestamp = 0;
    let sessionContinuousSeconds = 0;

    function playReminderSound() {
        const cfg = getConfig();
        if (!cfg.alertSound) return;
        try {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (!AudioCtx) return;
            const ctx = new AudioCtx();

            const notes = [
                { f: 659.25, start: 0, duration: 0.18 },
                { f: 830.61, start: 0.16, duration: 0.22 },
                { f: 987.77, start: 0.35, duration: 0.45 }
            ];

            notes.forEach(n => {
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(n.f, ctx.currentTime + n.start);

                gain.gain.setValueAtTime(0, ctx.currentTime + n.start);
                gain.gain.linearRampToValueAtTime(0.18, ctx.currentTime + n.start + 0.03);
                gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + n.start + n.duration);

                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start(ctx.currentTime + n.start);
                osc.stop(ctx.currentTime + n.start + n.duration);
            });
        } catch (e) {}
    }

    function showReminderToast(type, currentMinutes, targetMinutes) {
        if (Date.now() < snoozeUntilTimestamp) return;

        playReminderSound();

        const existing = document.getElementById('bili-counter-reminder-toast');
        if (existing) existing.remove();

        const toast = document.createElement('div');
        toast.id = 'bili-counter-reminder-toast';

        let title = '';
        let message = '';

        if (type === 'daily_goal') {
            title = '⏰ 今日刷视频时长达标提醒';
            message = `你今天在 B 站已累计刷视频 <b>${currentMinutes} 分钟</b>，达到设定的 <b>${targetMinutes} 分钟</b> 目标！注意休息眼睛哦~`;
        } else if (type === 'continuous') {
            title = '☕ 连续观看休息提醒';
            message = `你已经连续观看了 <b>${currentMinutes} 分钟</b>，起来喝口水、活动一下身体吧！`;
        }

        toast.innerHTML = `
            <div class="bcrt-icon">🔔</div>
            <div class="bcrt-content">
                <div class="bcrt-title">${title}</div>
                <div class="bcrt-desc">${message}</div>
            </div>
            <div class="bcrt-actions">
                <button class="bcrt-btn bcrt-btn-primary" id="bcrt-btn-ok">我知道啦</button>
                <button class="bcrt-btn bcrt-btn-sub" id="bcrt-btn-snooze">稍后提醒</button>
            </div>
        `;

        document.body.appendChild(toast);
        setTimeout(() => toast.classList.add('active'), 50);

        const dismiss = () => {
            toast.classList.remove('active');
            setTimeout(() => toast.remove(), 400);
        };

        toast.querySelector('#bcrt-btn-ok').addEventListener('click', dismiss);
        toast.querySelector('#bcrt-btn-snooze').addEventListener('click', () => {
            const cfg = getConfig();
            snoozeUntilTimestamp = Date.now() + (cfg.snoozeMinutes || 15) * 60 * 1000;
            dismiss();
        });

        setTimeout(() => {
            if (document.getElementById('bili-counter-reminder-toast') === toast) {
                dismiss();
            }
        }, 15000);
    }

    function checkReminders(totalSeconds) {
        const cfg = getConfig();
        const { todayKey, all, todayData } = getTodayStats();
        const totalMinutes = Math.floor(totalSeconds / 60);

        if (cfg.dailyGoalMinutes > 0 && totalMinutes >= cfg.dailyGoalMinutes) {
            if (!todayData.remindedDailyGoal) {
                todayData.remindedDailyGoal = true;
                todayData.lastRemindedTime = Date.now();
                all[todayKey] = todayData;
                saveAllStats(all, true);
                showReminderToast('daily_goal', totalMinutes, cfg.dailyGoalMinutes);
            }
        }

        if (cfg.continuousAlertMinutes > 0) {
            const continuousMinutes = Math.floor(sessionContinuousSeconds / 60);
            if (continuousMinutes >= cfg.continuousAlertMinutes && continuousMinutes % cfg.continuousAlertMinutes === 0 && sessionContinuousSeconds % 60 === 0) {
                showReminderToast('continuous', continuousMinutes, cfg.continuousAlertMinutes);
            }
        }
    }

    // ==========================================
    // 3. 视频信息提取与监控逻辑
    // ==========================================
    let currentVideoState = {
        id: '',
        title: '',
        up: '',
        url: '',
        watchSeconds: 0,
        counted: false
    };

    function extractVideoInfo() {
        const url = window.location.href;
        let id = '';

        const bvMatch = url.match(/\/video\/(BV[a-zA-Z0-9]+)/i);
        if (bvMatch) {
            id = bvMatch[1];
        } else {
            const epMatch = url.match(/\/(ep\d+|ss\d+)/i);
            if (epMatch) {
                id = epMatch[1];
            } else {
                id = window.location.pathname;
            }
        }

        let title = '';
        const titleEl = document.querySelector('.video-title, .video-info-title .title, .media-info-title-t, h1.title');
        if (titleEl && titleEl.textContent) {
            title = titleEl.textContent.trim();
        } else {
            title = document.title.replace(/_哔哩哔哩_bilibili.*$/, '').trim();
        }

        let up = '';
        const upEl = document.querySelector('.up-name, .username, .up-detail-top .name, .staff-name');
        if (upEl && upEl.textContent) {
            up = upEl.textContent.trim();
        }

        return { id, title: title || '未知视频', up: up || '未知UP主', url };
    }

    function registerVideoInfo(info) {
        if (!info.id) return;
        const { todayKey, all, todayData } = getTodayStats();

        let existingVideo = todayData.videos.find(v => v.id === info.id);
        const nowTimeStr = new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });

        if (!existingVideo) {
            existingVideo = {
                id: info.id,
                title: info.title,
                up: info.up,
                url: info.url,
                watchSeconds: 0,
                firstTime: nowTimeStr,
                lastTime: nowTimeStr,
                playTimes: 0,
                counted: false
            };
            todayData.videos.unshift(existingVideo);
            all[todayKey] = todayData;
            saveAllStats(all, true);
        } else {
            if (info.title && info.title !== '未知视频') existingVideo.title = info.title;
            if (info.up && info.up !== '未知UP主') existingVideo.up = info.up;
            existingVideo.lastTime = nowTimeStr;
            all[todayKey] = todayData;
            saveAllStats(all, true);
        }
    }

    function markCurrentVideoCounted() {
        if (!currentVideoState.id || currentVideoState.counted) return;
        currentVideoState.counted = true;

        const { todayKey, all, todayData } = getTodayStats();
        let existingVideo = todayData.videos.find(v => v.id === currentVideoState.id);
        const nowTimeStr = new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });

        if (!existingVideo) {
            existingVideo = {
                id: currentVideoState.id,
                title: currentVideoState.title,
                up: currentVideoState.up,
                url: currentVideoState.url,
                watchSeconds: currentVideoState.watchSeconds,
                firstTime: nowTimeStr,
                lastTime: nowTimeStr,
                playTimes: 1,
                counted: true
            };
            todayData.videos.unshift(existingVideo);
            todayData.uniqueCount += 1;
            todayData.totalCount += 1;
        } else {
            existingVideo.playTimes = (existingVideo.playTimes || 0) + 1;
            todayData.totalCount += 1;
            if (!existingVideo.counted) {
                existingVideo.counted = true;
                todayData.uniqueCount += 1;
            }
            existingVideo.lastTime = nowTimeStr;
        }

        all[todayKey] = todayData;
        saveAllStats(all, true);
        updateBadgeUI();
    }

    function accumulateWatchTime(seconds = 1) {
        const { todayKey, all, todayData } = getTodayStats();
        todayData.totalWatchSeconds = (todayData.totalWatchSeconds || 0) + seconds;

        if (currentVideoState.id) {
            const v = todayData.videos.find(item => item.id === currentVideoState.id);
            if (v) {
                v.watchSeconds = (v.watchSeconds || 0) + seconds;
            }
        }

        all[todayKey] = todayData;
        saveAllStats(all);
        updateBadgeUI();

        checkReminders(todayData.totalWatchSeconds);
    }

    function onNewVideoDetected() {
        const info = extractVideoInfo();
        if (!info.id) return;

        if (currentVideoState.id === info.id && currentVideoState.title !== '未知视频') {
            return;
        }

        currentVideoState = {
            id: info.id,
            title: info.title,
            up: info.up,
            url: info.url,
            watchSeconds: 0,
            counted: false
        };

        registerVideoInfo(currentVideoState);

        setTimeout(() => {
            const updatedInfo = extractVideoInfo();
            if (currentVideoState.id === updatedInfo.id) {
                currentVideoState.title = updatedInfo.title;
                currentVideoState.up = updatedInfo.up;
                registerVideoInfo(currentVideoState);
            }
        }, 1500);

        const config = getConfig();
        if (config.minWatchSeconds <= 0) {
            markCurrentVideoCounted();
        }

        createOrAttachBadge();
    }

    let tickInterval = null;
    let lastTrackedUrl = location.href;

    function attachVideoListeners() {
        const video = document.querySelector('video');
        if (!video) return;

        video.addEventListener('play', () => {
            onNewVideoDetected();
        });
    }

    function startHeartbeat() {
        if (tickInterval) clearInterval(tickInterval);
        tickInterval = setInterval(() => {
            if (location.href !== lastTrackedUrl) {
                lastTrackedUrl = location.href;
                titleContainerCache = null; // 换视频了，重新找挂载点
                setTimeout(() => {
                    attachVideoListeners();
                    onNewVideoDetected();
                }, 600);
            }

            const video = document.querySelector('video');
            const isVideoActive = video && !video.paused && !video.ended && video.readyState > 2;

            if (isVideoActive) {
                currentVideoState.watchSeconds += 1;
                sessionContinuousSeconds += 1;
                accumulateWatchTime(1);

                const config = getConfig();
                if (!currentVideoState.counted && currentVideoState.watchSeconds >= config.minWatchSeconds) {
                    markCurrentVideoCounted();
                }
            }

            const cfg = getConfig();
            const badge = document.getElementById('bili-counter-badge');
            if (biliHeaderReady && cfg.badgePositionMode === 'title' && badge) {
                const targetContainer = getTitleDetailContainer();
                if (targetContainer && badge.parentElement !== targetContainer) {
                    targetContainer.appendChild(badge);
                }
            }
        }, 1000);
    }

    // ==========================================
    // 4. UI 界面与挂载（完全不影响原生顶栏与布局）
    // ==========================================
    function formatTime(seconds) {
        if (!seconds || seconds <= 0) return '0秒';
        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = seconds % 60;
        if (h > 0) {
            return `${h}小时${m}分`;
        }
        if (m > 0) {
            return `${m}分${s}秒`;
        }
        return `${s}秒`;
    }

    function injectStyles() {
        if (document.getElementById('bili-counter-injected-styles')) return;

        const css = `
            /* 悬浮胶囊基础样式 - 绝不使用任何全局污染选择器 */
            #bili-counter-badge {
                background: linear-gradient(135deg, rgba(255, 102, 153, 0.95), rgba(251, 114, 153, 0.98)) !important;
                color: #ffffff !important;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif !important;
                padding: 4px 12px !important;
                border-radius: 18px !important;
                font-size: 12px !important;
                font-weight: 600 !important;
                cursor: pointer !important;
                user-select: none !important;
                display: inline-flex !important;
                align-items: center !important;
                gap: 5px !important;
                transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.3s ease !important;
                line-height: 1.4 !important;
                white-space: nowrap !important;
                box-sizing: border-box !important;
                height: 26px !important;
            }
            #bili-counter-badge:hover {
                transform: scale(1.04) !important;
                box-shadow: 0 4px 14px rgba(255, 102, 153, 0.45) !important;
            }

            /* 模式 1：自然排列在标题栏/播放量右侧（播放器外面右上方，随页面滚动） */
            #bili-counter-badge.badge-mode-title {
                margin-left: auto !important;
                position: relative !important;
                box-shadow: 0 2px 8px rgba(255, 102, 153, 0.25) !important;
            }

            /* 模式 2：屏幕全局固定悬浮（固定在视口，支持自由拖拽） */
            #bili-counter-badge.badge-mode-fixed {
                position: fixed !important;
                z-index: 999999 !important;
                box-shadow: 0 4px 16px rgba(255, 102, 153, 0.35) !important;
            }

            /* 达标高亮呼吸灯状态 */
            #bili-counter-badge.goal-reached {
                background: linear-gradient(135deg, rgba(255, 122, 69, 0.95), rgba(250, 84, 28, 0.95)) !important;
                box-shadow: 0 4px 16px rgba(250, 84, 28, 0.4) !important;
                animation: bc-pulse 2s infinite ease-in-out !important;
            }
            @keyframes bc-pulse {
                0%, 100% { transform: scale(1); }
                50% { transform: scale(1.04); }
            }

            #bili-counter-badge .badge-icon {
                font-size: 14px !important;
            }
            #bili-counter-badge .badge-goal-tag {
                background: rgba(0,0,0,0.18) !important;
                padding: 1px 6px !important;
                border-radius: 10px !important;
                font-size: 11px !important;
                margin-left: 2px !important;
            }

            /* 时长达标提醒 Toast */
            #bili-counter-reminder-toast {
                position: fixed !important;
                top: 70px !important;
                left: 50% !important;
                transform: translate(-50%, -30px) scale(0.95) !important;
                background: #ffffff !important;
                border-radius: 14px !important;
                box-shadow: 0 12px 36px rgba(0, 0, 0, 0.22) !important;
                border: 1px solid rgba(251, 114, 153, 0.3) !important;
                padding: 14px 20px !important;
                display: flex !important;
                align-items: center !important;
                gap: 14px !important;
                z-index: 1000001 !important;
                opacity: 0 !important;
                visibility: hidden !important;
                transition: all 0.35s cubic-bezier(0.34, 1.56, 0.64, 1) !important;
                max-width: 520px !important;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", sans-serif !important;
            }
            #bili-counter-reminder-toast.active {
                opacity: 1 !important;
                visibility: visible !important;
                transform: translate(-50%, 0) scale(1) !important;
            }
            .bcrt-icon {
                font-size: 28px !important;
                flex-shrink: 0 !important;
            }
            .bcrt-content {
                flex: 1 !important;
            }
            .bcrt-title {
                font-size: 15px !important;
                font-weight: 700 !important;
                color: #18191c !important;
                margin-bottom: 3px !important;
            }
            .bcrt-desc {
                font-size: 13px !important;
                color: #61666d !important;
                line-height: 1.4 !important;
            }
            .bcrt-desc b {
                color: #fb7299 !important;
            }
            .bcrt-actions {
                display: flex !important;
                flex-direction: column !important;
                gap: 6px !important;
                flex-shrink: 0 !important;
            }
            .bcrt-btn {
                padding: 6px 12px !important;
                border-radius: 6px !important;
                font-size: 12px !important;
                font-weight: 600 !important;
                cursor: pointer !important;
                border: none !important;
                transition: all 0.2s !important;
                white-space: nowrap !important;
            }
            .bcrt-btn-primary {
                background: #fb7299 !important;
                color: #fff !important;
            }
            .bcrt-btn-primary:hover {
                background: #ff5c8a !important;
            }
            .bcrt-btn-sub {
                background: #f1f2f3 !important;
                color: #61666d !important;
            }
            .bcrt-btn-sub:hover {
                background: #e3e5e7 !important;
            }

            /* 弹窗遮罩与主体 */
            #bili-counter-modal-mask {
                position: fixed !important;
                inset: 0 !important;
                background: rgba(0, 0, 0, 0.6) !important;
                -webkit-backdrop-filter: blur(5px) !important;
                backdrop-filter: blur(5px) !important;
                z-index: 1000000 !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                opacity: 0 !important;
                visibility: hidden !important;
                pointer-events: none !important;
                transition: opacity 0.25s ease, visibility 0.25s !important;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif !important;
            }
            #bili-counter-modal-mask.active {
                opacity: 1 !important;
                visibility: visible !important;
                pointer-events: auto !important;
            }
            #bili-counter-modal {
                background: #ffffff !important;
                width: 680px !important;
                max-width: 90vw !important;
                max-height: 85vh !important;
                border-radius: 16px !important;
                box-shadow: 0 20px 40px rgba(0,0,0,0.25) !important;
                display: flex !important;
                flex-direction: column !important;
                overflow: hidden !important;
                transform: translateY(20px) scale(0.96) !important;
                transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1) !important;
            }
            #bili-counter-modal-mask.active #bili-counter-modal {
                transform: translateY(0) scale(1) !important;
            }

            /* 头部 */
            .bcm-header {
                padding: 16px 22px !important;
                background: linear-gradient(135deg, #fb7299, #ff5c8a) !important;
                color: #ffffff !important;
                display: flex !important;
                justify-content: space-between !important;
                align-items: center !important;
            }
            .bcm-header h2 {
                margin: 0 !important;
                font-size: 17px !important;
                font-weight: 700 !important;
                display: flex !important;
                align-items: center !important;
                gap: 8px !important;
                color: #fff !important;
            }
            .bcm-close-btn {
                background: rgba(255,255,255,0.2) !important;
                border: none !important;
                color: #fff !important;
                width: 28px !important;
                height: 28px !important;
                border-radius: 50 !important;
                border-radius: 50% !important;
                font-size: 16px !important;
                cursor: pointer !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                transition: background 0.2s !important;
            }
            .bcm-close-btn:hover {
                background: rgba(255,255,255,0.35) !important;
            }

            /* Tab 导航 */
            .bcm-nav {
                display: flex !important;
                background: #f6f7f8 !important;
                border-bottom: 1px solid #e3e5e7 !important;
                padding: 0 16px !important;
            }
            .bcm-tab {
                padding: 12px 18px !important;
                font-size: 14px !important;
                color: #61666d !important;
                cursor: pointer !important;
                border-bottom: 2px solid transparent !important;
                font-weight: 500 !important;
                transition: all 0.2s !important;
            }
            .bcm-tab:hover {
                color: #fb7299 !important;
            }
            .bcm-tab.active {
                color: #fb7299 !important;
                border-bottom-color: #fb7299 !important;
                font-weight: 600 !important;
            }

            /* 页面内容区 */
            .bcm-body {
                padding: 20px !important;
                overflow-y: auto !important;
                flex: 1 !important;
                background: #fdfdfd !important;
            }

            /* 目标进度卡片 */
            .bcm-goal-box {
                background: #fff0f5 !important;
                border: 1px solid #fed2e2 !important;
                border-radius: 12px !important;
                padding: 14px 16px !important;
                margin-bottom: 16px !important;
                display: flex !important;
                flex-direction: column !important;
                gap: 8px !important;
            }
            .bcm-goal-header {
                display: flex !important;
                justify-content: space-between !important;
                align-items: center !important;
                font-size: 13px !important;
                font-weight: 600 !important;
                color: #18191c !important;
            }
            .bcm-goal-track {
                height: 10px !important;
                background: #fedce7 !important;
                border-radius: 5px !important;
                overflow: hidden !important;
            }
            .bcm-goal-bar {
                height: 100 !important;
                height: 100% !important;
                background: linear-gradient(90deg, #ff85ad, #fb7299) !important;
                border-radius: 5px !important;
                transition: width 0.5s ease !important;
            }
            .bcm-goal-bar.reached {
                background: linear-gradient(90deg, #ff7a45, #fa541c) !important;
            }

            /* 核心指标卡片 */
            .bcm-kpi-grid {
                display: grid !important;
                grid-template-columns: repeat(3, 1fr) !important;
                gap: 14px !important;
                margin-bottom: 20px !important;
            }
            .bcm-kpi-card {
                background: #ffffff !important;
                border: 1px solid #f1f2f3 !important;
                padding: 14px 16px !important;
                border-radius: 12px !important;
                box-shadow: 0 2px 8px rgba(0,0,0,0.03) !important;
                display: flex !important;
                flex-direction: column !important;
                gap: 4px !important;
            }
            .bcm-kpi-title {
                font-size: 12px !important;
                color: #9499a0 !important;
            }
            .bcm-kpi-val {
                font-size: 22px !important;
                font-weight: 700 !important;
                color: #18191c !important;
            }
            .bcm-kpi-val span {
                font-size: 13px !important;
                font-weight: 400 !important;
                margin-left: 4px !important;
                color: #61666d !important;
            }

            /* 列表 */
            .bcm-list-header {
                font-size: 14px !important;
                font-weight: 600 !important;
                color: #18191c !important;
                margin-bottom: 10px !important;
                display: flex !important;
                justify-content: space-between !important;
                align-items: center !important;
            }
            .bcm-video-list {
                display: flex !important;
                flex-direction: column !important;
                gap: 8px !important;
                max-height: 300px !important;
                overflow-y: auto !important;
                padding-right: 4px !important;
            }
            .bcm-video-item {
                display: flex !important;
                align-items: center !important;
                justify-content: space-between !important;
                padding: 10px 14px !important;
                background: #ffffff !important;
                border: 1px solid #f1f2f3 !important;
                border-radius: 8px !important;
                transition: background 0.15s !important;
            }
            .bcm-video-item:hover {
                background: #f6f7f8 !important;
            }
            .bcm-video-info {
                flex: 1 !important;
                min-width: 0 !important;
                margin-right: 12px !important;
            }
            .bcm-video-title {
                font-size: 13px !important;
                color: #18191c !important;
                text-decoration: none !important;
                display: block !important;
                overflow: hidden !important;
                text-overflow: ellipsis !important;
                white-space: nowrap !important;
                font-weight: 500 !important;
            }
            .bcm-video-title:hover {
                color: #00aeec !important;
            }
            .bcm-video-sub {
                font-size: 12px !important;
                color: #9499a0 !important;
                margin-top: 3px !important;
                display: flex !important;
                gap: 12px !important;
            }
            .bcm-video-tag {
                background: #e3f5fb !important;
                color: #00aeec !important;
                padding: 2px 8px !important;
                border-radius: 4px !important;
                font-size: 12px !important;
                white-space: nowrap !important;
            }

            /* 图表区 */
            .bcm-chart-container {
                display: flex !important;
                align-items: flex-end !important;
                gap: 12px !important;
                height: 160px !important;
                padding: 20px 10px 10px !important;
                background: #fff !important;
                border: 1px solid #f1f2f3 !important;
                border-radius: 12px !important;
                margin-bottom: 20px !important;
            }
            .bcm-chart-col {
                flex: 1 !important;
                display: flex !important;
                flex-direction: column !important;
                align-items: center !important;
                height: 100% !important;
                justify-content: flex-end !important;
                gap: 6px !important;
            }
            .bcm-bar-wrapper {
                width: 100% !important;
                max-width: 28px !important;
                height: 100px !important;
                background: #f1f2f3 !important;
                border-radius: 6px 6px 0 0 !important;
                display: flex !important;
                align-items: flex-end !important;
                overflow: hidden !important;
            }
            .bcm-bar-fill {
                width: 100% !important;
                background: linear-gradient(180deg, #ff6699, #fb7299) !important;
                border-radius: 6px 6px 0 0 !important;
                transition: height 0.4s ease !important;
            }
            .bcm-chart-date {
                font-size: 11px !important;
                color: #9499a0 !important;
            }
            .bcm-chart-count {
                font-size: 12px !important;
                font-weight: 600 !important;
                color: #18191c !important;
            }

            /* 表单与设置 */
            .bcm-setting-item {
                display: flex !important;
                justify-content: space-between !important;
                align-items: center !important;
                padding: 14px 0 !important;
                border-bottom: 1px solid #f1f2f3 !important;
            }
            .bcm-setting-label {
                font-size: 14px !important;
                color: #18191c !important;
                font-weight: 500 !important;
            }
            .bcm-setting-desc {
                font-size: 12px !important;
                color: #9499a0 !important;
                margin-top: 2px !important;
            }
            .bcm-input-num {
                width: 75px !important;
                padding: 6px 10px !important;
                border: 1px solid #ccd0d7 !important;
                border-radius: 6px !important;
                font-size: 13px !important;
                text-align: center !important;
            }
            .bcm-select {
                padding: 6px 10px !important;
                border: 1px solid #ccd0d7 !important;
                border-radius: 6px !important;
                font-size: 13px !important;
                background: #fff !important;
                color: #18191c !important;
                cursor: pointer !important;
            }
            .bcm-btn {
                padding: 7px 16px !important;
                border-radius: 6px !important;
                border: none !important;
                cursor: pointer !important;
                font-size: 13px !important;
                font-weight: 500 !important;
                transition: all 0.2s !important;
            }
            .bcm-btn-primary {
                background: #fb7299 !important;
                color: #fff !important;
            }
            .bcm-btn-primary:hover {
                background: #ff5c8a !important;
            }
            .bcm-btn-sub {
                background: #f1f2f3 !important;
                color: #61666d !important;
            }
            .bcm-btn-sub:hover {
                background: #e3e5e7 !important;
            }
            .bcm-btn-danger {
                background: #fef0f0 !important;
                color: #f56c6c !important;
                border: 1px solid #fde2e2 !important;
            }
            .bcm-btn-danger:hover {
                background: #f56c6c !important;
                color: #fff !important;
            }
        `;

        const styleEl = document.createElement('style');
        styleEl.id = 'bili-counter-injected-styles';
        styleEl.textContent = css;
        (document.head || document.documentElement).appendChild(styleEl);
    }

    // 查找标题栏信息行（播放量、弹幕、发布时间那一行，自带 flex 布局）
    // 心跳每秒都会调它，命中缓存就不用再跑 7 次 querySelector；
    // 元素被 Vue 换掉（isConnected 变 false）或 SPA 切视频时自动失效。
    let titleContainerCache = null;

    function getTitleDetailContainer() {
        if (titleContainerCache && titleContainerCache.isConnected) return titleContainerCache;
        const candidates = [
            document.querySelector('#viewbox_report .video-info-detail-list'),
            document.querySelector('.video-info-v1 .video-info-detail-list'),
            document.querySelector('#viewbox_report .video-data'),
            document.querySelector('.video-info-container .video-info-detail-list'),
            document.querySelector('.media-info-header .media-info-title'),
            document.getElementById('viewbox_report'),
            document.querySelector('.video-info-v1')
        ];
        for (const el of candidates) {
            if (el && el.isConnected) {
                titleContainerCache = el;
                return el;
            }
        }
        titleContainerCache = null;
        return null;
    }

    // ------------------------------------------------------------------
    // 挂载时机闸门（顶栏消失 bug 的修复点）
    //
    // B 站视频页是 Vue 2 SSR + 客户端 hydration。如果在 hydration 完成前就把徽章
    // 塞进 .video-info-detail-list 这类 Vue 托管容器，会造成 hydration 失配，
    // Vue 丢弃服务端树、整棵重建，于是顶栏组件的 mounted() 被执行**第二次**。
    // 而 B 站那个 mounted() 是这么写的（video.js 里）：
    //
    //     await this.getScript('//s1.hdslb.com/bfs/seed/laputa-header/bili-header.umd.js')
    //     new BiliHeader({ config }).init(document.getElementById('biliMainHeader'))
    //
    //     getScript(t) { var e = document.createElement('script'); e.src = t;
    //                    document.body.appendChild(e); ... }      // ← 完全没有去重
    //
    // 结果 bili-header.umd.js 被插入两次、init() 跑两次，第二次撞上 Vue3 的
    // "There is already an app instance mounted on the host container"，
    // 把已经渲染好的顶栏整个清空，只剩下 min-height:64px 的空白条——
    // 表现就是「最顶上的 logo / 导航 / 搜索框全不见了」。
    //
    // 所以：必须等 B 站顶栏那个 Vue3 app 真正挂载完成之后，再去动页面 DOM。
    // data-v-app 是 Vue3 createApp().mount() 打上的标记；注意不能用
    // .bili-header__bar 当信号——B 站 Vue2 模板里本来就有一个同名的静态占位符，
    // 页面刚开始几十毫秒它就存在了，等于没等。
    // ------------------------------------------------------------------
    let biliHeaderReady = false;
    let badgeMountDeferred = false;
    const readyWaiters = [];

    function whenBiliHeaderReady(cb) {
        if (biliHeaderReady) { cb(); return; }
        readyWaiters.push(cb);
        if (readyWaiters.length > 1) return; // 轮询只启动一次

        const startedAt = Date.now();
        const flush = () => {
            biliHeaderReady = true;
            readyWaiters.splice(0).forEach(fn => { try { fn(); } catch (e) {} });
        };

        (function poll() {
            const host = document.getElementById('biliMainHeader');
            const elapsed = Date.now() - startedAt;

            if (host && host.hasAttribute('data-v-app') && host.querySelector('.bili-header__bar')) {
                setTimeout(flush, 300); // 留一点余量给顶栏内部的收尾渲染
                return;
            }
            // 番剧 / 活动页等没有 laputa 顶栏容器，等页面 load 完就可以挂了
            if (!host && document.readyState === 'complete' && elapsed > 3000) { flush(); return; }
            if (elapsed > 20000) { flush(); return; } // 兜底，绝不把徽章永久卡住

            setTimeout(poll, 120);
        })();
    }

    // 创建或挂载悬浮胶囊
    function createOrAttachBadge() {
        if (!biliHeaderReady) {
            if (!badgeMountDeferred) {
                badgeMountDeferred = true;
                whenBiliHeaderReady(() => { badgeMountDeferred = false; createOrAttachBadge(); });
            }
            return;
        }
        const cfg = getConfig();
        let badge = document.getElementById('bili-counter-badge');
        if (!badge) {
            badge = document.createElement('div');
            badge.id = 'bili-counter-badge';
            badge.title = '点击查看每日刷视频统计看板';

            badge.addEventListener('click', () => {
                if (!badge._isDragging) {
                    openModal();
                }
            });

            // 拖拽逻辑（仅在 fixed 模式下生效）
            let isDragging = false;
            let startX, startY, origTop, origRight;

            badge.addEventListener('mousedown', (e) => {
                const currentCfg = getConfig();
                if (currentCfg.badgePositionMode !== 'fixed') return;

                isDragging = false;
                badge._isDragging = false;
                startX = e.clientX;
                startY = e.clientY;
                const rect = badge.getBoundingClientRect();
                origTop = rect.top;
                origRight = window.innerWidth - rect.right;

                function onMouseMove(moveEvent) {
                    const dx = moveEvent.clientX - startX;
                    const dy = moveEvent.clientY - startY;
                    if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
                        isDragging = true;
                        badge._isDragging = true;
                    }
                    badge.style.top = `${Math.max(10, Math.min(window.innerHeight - 50, origTop + dy))}px`;
                    badge.style.right = `${Math.max(10, Math.min(window.innerWidth - 150, origRight - dx))}px`;
                }

                function onMouseUp() {
                    document.removeEventListener('mousemove', onMouseMove);
                    document.removeEventListener('mouseup', onMouseUp);
                    if (isDragging) {
                        const updatedCfg = getConfig();
                        updatedCfg.badgePosition = { top: badge.style.top, right: badge.style.right };
                        saveConfig(updatedCfg);
                    }
                    setTimeout(() => { badge._isDragging = false; }, 50);
                }

                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });
        }

        // 根据配置设置模式与挂载目标
        if (cfg.badgePositionMode === 'title') {
            badge.className = 'badge-mode-title';
            badge.style.top = '';
            badge.style.right = '';
            const targetContainer = getTitleDetailContainer();
            if (targetContainer) {
                if (badge.parentElement !== targetContainer) {
                    targetContainer.appendChild(badge);
                }
            } else {
                if (!badge.parentElement) document.body.appendChild(badge);
            }
        } else {
            badge.className = 'badge-mode-fixed';
            if (cfg.badgePosition) {
                badge.style.top = cfg.badgePosition.top;
                badge.style.right = cfg.badgePosition.right;
            }
            if (badge.parentElement !== document.body) {
                document.body.appendChild(badge);
            }
        }

        if (!cfg.showFloatingBadge) {
            badge.style.display = 'none';
        } else {
            badge.style.display = 'inline-flex';
        }

        updateBadgeUI();
    }

    // 结构只建一次，之后每秒只改文本节点。
    // 原来是每秒 badge.innerHTML = `...`，等于每秒解析一遍 HTML、
    // 销毁重建 3 个元素，纯属浪费。
    function buildBadgeParts(badge) {
        badge.textContent = '';

        const icon = document.createElement('span');
        icon.className = 'badge-icon';
        icon.textContent = '📺';

        const main = document.createElement('span');
        const lead = document.createTextNode('今日已刷 ');
        const count = document.createElement('b');
        const tail = document.createTextNode('');
        main.appendChild(lead);
        main.appendChild(count);
        main.appendChild(tail);

        const goal = document.createElement('span');
        goal.className = 'badge-goal-tag';

        badge.appendChild(icon);
        badge.appendChild(main);
        badge.appendChild(goal);

        badge._parts = { count, tail, goal };
        return badge._parts;
    }

    function updateBadgeUI() {
        const badge = document.getElementById('bili-counter-badge');
        if (!badge) return;
        const cfg = getConfig();
        const { todayData } = getTodayStats();
        const durationStr = formatTime(todayData.totalWatchSeconds);
        const currentMins = Math.floor(todayData.totalWatchSeconds / 60);

        let goalText = '';
        let isReached = false;
        if (cfg.dailyGoalMinutes > 0) {
            isReached = currentMins >= cfg.dailyGoalMinutes;
            goalText = isReached
                ? `已达标 ⏰ ${currentMins}/${cfg.dailyGoalMinutes}分`
                : `${currentMins}/${cfg.dailyGoalMinutes}分`;
        }

        // 文案没变就完全不碰 DOM（暂停、重复调用时会命中）
        const signature = `${todayData.totalCount}|${durationStr}|${goalText}`;
        if (badge._sig === signature) return;
        badge._sig = signature;

        const parts = badge._parts && badge._parts.count.isConnected
            ? badge._parts
            : buildBadgeParts(badge);

        parts.count.textContent = String(todayData.totalCount);
        parts.tail.nodeValue = ` 个 (${durationStr})`;

        if (goalText) {
            parts.goal.textContent = goalText;
            parts.goal.style.display = '';
        } else {
            parts.goal.style.display = 'none';
        }

        badge.classList.toggle('goal-reached', isReached);
    }

    // 统计看板弹窗
    let currentTab = 'today';

    function openModal() {
        let mask = document.getElementById('bili-counter-modal-mask');
        if (!mask) {
            mask = document.createElement('div');
            mask.id = 'bili-counter-modal-mask';
            mask.innerHTML = `
                <div id="bili-counter-modal">
                    <div class="bcm-header">
                        <h2>📊 Bilibili 刷视频统计看板</h2>
                        <button class="bcm-close-btn" id="bcm-close-btn">✕</button>
                    </div>
                    <div class="bcm-nav">
                        <div class="bcm-tab active" data-tab="today">今日概览</div>
                        <div class="bcm-tab" data-tab="history">历史趋势 (近7天)</div>
                        <div class="bcm-tab" data-tab="settings">设置与提醒</div>
                    </div>
                    <div class="bcm-body" id="bcm-body-content"></div>
                </div>
            `;
            document.body.appendChild(mask);

            mask.querySelector('#bcm-close-btn').addEventListener('click', closeModal);
            mask.addEventListener('click', (e) => {
                if (e.target === mask) closeModal();
            });

            mask.querySelectorAll('.bcm-tab').forEach(tab => {
                tab.addEventListener('click', () => {
                    mask.querySelectorAll('.bcm-tab').forEach(t => t.classList.remove('active'));
                    tab.classList.add('active');
                    currentTab = tab.dataset.tab;
                    renderModalTab(currentTab);
                });
            });
        }

        renderModalTab(currentTab);
        mask.classList.add('active');
    }

    function closeModal() {
        const mask = document.getElementById('bili-counter-modal-mask');
        if (!mask) return;
        mask.classList.remove('active');
        // 关闭后把整屏遮罩从 DOM 里彻底移除，不给浏览器留下任何常驻的整屏 fixed 合成层，
        // 避免它影响 B 站自己的 position:fixed 顶栏。下次打开时 openModal() 会重新创建。
        setTimeout(() => {
            if (mask.isConnected && !mask.classList.contains('active')) {
                mask.remove();
            }
        }, 300);
    }

    function renderModalTab(tab) {
        const container = document.getElementById('bcm-body-content');
        if (!container) return;

        if (tab === 'today') {
            const cfg = getConfig();
            const { todayData, todayKey } = getTodayStats();
            const currentMins = Math.floor(todayData.totalWatchSeconds / 60);

            let goalBoxHtml = '';
            if (cfg.dailyGoalMinutes > 0) {
                const percent = Math.min(100, Math.round((currentMins / cfg.dailyGoalMinutes) * 100));
                const isReached = currentMins >= cfg.dailyGoalMinutes;
                goalBoxHtml = `
                    <div class="bcm-goal-box">
                        <div class="bcm-goal-header">
                            <span>🎯 今日时长目标进度: ${currentMins} / ${cfg.dailyGoalMinutes} 分钟 (${percent}%)</span>
                            <span style="color: ${isReached ? '#fa541c' : '#fb7299'};">${isReached ? '🎉 已达标！注意休息' : '正在进行中'}</span>
                        </div>
                        <div class="bcm-goal-track">
                            <div class="bcm-goal-bar ${isReached ? 'reached' : ''}" style="width: ${percent}%;"></div>
                        </div>
                    </div>
                `;
            }

            let videosHtml = '';
            if (todayData.videos && todayData.videos.length > 0) {
                videosHtml = todayData.videos.map(v => `
                    <div class="bcm-video-item">
                        <div class="bcm-video-info">
                            <a class="bcm-video-title" href="${v.url}" target="_blank" title="${v.title}">${v.title}</a>
                            <div class="bcm-video-sub">
                                <span>👤 UP: ${v.up}</span>
                                <span>⏱ 观看: ${formatTime(v.watchSeconds)}</span>
                                <span>🕒 时间: ${v.firstTime || v.lastTime}</span>
                            </div>
                        </div>
                        <span class="bcm-video-tag">${v.playTimes > 1 ? `观看 ${v.playTimes} 次` : '已刷过'}</span>
                    </div>
                `).join('');
            } else {
                videosHtml = '<div style="text-align:center; color:#9499a0; padding:30px 0;">今天还没有刷过视频哦，快去看看感兴趣的视频吧~</div>';
            }

            container.innerHTML = `
                ${goalBoxHtml}
                <div class="bcm-kpi-grid">
                    <div class="bcm-kpi-card">
                        <span class="bcm-kpi-title">今日刷视频总数</span>
                        <span class="bcm-kpi-val">${todayData.totalCount} <span>个</span></span>
                    </div>
                    <div class="bcm-kpi-card">
                        <span class="bcm-kpi-title">独立不同视频</span>
                        <span class="bcm-kpi-val">${todayData.uniqueCount} <span>个</span></span>
                    </div>
                    <div class="bcm-kpi-card">
                        <span class="bcm-kpi-title">今日累计时长</span>
                        <span class="bcm-kpi-val">${formatTime(todayData.totalWatchSeconds)}</span>
                    </div>
                </div>

                <div class="bcm-list-header">
                    <span>📋 今日刷过清单 (${todayData.videos.length})</span>
                    <span style="font-size:12px; color:#9499a0;">日期: ${todayKey}</span>
                </div>
                <div class="bcm-video-list">
                    ${videosHtml}
                </div>
            `;
        } else if (tab === 'history') {
            const all = getAllStats();
            const days = [];
            for (let i = 6; i >= 0; i--) {
                const d = new Date();
                d.setDate(d.getDate() - i);
                const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
                const label = `${d.getMonth() + 1}/${d.getDate()}`;
                const stat = all[k] || { totalCount: 0, totalWatchSeconds: 0 };
                days.push({ key: k, label, count: stat.totalCount, duration: stat.totalWatchSeconds });
            }

            const maxCount = Math.max(1, ...days.map(d => d.count));

            const chartCols = days.map(d => {
                const heightPercent = Math.min(100, Math.round((d.count / maxCount) * 100));
                return `
                    <div class="bcm-chart-col">
                        <span class="bcm-chart-count">${d.count > 0 ? d.count : ''}</span>
                        <div class="bcm-bar-wrapper">
                            <div class="bcm-bar-fill" style="height: ${heightPercent}%;"></div>
                        </div>
                        <span class="bcm-chart-date">${d.label}</span>
                    </div>
                `;
            }).join('');

            const total7DaysCount = days.reduce((sum, d) => sum + d.count, 0);
            const total7DaysTime = days.reduce((sum, d) => sum + d.duration, 0);

            container.innerHTML = `
                <div class="bcm-kpi-grid" style="grid-template-columns: 1fr 1fr; margin-bottom:15px;">
                    <div class="bcm-kpi-card">
                        <span class="bcm-kpi-title">近7天刷视频总量</span>
                        <span class="bcm-kpi-val">${total7DaysCount} <span>个</span></span>
                    </div>
                    <div class="bcm-kpi-card">
                        <span class="bcm-kpi-title">近7天总耗时</span>
                        <span class="bcm-kpi-val">${formatTime(total7DaysTime)}</span>
                    </div>
                </div>

                <div class="bcm-list-header">
                    <span>📈 近7天每日刷视频柱状图</span>
                </div>
                <div class="bcm-chart-container">
                    ${chartCols}
                </div>
            `;
        } else if (tab === 'settings') {
            const cfg = getConfig();
            container.innerHTML = `
                <div class="bcm-setting-item">
                    <div>
                        <div class="bcm-setting-label">📍 悬浮胶囊显示位置</div>
                        <div class="bcm-setting-desc">选择固定在视频标题栏右侧（随页面滚动，推荐）或屏幕全局固定悬浮</div>
                    </div>
                    <select id="setting-badge-mode" class="bcm-select">
                        <option value="title" ${cfg.badgePositionMode === 'title' ? 'selected' : ''}>固定在视频标题栏右侧（播放器外右上角，随页面滚动，推荐）</option>
                        <option value="fixed" ${cfg.badgePositionMode === 'fixed' ? 'selected' : ''}>屏幕全局固定悬浮（固定在视口，支持自由拖拽）</option>
                    </select>
                </div>

                <div class="bcm-setting-item">
                    <div>
                        <div class="bcm-setting-label">🎯 每日刷视频目标时长（分钟）</div>
                        <div class="bcm-setting-desc">当天累计观看达到此时间时，弹出提醒弹窗并播放提示音（设为0则关闭提醒）</div>
                    </div>
                    <input type="number" id="setting-goal-min" class="bcm-input-num" min="0" max="600" step="5" value="${cfg.dailyGoalMinutes}">
                </div>

                <div class="bcm-setting-item">
                    <div>
                        <div class="bcm-setting-label">☕ 连续观看防沉迷提醒（分钟）</div>
                        <div class="bcm-setting-desc">单次连续播放达到此时间时提醒休息眼睛（设为0则关闭）</div>
                    </div>
                    <input type="number" id="setting-continuous-min" class="bcm-input-num" min="0" max="180" step="5" value="${cfg.continuousAlertMinutes}">
                </div>

                <div class="bcm-setting-item">
                    <div>
                        <div class="bcm-setting-label">🔔 提醒提示音效</div>
                        <div class="bcm-setting-desc">时长达标或连续观看提醒时播放清脆提示音</div>
                    </div>
                    <div style="display:flex; align-items:center; gap:10px;">
                        <button class="bcm-btn bcm-btn-sub" id="btn-test-sound">试听音效</button>
                        <input type="checkbox" id="setting-alert-sound" ${cfg.alertSound ? 'checked' : ''} style="width:18px; height:18px; cursor:pointer;">
                    </div>
                </div>

                <div class="bcm-setting-item">
                    <div>
                        <div class="bcm-setting-label">⏱ 有效观看判定门槛（秒）</div>
                        <div class="bcm-setting-desc">当播放时间达到此秒数时才算作刷过该视频（防止误触点开立马划走）</div>
                    </div>
                    <input type="number" id="setting-min-sec" class="bcm-input-num" min="0" max="120" value="${cfg.minWatchSeconds}">
                </div>

                <div class="bcm-setting-item">
                    <div>
                        <div class="bcm-setting-label">显示悬浮胶囊</div>
                        <div class="bcm-setting-desc">在视频页面显示小巧的计数与目标进度悬浮球</div>
                    </div>
                    <input type="checkbox" id="setting-show-badge" ${cfg.showFloatingBadge ? 'checked' : ''} style="width:18px; height:18px; cursor:pointer;">
                </div>

                <div class="bcm-setting-item">
                    <div>
                        <div class="bcm-setting-label">数据备份与导出</div>
                        <div class="bcm-setting-desc">导出本地存储的所有刷视频历史记录为 JSON 文件</div>
                    </div>
                    <button class="bcm-btn bcm-btn-primary" id="btn-export-data">导出数据</button>
                </div>

                <div class="bcm-setting-item">
                    <div>
                        <div class="bcm-setting-label">清空历史统计</div>
                        <div class="bcm-setting-desc" style="color:#f56c6c;">将永久删除本地所有已记录的历史统计数据</div>
                    </div>
                    <button class="bcm-btn bcm-btn-danger" id="btn-clear-data">清空所有数据</button>
                </div>
            `;

            const modeSelect = container.querySelector('#setting-badge-mode');
            modeSelect.addEventListener('change', () => {
                const c = getConfig();
                c.badgePositionMode = modeSelect.value;
                saveConfig(c);
                createOrAttachBadge();
            });

            const goalMinInput = container.querySelector('#setting-goal-min');
            goalMinInput.addEventListener('change', () => {
                const val = parseInt(goalMinInput.value, 10);
                const c = getConfig();
                c.dailyGoalMinutes = isNaN(val) ? 0 : Math.max(0, val);
                saveConfig(c);
                updateBadgeUI();
            });

            const continuousMinInput = container.querySelector('#setting-continuous-min');
            continuousMinInput.addEventListener('change', () => {
                const val = parseInt(continuousMinInput.value, 10);
                const c = getConfig();
                c.continuousAlertMinutes = isNaN(val) ? 0 : Math.max(0, val);
                saveConfig(c);
            });

            const alertSoundInput = container.querySelector('#setting-alert-sound');
            alertSoundInput.addEventListener('change', () => {
                const c = getConfig();
                c.alertSound = alertSoundInput.checked;
                saveConfig(c);
            });

            container.querySelector('#btn-test-sound').addEventListener('click', () => {
                playReminderSound();
            });

            const minSecInput = container.querySelector('#setting-min-sec');
            minSecInput.addEventListener('change', () => {
                const val = parseInt(minSecInput.value, 10);
                const c = getConfig();
                c.minWatchSeconds = isNaN(val) ? 5 : Math.max(0, val);
                saveConfig(c);
            });

            const showBadgeInput = container.querySelector('#setting-show-badge');
            showBadgeInput.addEventListener('change', () => {
                const c = getConfig();
                c.showFloatingBadge = showBadgeInput.checked;
                saveConfig(c);
                createOrAttachBadge();
            });

            container.querySelector('#btn-export-data').addEventListener('click', () => {
                const all = getAllStats();
                const blob = new Blob([JSON.stringify(all, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `bilibili_watch_stats_${getTodayKey()}.json`;
                a.click();
                URL.revokeObjectURL(url);
            });

            container.querySelector('#btn-clear-data').addEventListener('click', () => {
                if (confirm('确定要清空所有的刷视频统计数据吗？此操作无法撤销。')) {
                    saveAllStats({}, true);
                    updateBadgeUI();
                    renderModalTab('settings');
                    alert('已清空所有统计数据！');
                }
            });
        }
    }

    // ==========================================
    // 5. 注册油猴菜单与初始化
    // ==========================================
    function initTampermonkeyMenu() {
        if (typeof GM_registerMenuCommand !== 'undefined') {
            GM_registerMenuCommand('📊 查看今日刷视频统计看板', () => {
                openModal();
            });
            GM_registerMenuCommand('🎯 设置刷视频目标与提醒', () => {
                openModal();
                const mask = document.getElementById('bili-counter-modal-mask');
                if (mask) {
                    const tab = mask.querySelector('.bcm-tab[data-tab="settings"]');
                    if (tab) tab.click();
                }
            });
        }
    }

    function init() {
        // 节流落盘的代价是最多可能有 STATS_FLUSH_INTERVAL 的数据悬在内存里，
        // 所以在页面离开视野 / 卸载时兜底 flush 一次。
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'hidden') flushStats();
        });
        window.addEventListener('pagehide', flushStats);
        window.addEventListener('beforeunload', flushStats);

        injectStyles();
        cleanExpiredData();
        createOrAttachBadge();
        startHeartbeat();
        initTampermonkeyMenu();

        setTimeout(() => {
            attachVideoListeners();
            onNewVideoDetected();
        }, 1000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
